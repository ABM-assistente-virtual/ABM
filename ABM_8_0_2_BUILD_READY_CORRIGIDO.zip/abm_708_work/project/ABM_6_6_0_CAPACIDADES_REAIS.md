# ABM 6.6.0 — Integração de visão e execução Android

## Alteração efetiva nesta versão
- A atividade de câmara acessível passa a executar, em paralelo, deteção facial (pose da cabeça/olhos) e deteção/classificação de objetos com ML Kit em modo STREAM.
- Mantém a análise limitada à sessão visível da câmara acessível; não há gravação contínua oculta.
- Mantém o encaminhamento de comandos por voz/texto existente: abertura de aplicações instaladas por nome, abertura do marcador para chamadas e compositor SMS para revisão e envio manual.
- Mantém os controlos globais permitidos pelo AccessibilityService, quando o utilizador ativa explicitamente o serviço nas definições.

## Limites não resolvidos
- O Android não permite a uma aplicação comum controlar tudo nem ignorar permissões, bloqueio, confirmações ou políticas de outras aplicações.
- Chamadas/SMS continuam a exigir confirmação humana na interface oficial.
- Deteção facial não identifica a identidade de uma pessoa; deteção de objetos é classificação visual básica, não compreensão humana.
- Rastreamento ocular/head pose depende de câmara frontal, iluminação, posição e calibração; não substitui controlo ocular especializado.
- O serviço foreground não garante execução eterna: Android/OEM pode interromper processos e o utilizador pode parar o serviço.
- Cloud exige URL de backend HTTPS real, contas, chaves/segredos configurados e deploy. Nenhum servidor foi provisionado nesta entrega.
- Android OS independente exige AOSP, device tree, kernel/vendor blobs, bootloader desbloqueável, assinatura e testes específicos do dispositivo. Não é uma função que se acrescente a um APK.

## Compatibilidade
O projeto mantém minSdk 26 (Android 8.0), logo Android 8.1 é elegível em termos de API. Compatibilidade efetiva depende do fabricante, RAM, câmera, Google Play Services/ML Kit e compilação.

## Verificação
Foram executadas verificações estáticas e compilação de sintaxe Python. Não foi possível compilar APK nesta execução: requer Android SDK/Gradle e resolução das dependências Android. Não houve teste físico no OPPO A3S.
