# ABM 7.0.10

## Implementado nesta etapa
- Base de conhecimento (`UniversalKnowledgeEngine`): os campos subject/relation/object/source podem ser guardados no Android Keystore AES-256-GCM; migração dos registos antigos; pesquisa/consulta por descodificação em memória; eliminação de chaves ao apagar por origem.
- Controlo de dispositivo: detalhes dos tickets protegidos pelo Keystore, migração de detalhes antigos e remoção da chave ao cancelar.
- Integração: o adaptador `ABMSecureStore` é passado a ambos os módulos durante a inicialização Android.
- Auditoria: passa a reportar os estados de proteção de conhecimento e controlo de dispositivo e identifica com clareza os dados ainda não abrangidos.
- Compatibilidade: migração da tabela de conhecimento antiga, removendo a restrição UNIQUE incompatível com valores-marcador cifrados.

## Limites
- Os testes de cifragem desta etapa usam adaptador simulado; não comprovam o Android Keystore num aparelho físico.
- Companion profile/brain state e metadados restantes ainda precisam de auditoria/cifragem.
- APK não compilado neste ambiente; telefone OPPO A3S não testado; cloud não implantada; AOSP não compilado.
