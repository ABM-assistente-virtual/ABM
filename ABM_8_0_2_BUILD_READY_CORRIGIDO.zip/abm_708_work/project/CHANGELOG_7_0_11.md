# ABM 7.0.11

## Proteção do estado central
- O estado JSON do companheiro, incluindo perfil, contexto de atividade, consentimento e ação pendente, passa a ser cifrado através do adaptador Android Keystore quando este é fornecido.
- O snapshot neuronal (`*.brain.json`) passa a ser guardado no mesmo armazenamento protegido.
- O estado de permissões, objetivos e tarefas pendentes dos módulos passa a usar o armazenamento protegido.
- Ficheiros legados em JSON simples são migrados para o Keystore durante a inicialização, quando possível.
- Os ficheiros persistentes ficam com um marcador, e o conteúdo cifrado permanece no `ABMSecureStore`.
- Se o segredo não estiver disponível, a leitura falha fechada; não há fallback silencioso para texto simples.
- O modo desktop/teste sem adaptador continua a usar JSON local simples e é explicitamente distinto do modo Android.

## Verificação
- Testes unitários de escrita, leitura, migração, falha fechada e modo desktop.
- Teste de ciclo de vida do estado do companheiro e snapshot neuronal usando adaptador simulado.
- A validação com o Android Keystore físico ainda requer execução no dispositivo.
