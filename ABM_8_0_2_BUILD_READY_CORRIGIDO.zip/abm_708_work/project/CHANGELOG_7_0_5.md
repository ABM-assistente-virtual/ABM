# ABM 7.0.5 — alterações desta revisão

## Implementado
- A Activity Android passa a instância `ABMSecureStore` para o núcleo Python durante a inicialização.
- `LocalMemoryStore` aceita um adaptador seguro e grava o conteúdo das memórias no Android Keystore através de AES-256-GCM; o SQLite conserva metadados e um marcador, não o conteúdo em texto simples.
- Migração automática dos registos legados de `abm_memory.sqlite3` para o Keystore quando a aplicação Android inicializa com o adaptador disponível.
- Eliminação de segredos associados quando uma memória é apagada ou toda a memória é limpa.
- Falha fechada: se a chave/segredo protegido não puder ser recuperado, o conteúdo original não é exposto.
- Testes comportamentais para cifragem, migração, eliminação e falha de recuperação.
- Diagnóstico atualizado para distinguir a memória protegida das outras bases SQLite que ainda não estão cifradas.
- Versão Android atualizada para `7.0.5` / `versionCode 35`.

## Validação executada
- `python -m compileall -q app/src/main/python`: aprovado.
- `python -m pytest -q`: 119 aprovados.
- `python tools/test_final_release.py`: 35/35 verificações estáticas aprovadas.
- `python tools/validate_project.py`: aprovado.
- `PYTHONPATH=cloud python -m pytest -q cloud/tests`: 25 aprovados.
- `python tools/test_memory_keystore_5_0.py`: 4 testes comportamentais com adaptador simulado aprovados.

## Limites desta revisão
- Os testes do adaptador Keystore são testes de contrato com adaptador simulado; não substituem teste no Android real.
- Apenas o conteúdo do `abm_memory.sqlite3` foi ligado ao Keystore nesta revisão. Outras bases SQLite (incluindo memória contextual, aprendizagem e histórico de execução) continuam sem cifragem integral.
- APK não compilado neste ambiente: Android SDK, `sdkmanager` e Gradle não estão instalados.
- Cloud de produção, OPPO A3S e AOSP continuam sem validação externa/física.
