# ABM 7.0.6 — alterações desta revisão

- Contextual Memory agora aceita o adaptador Android Keystore AES-256-GCM.
- Tema e conteúdo das memórias contextuais são guardados cifrados; SQLite mantém apenas marcadores e metadados.
- Dados contextuais antigos são migrados automaticamente para o Keystore na inicialização Android.
- Adaptive Learning cifra exemplos de feedback e valores de preferências com o mesmo adaptador.
- Exemplos e preferências antigos são migrados automaticamente; exclusão/limpeza remove as respetivas chaves.
- A auditoria distingue os três repositórios com campos protegidos dos restantes bancos ainda não cifrados.
- Adicionados quatro testes com adaptador simulado. Estes não substituem testes no Android Keystore real.
- Android `versionName 7.0.6`, `versionCode 36`.

## Limites conhecidos

O histórico de execução, workflows, recuperação, estado JSON do companheiro e outros metadados SQLite ainda não estão integralmente cifrados. APK não compilado neste ambiente; sem validação física em OPPO A3S, sem cloud publicada e sem AOSP/firmware.
