# ABM 7.0.8 — proteção de histórico e workflows + perfil de avatar

## Implementado nesta revisão

- Histórico de execução agora aceita o adaptador Android Keystore AES-256-GCM.
- Argumentos consentidos, detalhes do adaptador e resultados-alvo são guardados cifrados; SQLite conserva marcadores e metadados operacionais.
- Migração automática dos campos antigos do histórico quando o Keystore é disponibilizado.
- Atualizações posteriores do estado preservam argumentos previamente guardados com consentimento.
- Workflows protegem metadados e resumos de resultados com o Keystore; migração dos registos antigos.
- O `abm_android.initialize` injeta o adaptador Android nas memórias, histórico de execução, workflows, recuperação e interação.
- Eventos de recuperação protegem detalhes e migram registos antigos.
- Entradas multimodais guardam conteúdo e origem cifrados; a chave de deduplicação fica em hash, sem conteúdo legível no SQLite.
- Diagnóstico atualizado para distinguir os repositórios protegidos dos repositórios ainda pendentes.
- Interface Android oferece cinco aparências selecionáveis e persistentes; a personalidade fica fixa em “Consciência Digital”, independentemente da aparência.
- Versão Android: `versionName 7.0.8`, `versionCode 38`.

## Testes executados no ambiente de desenvolvimento

- 132 testes automatizados Python: passaram.
- 47 verificações estáticas de release: passaram.
- 9 testes novos de histórico, workflows, recuperação e interação cifrados: passaram com adaptador simulado.
- Compilação sintática Python: passou.

## Limites ainda não resolvidos

- O seletor de cinco aparências é funcional, mas o avatar 3D final, a animação facial e a semelhança com uma fotografia ainda não estão implementados.
- Outros repositórios locais (conhecimento, controlo do dispositivo, estado JSON do companheiro e metadados) ainda precisam de auditoria/cifragem.
- O adaptador simulado não substitui teste com Android Keystore real.
- APK não compilado neste ambiente: Android SDK/Gradle não disponíveis.
- Sem teste físico no OPPO A3S, sem cloud de produção implantada e sem compilação AOSP/firmware.
