# ABM 7.0.9 — avatar OpenGL e proteção adicional

## Implementado nesta versão

- Novo avatar procedural em OpenGL ES 2.0 (`ABMAvatar3DView`), com malha esférica 3D, cinco variações visuais, animação periódica de pestanejo e movimento da boca enquanto o Android TextToSpeech está a falar.
- A boca acompanha o estado de fala do TTS e oscila durante a locução. Isto é sincronização aproximada por atividade de fala, não sincronização fonema-a-fonema nem captura de movimento facial.
- O avatar respeita a aparência escolhida e mantém a personalidade fixa `Consciência Digital`.
- Perfil de acessibilidade passa a cifrar o JSON do perfil com `SecureFieldVault`/Android Keystore quando o adaptador Android é fornecido, com migração de perfil antigo e remoção da chave ao limpar.
- Payloads do barramento entre departamentos e valores do contexto partilhado passam a usar o mesmo cofre, com migração dos registos antigos.
- O adaptador Android injeta o Keystore nos dois módulos novos.

## Verificações executadas no ambiente de desenvolvimento

- `python -m pytest -q`: 135 testes passaram.
- `python -m compileall -q app/src/main/python`: passou.
- `python tools/test_final_release.py`: 53/53 verificações estáticas passaram.
- `python tools/validate_project.py`: `PASSOU_TOTALMENTE`.

Os testes do cofre usam adaptador simulado. Não provam a execução do Android Keystore num telefone. As verificações Java são estáticas; não houve compilação Android nesta máquina.

## Limitações ainda abertas

- O avatar é uma cabeça procedural genérica, não uma reconstrução da face do utilizador. Para semelhança facial é necessária uma fotografia de referência autorizada e trabalho adicional de modelação/rig.
- A animação da boca é aproximada por atividade TTS, não fonética.
- Nem todos os bancos SQLite estão integralmente cifrados. O motor de conhecimento e outras tabelas técnicas/operacionais continuam a exigir uma revisão de classificação e proteção.
- APK não compilado: não há Android SDK, `android.jar`, Gradle instalado nem wrapper no ambiente utilizado.
- Não foi possível fazer teste físico no OPPO A3S a partir deste ambiente.
- Cloud não implantada: requer destino de hospedagem, segredos reais e validação de rede/serviços.
- ABM SYSTEM/AOSP não compilado: faltam device tree, kernel, vendor blobs licenciados, chave de assinatura e hardware-alvo.
