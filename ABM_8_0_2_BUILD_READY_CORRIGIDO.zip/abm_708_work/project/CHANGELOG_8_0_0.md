# ABM Universal Digital System 8.0.0

## Implementado nesta entrega

- Atualizada a versão Android para `8.0.0` (`versionCode 50`).
- Avatar OpenGL ES 2.0: cinco aparências continuam selecionáveis; foram acrescentados estados visuais de escuta/pensamento, movimento subtil do olhar e inclinação natural da cabeça e visemas aproximados A/E/O.
- Integração dos visemas com `UtteranceProgressListener.onRangeStart`, quando o motor TTS Android fornece intervalos de texto. Isto é uma aproximação por vogais, não captura de áudio nem sincronização fonética perfeita.
- Corrigida a persistência do perfil de acessibilidade: o feedback agora é consultado corretamente quando o perfil está cifrado.
- Modalidades de feedback de acessibilidade são cifradas através do Android Keystore quando o adaptador está disponível; linhas antigas migram automaticamente.
- A eliminação do perfil também elimina as chaves dos registos de feedback.
- Diagnóstico de armazenamento esclarece que a proteção é ao nível dos campos e que os metadados SQLite continuam visíveis; SQLCipher não está configurado.
- Acrescentados testes de migração, cifragem, consulta e eliminação do feedback protegido.

## Verificações locais

- `python -m pytest -q`: 146 aprovados.
- `python tools/test_final_release.py`: 65/65 verificações estáticas aprovadas.
- `python tools/validate_project.py`: `PASSOU_TOTALMENTE`.
- `PYTHONPATH=cloud python -m pytest -q cloud/tests`: 25 aprovados.
- `python -m compileall -q app/src/main/python`: aprovado.

## Limites conhecidos

- O APK não foi compilado neste ambiente: Android SDK, `sdkmanager` e Gradle não estão instalados/configurados aqui.
- O workflow GitHub Actions está preparado para compilar o APK quando executado num runner com SDK/Gradle.
- Não foi possível testar o Android Keystore real nem o OPPO A3S fisicamente.
- Os testes de armazenamento Android usam adaptador simulado; não contam como validação física.
- O avatar é procedural em OpenGL ES; não é um modelo facial humano rigged nem uma reprodução da face do utilizador. A sincronização labial depende do motor TTS e é aproximada por vogais.
- O backend cloud e Docker Compose estão no projeto, mas não foram implantados num servidor nem ligados a credenciais reais.
- AOSP continua como trilho de integração documentado; não há árvore AOSP, device tree, kernel/vendor blobs, chaves ou firmware compilado para o dispositivo-alvo.
- A proteção dos dados é por campos através do Android Keystore quando injetado. Metadados estruturais SQLite permanecem visíveis e SQLCipher não está configurado.
