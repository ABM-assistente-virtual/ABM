# ABM 8.0.1 — Avatar facial aprimorado

- Mantidas as cinco aparências selecionáveis: Clássico, Moderno, Futurista, Natural e Consciência Digital.
- A personalidade continua fixa em **Consciência Digital**, independentemente da aparência escolhida.
- O avatar OpenGL ES passou a desenhar busto/ombros, pescoço, rosto com tom de pele, orelhas estilizadas, cabelo curto, sobrancelhas, nariz e boca.
- Mantidos pestanejar, movimento subtil dos olhos/cabeça e estados de escuta/pensamento.
- Mantida a animação aproximada da boca durante TTS, dependente dos intervalos de texto fornecidos pelo Android.

## Limites desta versão

Este é um avatar 3D procedural estilizado, não um modelo humano realista com esqueleto facial, nem uma cópia do rosto do utilizador. Para obter semelhança facial será necessária uma fotografia de referência e um modelo 3D criado/rigged para esse rosto. A sincronização labial continua aproximada. O código Android ainda precisa de compilação APK e teste físico no dispositivo.
