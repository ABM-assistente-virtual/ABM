# ABM 8.0.2 — Avatar humano com polo ABM

- Substituída a apresentação de armadura tecnológica por um busto humano com polo preto simples.
- Adicionados detalhes discretos de gola, carcela e símbolo luminoso ABM no peito.
- Ajustados tom de pele, cabelo curto natural, olhos e detalhe subtil de bigode para se aproximarem melhor da fotografia de referência, sem afirmar reprodução biométrica exata.
- As cinco aparências agora alteram apenas detalhes visuais: Clássico, Moderno, Futurista, Natural e Consciência Digital.
- A personalidade continua fixa em **Consciência Digital** para todas as aparências.
- Mantidos pestanejar, movimento dos olhos/cabeça, estados de escuta/pensamento e visemas aproximados durante TTS.

## Limites e validação

O avatar continua a ser uma representação 3D procedural feita de formas OpenGL ES 2.0, não um modelo facial digitalizado nem uma cópia exata da fotografia. A sincronização labial é aproximada. A validação automática de lançamento e a compilação Android devem ser executadas; esta entrega não deve ser considerada APK compilado ou testado num telefone físico.
