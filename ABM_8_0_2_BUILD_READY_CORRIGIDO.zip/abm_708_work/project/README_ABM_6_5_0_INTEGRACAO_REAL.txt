ABM UNIFICADO 6.5.0 — INTEGRAÇÃO ANDROID E ACESSIBILIDADE
========================================================

BASE
- Continuação direta do projeto ABM UNIFICADO 6.4.0.
- Compatibilidade declarada do projeto: Android 8.0+ (minSdk 26); o OPPO A3S Android 8.1 está dentro do mínimo declarado, mas ainda precisa de compilação e teste físico.

CAPACIDADES PRESENTES NO CÓDIGO
1. VOZ E RESPOSTA: Android SpeechRecognizer e TextToSpeech já integrados na Activity; modo de escuta contínua é ativado explicitamente e a interface explica o seu âmbito.
2. ABRIR APLICAÇÕES: pesquisa aplicações instaladas pelo nome visível e abre pelo launcher Intent. Não consegue abrir apps que não estejam instaladas, que não exponham launcher ou que bloqueiem a operação.
3. CHAMADAS: comando de voz abre o marcador com o número; a pessoa confirma a chamada no Android.
4. SMS: novo comando “envia mensagem para NÚMERO TEXTO” abre a aplicação SMS com destinatário e texto preenchidos. O utilizador revê e envia manualmente.
5. CONTROLO GLOBAL: AccessibilityService opcional existente com ações Home, Back, notificações, definições rápidas, cursor, varrimento, seleção e gestos. Requer ativação manual em Definições > Acessibilidade. Não é controlo irrestrito de qualquer app.
6. SERVIÇO PERSISTENTE: serviço foreground com notificação persistente e START_STICKY. Android/OEM podem interrompê-lo; o utilizador pode pará-lo. Não garante execução eterna.
7. CÂMARA/VISÃO: CameraX/ML Kit e atividade de acesso visual já existem no projeto, além de análise de imagem/vídeo. Câmara não fica escondida nem ativa em segredo; deve ser iniciada visivelmente e com permissão.
8. OLHAR/CABEÇA/INTERRUPTORES: motores Java de cursor adaptativo, rastreio ocular/gestos, pose da cabeça e switch scanning já estão incluídos. Precisam de câmara, calibração, iluminação, desempenho e validação no hardware; não prometem controlo ocular fiável no A3S.
9. CLOUD: cliente CloudApiClient e backend cloud com Docker/PostgreSQL/Redis/Kubernetes/load test estão no projeto como componentes de implantação. Não há URL de produção, credenciais, domínio, cluster nem serviço global provisionado. Logo, cloud não está ligado em produção.
10. SISTEMA OPERATIVO: este repositório é uma aplicação Android. Não é Android OS/AOSP nem firmware. Um sistema operativo independente exigiria fork AOSP, drivers, HAL, kernel, build de imagens, assinatura, bootloader compatível, testes e distribuição OEM. Não pode ser obtido apenas alterando esta app.

LIMITES DE SEGURANÇA
- Chamadas e mensagens abrem interfaces oficiais para confirmação humana. Não enviar nem ligar silenciosamente.
- Não recolher continuamente conteúdo de outras aplicações. O serviço de acessibilidade evita ler e guardar texto de janelas.
- Não contornar PIN, biometria, permissões, ecrã de bloqueio ou políticas Android.
- Ações sensíveis e ações que podem comunicar externamente exigem confirmação explícita.
- Android 8.1 tem limites de APIs e políticas de execução em segundo plano. Compatibilidade final depende do fabricante.

COMANDOS NOVOS/RELEVANTES
- “abre [nome da aplicação]”
- “liga para [número]” (abre marcador)
- “envia mensagem para [número] [texto]” (abre SMS pré-preenchido, não envia)
- “volta”, “vai para início”, “abre notificações”, “abre definições rápidas”
- “ativa cursor”, “inicia varrimento”, “próximo elemento”, “seleciona”

O QUE FOI VALIDADO NESTA ENTREGA
- Verificação de sintaxe Python do núcleo e módulos.
- Testes automatizados de contrato/static checks da nova integração e dos limites de segurança.
- Integridade do ZIP.

O QUE NÃO FOI VALIDADO
- Compilação APK/AAB: não afirmada nesta entrega.
- Instalação/execução no OPPO A3S: não realizada.
- Microfone, câmara, rastreio ocular, gestos, chamadas, SMS, acessibilidade e serviço persistente em dispositivo físico: não testados.
- Infraestrutura cloud de produção: não provisionada nem conectada.
- Firmware/OS AOSP: não construído.
