# ABM 8.0.2 — Avatar humano

## O que mudou
O avatar procedural OpenGL foi ajustado para apresentar um busto humano com polo preto simples, gola discreta e símbolo luminoso ABM no peito, em vez de armadura. Foram afinados cabelo curto, tom de pele, olhos e detalhe subtil de bigode com base na referência visual aprovada.

## Cinco aparências
1. Clássico
2. Moderno
3. Futurista
4. Natural
5. Consciência Digital

A aparência pode mudar, mas a personalidade e o comportamento permanecem sempre em **Consciência Digital**.

## Animações presentes no código
- Pestanejar e movimento subtil dos olhos.
- Pequeno movimento da cabeça.
- Estados de escuta e pensamento.
- Movimento da boca com visemas aproximados acionados pelos intervalos do TTS.

## Limitações importantes
Este avatar é construído por formas OpenGL ES 2.0. Não é uma digitalização 3D do rosto nem garante semelhança biométrica exata. A boca não usa um sistema fonético profissional. A compilação APK e o teste no OPPO A3S ainda precisam de ser feitos num ambiente Android/Gradle.

## Validação executada
- `tools/test_final_release.py`: 67/67 verificações estáticas passaram.
- `tools/validate_project.py`: PASSOU_TOTALMENTE; compilação sintática Python e suites incluídas passaram.
- APK: não compilado neste ambiente por ausência de Android SDK/Gradle configurados.
