ABM UNIFICADO 4.4.0

Esta versão parte do projeto ABM Unificado 4.3.0 e acrescenta aprendizagem adaptativa local baseada em correções e preferências explicitamente autorizadas.

PASTAS PRINCIPAIS
- app/: projeto Android e código Python integrado.
- app/src/main/python/ABM_UNIFICADO_5_2.py: núcleo herdado ABM 5.2.
- app/src/main/python/abm_modules/: módulos e orquestrador, incluindo adaptive_learning.py.
- cloud/: backend e infraestrutura cloud herdados.
- tools/: testes e validadores.
- docs/: documentação de arquitetura e limitações.
- backup/: cópia de segurança do núcleo herdado.

TESTES EXECUTADOS NESTA VERSÃO
- Validação geral Python/Android estático: PASSOU.
- 48 testes do núcleo ABM 5.2 (suites 7+15+10+6+10): PASSOU.
- 20 verificações dos módulos especializados: PASSOU.
- 10 verificações do sistema unificado: PASSOU.
- 19 verificações do motor de aprendizagem adaptativa: PASSOU.
- 25 testes cloud herdados: PASSOU.

LIMITES
- Aprendizagem significa guardar exemplos/correções/preferências e recuperá-los por correspondência lexical. Não treina uma rede neural nem altera pesos.
- Gravações exigem consentimento explícito; não existe recolha automática de conversas.
- Base SQLite local sem cifragem própria.
- Integrações Redis/PostgreSQL/Kubernetes e testes de carga exigem infraestrutura real e não foram executados.
- APK não foi compilado nem testado num telefone: este ambiente não dispõe de Android SDK/Gradle.
- A presença de código cloud não significa servidor publicado.

COMEÇAR A EXPLORAR
Consultar docs/ABM_UNIFICADO_4_4_0_APRENDIZAGEM_ADAPTATIVA.md.
Executar: python tools/validate_project.py
Executar: python tools/validate_global.py
