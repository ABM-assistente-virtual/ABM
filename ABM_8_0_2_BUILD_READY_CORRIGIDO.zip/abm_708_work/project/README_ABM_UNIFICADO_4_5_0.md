# ABM UNIFICADO 4.5.0

Esta versão continua a linha 4.x do projeto unificado e acrescenta memória contextual local com consentimento explícito.

## Começar
- Android/Python: `app/src/main/python/abm_android.py`
- Módulos centrais: `app/src/main/python/abm_modules/`
- Novo módulo: `abm_modules/contextual_memory.py`
- Teste da nova etapa: `python tools/test_contextual_memory_4_5.py`
- Validador do projeto: `python tools/validate_project.py`

## O que muda em 4.5.0
- Memórias podem ser associadas a um perfil e departamento.
- Guardar requer consentimento explícito.
- Expiração opcional (`ttl_days`).
- Auditoria de gravação, pesquisa e eliminação.
- Eliminação individual ou por perfil exige confirmação.
- O orquestrador pode anexar até três memórias lexicalmente relevantes ao contexto.
- Bloqueio heurístico de alguns padrões óbvios de senhas e números de cartão.

## Limitações
A base de dados é SQLite sem cifragem. O filtro não deteta todos os segredos. `profile_id` é um âmbito lógico e não autenticação. A pesquisa é lexical, não semântica. Não existe recolha automática, treino neuronal nem sincronização cloud implementados por esta etapa. O APK não foi compilado e o projeto não foi testado num telefone físico.
