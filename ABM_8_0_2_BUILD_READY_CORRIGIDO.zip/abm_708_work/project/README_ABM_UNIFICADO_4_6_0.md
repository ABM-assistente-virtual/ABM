# ABM UNIFICADO 4.6.0 — BRAIN ADVANCED

Esta é uma versão de código-fonte que mantém o projeto unificado anterior e acrescenta um planeador multi-etapas para o BRAIN.

## Começar
1. Extrair o ZIP.
2. Abrir `app/src/main/python/abm_android.py` como ponto de integração Python/Android.
3. Inicializar com `abm_android.initialize(pasta_de_dados)`.
4. Preparar um plano com `abm_android.advanced_plan("Abre o WhatsApp")`.
5. Também é possível usar o comando `abm_android.command("/plano-avancado Abre a câmara")`.
6. Quando um executor Android real devolver evidência, registar o resultado com `abm_android.verify_advanced_plan_step(...)`.
7. Executar `python tools/test_brain_advanced_4_6.py` e `python tools/validate_project.py`.

## Novidade 4.6.0
- Planeamento com etapas ordenadas e dependências explícitas.
- Cada etapa indica departamento, ação proposta, risco e critério de verificação.
- Ações sensíveis requerem confirmação explícita para serem marcadas como concluídas.
- Resultados não podem ser marcados como sucesso sem evidência textual.
- Integração opcional de memória contextual em modo apenas leitura.
- API disponível no orquestrador e na ponte Python usada pelo Android.

## O que isto NÃO faz
- Não executa automaticamente as ações do telefone.
- Não substitui permissões Android nem o AccessibilityService.
- Não comprova por si só que o Android executou uma ação; recebe evidência do executor.
- Não treina pesos de rede neuronal nem transforma o ABM em AGI.
- Não publica a Cloud.

## Estado de compilação
É código-fonte. O APK não foi compilado neste ambiente e não foi testado num telefone físico. A compilação Android exige Android SDK/Gradle e validação no dispositivo.
