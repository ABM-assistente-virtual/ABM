# ABM UNIFICADO 4.7.0 — Universal Tool Engine

Esta versão continua o projeto 4.6.0 e acrescenta um motor seguro para descoberta, pesquisa, validação, preparação e despacho de ferramentas previamente registadas.

## Começar
Ver `COMECE_AQUI_4_7_0.txt` e `docs/ABM_UNIFICADO_4_7_0_FERRAMENTAS_UNIVERSAIS.md`.

## Novidade principal
O BRAIN/CONNECT pode consultar um catálogo, validar argumentos, criar um identificador de execução, exigir confirmação em ferramentas sensíveis e manter uma auditoria.

## Limites
Não há execução de código arbitrário nem descoberta automática de qualquer software instalado. Ações Android são despachadas à ponte oficial e dependem de implementação Java, permissões e testes no dispositivo. O APK não foi compilado nem testado fisicamente neste ambiente.
