# ABM UNIFICADO 4.8.0 — Universal Android Execution Bridge

Esta versão liga o catálogo seguro de ferramentas 4.7 à Activity Android: planos preparados podem ser encaminhados a adaptadores Android reais, com confirmação explícita para ações sensíveis e retorno de aceitação/rejeição.

Leia `COMECE_AQUI_4_8_0.txt` e `docs/ABM_UNIFICADO_4_8_0_EXECUTION_BRIDGE.md`.

**Limite:** o retorno `android_accepted` confirma que o adaptador conseguiu iniciar/encaminhar o Intent, não que a operação interna da aplicação externa terminou. APK ainda não compilado nem testado num dispositivo físico.
