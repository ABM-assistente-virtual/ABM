# ABM UNIFICADO 4.9.0 — Real Device Feedback

Esta versão acrescenta um ciclo explícito de feedback após o adaptador Android aceitar uma ação. O utilizador pode indicar se a tarefa na aplicação-alvo foi concluída, falhou ou continua por verificar. O sistema distingue cuidadosamente o que o Android aceitou daquilo que o utilizador relatou.

Leia `COMECE_AQUI_4_9_0.txt` e `docs/ABM_UNIFICADO_4_9_0_REAL_DEVICE_FEEDBACK.md`.

**Limites:** o feedback ainda é mantido em memória, não há verificação automática universal da aplicação-alvo e o APK não foi compilado nem testado num telefone físico.
