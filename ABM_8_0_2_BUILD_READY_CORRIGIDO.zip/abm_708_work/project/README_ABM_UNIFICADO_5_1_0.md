# ABM UNIFICADO 5.1.0

Esta versão acrescenta o **Self-Recovery Engine** ao projeto ABM 5.0.0.

Começa por consultar `COMECE_AQUI_5_0_0.txt` e `docs/ABM_UNIFICADO_5_1_0_SELF_RECOVERY.md`.

O motor diagnostica falhas e prepara recuperação assistida. Não repete ações automaticamente.

## Validar

```bash
python tools/test_self_recovery_5_1.py
python tools/validate_project.py
```

O APK não foi compilado neste ambiente: Android SDK/Gradle não disponíveis.
