# ABM UNIFICADO 5.2.0 — Continuous Operation Engine

Adiciona fluxos persistentes com etapas, dependências, pausa, retoma, cancelamento e confirmação humana. O motor guarda estado em SQLite e recupera o registo após reinício.

**Segurança:** não executa ferramentas nem ações Android. `proximo` apenas apresenta a próxima etapa e muda-a para `waiting_user`; só avança depois de confirmação explícita. Falhas marcam o fluxo como failed. Não há repetição automática.

## Comandos
- `/fluxos` — lista fluxos e estado
- `/fluxo criar {"title":"Preparar documento","steps":[{"title":"Reunir dados","department":"ABM BRAIN"},{"title":"Rever","dependencies":[0]}]}`
- `/fluxo ver ID`
- `/fluxo proximo ID`
- `/fluxo confirmar ID:ETAPA sim|nao [resultado]`
- `/fluxo pausar ID`, `/fluxo retomar ID`, `/fluxo cancelar ID`

Os IDs da etapa são devolvidos em `proximo`. `sim` confirma que a etapa foi concluída; não aciona a ferramenta.

## Limitações
Não é um serviço Android em segundo plano e não mantém tarefas a correr enquanto o processo está fechado. Persistência do estado não equivale a execução autónoma. APK não compilado nem testado no OPPO A3S neste ambiente.
