# ABM UNIFICADO 5.3.0 — Intelligent Decision Engine

Adiciona uma camada de apoio à decisão que compara o pedido com ferramentas locais previamente registadas, calcula uma pontuação simples, aplica limite de risco e indica quando faltam dados ou é necessária clarificação.

## O que faz
- Analisa texto do pedido e compara expressões com o catálogo de ferramentas registadas.
- Ordena candidatos por correspondência e risco.
- Indica pedido desconhecido, informação em falta, risco bloqueado ou recomendação.
- Expõe estado e comando na ponte Android.
- Mantém a decisão separada da preparação e execução.

## Comandos
- `/decidir Abre o YouTube`
- `/decisao estado`

## Limites importantes
É um motor determinístico por palavras-chave e pontuação, não um modelo de linguagem nem raciocínio humano geral. Não aprende com decisões, não cria ferramentas, não prepara planos nem executa operações. Pode falhar em frases ambíguas ou em idiomas/expressões não previstos. O catálogo e as permissões continuam a ser a fonte de autorização. A execução exige os fluxos separados já existentes e confirmação quando aplicável.

A validação Python não equivale a compilar APK nem a testar no OPPO A3S. Não foi demonstrado funcionamento em segundo plano ou em escala global.
