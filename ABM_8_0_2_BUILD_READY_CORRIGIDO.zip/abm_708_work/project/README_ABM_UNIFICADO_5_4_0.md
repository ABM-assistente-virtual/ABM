# ABM UNIFICADO 5.4.0

## Context Understanding Engine
Interpreta pedidos em português através de regras explícitas, identifica intenção, entidades, argumentos em falta e ambiguidades. Pode consultar memória contextual local quando recebe uma referência.

### Comandos
- `/compreender <pedido>` — analisar pedido.
- `/compreensao estado` — estado do módulo.

### Limites
Este módulo é determinístico, não é um LLM nem compreensão humana. Não executa ações, não adivinha valores em falta e não resolve automaticamente todas as referências. A memória SQLite permanece sem cifragem nesta versão. APK não compilado nem testado num telefone real.
