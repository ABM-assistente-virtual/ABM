# ABM UNIFICADO 5.5.0 — Adaptive Intelligence Engine

## O que acrescenta
- Liga compreensão contextual 5.4 à aprendizagem local por feedback explícito.
- Apresenta correções anteriores relevantes e preferências consentidas como contexto adicional.
- Mantém as correções visíveis e auditáveis; não as aplica silenciosamente.
- Não executa ferramentas nem altera pesos de redes neurais.

## Comandos
- `/adaptar <pedido>` — analisa contexto e apresenta exemplos/preferências relevantes.
- `/inteligencia estado` — estado do motor.
- `/aprender corrigir <tema> | <pedido original> | <correção>` — guardar correção com consentimento explícito.
- `/aprender preferencia <chave> | <valor>` — guardar preferência com consentimento explícito.

## Limites
É aprendizagem por exemplos e preferências em SQLite local, não treino de modelo neural nem inteligência geral. O APK não foi compilado nem testado num dispositivo físico nesta validação.
