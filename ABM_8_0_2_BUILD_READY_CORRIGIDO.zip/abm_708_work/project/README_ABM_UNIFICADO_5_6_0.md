# ABM UNIFICADO 5.6.0 — Predictive Intelligence Engine

## Objetivo
Acrescenta sugestões contextuais conservadoras a partir de correções e padrões que o utilizador autorizou guardar.

## Capacidades
- Analisa o pedido explícito através do Context Understanding Engine.
- Procura exemplos semelhantes no armazenamento de aprendizagem local.
- Classifica sugestões com uma pontuação heurística de relevância (não é probabilidade estatística calibrada).
- Exige escolha/confirmação do utilizador antes de qualquer ação.
- Permite guardar contadores de padrões apenas com consentimento explícito.

## Comandos
- `/prever <pedido>` — gerar sugestões contextuais.
- `/previsao estado` — consultar capacidades e limitações.
- `/padrao autorizar <padrão>` — registar padrão após autorização explícita.

## Limites e privacidade
Não observa atividade em segundo plano, não prevê com certeza o futuro, não treina rede neural, não executa ações e não recolhe dados silenciosamente. A pontuação é uma heurística de semelhança, não uma confiança probabilística validada. O armazenamento herdado de aprendizagem usa SQLite local sem encriptação automática.

## Android
Este pacote contém código-fonte Python e integração com a ponte Android existente. APK não foi compilado nem testado num dispositivo nesta execução. Recursos dependem das permissões e APIs Android disponíveis.
