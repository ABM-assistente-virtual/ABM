# ABM UNIFICADO 5.7.0 — Universal Knowledge Engine

## Objectivo
Adicionar uma base local de conhecimento estruturado que permita guardar factos autorizados, pesquisar relações e recuperar informação relevante entre sessões.

## Implementação
- `app/src/main/python/abm_modules/universal_knowledge.py`
- SQLite local com factos (assunto, relação, informação, origem, confiança e data).
- Pesquisa textual por termos e consulta de relações por assunto/objecto.
- Registo exige consentimento explícito; eliminação por origem também exige consentimento.
- Persistência entre reinicializações.
- Integração na ponte `abm_android.py`.

## Comandos
- `/conhecimento estado`
- `/conhecimento guardar assunto | relação | informação [| origem]`
- `/conhecimento procurar termos`
- `/conhecimento relacionado assunto`

Os comandos de guardar e eliminar assumem que o utilizador digitou explicitamente o comando, que constitui consentimento para essa operação. A pesquisa é apenas leitura. O motor não executa ferramentas, não consulta a internet e não treina uma rede neural.

## Limitações
A pesquisa é lexical, não semântica; não cria automaticamente conhecimento a partir de conversas; não valida a verdade dos factos guardados; a base SQLite local não é encriptada nesta versão. Não existe sincronização cloud nesta implementação. APK não compilado nem testado num telefone físico.
