# ABM UNIFICADO 5.8.0

Cross-Department Intelligence Engine: barramento persistente e controlado de mensagens e contexto entre departamentos. Ver `docs/ABM_UNIFICADO_5_8_0_CROSS_DEPARTMENT.md`.

Execute testes: `python tools/test_cross_department_5_8.py` e `python tools/validate_project.py`.

Não representa execução autónoma global nem APK validado em hardware.
