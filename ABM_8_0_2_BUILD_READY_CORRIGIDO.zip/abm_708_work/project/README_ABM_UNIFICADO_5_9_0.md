# ABM UNIFICADO 5.9.0 — Universal Interaction Engine

## Objetivo
Normalizar entradas acessíveis de diferentes modalidades num formato comum, para que o núcleo ABM possa receber eventos de texto, voz, câmara (descrição/transcrição), movimentos da cabeça, olhar, interruptores, Braille e comunicação aumentativa/alternativa.

## O que existe nesta versão
- `UniversalInteractionEngine` com armazenamento SQLite local.
- Validação de modalidade, conteúdo, confiança e consentimento.
- Fila persistente de eventos e seleção com prioridade configurável por modalidade.
- Confirmação ou rejeição de eventos entregues.
- Deduplicação curta de eventos repetidos.
- Metadados limitados e sem guardar ficheiros de áudio, imagem ou vídeo brutos.
- Comandos na ponte Python: `/interacao estado`, `/interacao entrada modalidade | conteúdo | origem [| confiança]`, `/interacao proxima`, `/interacao confirmar ID | sim|nao`.

## Limites importantes
Este módulo não ativa microfone, câmara, eye tracking, sensores ou AccessibilityService. Os adaptadores Android ainda precisam ser implementados, ligados às APIs reais e testados no dispositivo. Para voz/câmara, o motor recebe apenas transcrição ou descrição textual do adaptador. Não executa ações externas. A entrada via comando tem consentimento explícito implícito no próprio comando; integrações de UI devem mostrar uma autorização clara antes de enviar eventos sensíveis.

## Segurança e acessibilidade
As modalidades são caminhos alternativos de entrada, não exigências simultâneas. A prioridade da fila é uma política técnica inicial, que deverá ser configurável por perfil e não deve tornar modalidades de menor prioridade inutilizáveis. Dados de sensores não devem ser capturados continuamente sem indicação e consentimento.
