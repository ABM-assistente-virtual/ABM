# ABM UNIFICADO 6.0.0 — Universal Execution & Accessibility Bridge

## Objetivo
Criar uma primeira ponte nativa Android, com política de autorização, entre a interface ABM e o serviço de acessibilidade Android.

## Implementado
- `ABMExecutionBridge.java`: consulta se o serviço ABM está ativado nas definições Android e encaminha uma lista restrita de ações.
- Lista permitida: voltar, início, notificações, definições rápidas, cursor e varrimento assistivo.
- Ações sensíveis exigem confirmação explícita no método `dispatch`.
- `AndroidExecutionBridge` Python valida estado, lista de ações e confirmação antes de encaminhar intenção.
- Comandos Python: `/android ponte estado`, `/android ponte permissao sim|nao`, `/android ponte validar ação [| confirmar]`.
- O serviço de acessibilidade existente continua a exigir ativação manual nas definições Android.

## Limites
- A ponte não contorna permissões, bloqueio de ecrã nem diálogos do sistema.
- A validação Python não prova que o serviço está realmente ativo; `permissao sim` é um estado informado/confirmado pela interface. A verificação nativa Java é a fonte real.
- Não inclui ainda um adaptador completo de voz Android para eventos universais; o reconhecimento de voz existente em MainActivity continua separado.
- Não controla arbitrariamente outras aplicações; apenas ações disponibilizadas pelo AccessibilityService e permitidas pelo Android.
- Não foi possível afirmar funcionamento no OPPO A3S sem instalação e teste físico.
