# ABM UNIFICADO 6.1.0 — Universal Voice & Accessibility Controller

## Objetivo
Ligar as transcrições produzidas pelo `SpeechRecognizer` Android aos comandos assistivos já existentes no `ABMAccessibilityService`, com confirmação antes de ações que selecionam/ativam elementos.

## Implementação
- `VoiceAccessibilityController` em `app/src/main/python/abm_modules/voice_access_controller.py`: catálogo de intenções por voz, normalização de texto, limiar mínimo de confiança e marcação de ações que exigem confirmação.
- `MainActivity`: comandos de seleção e seleção por varrimento abrem diálogo de confirmação antes de enviar a ação ao serviço de acessibilidade.
- O reconhecimento de voz continua a ser fornecido pelo adaptador Android existente (`SpeechRecognizer`/`RecognizerIntent`). O módulo Python não grava áudio nem executa ações Android.
- A navegação não destrutiva existente continua a usar a interpretação de comandos Android 6.0.

## Limites
O catálogo Python é um interpretador determinístico de frases conhecidas, não reconhecimento de linguagem livre. A confiança fornecida por um futuro adaptador deve ser calibrada; atualmente o serviço Android não fornece score de confiança de forma uniforme. O serviço de acessibilidade deve ser ativado manualmente pelo utilizador. O funcionamento real depende do serviço SpeechRecognizer instalado, permissões e versão Android.

## Segurança
A seleção de elementos exige confirmação visível. Chamadas continuam a abrir o marcador para confirmação manual. Nenhum bloqueio Android é contornado. O sistema não mantém microfone ativo por este módulo.

## Testes
Executar `python tools/test_voice_access_controller_6_1.py`. Os testes cobrem aliases, comandos conhecidos, confiança baixa, frases desconhecidas, confirmação e ausência de captura de áudio/execução direta.
