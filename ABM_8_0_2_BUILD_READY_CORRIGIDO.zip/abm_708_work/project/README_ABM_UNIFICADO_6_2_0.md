# ABM UNIFICADO 6.2.0 — Adaptive Accessibility Intelligence

## Objetivo
Adicionar um perfil configurável de acessibilidade que recomenda modalidades de interação escolhidas pelo utilizador. O motor não diagnostica deficiência, não liga sensores por conta própria e não executa ações Android.

## Modalidades reconhecidas
`touch`, `voice`, `head`, `eye`, `switch`, `braille`, `aac`, `keyboard`.

## Comandos
- `/acessibilidade inteligente estado`
- `/acessibilidade perfil preferidas=voice,switch | disponiveis=voice,switch | confirmar`
- `/acessibilidade recomendar navegação`
- `/acessibilidade feedback switch | sim`
- `/acessibilidade limpar confirmar`

A configuração e o feedback são guardados numa base SQLite local. O perfil só é guardado após confirmação explícita. Recomendações nunca mudam automaticamente a modalidade ativa.

## Limites
Este módulo gere preferências e recomendações. Não implementa rastreamento ocular, deteção de cabeça, Braille físico, AAC ou reconhecimento de voz por si só; depende dos adaptadores Android/dispositivos correspondentes. Não diagnostica condições médicas. A disponibilidade real deve ser confirmada no dispositivo. APK não compilado nem testado em hardware nesta entrega.
