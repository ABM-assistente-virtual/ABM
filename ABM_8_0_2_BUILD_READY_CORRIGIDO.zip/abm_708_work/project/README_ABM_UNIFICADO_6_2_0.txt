ABM UNIFICADO 6.2.0
Adaptive Accessibility Intelligence Engine
Consulte README_ABM_UNIFICADO_6_2_0.md e COMECE_AQUI_6_2_0.txt.
Este motor recomenda modalidades escolhidas pelo utilizador; não diagnostica nem ativa hardware automaticamente.
