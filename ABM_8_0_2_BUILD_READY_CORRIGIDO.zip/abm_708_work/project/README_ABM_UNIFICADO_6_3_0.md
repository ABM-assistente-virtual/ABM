# ABM UNIFICADO 6.3.0 — Universal Device Control Engine

## Objetivo
Acrescentar uma camada única de preparação, autorização e auditoria de operações assistivas Android, reutilizando a ponte Android existente.

## Comandos
- `/dispositivo estado`
- `/dispositivo preparar back|home|notifications|quick_settings|cursor_on|cursor_off|scan_start|scan_next|scan_select|scan_stop`
- `/dispositivo autorizar ID [confirmar]`
- `/dispositivo cancelar ID`

## Fluxo
1. Preparar cria um ticket persistente; não executa nada.
2. Ações de risco médio/alto exigem a palavra `confirmar`.
3. A ponte deve estar ativada manualmente nas definições Android.
4. A autorização produz o estado `authorized_for_android_dispatch`.
5. O adaptador nativo ainda precisa receber o pedido, encaminhar o Intent e registar o resultado.

## Segurança e limites
- Lista de permissões fechada; ações desconhecidas são rejeitadas.
- Tickets processados não podem ser reutilizados.
- Ações sensíveis exigem confirmação explícita.
- O motor não desbloqueia o telefone, não contorna permissões e não executa ações por conta própria.
- `authorized_for_android_dispatch` significa apenas autorização pela política Python; não significa Intent enviado, ação executada ou sucesso verificado.
- A base SQLite local não está encriptada.
- APK não compilado neste ambiente; nenhum teste físico no OPPO A3S foi realizado.
