# ABM UNIFICADO 6.4.0 — Unificação do Sistema

## Objetivo
Consolidar os componentes desenvolvidos até 6.3.0 num registo central de 15 departamentos, com dependências declaradas e diagnóstico único.

## O que foi integrado
- `ABMSystemUnification`: inventário comum, mapa de dependências e relatório de integridade.
- Registo dos 15 departamentos: BRAIN, EARS, EYES, VOICE, BODY, ACCESSIBILITY, AUTONOMY, SOCIAL, MEMORY, SECURITY, CONNECT, SYSTEM, INTERFACE, CLOUD e DEVELOPER.
- Integração na inicialização de `abm_android.py`.
- Adaptador de voz registado para interpretar transcrições fornecidas pelo Android; não captura microfone por si.
- Adaptador cloud identificado como não conectado; não simula backend ativo.

## Comandos
- `/abm sistema` — estado unificado e departamentos.
- `/abm departamentos` — mesmo inventário, para consulta rápida.
- `/unificacao validar` — verifica os 15 registos e integrações centrais.

## Limites importantes
Unificação significa registo e coordenação dos módulos no mesmo runtime Python. Não significa que todas as capacidades estejam operacionais no telefone. Voz ainda depende do adaptador Android; câmara/olhar dependem de permissões e componentes nativos; cloud não está conectado por defeito. A ponte de controlo 6.3 ainda prepara e autoriza tickets, mas não envia automaticamente Intents. Não há APK compilado nem teste físico no OPPO A3S nesta entrega.

## Segurança
O inventário não concede permissões, não ativa sensores, não desbloqueia Android e não executa ações externas automaticamente.
