# Relatório de entrega — ABM 6.7.0

## Alterações comprováveis nesta entrega
- Projeto de origem: ABM UNIFICADO 6.6.0, copiado integralmente para 6.7.0.
- Versão Android atualizada para `versionCode 29` / `versionName 6.7.0`.
- Corrigida a libertação prematura de `ImageProxy` na análise simultânea de objetos e rostos. Agora o frame é libertado após a conclusão de ambas as tarefas ML Kit.
- Adicionados testes de contrato e documentação de instalação/AOSP.

## Capacidades presentes no código (dependem de permissões/serviços/dispositivo)
- SpeechRecognizer e Android TextToSpeech; escuta contínua apenas enquanto a atividade mantém o modo ativo, sujeita a serviço de reconhecimento e ciclo de vida Android.
- Abertura de aplicações instaladas por correspondência do nome visível.
- Abertura do marcador para chamada e compositor SMS para revisão/envio manual.
- AccessibilityService opcional com ações globais, cursor e varrimento, após ativação manual nas definições.
- CameraX + ML Kit para análise em sessão visível da câmara; deteção facial não identifica identidade. Rastreamento ocular é estimado pela abertura dos olhos e não é eye tracking clínico/preciso.
- Backend FastAPI, contas, memória, filas e tarefas; necessita deploy e configuração de Redis/PostgreSQL/segredos.

## Testes executados nesta execução
- `python -m compileall -q app/src/main/python`: PASSOU.
- `python tools/validate_project.py`: PASSOU_TOTALMENTE (o relatório do validador está preservado em `TEST_REPORT_6_7_0_PROJECT.json`).
- `PYTHONPATH=cloud pytest -q cloud/tests`: 25 testes PASSARAM.
- Testes de contrato 6.7.0: executados no script `tools/test_release_6_7.py`.
- Integridade do ZIP: verificada após empacotamento.

## Não executado / não comprovado
- APK: não compilado, pois Android SDK/Gradle não estão disponíveis neste ambiente.
- Dispositivo físico: não testado no OPPO A3S.
- Cloud: não implantada; nenhuma URL, conta de produção, segredo ou servidor foi provisionado.
- AOSP: não existe firmware compilado; apenas trilho/documentação de integração.
- 30 milhões de utilizadores: não há teste de carga ou capacidade medida que comprove essa escala.

## Limites Android
Uma app comum não pode controlar irrestritamente todas as apps, contornar bloqueio/consentimento, enviar SMS ou fazer chamadas sem os fluxos e permissões apropriados. Serviços foreground podem ser interrompidos pelo sistema/OEM. Câmera/microfone dependem de permissões e políticas de execução.
