# ABM Universal Digital System — entrega final técnica 7.0.0

## Base auditada
- Projeto integral de trabalho: `ABM_UNIFICADO_6_7_0` (inclui código cumulativo, changelogs e relatórios históricos 1.x–6.7.0).
- Android: aplicação Java + Chaquopy/Python, minSdk 26 (Android 8.0+), compileSdk 35, targetSdk 28.
- Departamentos: registo comum dos 15 departamentos em `system_unification.py`.
- Backend: FastAPI, autenticação por token assinado, contas/memória, filas e adaptadores SQLite/PostgreSQL/Redis.
- AOSP: apenas documentação/trilho de integração; não é firmware compilado.

## Alteração efetiva desta entrega
- Atualização da versão Android para 7.0.0 / versionCode 30.
- Novo `RuntimeAudit`, integrado no núcleo Python.
- Novo comando `/diagnostico` (também `/diagnóstico`) para expor o estado real do runtime, cloud, armazenamento e dependências de hardware.
- O diagnóstico diferencia código inicializado de câmara/microfone/serviços nativos que dependem de permissões e sessão ativa.
- O diagnóstico declara explicitamente que a implantação cloud não foi verificada e que os adaptadores SQLite locais não fornecem criptografia por si mesmos.
- Testes unitários para estados completos e ausentes do diagnóstico.

## Auditoria de capacidades existentes
- Voz: Android SpeechRecognizer e TextToSpeech presentes; reconhecimento depende do serviço de voz instalado, idioma, microfone e permissões.
- Visão: CameraX e ML Kit para objetos/rostos em sessão visível; deteção facial não identifica a pessoa. Rastreamento ocular não é eye tracking preciso.
- Controlo: abertura de apps e intents nativos presentes; AccessibilityService executa ações globais/varrimento apenas após ativação explícita. Não há controlo irrestrito de qualquer app.
- Ferramentas: catálogo, validação de argumentos, confirmações, dispatch Android e registo de resultado existem; o dispatch não comprova o resultado final dentro de apps de terceiros.
- Memória: vários SQLite locais; os adaptadores SQLite padrão não cifram o ficheiro da base de dados.
- Cloud: código de backend e testes disponíveis; precisa de configuração de segredos, PostgreSQL/Redis e deploy real.
- AOSP: documentação de integração; não há árvore AOSP completa nem firmware compilado nesta entrega.

## Testes executados nesta entrega
- `python -m compileall -q app/src/main/python`: PASSOU.
- `pytest -q tools/test_runtime_audit_final.py`: 2 testes PASSARAM.
- `PYTHONPATH=cloud pytest -q cloud/tests`: 25 testes PASSARAM.
- `python tools/validate_project.py`: PASSOU TOTALMENTE.
- `python tools/test_final_release.py`: validação estática da entrega (resultado em `TEST_REPORT_FINAL_7_0_0.json`).
- Integridade ZIP: verificada após criação.

## Não executado / bloqueios externos
- APK: não compilado neste ambiente (Gradle e Android SDK não instalados/disponíveis).
- OPPO A3S físico: não testado.
- Câmera, microfone, TTS, acessibilidade e intents: testes instrumentados físicos não executados.
- Cloud de produção: não implantada; sem URL/credenciais/infraestrutura provisionadas.
- Teste de carga para milhões de utilizadores: não executado.
- AOSP: firmware não compilado nem testado em hardware.

## Segurança e privacidade — ações necessárias antes de produção
- Proteger bases SQLite locais com armazenamento cifrado apropriado e chaves geridas pelo Android Keystore; a auditoria atual alerta que SQLite simples não cifra os ficheiros.
- Configurar segredos apenas no servidor, HTTPS, backups protegidos, política de retenção e monitorização.
- Revisar permissões Android e testar o fluxo de consentimento no dispositivo.

## Estado global
`IMPLEMENTAÇÃO PARCIAL INTEGRADA — TESTES DE SOFTWARE PASSARAM — VALIDAÇÃO FÍSICA, CLOUD DE PRODUÇÃO E FIRMWARE AOSP PENDENTES`.
