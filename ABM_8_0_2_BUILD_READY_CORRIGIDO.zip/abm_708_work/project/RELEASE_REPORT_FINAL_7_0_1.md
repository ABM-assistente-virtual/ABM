# ABM Universal Digital System — Auditoria 7.0.1

## Base de trabalho
A versão 7.0.1 foi preparada diretamente sobre o pacote 7.0.0 fornecido no ambiente: `ABM_UNIVERSAL_DIGITAL_SYSTEM_FINAL_7_0_0.zip`.

## Alterações efetivamente realizadas
- Atualizado `versionName` para `7.0.1` e `versionCode` para `31`.
- Preservado o código funcional existente.
- Renomeado `tools/test_release_6_7.py` para `tools/audit_release_6_7_legacy.py`. Era um verificador histórico executável no momento da importação; o pytest tentava recolhê-lo como teste e recebia `SystemExit`, interrompendo a recolha global.
- Pipeline GitHub Actions atualizado para executar testes cloud, testes do RuntimeAudit e auditoria estática antes de `assembleDebug`.
- Mantida a indicação explícita de que o estado cloud/deploy e o armazenamento SQLite local não são automaticamente seguros ou verificados.

## Testes executados nesta sessão
- `python -m compileall -q app/src/main/python`: PASSOU.
- `PYTHONPATH=cloud python -m pytest -q cloud/tests`: 25 passaram.
- `python -m pytest -q tools/test_runtime_audit_final.py`: 2 passaram.
- `python tools/test_final_release.py`: 22/22 verificações estáticas passaram após a atualização para 7.0.1.
- `python tools/validate_project.py`: PASSOU TOTALMENTE, com ressalvas descritas pelo próprio validador.

## Falhas/limitações identificadas
- `python -m pytest -q cloud/tests tools` não é um comando válido para todo o diretório `tools`: vários arquivos `test_*.py` são scripts históricos executáveis e não testes pytest import-safe. O CI usa apenas as suites que são pytest-safe e executa os validadores de projeto como scripts separados.
- Não existe Gradle Wrapper no pacote.
- `gradle`, Android SDK e `sdkmanager` não estão instalados/disponíveis neste ambiente; por isso o APK não foi compilado aqui.
- O pipeline GitHub Actions está configurado para compilar o APK em runner Ubuntu, mas a execução remota do workflow não foi disparada/verificada nesta sessão.
- Não foi possível instalar/testar no OPPO A3S.
- Cloud de produção não foi provisionada nem implantada; não existem credenciais/URL de produção fornecidas.
- Não existe árvore AOSP completa nem firmware ABM compilado.
- SQLite local continua sem cifragem de base de dados integrada; não se declara proteção criptográfica completa dos dados locais.
- Recursos de câmara, microfone, TTS, AccessibilityService, rastreio ocular e operações em apps externas ainda exigem validação real no dispositivo e dependem de permissões, serviços e hardware.

## Estado honesto
`CÓDIGO PYTHON VALIDADO + BACKEND TESTADO + AUDITORIA ESTÁTICA APROVADA; APK/GRADLE, DEPLOY CLOUD, CIFRAGEM SQLITE, AOSP E TESTES FÍSICOS AINDA PENDENTES.`

Esta entrega não pode ser descrita como “só falta testar no telemóvel”, porque a compilação APK e algumas integrações externas ainda não foram verificadas.
