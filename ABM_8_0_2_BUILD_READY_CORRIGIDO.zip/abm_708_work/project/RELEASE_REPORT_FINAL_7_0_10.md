# Relatório de lançamento — ABM 7.0.10

## Alterações comprovadas
1. Conhecimento local: campos factuais cifrados via `SecureFieldVault` quando o adaptador Android Keystore é fornecido; migração de dados antigos; busca e relações continuam funcionais; apagar por origem remove a chave protegida.
2. Controlo Android: detalhe dos tickets cifrado; migração dos detalhes antigos; cancelamento elimina a chave correspondente.
3. `abm_android.initialize` injeta o armazenamento seguro nos dois módulos.
4. Diagnóstico atualizado para refletir estes armazenamentos e manter explícitos os restantes limites.

## Testes neste ambiente
- `python -m compileall -q app/src/main/python`: aprovado.
- `python -m pytest -q`: 138 aprovados, 0 falhados.
- `python tools/test_final_release.py`: 56/56 verificações estáticas aprovadas.
- `python tools/validate_project.py`: `PASSOU_TOTALMENTE`.
- Os testes novos usam um adaptador Keystore simulado. Não equivalem a teste físico do Android Keystore.

## Estado de tarefas externas
- APK: não compilado; Android SDK/Gradle não encontrados neste ambiente.
- OPPO A3S: sem teste físico.
- Cloud: backend/cliente presentes, mas deployment e credenciais reais não configurados/verificados.
- AOSP: documentação e estrutura de fronteira presentes; faltam árvore de dispositivo, kernel, vendor blobs, toolchain e chave de assinatura.
- Avatar: OpenGL procedural, cinco estilos, pestanejo e animação aproximada da boca já presentes; likeness facial pessoal e sincronização fonética ainda não concluídos.

## Limites de segurança
A cifra cobre campos sensíveis nos módulos integrados, não o ficheiro completo do perfil/estado do cérebro nem todos os metadados SQLite. O diagnóstico continua a reportar proteção parcial.
