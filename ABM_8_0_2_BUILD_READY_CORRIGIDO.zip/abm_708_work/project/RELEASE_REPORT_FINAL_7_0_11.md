# Relatório técnico — ABM 7.0.11

## Alteração principal
A persistência central do ABM foi integrada com o `ABMSecureStore`: estado do companheiro, snapshot neuronal e estado de permissões/objetivos/pendências. Os JSON persistentes são substituídos por um marcador quando o adaptador de segurança Android está ativo. A migração de ficheiros antigos é automática na inicialização.

## Testes executados neste ambiente
- Pytest: 143 testes aprovados, 0 falhados.
- Verificações estáticas do release: 59/59 aprovadas.
- `compileall` Python: aprovado.
- Validador geral: `PASSOU_TOTALMENTE`.
- Teste de ciclo de vida do estado central: adaptador Keystore simulado.

## Limites não verificados
- APK não compilado neste ambiente: Android SDK/Gradle não estão instalados/configurados.
- Android Keystore físico não testado.
- OPPO A3S não testado fisicamente.
- Cloud não implantada nem ligada a credenciais de produção.
- AOSP não compilado: é necessário obter e configurar a árvore AOSP e os componentes específicos do dispositivo.
- A cifragem protege os valores sensíveis persistidos através do adaptador; metadados SQLite e outros dados residuais ainda exigem auditoria. O modo desktop sem adaptador permanece sem cifragem.
