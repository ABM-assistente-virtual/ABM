# Relatório de release — ABM Universal Digital System 8.0.0

## Alterações principais

- Atualização de versão Android para `8.0.0` / `versionCode 50`.
- Avatar OpenGL ES com cinco aparências, estados de escuta/pensamento, olhar subtil e visemas aproximados derivados dos intervalos de texto reportados pelo TTS Android.
- Correção da leitura e gravação de feedback quando o perfil de acessibilidade está cifrado.
- Migração e cifragem de modalidades de feedback de acessibilidade pelo Android Keystore, com remoção das chaves ao limpar os dados.
- Diagnóstico mais preciso: cifragem por campo não é confundida com cifragem integral SQLite.
- Pipeline GitHub Actions atualizado para executar a suíte Python completa, validar o projeto, executar testes cloud e compilar o APK debug num runner Android configurado.

## Testes executados neste ambiente

- Suíte completa `python -m pytest -q`: **146 passed, 0 failed**.
- Verificações estáticas `python tools/test_final_release.py`: **67/67 passed**.
- Validador `python tools/validate_project.py`: **PASSOU TOTALMENTE**.
- Suíte cloud `PYTHONPATH=cloud python -m pytest -q cloud/tests`: **25 passed**.
- `python -m compileall -q app/src/main/python`: **PASSOU**.
- Integridade do ZIP: a validar na criação do pacote.

## Resultados não executados / dependências

- APK: **não compilado neste ambiente**. Não estão instalados/configurados Gradle, Android SDK ou `sdkmanager`. O workflow CI está preparado para tentar a compilação num runner com as dependências.
- OPPO A3S: **não testado fisicamente**.
- Android Keystore: **não validado em hardware**; os testes Python usam um adaptador simulado.
- Cloud: **não implantada**; faltam servidor, domínio/TLS e credenciais do operador.
- AOSP: **não compilado**; faltam árvore AOSP compatível, device tree, kernel, vendor blobs, chaves e dispositivo-alvo.
- Avatar: **não é um avatar facial final**. É um avatar procedural OpenGL ES com visemas aproximados. A sincronização fonética precisa de um motor TTS que reporte intervalos úteis e de validação visual em dispositivo.
- Armazenamento: conteúdo sensível de vários módulos é cifrado por campo quando o adaptador Android Keystore está ativo. Metadados estruturais SQLite continuam visíveis; SQLCipher não está configurado.

## Classificação

Esta entrega é uma integração de software com testes automatizados aprovados. Não é correto classificá-la como produto integralmente concluído enquanto APK, hardware, implantação cloud e firmware AOSP não forem efetivamente validados.
