# ABM SYSTEM — trilho AOSP (não é firmware compilado)

Este diretório documenta a migração futura do ABM para uma distribuição baseada em Android Open Source Project. A aplicação ABM Mobile continua a ser o artefacto executável atual.

## Componentes necessários antes de produzir uma imagem

1. Escolher um dispositivo-alvo com bootloader desbloqueável e suporte AOSP comprovado.
2. Fixar uma tag AOSP compatível com o dispositivo e obter device tree, kernel source e vendor blobs licenciados.
3. Definir `PRODUCT_PACKAGES` para ABM SystemUI/serviços privilegiados, assinaturas de plataforma e políticas SELinux.
4. Migrar apenas as funções que necessitam de privilégio para serviços de sistema; manter dados pessoais sob permissões explícitas.
5. Criar testes CTS/VTS, testes de acessibilidade, boot, atualização OTA, recuperação e segurança.
6. Assinar imagens, gerar OTA e validar em hardware antes de distribuição.

## Estrutura de integração proposta

- `ABMSystemService`: serviço de sistema para orquestração local, apenas em builds autorizadas.
- `ABMAccessibility`: continua a usar APIs públicas quando executado como app comum.
- `ABMPolicy`: políticas de permissões, auditoria e confirmação.
- `ABMSystemUI`: interface de sistema opcional, não implementada neste pacote.

## Bloqueios explícitos

Não há device tree, kernel, vendor blobs, chave de assinatura, imagem AOSP, bootloader ou dispositivo de referência AOSP neste ambiente. Portanto, nenhum firmware ABM foi compilado. Não usar este documento como instrução para desbloquear ou regravar um OPPO A3S sem confirmar primeiro suporte específico do fabricante/modelo.
