package com.forla.abm;

import java.text.Normalizer;
import java.util.Locale;

/** Interpreta comandos de acessibilidade em português sem recolher dados do ecrã. */
public final class ABMAccessibilityEngine {
    public enum Action {
        NONE, BACK, HOME, NOTIFICATIONS, QUICK_SETTINGS, CURSOR_ON, CURSOR_OFF, SELECT, SCAN_START, SCAN_NEXT, SCAN_SELECT, SCAN_STOP,
        OPEN_YOUTUBE, OPEN_WHATSAPP, OPEN_SETTINGS,
        READ_LAST_REPLY, STOP_SPEAKING, HELP
    }

    public static final class Result {
        public final Action action;
        public final String argument;
        Result(Action action, String argument) { this.action = action; this.argument = argument; }
    }

    private ABMAccessibilityEngine() { }

    private static String normalize(String text) {
        String value = text == null ? "" : text.toLowerCase(Locale.ROOT).trim();
        value = Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return value.replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    public static Result interpret(String spokenText) {
        String s = normalize(spokenText);
        if (s.isEmpty()) return new Result(Action.NONE, "");
        if (matches(s, "volta", "voltar", "regressa", "pagina anterior", "volta atras")) return new Result(Action.BACK, "");
        if (matches(s, "inicio", "vai para inicio", "ecra inicial", "tela inicial", "volta ao inicio")) return new Result(Action.HOME, "");
        if (matches(s, "abre notificacoes", "mostrar notificacoes", "ler notificacoes", "mostra notificacoes")) return new Result(Action.NOTIFICATIONS, "");
        if (matches(s, "abre definicoes rapidas", "abre painel rapido", "definicoes rapidas", "abre os atalhos")) return new Result(Action.QUICK_SETTINGS, "");
        if (matches(s, "ativa cursor", "mostrar cursor", "liga cursor", "ativa o cursor")) return new Result(Action.CURSOR_ON, "");
        if (matches(s, "desativa cursor", "esconde cursor", "desliga cursor", "desativa o cursor")) return new Result(Action.CURSOR_OFF, "");
        if (matches(s, "inicia varrimento", "inicia leitura de botoes", "varrimento automatico", "ativa varrimento")) return new Result(Action.SCAN_START, "");
        if (matches(s, "proximo", "proximo elemento", "seguinte", "avanca", "passa")) return new Result(Action.SCAN_NEXT, "");
        if (matches(s, "seleciona", "clicar", "clica", "confirmar selecao", "pressiona enter", "escolhe")) return new Result(Action.SCAN_SELECT, "");
        if (matches(s, "para varrimento", "termina varrimento", "desativa varrimento")) return new Result(Action.SCAN_STOP, "");
        if (matches(s, "abre youtube", "abre o youtube")) return new Result(Action.OPEN_YOUTUBE, "");
        if (matches(s, "abre whatsapp", "abre o whatsapp")) return new Result(Action.OPEN_WHATSAPP, "");
        if (matches(s, "abre definicoes", "abre as definicoes", "abre configuracoes", "definicoes do telefone", "configuracoes do telefone")) return new Result(Action.OPEN_SETTINGS, "");
        if (matches(s, "le a resposta", "le ultima resposta", "le a ultima resposta", "repete", "repete a resposta", "fala novamente")) return new Result(Action.READ_LAST_REPLY, "");
        if (matches(s, "para de falar", "silencio", "cala", "parar voz")) return new Result(Action.STOP_SPEAKING, "");
        if (matches(s, "ajuda", "o que posso dizer", "comandos disponiveis")) return new Result(Action.HELP, "");
        return new Result(Action.NONE, spokenText == null ? "" : spokenText.trim());
    }

    private static boolean matches(String value, String... choices) {
        for (String choice : choices) if (value.equals(choice)) return true;
        return false;
    }
}
