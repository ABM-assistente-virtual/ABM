package com.forla.abm;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import android.graphics.PixelFormat;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

/**
 * Serviço global opcional. Só examina a estrutura de acessibilidade durante um
 * comando explícito de varrimento; não recolhe texto, rótulos ou conteúdo digitado.
 */
public class ABMAccessibilityService extends AccessibilityService {
    public static final String ACTION = "com.forla.abm.ACCESSIBILITY_ACTION";
    public static final String ACTION_CURSOR = "com.forla.abm.ACCESSIBILITY_CURSOR";
    public static final String EXTRA_COMMAND = "command";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    public static final String EXTRA_ENABLED = "enabled";
    private BroadcastReceiver receiver;
    private WindowManager windowManager;
    private ABMGlobalCursorOverlay overlay;
    private boolean overlayEnabled;
    private final ABMSwitchInputEngine switchInput = new ABMSwitchInputEngine();
    private final ABMScanEngine scanEngine = new ABMScanEngine();
    private boolean scanActive = false;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (ACTION.equals(action)) {
                    String command = intent.getStringExtra(EXTRA_COMMAND);
                    if (command == null) return;
                    boolean ok = false;
                    switch (command) {
                        case "back": ok = performGlobalAction(GLOBAL_ACTION_BACK); break;
                        case "home": ok = performGlobalAction(GLOBAL_ACTION_HOME); break;
                        case "notifications": ok = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); break;
                        case "quick_settings": ok = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS); break;
                        case "cursor_on": setOverlayEnabled(true); ok = true; break;
                        case "cursor_off": setOverlayEnabled(false); ok = true; break;
                        case "select":
                            if (overlayEnabled) { dispatchTap(switchInput.getX(), switchInput.getY()); ok = true; }
                            break;
                        case "scan_start": ok = startScan(); break;
                        case "scan_next": ok = advanceScan(); break;
                        case "scan_select": ok = selectScanned(); break;
                        case "scan_stop": scanActive = false; setOverlayEnabled(false); ok = true; break;
                        default: break;
                    }
                    Toast.makeText(ABMAccessibilityService.this, ok ? "ABM: ação executada" : "ABM: ação indisponível", Toast.LENGTH_SHORT).show();
                } else if (ACTION_CURSOR.equals(action)) {
                    boolean enabled = intent.getBooleanExtra(EXTRA_ENABLED, overlayEnabled);
                    if (enabled != overlayEnabled) setOverlayEnabled(enabled);
                    if (overlayEnabled && intent.hasExtra(EXTRA_X) && intent.hasExtra(EXTRA_Y)) {
                        float x = intent.getFloatExtra(EXTRA_X, 0.5f);
                        float y = intent.getFloatExtra(EXTRA_Y, 0.5f);
                        if (overlay != null) overlay.setPosition(x, y);
                    }
                    if (overlayEnabled && intent.getBooleanExtra("tap", false)) dispatchTap(
                        intent.getFloatExtra(EXTRA_X, 0.5f), intent.getFloatExtra(EXTRA_Y, 0.5f));
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION); filter.addAction(ACTION_CURSOR);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, "com.forla.abm.permission.CONTROL_ACCESSIBILITY", null, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter, "com.forla.abm.permission.CONTROL_ACCESSIBILITY", null);
    }

    private void setOverlayEnabled(boolean enabled) {
        overlayEnabled = enabled;
        if (enabled) {
            if (overlay == null) overlay = new ABMGlobalCursorOverlay(this);
            try {
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP | Gravity.START;
                windowManager.addView(overlay, lp);
            } catch (IllegalStateException alreadyAdded) { /* já visível */ }
        } else if (overlay != null) {
            try { windowManager.removeView(overlay); } catch (IllegalArgumentException ignored) { }
            overlay = null;
        }
    }

    /** Percorre apenas nós clicáveis/focáveis; nunca lê nem guarda o texto apresentado. */
    private ArrayList<AccessibilityNodeInfo> collectTargets() {
        ArrayList<AccessibilityNodeInfo> found = new ArrayList<>();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return found;
        collectRecursive(root, found, 0);
        root.recycle();
        Collections.sort(found, new Comparator<AccessibilityNodeInfo>() {
            @Override public int compare(AccessibilityNodeInfo a, AccessibilityNodeInfo b) {
                Rect ra = new Rect(), rb = new Rect(); a.getBoundsInScreen(ra); b.getBoundsInScreen(rb);
                int row = Integer.compare(ra.top, rb.top);
                return row != 0 ? row : Integer.compare(ra.left, rb.left);
            }
        });
        return found;
    }

    private void collectRecursive(AccessibilityNodeInfo node, ArrayList<AccessibilityNodeInfo> out, int depth) {
        if (node == null || depth > 30 || out.size() >= 150) return;
        if ((node.isClickable() || node.isFocusable()) && node.isVisibleToUser()) {
            out.add(AccessibilityNodeInfo.obtain(node));
        }
        for (int i = 0; i < node.getChildCount() && out.size() < 150; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectRecursive(child, out, depth + 1); child.recycle(); }
        }
    }

    private boolean startScan() {
        scanActive = true; scanEngine.reset(0);
        setOverlayEnabled(true);
        return advanceScan();
    }

    private boolean advanceScan() {
        if (!scanActive) return false;
        ArrayList<AccessibilityNodeInfo> targets = collectTargets();
        int count = targets.size();
        for (AccessibilityNodeInfo n : targets) n.recycle();
        if (scanEngine.count() != count) scanEngine.reset(count);
        if (count == 0) {
            Toast.makeText(this, "ABM: não encontrei botões acessíveis nesta janela", Toast.LENGTH_SHORT).show();
            return false;
        }
        int selected = scanEngine.next();
        return moveOverlayToTarget(selected);
    }

    private boolean moveOverlayToTarget(int index) {
        ArrayList<AccessibilityNodeInfo> targets = collectTargets();
        if (index < 0 || index >= targets.size()) { for (AccessibilityNodeInfo n : targets) n.recycle(); return false; }
        Rect bounds = new Rect(); targets.get(index).getBoundsInScreen(bounds);
        for (AccessibilityNodeInfo n : targets) n.recycle();
        if (bounds.isEmpty()) return false;
        DisplayMetrics dm = new DisplayMetrics(); windowManager.getDefaultDisplay().getRealMetrics(dm);
        float nx = Math.max(0f, Math.min(1f, bounds.centerX() / (float) dm.widthPixels));
        float ny = Math.max(0f, Math.min(1f, bounds.centerY() / (float) dm.heightPixels));
        if (overlay != null) overlay.setPosition(nx, ny);
        Toast.makeText(this, "ABM: elemento " + (index + 1), Toast.LENGTH_SHORT).show();
        return true;
    }

    private boolean selectScanned() {
        if (!scanActive) { if (overlayEnabled) { dispatchTap(switchInput.getX(), switchInput.getY()); return true; } return false; }
        if (!scanEngine.hasSelection()) return false;
        ArrayList<AccessibilityNodeInfo> targets = collectTargets();
        int index = scanEngine.current();
        if (index < 0 || index >= targets.size()) { for (AccessibilityNodeInfo n : targets) n.recycle(); return false; }
        AccessibilityNodeInfo target = targets.get(index);
        boolean done = target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        if (!done) done = target.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS);
        for (AccessibilityNodeInfo n : targets) n.recycle();
        return done;
    }

    private void dispatchTap(float nx, float ny) {
        if (Build.VERSION.SDK_INT < 24) return;
        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(dm);
        float x = Math.max(1f, Math.min(dm.widthPixels - 1f, nx * dm.widthPixels));
        float y = Math.max(1f, Math.min(dm.heightPixels - 1f, ny * dm.heightPixels));
        Path path = new Path(); path.moveTo(x, y);
        android.accessibilityservice.GestureDescription.StrokeDescription stroke =
            new android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 90);
        android.accessibilityservice.GestureDescription gesture =
            new android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture, null, null);
    }

    /** Teclas DPAD/ENTER de teclado ou interruptor externo, apenas durante sessão assistiva ativa. */
    @Override public boolean onKeyEvent(KeyEvent event) {
        if (!overlayEnabled || event.getAction() != KeyEvent.ACTION_UP) return false;
        if (scanActive) {
            int code = event.getKeyCode();
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT || code == KeyEvent.KEYCODE_DPAD_DOWN) return advanceScan();
            if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) return selectScanned();
            if (code == KeyEvent.KEYCODE_ESCAPE) { scanActive = false; setOverlayEnabled(false); return true; }
        }
        ABMSwitchInputEngine.Action action = switchInput.key(event.getKeyCode());
        if (action == ABMSwitchInputEngine.Action.MOVE) {
            if (overlay != null) overlay.setPosition(switchInput.getX(), switchInput.getY());
            return true;
        }
        if (action == ABMSwitchInputEngine.Action.SELECT) {
            dispatchTap(switchInput.getX(), switchInput.getY());
            return true;
        }
        return false;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* Não recolhe texto nem conteúdo das apps. */ }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        scanActive = false;
        setOverlayEnabled(false);
        if (receiver != null) { try { unregisterReceiver(receiver); } catch (Exception ignored) { } }
        super.onDestroy();
    }
}
