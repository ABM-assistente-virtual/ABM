package com.forla.abm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Indicador visual do cursor adaptativo. É uma vista que o ecrã anfitrião pode sobrepor. */
public final class ABMAdaptiveCursorView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float normalizedX = 0.5f;
    private float normalizedY = 0.5f;
    private float radius = 22f;

    public ABMAdaptiveCursorView(Context context) {
        super(context);
        setContentDescription("Cursor de acessibilidade ABM");
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
    }

    public void setNormalizedPosition(float x, float y) {
        if (Float.isNaN(x) || Float.isNaN(y) || Float.isInfinite(x) || Float.isInfinite(y)) return;
        normalizedX = Math.max(0f, Math.min(1f, x));
        normalizedY = Math.max(0f, Math.min(1f, y));
        postInvalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float x = normalizedX * getWidth();
        float y = normalizedY * getHeight();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5f);
        canvas.drawCircle(x, y, radius, paint);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(x, y, 5f, paint);
    }
}
