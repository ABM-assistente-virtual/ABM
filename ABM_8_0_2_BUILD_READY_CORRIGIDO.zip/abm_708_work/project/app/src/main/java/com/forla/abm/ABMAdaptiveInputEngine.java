package com.forla.abm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Núcleo independente de entrada adaptativa.
 * Recebe medições normalizadas de um rastreador externo (câmara/sensor) e eventos
 * de interruptor. Não abre a câmara nem recolhe biometria por conta própria.
 */
public final class ABMAdaptiveInputEngine {
    public enum EventType { NONE, CURSOR_MOVED, DWELL_SELECT, SCAN_HIGHLIGHT, SCAN_SELECT }

    public static final class Event {
        public final EventType type;
        public final float x;
        public final float y;
        public final int itemIndex;
        Event(EventType type, float x, float y, int itemIndex) {
            this.type = type; this.x = x; this.y = y; this.itemIndex = itemIndex;
        }
    }

    private float cursorX = 0.5f, cursorY = 0.5f;
    private float smoothX = 0.5f, smoothY = 0.5f;
    private float deadZone = 0.035f;
    private float sensitivity = 1.8f;
    private long dwellMillis = 1400L;
    private long stableSince = -1L;
    private boolean dwellEnabled;
    private boolean scanEnabled;
    private int scanIndex = -1;
    private long lastScanAdvance;
    private long scanIntervalMillis = 1100L;
    private List<String> scanItems = Collections.emptyList();

    public synchronized void configureHead(float sensitivity, float deadZone, boolean dwellEnabled, long dwellMillis) {
        this.sensitivity = clamp(sensitivity, 0.3f, 4.0f);
        this.deadZone = clamp(deadZone, 0.0f, 0.20f);
        this.dwellEnabled = dwellEnabled;
        this.dwellMillis = Math.max(400L, Math.min(5000L, dwellMillis));
        stableSince = -1L;
    }

    /** yaw/pitch são valores normalizados em [-1, 1], fornecidos por um tracker. */
    public synchronized Event updateHeadPose(float yaw, float pitch, long nowMillis) {
        if (!isFinite(yaw) || !isFinite(pitch)) return none();
        yaw = clamp(yaw, -1f, 1f); pitch = clamp(pitch, -1f, 1f);
        float dx = Math.abs(yaw) < deadZone ? 0f : yaw * sensitivity * 0.025f;
        float dy = Math.abs(pitch) < deadZone ? 0f : pitch * sensitivity * 0.025f;
        float targetX = clamp(cursorX + dx, 0f, 1f);
        float targetY = clamp(cursorY + dy, 0f, 1f);
        smoothX += (targetX - smoothX) * 0.32f;
        smoothY += (targetY - smoothY) * 0.32f;
        boolean moved = Math.abs(smoothX - cursorX) > 0.002f || Math.abs(smoothY - cursorY) > 0.002f;
        cursorX = smoothX; cursorY = smoothY;
        if (moved) stableSince = -1L;
        else if (stableSince < 0L) stableSince = nowMillis;
        if (dwellEnabled && stableSince >= 0L && nowMillis - stableSince >= dwellMillis) {
            stableSince = nowMillis;
            return new Event(EventType.DWELL_SELECT, cursorX, cursorY, -1);
        }
        return moved ? new Event(EventType.CURSOR_MOVED, cursorX, cursorY, -1) : none();
    }

    public synchronized void setScanItems(List<String> labels, long intervalMillis) {
        ArrayList<String> safe = new ArrayList<>();
        if (labels != null) for (String label : labels) if (label != null && !label.trim().isEmpty()) safe.add(label.trim());
        scanItems = Collections.unmodifiableList(safe);
        scanIntervalMillis = Math.max(350L, Math.min(5000L, intervalMillis));
        scanIndex = safe.isEmpty() ? -1 : 0;
    }

    public synchronized Event startSwitchScan(long nowMillis) {
        if (scanItems.isEmpty()) return none();
        scanEnabled = true; scanIndex = 0; lastScanAdvance = nowMillis;
        return new Event(EventType.SCAN_HIGHLIGHT, cursorX, cursorY, scanIndex);
    }

    public synchronized Event advanceSwitchScan(long nowMillis) {
        if (!scanEnabled || scanItems.isEmpty()) return none();
        if (nowMillis - lastScanAdvance < scanIntervalMillis) return none();
        scanIndex = (scanIndex + 1) % scanItems.size();
        lastScanAdvance = nowMillis;
        return new Event(EventType.SCAN_HIGHLIGHT, cursorX, cursorY, scanIndex);
    }

    /** Um toque no interruptor seleciona o item atualmente destacado. */
    public synchronized Event pressSwitch() {
        if (!scanEnabled || scanIndex < 0) return none();
        return new Event(EventType.SCAN_SELECT, cursorX, cursorY, scanIndex);
    }

    public synchronized void stopSwitchScan() { scanEnabled = false; scanIndex = -1; }
    public synchronized float getCursorX() { return cursorX; }
    public synchronized float getCursorY() { return cursorY; }
    public synchronized List<String> getScanItems() { return scanItems; }

    private static Event none() { return new Event(EventType.NONE, 0f, 0f, -1); }
    private static boolean isFinite(float v) { return !Float.isNaN(v) && !Float.isInfinite(v); }
    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
}
