package com.forla.abm;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Avatar 3D procedural leve do ABM: rosto humano estilizado e polo simples, OpenGL ES 2.0. */
public final class ABMAvatar3DView extends GLSurfaceView {
    private final AvatarRenderer renderer;
    public ABMAvatar3DView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        renderer = new AvatarRenderer();
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
    public void setAppearance(int value) { renderer.appearance = Math.max(0, Math.min(4, value)); }
    public void setSpeaking(boolean value) {
        renderer.speaking = value;
        if (!value) renderer.viseme = "rest";
    }
    /** Visema aproximado a partir do intervalo de texto reportado pelo motor TTS. */
    public void setVisemeFromText(String text) {
        if (text == null || text.isEmpty()) { renderer.viseme = "rest"; return; }
        String value = text.toLowerCase(java.util.Locale.ROOT);
        String selected = "rest";
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c == 'a' || c == 'á' || c == 'ã' || c == 'â') { selected = "A"; break; }
            if (c == 'o' || c == 'ó' || c == 'ô' || c == 'u' || c == 'ú') selected = "O";
            else if ((c == 'e' || c == 'é' || c == 'ê' || c == 'i') && "rest".equals(selected)) selected = "E";
        }
        renderer.viseme = selected;
    }
    public void setListening(boolean value) { renderer.listening = value; }
    public void setThinking(boolean value) { renderer.thinking = value; }

    private static final class AvatarRenderer implements Renderer {
        volatile int appearance = 0;
        volatile boolean speaking = false;
        volatile boolean listening = false;
        volatile boolean thinking = false;
        volatile String viseme = "rest";
        private int program, position, mvpHandle, colorHandle;
        private FloatBuffer sphere;
        private int vertexCount;
        private float headTiltRadians = 0f;
        private final float[] projection = new float[16], view = new float[16], model = new float[16], mvp = new float[16];
        private long start = System.currentTimeMillis();
        private final String vertexShader = "attribute vec3 aPosition; uniform mat4 uMVP; void main(){ gl_Position=uMVP*vec4(aPosition,1.0); }";
        private final String fragmentShader = "precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor=uColor; }";
        @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GLES20.glClearColor(0.025f,0.035f,0.07f,1f);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            program = link(vertexShader, fragmentShader);
            position = GLES20.glGetAttribLocation(program,"aPosition");
            mvpHandle = GLES20.glGetUniformLocation(program,"uMVP");
            colorHandle = GLES20.glGetUniformLocation(program,"uColor");
            sphere = makeSphere(24, 32); vertexCount = 24*32*6;
        }
        @Override public void onSurfaceChanged(GL10 gl, int width, int height) {
            GLES20.glViewport(0,0,width,height);
            float ratio = (float)width/Math.max(1,height);
            Matrix.frustumM(projection,0,-ratio,ratio,-1,1,2,10);
            Matrix.setLookAtM(view,0,0,0,4.2f,0,0,0,0,1,0);
        }
        @Override public void onDrawFrame(GL10 gl) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
            float t=(System.currentTimeMillis()-start)/1000f;
            headTiltRadians = (float)Math.toRadians(0.9f * Math.sin(t * 0.62f));
            float blink=(t%4.1f>3.88f || (t%7.3f>7.12f))?0.12f:1f;
            float gazeX = 0.018f*(float)Math.sin(t*0.83f) + (thinking ? 0.035f : 0f);
            float gazeY = 0.012f*(float)Math.sin(t*0.57f) + (listening ? 0.018f : 0f);
            float mouth = 0.035f;
            float mouthWidth = 0.19f;
            if (speaking) {
                float pulse = 0.5f + 0.5f*(float)Math.sin(t*13.0f);
                mouth = 0.035f + 0.035f*pulse;
                if ("A".equals(viseme)) { mouth = 0.12f + 0.025f*pulse; mouthWidth = 0.22f; }
                else if ("E".equals(viseme)) { mouth = 0.075f + 0.018f*pulse; mouthWidth = 0.23f; }
                else if ("O".equals(viseme)) { mouth = 0.105f + 0.02f*pulse; mouthWidth = 0.13f; }
            }
            float[][] palettes={{0.35f,0.55f,0.95f},{0.48f,0.62f,0.88f},{0.20f,0.82f,1.00f},{0.42f,0.52f,0.70f},{0.22f,0.72f,1.00f}};
            float[] c=palettes[appearance];
            // Corpo humano com polo preto simples — sem armadura ou placas de combate.
            draw(0,-1.18f,-0.16f,0.98f,0.62f,0.39f,0.018f,0.025f,0.045f,1f);
            draw(-0.58f,-1.02f,-0.10f,0.48f,0.43f,0.34f,0.018f,0.025f,0.045f,1f);
            draw(0.58f,-1.02f,-0.10f,0.48f,0.43f,0.34f,0.018f,0.025f,0.045f,1f);
            // Pescoço e rosto com proporções mais naturais e tom de pele castanho escuro.
            draw(0,-0.72f,-0.02f,0.29f,0.43f,0.28f,0.34f,0.19f,0.13f,1f);
            draw(0,0.00f,0.00f,0.75f,0.91f,0.53f,0.39f,0.23f,0.17f,1f);
            draw(-0.72f,-0.02f,0.12f,0.13f,0.22f,0.16f,0.36f,0.20f,0.15f,1f);
            draw(0.72f,-0.02f,0.12f,0.13f,0.22f,0.16f,0.36f,0.20f,0.15f,1f);
            // Cabelo curto natural e textura encaracolada.
            draw(0,0.66f,0.02f,0.73f,0.34f,0.48f,0.035f,0.028f,0.026f,1f);
            for (int i=0;i<15;i++) {
                float x=-0.62f+i*0.088f;
                float y=0.73f+(float)Math.sin(i*1.7f)*0.045f;
                draw(x,y,0.18f,0.075f,0.085f,0.075f,0.055f,0.043f,0.038f,1f);
            }
            // Gola e carcela discretas do polo preto.
            draw(-0.16f,-0.79f,0.28f,0.18f,0.12f,0.035f,0.055f,0.065f,0.085f,1f);
            draw(0.16f,-0.79f,0.28f,0.18f,0.12f,0.035f,0.055f,0.065f,0.085f,1f);
            draw(0,-1.02f,0.245f,0.035f,0.20f,0.025f,0.09f,0.10f,0.13f,1f);
            // Pequeno símbolo ABM luminoso no peito: dois anéis de pontos e texto curto.
            for (int i=0;i<12;i++) {
                double a=i*Math.PI/6.0;
                draw(0.52f+(float)Math.cos(a)*0.105f,-1.08f+(float)Math.sin(a)*0.055f,0.27f,
                    0.018f,0.018f,0.018f,0.18f,0.72f,1.00f,1f);
                draw(0.69f+(float)Math.cos(a)*0.105f,-1.08f+(float)Math.sin(a)*0.055f,0.27f,
                    0.018f,0.018f,0.018f,0.18f,0.72f,1.00f,1f);
            }
            draw(0.60f,-1.19f,0.27f,0.12f,0.025f,0.018f,0.22f,0.78f,1.00f,1f);
            // As cinco escolhas alteram apenas o acabamento visual, nunca a personalidade.
            if (appearance == 1) { // Moderno: óculos discretos.
                draw(-0.27f,0.18f,0.55f,0.19f,0.13f,0.025f,0.12f,0.20f,0.28f,0.72f);
                draw(0.27f,0.18f,0.55f,0.19f,0.13f,0.025f,0.12f,0.20f,0.28f,0.72f);
                draw(0,0.18f,0.56f,0.09f,0.018f,0.018f,0.12f,0.20f,0.28f,1f);
            } else if (appearance == 2) { // Futurista: pontos luminosos subtis.
                for (int i=0;i<8;i++) { double a=i*Math.PI/4.0; draw((float)Math.cos(a)*0.91f,(float)Math.sin(a)*0.92f,0.02f,0.035f,0.035f,0.035f,0.20f,0.82f,1f,1f); }
            } else if (appearance == 3) { // Natural: sem acessórios, luz suave nas têmporas.
                draw(-0.68f,0.30f,0.30f,0.035f,0.08f,0.025f,0.48f,0.60f,0.78f,0.7f);
                draw(0.68f,0.30f,0.30f,0.035f,0.08f,0.025f,0.48f,0.60f,0.78f,0.7f);
            } else if (appearance == 4) { // Consciência Digital: halo e partículas azuis.
                draw(0,1.03f,-0.02f,0.42f,0.035f,0.035f,0.18f,0.72f,1f,0.9f);
                for (int i=0;i<6;i++) { double a=i*Math.PI/3.0; draw((float)Math.cos(a)*0.98f,(float)Math.sin(a)*0.78f,0.08f,0.028f,0.028f,0.028f,0.25f,0.78f,1f,1f); }
            }
            // Sobrancelhas, olhos e pupilas com movimento subtil do olhar.
            draw(-0.27f,0.34f,0.48f,0.18f,0.035f,0.035f,0.10f,0.065f,0.055f,1f);
            draw(0.27f,0.34f,0.48f,0.18f,0.035f,0.035f,0.10f,0.065f,0.055f,1f);
            draw(-0.27f,0.18f,0.445f,0.16f,0.090f*blink,0.055f,0.91f,0.86f,0.76f,1f);
            draw(0.27f,0.18f,0.445f,0.16f,0.090f*blink,0.055f,0.91f,0.86f,0.76f,1f);
            draw(-0.27f,0.18f,0.495f,0.055f,0.075f*blink,0.035f,0.08f,0.12f,0.22f,1f);
            draw(0.27f,0.18f,0.495f,0.055f,0.075f*blink,0.035f,0.08f,0.12f,0.22f,1f);
            draw(-0.27f+gazeX,0.18f+gazeY,0.527f,0.018f,0.022f*blink,0.012f,1f,1f,1f,1f);
            draw(0.27f+gazeX,0.18f+gazeY,0.527f,0.018f,0.022f*blink,0.012f,1f,1f,1f,1f);
            // Nariz e boca animada por visemas aproximados do TTS.
            draw(0,-0.04f,0.56f,0.055f,0.13f,0.045f,0.40f,0.22f,0.17f,1f);
            draw(0,-0.285f,0.485f,0.16f,0.018f,0.018f,0.20f,0.12f,0.10f,0.65f);
            draw(0,-0.35f,0.475f,mouthWidth,mouth,0.045f,0.12f,0.025f,0.045f,1f);
            draw(-0.12f,-0.52f,0.43f,0.08f,0.025f,0.02f,0.39f,0.22f,0.17f,1f);
            draw(0.12f,-0.52f,0.43f,0.08f,0.025f,0.02f,0.39f,0.22f,0.17f,1f);
            if (listening) draw(0.0f,0.91f,0.02f,0.045f,0.045f,0.045f,0.20f,0.95f,0.72f,1f);
            if (thinking) draw(0.0f,1.08f,0.0f,0.035f,0.035f,0.035f,0.95f,0.72f,0.22f,1f);
            draw(0,-0.02f,0.515f,0.045f,0.08f,0.025f,0.72f,0.82f,0.96f,1f);
        }
        private void draw(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b,float a) {
            float cosine = (float)Math.cos(headTiltRadians), sine = (float)Math.sin(headTiltRadians);
            float rotatedX = x * cosine - y * sine;
            float rotatedY = x * sine + y * cosine;
            Matrix.setIdentityM(model,0); Matrix.translateM(model,0,rotatedX,rotatedY,z); Matrix.scaleM(model,0,sx,sy,sz);
            float[] mv=new float[16]; Matrix.multiplyMM(mv,0,view,0,model,0); Matrix.multiplyMM(mvp,0,projection,0,mv,0);
            GLES20.glUseProgram(program); GLES20.glUniformMatrix4fv(mvpHandle,1,false,mvp,0); GLES20.glUniform4f(colorHandle,r,g,b,a);
            sphere.position(0); GLES20.glEnableVertexAttribArray(position); GLES20.glVertexAttribPointer(position,3,GLES20.GL_FLOAT,false,0,sphere);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,vertexCount); GLES20.glDisableVertexAttribArray(position);
        }
        private static int link(String vs,String fs) {
            int v=shader(GLES20.GL_VERTEX_SHADER,vs), f=shader(GLES20.GL_FRAGMENT_SHADER,fs), p=GLES20.glCreateProgram();
            GLES20.glAttachShader(p,v); GLES20.glAttachShader(p,f); GLES20.glLinkProgram(p); return p;
        }
        private static int shader(int type,String source) { int s=GLES20.glCreateShader(type); GLES20.glShaderSource(s,source); GLES20.glCompileShader(s); return s; }
        private static FloatBuffer makeSphere(int stacks,int slices) {
            float[] data=new float[stacks*slices*6*3]; int n=0;
            for(int i=0;i<stacks;i++){ double a=Math.PI*i/stacks, b=Math.PI*(i+1)/stacks;
                for(int j=0;j<slices;j++){ double c=2*Math.PI*j/slices,d=2*Math.PI*(j+1)/slices;
                    float[] p1=point(a,c),p2=point(b,c),p3=point(b,d),p4=point(a,d);
                    float[][] tri={p1,p2,p3,p1,p3,p4}; for(float[] p:tri){data[n++]=p[0];data[n++]=p[1];data[n++]=p[2];}
                }
            }
            ByteBuffer bb=ByteBuffer.allocateDirect(data.length*4).order(ByteOrder.nativeOrder()); FloatBuffer fb=bb.asFloatBuffer(); fb.put(data).position(0); return fb;
        }
        private static float[] point(double a,double b){return new float[]{(float)(Math.sin(a)*Math.cos(b)),(float)Math.cos(a),(float)(Math.sin(a)*Math.sin(b))};}
    }
}
