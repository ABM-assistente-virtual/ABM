package com.forla.abm;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import java.util.List;

/** Ponte nativa mínima: só envia ações permitidas ao serviço ABM que o utilizador ativou. */
public final class ABMExecutionBridge {
    private ABMExecutionBridge() {}
    public static boolean isAccessibilityEnabled(Context context) {
        AccessibilityManager manager = (AccessibilityManager) context.getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager == null || !manager.isEnabled()) return false;
        List<AccessibilityServiceInfo> services = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : services) {
            if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null &&
                "com.forla.abm".equals(info.getResolveInfo().serviceInfo.packageName) &&
                "ABMAccessibilityService".equals(info.getResolveInfo().serviceInfo.name.substring(info.getResolveInfo().serviceInfo.name.lastIndexOf('.') + 1))) return true;
        }
        return false;
    }
    public static void openAccessibilitySettings(Context context) {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
    public static boolean dispatch(Context context, String action, boolean confirmed) {
        if (!isAccessibilityEnabled(context) || action == null) return false;
        String a = action.trim().toLowerCase();
        if (!(a.equals("back") || a.equals("home") || a.equals("notifications") || a.equals("quick_settings") ||
              a.equals("scan_start") || a.equals("scan_next") || a.equals("scan_select") || a.equals("scan_stop") ||
              a.equals("cursor_on") || a.equals("cursor_off"))) return false;
        if ((a.equals("back") || a.equals("home") || a.equals("notifications") || a.equals("quick_settings") || a.equals("scan_select")) && !confirmed) return false;
        Intent intent = new Intent(ABMAccessibilityService.ACTION);
        intent.setPackage(context.getPackageName());
        intent.putExtra(ABMAccessibilityService.EXTRA_COMMAND, a);
        context.sendBroadcast(intent, "com.forla.abm.permission.CONTROL_ACCESSIBILITY");
        return true;
    }
}
