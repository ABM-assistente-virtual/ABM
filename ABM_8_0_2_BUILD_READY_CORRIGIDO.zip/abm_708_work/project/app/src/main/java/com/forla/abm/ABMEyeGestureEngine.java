package com.forla.abm;

/**
 * Motor independente de gestos oculares para acessibilidade.
 * Usa probabilidades de olhos abertos fornecidas por um detector facial;
 * não estima a direção do olhar nem identifica o utilizador.
 */
public final class ABMEyeGestureEngine {
    public interface Listener { void onIntentionalBlink(); }
    private final Listener listener;
    private float closedThreshold = 0.22f;
    private long holdMillis = 750L;
    private long debounceMillis = 1200L;
    private long closedSince = -1L;
    private long lastEvent = Long.MIN_VALUE;
    private boolean firedForClosure;

    public ABMEyeGestureEngine(Listener listener) {
        if (listener == null) throw new IllegalArgumentException("listener obrigatório");
        this.listener = listener;
    }

    /** Probabilidades entre 0 e 1; valores negativos ou não finitos significam desconhecido. */
    public synchronized void process(float leftOpen, float rightOpen, long nowMillis) {
        if (!valid(leftOpen) || !valid(rightOpen) || nowMillis < 0) { resetClosure(); return; }
        boolean bothClosed = leftOpen <= closedThreshold && rightOpen <= closedThreshold;
        if (!bothClosed) { resetClosure(); return; }
        if (closedSince < 0) closedSince = nowMillis;
        if (!firedForClosure && nowMillis - closedSince >= holdMillis
                && (lastEvent == Long.MIN_VALUE || nowMillis - lastEvent >= debounceMillis)) {
            firedForClosure = true;
            lastEvent = nowMillis;
            listener.onIntentionalBlink();
        }
    }

    public synchronized void configure(float threshold, long hold, long debounce) {
        if (!valid(threshold) || threshold < 0.05f || threshold > 0.5f) throw new IllegalArgumentException("threshold fora do intervalo");
        if (hold < 400L || hold > 2500L) throw new IllegalArgumentException("hold deve estar entre 400 e 2500 ms");
        if (debounce < 500L || debounce > 5000L) throw new IllegalArgumentException("debounce deve estar entre 500 e 5000 ms");
        closedThreshold = threshold; holdMillis = hold; debounceMillis = debounce; resetClosure();
    }

    public synchronized void reset() { resetClosure(); lastEvent = Long.MIN_VALUE; }
    private void resetClosure() { closedSince = -1L; firedForClosure = false; }
    private static boolean valid(float value) { return Float.isFinite(value) && value >= 0f && value <= 1f; }
}
