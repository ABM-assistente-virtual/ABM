package com.forla.abm;

import androidx.annotation.NonNull;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import java.util.List;

/**
 * Adaptador ML Kit para gestos de fechar os dois olhos intencionalmente.
 * Recebe frames de uma câmara gerida pelo chamador. Não guarda frames, não reconhece
 * identidade e não mede a direção do olhar (gaze tracking).
 */
public final class ABMEyeGestureTracker implements AutoCloseable {
    public interface Listener { void onIntentionalBlink(); void onNoFace(); void onUnavailable(); void onError(Exception error); }
    private final FaceDetector detector;
    private final ABMEyeGestureEngine engine;
    private final Listener listener;
    private boolean closed;

    public ABMEyeGestureTracker(@NonNull Listener listener) {
        this.listener = listener;
        engine = new ABMEyeGestureEngine(() -> { if (!closed) this.listener.onIntentionalBlink(); });
        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .enableTracking().build();
        detector = FaceDetection.getClient(options);
    }

    /** Enviar frames de baixa resolução, sem processar vários simultaneamente. */
    public void process(@NonNull InputImage image, long timestampMillis) {
        if (closed) return;
        detector.process(image).addOnSuccessListener(faces -> {
            if (closed) return;
            Face face = largestFace(faces);
            if (face == null) { listener.onNoFace(); return; }
            Float left = face.getLeftEyeOpenProbability();
            Float right = face.getRightEyeOpenProbability();
            if (left == null || right == null) { listener.onUnavailable(); return; }
            engine.process(left, right, timestampMillis);
        }).addOnFailureListener(error -> { if (!closed) listener.onError(error); });
    }

    public void configure(float closedThreshold, long holdMillis, long debounceMillis) {
        engine.configure(closedThreshold, holdMillis, debounceMillis);
    }
    private static Face largestFace(List<Face> faces) {
        Face best = null; int area = -1;
        for (Face face : faces) { int candidate = face.getBoundingBox().width() * face.getBoundingBox().height(); if (candidate > area) { area = candidate; best = face; } }
        return best;
    }
    @Override public void close() { closed = true; detector.close(); engine.reset(); }
}
