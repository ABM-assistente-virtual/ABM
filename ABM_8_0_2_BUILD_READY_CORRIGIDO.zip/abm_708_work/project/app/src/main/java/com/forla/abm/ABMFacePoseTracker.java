package com.forla.abm;

import androidx.annotation.NonNull;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import java.util.List;

/** Adaptador ML Kit: recebe frames fornecidos pela câmara e emite pose da cabeça.
 * Não faz reconhecimento de identidade, não guarda imagens e não desbloqueia o telefone.
 * O chamador deve controlar permissões, ciclo de vida e fechar este tracker.
 */
public final class ABMFacePoseTracker implements AutoCloseable {
    public interface Listener {
        void onHeadPose(float yawNormalized, float pitchNormalized);
        void onNoFace();
        void onError(Exception error);
    }

    private final FaceDetector detector;
    private final ABMHeadPoseMapper mapper = new ABMHeadPoseMapper();
    private final Listener listener;
    private boolean closed;

    public ABMFacePoseTracker(@NonNull Listener listener) {
        this.listener = listener;
        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .enableTracking()
            .build();
        detector = FaceDetection.getClient(options);
    }

    /** Calibrar olhando para o centro do ecrã, sem inclinar a cabeça. */
    public void calibrateFrom(InputImage image) {
        if (closed) return;
        detector.process(image)
            .addOnSuccessListener(faces -> {
                Face face = largestFace(faces);
                if (face == null) { listener.onNoFace(); return; }
                mapper.calibrate(face.getHeadEulerAngleY(), face.getHeadEulerAngleX());
            })
            .addOnFailureListener(listener::onError);
    }

    /** Processar um frame. Use frames reduzidos e não processe vários em paralelo. */
    public void process(InputImage image) {
        if (closed) return;
        detector.process(image)
            .addOnSuccessListener(faces -> {
                if (closed) return;
                Face face = largestFace(faces);
                if (face == null) { listener.onNoFace(); return; }
                float[] pose = mapper.map(face.getHeadEulerAngleY(), face.getHeadEulerAngleX());
                if (pose != null) listener.onHeadPose(pose[0], pose[1]);
            })
            .addOnFailureListener(error -> { if (!closed) listener.onError(error); });
    }

    public void setMovementRange(float yawDegrees, float pitchDegrees) {
        mapper.setRanges(yawDegrees, pitchDegrees);
    }

    private static Face largestFace(List<Face> faces) {
        Face best = null;
        int area = -1;
        for (Face face : faces) {
            int candidate = face.getBoundingBox().width() * face.getBoundingBox().height();
            if (candidate > area) { area = candidate; best = face; }
        }
        return best;
    }

    @Override public void close() {
        closed = true;
        detector.close();
    }
}
