package com.forla.abm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

/** Serviço visível. Não mantém microfone/câmara ativos; pode observar apenas estado de chamada
 * quando o utilizador ativa essa opção e concede READ_PHONE_STATE. */
public class ABMForegroundService extends Service {
    public static final String PREFS = "abm_settings";
    public static final String KEY_CALL_MONITOR = "call_monitor_enabled";
    private static final String CHANNEL = "abm_status";
    private static final String CALL_CHANNEL = "abm_calls";
    private TelephonyManager telephony;
    private PhoneStateListener callListener;

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
        startForeground(5201, buildStatusNotification());
        configureCallMonitor();
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Estado do ABM", NotificationManager.IMPORTANCE_LOW));
            nm.createNotificationChannel(new NotificationChannel(CALL_CHANNEL, "Avisos de chamadas", NotificationManager.IMPORTANCE_DEFAULT));
        }
    }

    private Notification buildStatusNotification() {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("ABM está em execução")
                .setContentText("Microfone/câmara apenas por ação visível do utilizador.")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi).setOngoing(true).build();
    }

    private void configureCallMonitor() {
        if (telephony != null && callListener != null) {
            try { telephony.listen(callListener, PhoneStateListener.LISTEN_NONE); } catch (Exception ignored) { }
            telephony = null; callListener = null;
        }
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean(KEY_CALL_MONITOR, false)) return;
        if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return;
        try {
            telephony = (TelephonyManager)getSystemService(TELEPHONY_SERVICE);
            callListener = new PhoneStateListener() {
                @Override public void onCallStateChanged(int state, String incomingNumber) {
                    if (state == TelephonyManager.CALL_STATE_RINGING) showIncomingCallNotice();
                }
            };
            telephony.listen(callListener, PhoneStateListener.LISTEN_CALL_STATE);
        } catch (SecurityException ignored) { }
    }

    private void showIncomingCallNotice() {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 2, open, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CALL_CHANNEL) : new Notification.Builder(this);
        Notification n = b.setContentTitle("ABM: chamada recebida")
                .setContentText("O telefone está a receber uma chamada. Abre o telefone para decidir se atendes.")
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setAutoCancel(true).setContentIntent(pi).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(5202, n);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        configureCallMonitor();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (telephony != null && callListener != null) {
            try { telephony.listen(callListener, PhoneStateListener.LISTEN_NONE); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
