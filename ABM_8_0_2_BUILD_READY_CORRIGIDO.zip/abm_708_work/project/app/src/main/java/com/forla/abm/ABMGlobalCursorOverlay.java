package com.forla.abm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Cursor visual global; a janela é não tocável e não intercepta os gestos do utilizador. */
public final class ABMGlobalCursorOverlay extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float x = 0.5f, y = 0.5f;
    public ABMGlobalCursorOverlay(Context context) { super(context); setContentDescription("Cursor global de acessibilidade ABM"); }
    public void setPosition(float nx, float ny) {
        if (Float.isNaN(nx) || Float.isNaN(ny) || Float.isInfinite(nx) || Float.isInfinite(ny)) return;
        x = Math.max(0f, Math.min(1f, nx)); y = Math.max(0f, Math.min(1f, ny)); postInvalidate();
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float px = x * getWidth(), py = y * getHeight();
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(5f);
        canvas.drawCircle(px, py, 25f, paint);
        paint.setStyle(Paint.Style.FILL); canvas.drawCircle(px, py, 5f, paint);
    }
}
