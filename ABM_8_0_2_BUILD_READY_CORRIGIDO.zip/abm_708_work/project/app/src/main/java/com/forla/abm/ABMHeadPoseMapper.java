package com.forla.abm;

/** Converte ângulos relativos da cabeça em coordenadas normalizadas para o cursor.
 * Não identifica pessoas: apenas transforma pose facial em movimento assistivo.
 */
public final class ABMHeadPoseMapper {
    private float neutralYaw;
    private float neutralPitch;
    private boolean calibrated;
    private float yawRange = 25f;
    private float pitchRange = 20f;

    public synchronized void setRanges(float yawDegrees, float pitchDegrees) {
        yawRange = clamp(yawDegrees, 8f, 50f);
        pitchRange = clamp(pitchDegrees, 8f, 45f);
    }

    public synchronized boolean calibrate(float yawDegrees, float pitchDegrees) {
        if (!finite(yawDegrees) || !finite(pitchDegrees)) return false;
        neutralYaw = yawDegrees;
        neutralPitch = pitchDegrees;
        calibrated = true;
        return true;
    }

    public synchronized float[] map(float yawDegrees, float pitchDegrees) {
        if (!calibrated || !finite(yawDegrees) || !finite(pitchDegrees)) return null;
        float yaw = clamp((yawDegrees - neutralYaw) / yawRange, -1f, 1f);
        float pitch = clamp((pitchDegrees - neutralPitch) / pitchRange, -1f, 1f);
        return new float[]{yaw, pitch};
    }

    public synchronized boolean isCalibrated() { return calibrated; }
    public synchronized void reset() { calibrated = false; }
    private static boolean finite(float v) { return !Float.isNaN(v) && !Float.isInfinite(v); }
    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
}
