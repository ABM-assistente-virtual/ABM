package com.forla.abm;

/** Estado simples do varrimento sequencial, independente das APIs Android. */
public final class ABMScanEngine {
    private int count;
    private int index = -1;
    public void reset(int targetCount) { count = Math.max(0, targetCount); index = -1; }
    public int next() {
        if (count <= 0) { index = -1; return -1; }
        index = (index + 1) % count;
        return index;
    }
    public int current() { return index; }
    public int count() { return count; }
    public boolean hasSelection() { return index >= 0 && index < count; }
}
