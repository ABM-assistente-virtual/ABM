package com.forla.abm;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Armazena tokens locais cifrados com AES-256-GCM e chave não exportável do Android Keystore. */
public final class ABMSecureStore {
    private static final String PREFS = "abm_secure_store_v1";
    private static final String KEY_ALIAS = "com.forla.abm.secure_store.aes.v1";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private final SharedPreferences preferences;

    public ABMSecureStore(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        java.security.Key existing = keyStore.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;

        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }

    public synchronized void putString(String name, String value) throws Exception {
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Nome de segredo vazio.");
        if (value == null) { remove(name); return; }
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] iv = cipher.getIV();
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        ByteBuffer payload = ByteBuffer.allocate(1 + iv.length + encrypted.length);
        payload.put((byte) iv.length).put(iv).put(encrypted);
        String encoded = Base64.encodeToString(payload.array(), Base64.NO_WRAP);
        if (!preferences.edit().putString(name, encoded).commit()) throw new IllegalStateException("Não foi possível guardar o segredo cifrado.");
    }

    public synchronized String getString(String name, String defaultValue) {
        String encoded = preferences.getString(name, null);
        if (encoded == null) return defaultValue;
        try {
            byte[] payloadBytes = Base64.decode(encoded, Base64.NO_WRAP);
            ByteBuffer payload = ByteBuffer.wrap(payloadBytes);
            int ivLength = payload.get() & 0xff;
            if (ivLength < 12 || ivLength > 16 || payload.remaining() <= ivLength) return defaultValue;
            byte[] iv = new byte[ivLength]; payload.get(iv);
            byte[] encrypted = new byte[payload.remaining()]; payload.get(encrypted);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception error) {
            // Falha fechada: nunca devolve o conteúdo cifrado nem tenta armazená-lo em texto simples.
            return defaultValue;
        }
    }

    public synchronized void remove(String name) {
        preferences.edit().remove(name).commit();
    }
}
