package com.forla.abm;

/** Mapeia teclas direcionais/interruptores para um cursor assistivo normalizado. */
public final class ABMSwitchInputEngine {
    public enum Action { NONE, MOVE, SELECT }
    private float x = 0.5f, y = 0.5f;
    private final float step;
    public ABMSwitchInputEngine() { this(0.045f); }
    public ABMSwitchInputEngine(float step) { this.step = Math.max(0.01f, Math.min(0.20f, step)); }
    public Action key(int keyCode) {
        switch (keyCode) {
            case 19: y -= step; break; // DPAD_UP
            case 20: y += step; break; // DPAD_DOWN
            case 21: x -= step; break; // DPAD_LEFT
            case 22: x += step; break; // DPAD_RIGHT
            case 23: case 66: return Action.SELECT; // DPAD_CENTER / ENTER
            default: return Action.NONE;
        }
        x = clamp(x); y = clamp(y); return Action.MOVE;
    }
    private float clamp(float v) { return Math.max(0.02f, Math.min(0.98f, v)); }
    public float getX() { return x; }
    public float getY() { return y; }
}
