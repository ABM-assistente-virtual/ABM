package com.forla.abm;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Modelo local de perfis e comunicação alternativa (CAA). Não recolhe dados biométricos. */
public final class ABMUniversalAccessEngine {
    public enum Profile {
        STANDARD("Padrão", "Toque, voz e teclado"),
        MOTOR("Mobilidade reduzida", "Voz, varrimento e interruptor compatível"),
        NON_SPEAKING("Sem fala", "Símbolos, frases, teclado e saída por voz"),
        BLIND("Baixa visão ou cegueira", "Leitor de ecrã, áudio e comandos falados"),
        DEAF("Surdez ou baixa audição", "Texto, legendas, sinais visuais e vibração"),
        DEAFBLIND("Surdocegueira", "Compatibilidade com Braille e dispositivos táteis externos"),
        COGNITIVE("Apoio cognitivo", "Passos simples, linguagem clara e confirmações"),
        CUSTOM("Personalizado", "Combinação escolhida pelo utilizador");

        public final String title;
        public final String guidance;
        Profile(String title, String guidance) { this.title = title; this.guidance = guidance; }
    }

    public static final class Phrase {
        public final String label;
        public final String spoken;
        public final String category;
        Phrase(String label, String spoken, String category) {
            this.label = label; this.spoken = spoken; this.category = category;
        }
    }

    private static final List<Phrase> PHRASES = Collections.unmodifiableList(Arrays.asList(
        new Phrase("Sim", "Sim", "Respostas"),
        new Phrase("Não", "Não", "Respostas"),
        new Phrase("Não entendi", "Não entendi. Podes explicar de outra maneira?", "Respostas"),
        new Phrase("Preciso de ajuda", "Preciso de ajuda, por favor.", "Ajuda"),
        new Phrase("Chama alguém", "Por favor, chama alguém para me ajudar.", "Ajuda"),
        new Phrase("Emergência", "É uma emergência. Preciso de ajuda agora.", "Ajuda"),
        new Phrase("Tenho sede", "Tenho sede. Podes trazer água?", "Necessidades"),
        new Phrase("Tenho fome", "Tenho fome. Podes trazer comida?", "Necessidades"),
        new Phrase("Tenho dor", "Estou com dor. Preciso de assistência.", "Necessidades"),
        new Phrase("Quero descansar", "Quero descansar um pouco.", "Necessidades"),
        new Phrase("Quero falar", "Quero comunicar contigo.", "Comunicação"),
        new Phrase("Obrigado", "Obrigado pela ajuda.", "Comunicação")
    ));

    private ABMUniversalAccessEngine() { }
    public static Profile[] profiles() { return Profile.values(); }
    public static List<Phrase> phrases() { return PHRASES; }
    public static boolean isValidProfile(String name) {
        if (name == null) return false;
        try { Profile.valueOf(name); return true; }
        catch (IllegalArgumentException ex) { return false; }
    }
}
