package com.forla.abm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.objects.ObjectDetection;
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.android.gms.tasks.Task;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.GridLayout;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.util.ArrayList;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 100;
    private static final int REQ_PHONE = 101;
    private static final int REQ_SPEECH = 102;
    private static final int REQ_FILE = 103;
    private static final int REQ_IMAGE = 104;
    private static final int REQ_CAMERA = 105;
    private static final int REQ_WAV = 106;
    private static final int REQ_VIDEO_ANALYSIS = 107;
    private EditText input;
    private TextView transcript;
    private TextView avatarStatus;
    private ABMAvatar3DView avatar3D;
    private TextToSpeech tts;
    private PyObject bridge;
    private boolean ttsReady = false;
    private SharedPreferences prefs;
    private ABMSecureStore secureStore;
    private SpeechRecognizer speechRecognizer;
    private boolean continuousListening = false;
    private boolean wakeWordMode = false;
    private boolean speechBusy = false;
    // Retoma a ação solicitada depois da autorização Android do microfone.
    private boolean pendingSingleSpeech = false;
    private boolean pendingContinuousListening = false;
    private final Handler speechHandler = new Handler(Looper.getMainLooper());
    private String lastSpokenReply = "";
    private volatile String currentTtsText = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(ABMForegroundService.PREFS, MODE_PRIVATE);
        secureStore = new ABMSecureStore(this);
        buildUi();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("pt", "PT"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                    result = tts.setLanguage(new Locale("pt", "BR"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { runOnUiThread(() -> { if (avatar3D != null) { avatar3D.setSpeaking(true); avatar3D.setListening(false); } }); }
                    @Override public void onRangeStart(String utteranceId, int start, int end, int frame) {
                        String spoken = currentTtsText;
                        int safeStart = Math.max(0, Math.min(start, spoken.length()));
                        int safeEnd = Math.max(safeStart, Math.min(end, spoken.length()));
                        String segment = spoken.substring(safeStart, safeEnd);
                        runOnUiThread(() -> { if (avatar3D != null) avatar3D.setVisemeFromText(segment); });
                    }
                    @Override public void onDone(String utteranceId) { runOnUiThread(() -> { if (avatar3D != null) avatar3D.setSpeaking(false); }); }
                    @Override public void onError(String utteranceId) { runOnUiThread(() -> { if (avatar3D != null) avatar3D.setSpeaking(false); }); }
                });
            }
        });
        initializeBrain();
        startVisibleService();
        append("ABM", "Sou o teu companheiro digital experimental. Diz ou escreve o que precisas.");
    }

    private void initializeBrain() {
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            bridge = Python.getInstance().getModule("abm_android");
            append("Sistema", bridge.callAttr("initialize", getFilesDir().getAbsolutePath(), secureStore).toString());
        } catch (Exception e) {
            append("ERRO", "Não consegui iniciar o cérebro Python: " + e.getMessage());
        }
    }

    private void startVisibleService() {
        Intent service = new Intent(this, ABMForegroundService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 12, 16, 12);
        root.setBackgroundColor(0xFF101522);

        TextView title = new TextView(this);
        title.setText("ABM  |  COMPANHEIRO DIGITAL");
        title.setTextColor(0xFFFFFFFF); title.setTextSize(20); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView subtitle = new TextView(this);
        subtitle.setText("ABM 8.0.2 • Avatar humano com polo ABM • Android 8.0+");
        subtitle.setTextColor(0xFFB8C2D8); subtitle.setTextSize(11); subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        avatar3D = new ABMAvatar3DView(this);
        int avatarHeight = (int)(210 * getResources().getDisplayMetrics().density);
        root.addView(avatar3D, new LinearLayout.LayoutParams(-1, avatarHeight));
        avatarStatus = new TextView(this);
        avatarStatus.setTextColor(0xFFE0D7FF); avatarStatus.setTextSize(13); avatarStatus.setGravity(Gravity.CENTER);
        updateAvatarStatus();
        root.addView(avatarStatus, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        transcript = new TextView(this); transcript.setTextColor(0xFFF1F4FA);
        transcript.setTextSize(15); transcript.setPadding(8, 14, 8, 14);
        scroll.addView(transcript);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.setMargins(0, 10, 0, 8); root.addView(scroll, sp);

        input = new EditText(this);
        input.setTextColor(0xFFFFFFFF); input.setHintTextColor(0xFF9AA7BD);
        input.setHint("Escreve aqui ou carrega em Falar..."); input.setMinLines(2);
        root.addView(input, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row1 = new LinearLayout(this);
        addButton(row1, "Enviar", v -> sendText());
        addButton(row1, "Falar", v -> startSpeech());
        addButton(row1, "Ouvir resposta", v -> speakLast());
        addButton(row1, "Ouvir sempre", v -> toggleContinuousListening());
        root.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        addButton(row2, "Código/ficheiro", v -> chooseFile("*/*", REQ_FILE));
        addButton(row2, "Música offline", v -> chooseFile("audio/*", REQ_FILE));
        addButton(row2, "Vídeo offline", v -> chooseFile("video/*", REQ_FILE));
        root.addView(row2);

        LinearLayout row3 = new LinearLayout(this);
        addButton(row3, "Procurar online", v -> searchOnline());
        addButton(row3, "Câmara", v -> openCamera());
        addButton(row3, "Analisar imagem", v -> chooseFile("image/*", REQ_IMAGE));
        addButton(row3, "Analisar vídeo", v -> chooseFile("video/*", REQ_VIDEO_ANALYSIS));
        root.addView(row3);

        LinearLayout row4 = new LinearLayout(this);
        addButton(row4, "Avatar / aparência", v -> showAvatarOptions());
        addButton(row4, "Pausar mídia", v -> pauseMedia());
        addButton(row4, "Avisos chamadas", v -> toggleCallMonitor());
        addButton(row4, "Segurança", v -> requestDeviceAuthentication());
        root.addView(row4);

        LinearLayout row5 = new LinearLayout(this);
        addButton(row5, "Estado", v -> runCommand("/estado"));
        addButton(row5, "Guardar", v -> runCommand("/guardar"));
        addButton(row5, "Ajuda", v -> showHelp());
        root.addView(row5);

        LinearLayout row6 = new LinearLayout(this);
        addButton(row6, "Analisar WAV", v -> chooseFile("audio/wav", REQ_WAV));
        addButton(row6, "ABM Global", v -> openCloudPanel());
        addButton(row6, "Entrar na fila", v -> cloudQueueAction(true));
        addButton(row6, "Ver fila", v -> cloudQueueAction(false));
        root.addView(row6);

        LinearLayout row7 = new LinearLayout(this);
        addButton(row7, "Sair da fila", v -> cloudQueueLeave());
        addButton(row7, "Acessibilidade", v -> openAccessibilitySettings());
        addButton(row7, "Modo mãos livres", v -> toggleContinuousListening());
        root.addView(row7);

        LinearLayout row9 = new LinearLayout(this);
        addButton(row9, "Comunicação", v -> openCommunicationBoard());
        addButton(row9, "Perfil adaptativo", v -> chooseAccessProfile());
        addButton(row9, "Câmara acessível", v -> startActivity(new Intent(this, ABMLiveAccessActivity.class)));
        root.addView(row9);

        LinearLayout row8 = new LinearLayout(this);
        addButton(row8, "Perguntar à IA Cloud", v -> cloudAgentAction(false));
        addButton(row8, "Pesquisar com IA", v -> cloudAgentAction(true));
        root.addView(row8);

        TextView foot = new TextView(this);
        foot.setText("Audição contínua apenas quando ativada e com a aplicação visível. Palavra-chave: ABM.");
        foot.setTextColor(0xFF9AA7BD); foot.setTextSize(10); foot.setGravity(Gravity.CENTER);
        root.addView(foot);
        setContentView(root);
    }



    private static final String[] AVATAR_APPEARANCES = {
        "Clássico", "Moderno", "Futurista",
        "Natural", "Consciência Digital"
    };
    private static final String[] AVATAR_SYMBOLS = {"◉", "◇", "✧", "▣", "✺"};

    private void updateAvatarStatus() {
        if (avatarStatus == null || prefs == null) return;
        int selected = Math.max(0, Math.min(4, prefs.getInt("abm_avatar_appearance", 0)));
        avatarStatus.setText(AVATAR_SYMBOLS[selected] + "  Avatar: " + AVATAR_APPEARANCES[selected]
            + "  •  Personalidade: Consciência Digital");
        if (avatar3D != null) avatar3D.setAppearance(selected);
    }

    private void showAvatarOptions() {
        int selected = Math.max(0, Math.min(4, prefs.getInt("abm_avatar_appearance", 0)));
        new AlertDialog.Builder(this)
            .setTitle("Escolher aparência do avatar")
            .setSingleChoiceItems(AVATAR_APPEARANCES, selected, (dialog, which) -> {
                prefs.edit().putInt("abm_avatar_appearance", which).apply();
                updateAvatarStatus();
                append("ABM INTERFACE", "Aparência selecionada: " + AVATAR_APPEARANCES[which]
                    + ". A personalidade permanece Consciência Digital.");
                dialog.dismiss();
            })
            .setMessage("Escolhe uma das cinco aparências. A personalidade e o comportamento permanecem sempre na opção 5: Consciência Digital.")
            .setNegativeButton("Fechar", null)
            .show();
    }

    private void openCloudPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(24, 12, 24, 4);
        EditText url = new EditText(this);
        url.setSingleLine(true);
        url.setHint("URL HTTPS da API ABM Global");
        url.setText(prefs.getString("abm_cloud_url", ""));
        box.addView(url);
        EditText email = new EditText(this);
        email.setSingleLine(true);
        email.setHint("Email da conta");
        email.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        box.addView(email);
        EditText password = new EditText(this);
        password.setSingleLine(true);
        password.setHint("Palavra-passe");
        password.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(password);
        new AlertDialog.Builder(this).setTitle("ABM Global Cloud")
            .setMessage("Liga esta aplicação à plataforma global. Usa apenas o endereço HTTPS fornecido pelo administrador.")
            .setView(box)
            .setPositiveButton("Entrar", (dialog, which) -> cloudAccountAction(url.getText().toString(), email.getText().toString(), password.getText().toString(), false))
            .setNeutralButton("Criar conta", (dialog, which) -> cloudAccountAction(url.getText().toString(), email.getText().toString(), password.getText().toString(), true))
            .setNegativeButton("Cancelar", null).show();
    }

    private void cloudAccountAction(String base, String email, String password, boolean register) {
        String cleanBase = base == null ? "" : base.trim().replaceAll("/+$", "");
        if (!cleanBase.startsWith("https://") || email.trim().isEmpty() || password.length() < 10) {
            append("ABM Cloud", "Indica um URL HTTPS, email e palavra-passe com pelo menos 10 caracteres.");
            return;
        }
        prefs.edit().putString("abm_cloud_url", cleanBase).apply();
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("email", email.trim()); body.put("password", password);
                JSONObject result = CloudApiClient.request(cleanBase,
                    register ? "/v1/accounts/register" : "/v1/accounts/login", "POST", null, body);
                if (register) {
                    runOnUiThread(() -> append("ABM Cloud", "Conta criada. Agora entra com as tuas credenciais."));
                } else {
                    String token = result.optString("access_token", "");
                    if (token.isEmpty()) throw new Exception("A API não devolveu token de sessão.");
                    secureStore.putString("abm_cloud_token", token);
                    runOnUiThread(() -> append("ABM Cloud", "Sessão iniciada. A conta está ligada à nuvem."));
                }
            } catch (Exception e) {
                runOnUiThread(() -> append("ABM Cloud — erro", e.getMessage() == null ? "Falha de ligação." : e.getMessage()));
            }
        }).start();
    }

    private void cloudAgentAction(boolean research) {
        String base = prefs.getString("abm_cloud_url", "");
        String token = secureStore.getString("abm_cloud_token", "");
        String question = input.getText().toString().trim();
        if (base.isEmpty() || token.isEmpty()) {
            append("ABM Cloud", "Liga primeiro a tua conta no botão ABM Global."); return;
        }
        if (question.isEmpty()) {
            append("ABM Cloud", "Escreve primeiro a pergunta ou o tema no campo de texto."); return;
        }
        input.setText(""); append("Tu", question);
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put(research ? "query" : "question", question);
                JSONObject result = CloudApiClient.request(base,
                    research ? "/v1/agent/research" : "/v1/agent/ask", "POST", token, body);
                String answer = research ? result.optString("summary", "Sem resumo.") : result.optString("answer", "Sem resposta.");
                JSONArray sources = result.optJSONArray("sources");
                if (research && sources != null) {
                    for (int i = 0; i < sources.length(); i++) {
                        JSONObject source = sources.optJSONObject(i);
                        if (source != null) answer += "\n[Fonte] " + source.optString("title") + " — " + source.optString("url");
                    }
                }
                final String finalAnswer = answer;
                runOnUiThread(() -> { append(research ? "ABM Pesquisa" : "ABM Cloud IA", finalAnswer); speak(finalAnswer); });
            } catch (Exception e) {
                runOnUiThread(() -> append("ABM Cloud — erro", e.getMessage() == null ? "Falha no serviço de IA." : e.getMessage()));
            }
        }).start();
    }

    private void cloudQueueAction(boolean join) {
        String base = prefs.getString("abm_cloud_url", "");
        String token = secureStore.getString("abm_cloud_token", "");
        if (base.isEmpty() || token.isEmpty()) { append("ABM Cloud", "Primeiro liga a tua conta no botão ABM Global."); return; }
        new Thread(() -> {
            try {
                JSONObject result;
                if (join) {
                    result = CloudApiClient.request(base, "/v1/queue/join", "POST", token, null);
                    secureStore.putString("abm_cloud_ticket", result.optString("ticket", ""));
                } else {
                    String ticket = secureStore.getString("abm_cloud_ticket", "");
                    if (ticket.isEmpty()) throw new Exception("Não existe ticket de espera guardado.");
                    result = CloudApiClient.request(base, "/v1/queue/" + ticket, "GET", token, null);
                }
                String message = join ? "Fila: " + result.optString("state") + ". Posição: " + result.optInt("queue_position") :
                    "Estado: " + result.optString("state") + ". Posição: " + result.optInt("queue_position");
                runOnUiThread(() -> append("ABM Cloud", message));
            } catch (Exception e) {
                runOnUiThread(() -> append("ABM Cloud — erro", e.getMessage() == null ? "Falha na fila." : e.getMessage()));
            }
        }).start();
    }

    private void cloudQueueLeave() {
        String base = prefs.getString("abm_cloud_url", "");
        String token = secureStore.getString("abm_cloud_token", "");
        String ticket = secureStore.getString("abm_cloud_ticket", "");
        if (base.isEmpty() || token.isEmpty() || ticket.isEmpty()) {
            append("ABM Cloud", "Não existe uma sessão de fila ativa neste telefone.");
            return;
        }
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject(); body.put("ticket", ticket);
                JSONObject result = CloudApiClient.request(base, "/v1/queue/leave", "POST", token, body);
                secureStore.remove("abm_cloud_ticket");
                runOnUiThread(() -> append("ABM Cloud", result.optBoolean("left") ? "Saíste da fila." : "O ticket já não está ativo ou não pertence à tua conta."));
            } catch (Exception e) {
                runOnUiThread(() -> append("ABM Cloud — erro", e.getMessage() == null ? "Não foi possível sair da fila." : e.getMessage()));
            }
        }).start();
    }

    private void addButton(LinearLayout row, String label, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(label); b.setTextSize(10); b.setOnClickListener(listener);
        row.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void append(String who, String message) {
        if (transcript != null) transcript.append(who + ": " + message + "\n\n");
    }

    private void sendText() {
        String message = input.getText().toString().trim();
        if (message.isEmpty()) return;
        input.setText(""); append("Tu", message); runCommand(message);
    }

    private void runCommand(String message) {
        String low = message.toLowerCase(new Locale("pt", "PT")).trim();
        try {
            if (low.startsWith("/ferramenta executar ")) {
                runUniversalToolExecution(message);
                return;
            }
            ABMAccessibilityEngine.Result accessibility = ABMAccessibilityEngine.interpret(message);
            switch (accessibility.action) {
                case BACK: sendAccessibilityAction("back"); return;
                case HOME: sendAccessibilityAction("home"); return;
                case NOTIFICATIONS: sendAccessibilityAction("notifications"); return;
                case QUICK_SETTINGS: sendAccessibilityAction("quick_settings"); return;
                case CURSOR_ON: sendAccessibilityAction("cursor_on"); return;
                case CURSOR_OFF: sendAccessibilityAction("cursor_off"); return;
                case SELECT: confirmVoiceAction("select", "Queres selecionar o elemento indicado? Esta ação pode ativar um botão na aplicação aberta."); return;
                case SCAN_START: sendAccessibilityAction("scan_start"); return;
                case SCAN_NEXT: sendAccessibilityAction("scan_next"); return;
                case SCAN_SELECT: confirmVoiceAction("scan_select", "Queres ativar o elemento atualmente destacado?"); return;
                case SCAN_STOP: sendAccessibilityAction("scan_stop"); return;
                case OPEN_YOUTUBE: launchPackage("com.google.android.youtube"); return;
                case OPEN_WHATSAPP: launchPackage("com.whatsapp"); return;
                case OPEN_SETTINGS: startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); return;
                case READ_LAST_REPLY: speakLast(); return;
                case STOP_SPEAKING:
                    if (tts != null) tts.stop();
                    append("ABM", "Voz interrompida."); return;
                case HELP:
                    speak("Podes dizer: volta, início, abre notificações, abre definições, ativa cursor, desativa cursor, inicia varrimento, próximo elemento, seleciona, para varrimento, abre YouTube, lê a resposta ou para de falar.");
                    showHelp(); return;
                default: break;
            }
            if (low.contains("desbloqueia") || low.contains("autentica-me")) { requestDeviceAuthentication(); return; }
            if (low.startsWith("procura música ") || low.startsWith("procura musica ") || low.startsWith("procura vídeo ") || low.startsWith("procura video ") || low.startsWith("toca música ") || low.startsWith("toca musica ")) {
                String q = message.substring(message.indexOf(' ') + 1).trim();
                String[] prefixes = {"música ", "musica ", "vídeo ", "video "};
                for (String p : prefixes) if (q.toLowerCase().startsWith(p)) q = q.substring(p.length());
                openYoutubeSearch(q); return;
            }
            if (low.contains("abre os meus ficheiros") || low.contains("abre o meu código") || low.contains("abre o meu codigo") || low.contains("abre o gestor de ficheiros")) {
                chooseFile("*/*", REQ_FILE); return;
            }
            if (low.startsWith("envia mensagem para ") || low.startsWith("manda mensagem para ")) {
                String prefix = low.startsWith("envia mensagem para ") ? "envia mensagem para " : "manda mensagem para ";
                String rest = message.substring(prefix.length()).trim();
                int split = rest.indexOf(' ');
                if (split < 1 || split == rest.length() - 1) {
                    append("ABM", "Diz: envia mensagem para NÚMERO TEXTO DA MENSAGEM."); return;
                }
                String number = rest.substring(0, split).replaceAll("[^+0-9]", "");
                String body = rest.substring(split + 1).trim();
                Intent sms = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)));
                sms.putExtra("sms_body", body);
                if (sms.resolveActivity(getPackageManager()) != null) {
                    startActivity(sms);
                    append("ABM", "Abri a aplicação de mensagens com o destinatário e texto preenchidos. Revê e carrega em Enviar; o ABM não envia sem a tua confirmação.");
                } else append("ABM", "Não encontrei uma aplicação de SMS disponível.");
                return;
            }
            if (low.startsWith("liga para ") || low.startsWith("telefonar ")) {
                String number = message.substring(message.indexOf(' ') + 1).trim();
                Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)));
                startActivity(dial); append("ABM", "Abri o marcador. Confirma manualmente antes de ligar."); return;
            }
            if (low.startsWith("abre ") && low.length() > 5) {
                String app = low.substring(5).trim();
                if (app.contains("câmara") || app.contains("camera")) { openCamera(); return; }
                if (app.contains("música") || app.contains("musica")) { chooseFile("audio/*", REQ_FILE); return; }
                if (app.contains("vídeo") || app.contains("video")) { chooseFile("video/*", REQ_FILE); return; }
                if (launchAppByName(app)) return;
            }
            if (bridge == null) { append("ABM", "O núcleo Python ainda não está disponível."); return; }
            if (runUniversalTask(message)) return;
            if (avatar3D != null) avatar3D.setThinking(true);
            String answer;
            try { answer = bridge.callAttr("command", message).toString(); }
            finally { if (avatar3D != null) avatar3D.setThinking(false); }
            append("ABM", answer);
            speak(answer);
        } catch (Exception e) { append("ABM", "Não consegui concluir a ação: " + e.getMessage()); }
    }

    /** Confirma ações de seleção recebidas por voz antes de tocar/ativar elementos. */
    private void confirmVoiceAction(String command, String message) {
        new AlertDialog.Builder(this)
            .setTitle("Confirmar comando de voz")
            .setMessage(message)
            .setNegativeButton("Cancelar", (dialog, which) -> append("ABM", "Comando cancelado. Nenhum elemento foi ativado."))
            .setPositiveButton("Confirmar", (dialog, which) -> sendAccessibilityAction(command))
            .show();
    }

    /** Liga a execução preparada do catálogo Python ao adaptador Android real. */
    private void runUniversalToolExecution(String command) {
        if (bridge == null) { append("ABM", "O núcleo Python ainda não está disponível."); return; }
        String[] parts = command.trim().split("\\s+");
        if (parts.length < 3 || parts.length > 4) {
            append("ABM", "Usa: /ferramenta executar ID. Para ações sensíveis, o ABM pedirá confirmação.");
            return;
        }
        String executionId = parts[2];
        boolean typedConfirmation = parts.length == 4 && "confirmar".equalsIgnoreCase(parts[3]);
        try {
            String raw = bridge.callAttr("execute_registered_tool", executionId, typedConfirmation).toString();
            JSONObject result = new JSONObject(raw);
            if ("confirmation_required".equals(result.optString("status"))) {
                new AlertDialog.Builder(this)
                    .setTitle("Confirmar ação do ABM")
                    .setMessage("Esta ferramenta pode abrir a câmara, partilhar conteúdo ou iniciar uma ação sensível. Queres continuar?")
                    .setNegativeButton("Cancelar", (dialog, which) -> append("ABM", "Ação cancelada. Nada foi enviado ao Android."))
                    .setPositiveButton("Confirmar", (dialog, which) -> executeUniversalToolConfirmed(executionId))
                    .show();
                return;
            }
            handleUniversalToolResult(result, executionId);
        } catch (Exception e) {
            append("ABM", "Não consegui executar o plano da ferramenta: " + e.getMessage());
        }
    }

    private void executeUniversalToolConfirmed(String executionId) {
        try {
            JSONObject result = new JSONObject(bridge.callAttr("execute_registered_tool", executionId, true).toString());
            handleUniversalToolResult(result, executionId);
        } catch (Exception e) {
            append("ABM", "Falha ao confirmar a ferramenta: " + e.getMessage());
        }
    }

    private void handleUniversalToolResult(JSONObject result, String executionId) {
        String status = result.optString("status", "unknown");
        if ("dispatched".equals(status)) {
            JSONObject tool = result.optJSONObject("result");
            boolean accepted = tool != null && dispatchAndroidTool(tool);
            String detail = accepted ? "O Android aceitou/iniciou o Intent solicitado." : "O Android não conseguiu iniciar o Intent.";
            try {
                JSONObject recorded = new JSONObject(bridge.callAttr("record_android_tool_result", executionId, accepted, detail).toString());
                append("ABM", recorded.optString("message", detail));
                if (accepted) {
                    append("ABM", "Pedido aceite pelo Android. Ainda falta confirmar o resultado dentro da aplicação.");
                    askTargetOutcome(executionId);
                }
            } catch (Exception e) {
                append("ABM", detail + " Não foi possível registar o retorno: " + e.getMessage());
            }
            return;
        }
        if ("completed".equals(status)) {
            JSONObject local = result.optJSONObject("result");
            append("ABM", "Ferramenta local concluída: " + (local == null ? result.toString() : local.toString()));
        } else {
            append("ABM", result.optString("message", result.toString()));
        }
    }

    /** Recolhe feedback explícito; nunca apresenta a resposta do utilizador como prova automática. */
    private void askTargetOutcome(String executionId) {
        new AlertDialog.Builder(this)
            .setTitle("A tarefa foi concluída?")
            .setMessage("O Android aceitou o pedido, mas o ABM não consegue confirmar automaticamente o que aconteceu dentro da outra aplicação. Qual é o resultado?")
            .setPositiveButton("Sim, foi concluída", (dialog, which) -> recordTargetOutcome(executionId, "success"))
            .setNegativeButton("Não foi concluída", (dialog, which) -> recordTargetOutcome(executionId, "failure"))
            .setNeutralButton("Não sei / verificar depois", (dialog, which) -> recordTargetOutcome(executionId, "unknown"))
            .show();
    }

    private void recordTargetOutcome(String executionId, String outcome) {
        try {
            JSONObject feedback = new JSONObject(bridge.callAttr("record_android_target_outcome", executionId, outcome,
                "Feedback declarado pelo utilizador na interface ABM.").toString());
            append("ABM — resultado", feedback.optString("message", feedback.toString()));
        } catch (Exception e) {
            append("ABM", "Não foi possível guardar o feedback: " + e.getMessage());
        }
    }

    private boolean runUniversalTask(String message) {
        try {
            String raw = bridge.callAttr("process_and_execute", message).toString();
            JSONObject root = new JSONObject(raw);
            String status = root.optString("status", "");
            if ("legacy_command".equals(status)) return false;
            if ("conversation".equals(status) || "needs_input".equals(status)) {
                String response = root.optString("response", root.optString("message", ""));
                if (!response.isEmpty()) { append("ABM", response); speak(response); }
                return true;
            }
            JSONObject execution = root.optJSONObject("execution");
            if (execution == null) {
                append("ABM", root.optString("response", raw));
                return true;
            }
            JSONArray results = execution.optJSONArray("results");
            boolean dispatched = false;
            if (results != null) {
                for (int i = 0; i < results.length(); i++) {
                    JSONObject item = results.optJSONObject(i);
                    if (item == null) continue;
                    JSONObject result = item.optJSONObject("result");
                    if (result != null && "android".equals(result.optString("dispatch"))) {
                        dispatchAndroidTool(result);
                        dispatched = true;
                    } else if (result != null) {
                        append("ABM", item.optString("capability") + ": " + result.toString());
                    }
                }
            }
            JSONArray blocked = execution.optJSONArray("blocked");
            if (blocked != null) {
                for (int i = 0; i < blocked.length(); i++) {
                    JSONObject item = blocked.optJSONObject(i);
                    if (item != null) append("ABM", "Ação pendente: " + item.optString("capability") + " — " + item.optString("reason"));
                }
            }
            if (!dispatched && (results == null || results.length() == 0)) {
                append("ABM", execution.optString("message", "A tarefa foi analisada."));
            }
            JSONObject plan = root.optJSONObject("plan");
            if (plan != null) append("ABM", "Plano " + plan.optString("id") + " — " + execution.optString("status"));
            return true;
        } catch (Exception e) {
            // Se não for um pedido reconhecido pelo motor, deixa o cérebro normal responder.
            return false;
        }
    }

    private boolean dispatchAndroidTool(JSONObject tool) {
        String action = tool.optString("action", "");
        JSONObject args = tool.optJSONObject("args");
        if (args == null) args = new JSONObject();
        try {
            switch (action) {
                case "open_app": {
                    String app = args.optString("app_name", "").trim();
                    if (app.isEmpty()) return false;
                    boolean launched = launchAppByName(app);
                    if (!launched) append("ABM", "Não encontrei uma aplicação instalada chamada: " + app);
                    return launched;
                }
                case "open_camera": return openCamera();
                case "choose_file": return chooseFile("*/*", REQ_FILE);
                case "web_search": return openWebSearch(args.optString("query", ""));
                case "open_url": {
                    String url = args.optString("url", "");
                    if (url.startsWith("https://") || url.startsWith("http://")) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true; }
                    append("ABM", "Endereço Web inválido."); return false;
                }
                case "share_text": {
                    Intent share = new Intent(Intent.ACTION_SEND); share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_TEXT, args.optString("text", ""));
                    startActivity(Intent.createChooser(share, "Partilhar com")); return true;
                }
                case "open_maps": {
                    String query = args.optString("query", "");
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(query)))); return true;
                }
                case "open_settings": startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); return true;
                case "pause_media": return pauseMedia();
                case "dial": {
                    String number = args.optString("number", "").trim();
                    if (number.isEmpty()) append("ABM", "Indica o número para abrir o marcador.");
                    else startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))));
                    return !number.isEmpty();
                }
                default: append("ABM", "A ferramenta Android ainda não tem um adaptador para: " + action); return false;
            }
        } catch (Exception e) {
            append("ABM", "Falha ao executar " + action + ": " + e.getMessage());
            return false;
        }
    }

    private void startSpeech() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingSingleSpeech = true;
            pendingContinuousListening = false;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); return;
        }
        pendingSingleSpeech = false;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Fala com o ABM");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (ActivityNotFoundException e) { append("ABM", "Não existe um serviço de reconhecimento de voz configurado."); }
    }

    private void speak(String text) {
        lastSpokenReply = text == null ? "" : text;
        if (ttsReady && tts != null && !lastSpokenReply.isEmpty()) {
            currentTtsText = lastSpokenReply;
            if (avatar3D != null) avatar3D.setSpeaking(true);
            tts.speak(lastSpokenReply, TextToSpeech.QUEUE_FLUSH, null, "abm_reply");
        }
    }

    private void toggleContinuousListening() {
        if (continuousListening) {
            stopContinuousListening();
            append("ABM", "Audição contínua desligada.");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            append("ABM", "Este telefone não tem um serviço de reconhecimento de voz disponível.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingContinuousListening = true;
            pendingSingleSpeech = false;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        pendingContinuousListening = false;
        continuousListening = true;
        wakeWordMode = true;
        if (avatar3D != null) avatar3D.setListening(true);
        createSpeechRecognizer();
        append("ABM", "Audição ativada. Diz 'ABM' e depois o comando. Mantém a aplicação aberta e o ecrã ligado. Toca novamente para desligar.");
        speak("Modo mãos livres ativado. Diz ABM e depois o teu comando.");
        scheduleSpeechRecognition(350);
    }

    private void createSpeechRecognizer() {
        if (speechRecognizer != null) { try { speechRecognizer.destroy(); } catch (Exception ignored) {} }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { speechBusy = true; if (avatar3D != null) avatar3D.setListening(true); }
            @Override public void onBeginningOfSpeech() { if (avatar3D != null) avatar3D.setListening(true); }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { speechBusy = false; }
            @Override public void onError(int error) { speechBusy = false; if (continuousListening) scheduleSpeechRecognition(900); }
            @Override public void onResults(Bundle results) {
                speechBusy = false;
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) handleContinuousTranscript(matches.get(0));
                if (continuousListening) scheduleSpeechRecognition(650);
            }
            @Override public void onPartialResults(Bundle partialResults) { }
            @Override public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void scheduleSpeechRecognition(long delayMs) {
        speechHandler.removeCallbacksAndMessages(null);
        speechHandler.postDelayed(() -> {
            if (!continuousListening || speechRecognizer == null || isFinishing()) return;
            try {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT");
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
                speechRecognizer.startListening(intent);
            } catch (Exception e) { speechBusy = false; if (continuousListening) scheduleSpeechRecognition(1500); }
        }, delayMs);
    }

    private void handleContinuousTranscript(String spoken) {
        String normalized = spoken == null ? "" : spoken.trim();
        if (normalized.isEmpty()) return;
        append("Audição", normalized);
        String lower = normalized.toLowerCase(new Locale("pt", "PT"));
        if (wakeWordMode) {
            int at = lower.indexOf("abm");
            if (at < 0 && lower.startsWith("abê eme")) at = 0;
            if (at < 0) return;
            String command = normalized.substring(Math.min(normalized.length(), at + (lower.startsWith("abê eme") ? 7 : 3))).trim();
            command = command.replaceFirst("^[,.:;!?\\s]+", "");
            if (command.isEmpty()) { speak("Estou a ouvir. Qual é o teu comando?"); return; }
            append("Tu (comando de voz)", command);
            runCommand(command);
        } else {
            append("ABM", "Reconheci: " + normalized);
        }
    }

    private void stopContinuousListening() {
        continuousListening = false;
        if (avatar3D != null) avatar3D.setListening(false);
        speechHandler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) { try { speechRecognizer.stopListening(); speechRecognizer.destroy(); } catch (Exception ignored) {} speechRecognizer = null; }
    }

    private void speakLast() {
        if (ttsReady && transcript != null) {
            String all = transcript.getText().toString();
            int pos = all.lastIndexOf("ABM: ");
            if (pos >= 0) speak(all.substring(pos + 5).trim());
            else speak("Ainda não tenho uma resposta para ler.");
        } else append("ABM", "O motor de voz do Android não está disponível.");
    }

    private boolean chooseFile(String mime, int requestCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(mime);
        try { startActivityForResult(i, requestCode); return true; }
        catch (ActivityNotFoundException e) { append("ABM", "Não encontrei um seletor de ficheiros."); return false; }
    }

    private boolean openCamera() {
        Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        try { startActivityForResult(i, REQ_CAMERA); return true; }
        catch (ActivityNotFoundException e) { append("ABM", "Não encontrei uma aplicação de câmara."); return false; }
    }

    private void searchOnline() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) { append("ABM", "Escreve o nome da música, vídeo ou assunto na caixa primeiro."); return; }
        input.setText(""); openYoutubeSearch(q);
    }

    private boolean openWebSearch(String query) {
        String q = query == null ? "" : query.trim();
        if (q.isEmpty()) { append("ABM", "Indica o que devo pesquisar."); return false; }
        Uri uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(q));
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); append("ABM", "Abri a pesquisa na Internet por: " + q); return true; }
        catch (Exception e) { append("ABM", "Não consegui abrir a pesquisa no navegador."); return false; }
    }

    private void openYoutubeSearch(String query) {
        Uri uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query));
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); append("ABM", "Abri a pesquisa online por: " + query); }
        catch (Exception e) { append("ABM", "Não consegui abrir a pesquisa online."); }
    }

    private boolean pauseMedia() {
        try {
            AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return false;
            long now = System.currentTimeMillis();
            KeyEvent down = new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0);
            KeyEvent up = new KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0);
            am.dispatchMediaKeyEvent(down); am.dispatchMediaKeyEvent(up);
            append("ABM", "Enviei um pedido de pausa. A aplicação de reprodução pode ignorá-lo.");
            return true;
        } catch (Exception e) { append("ABM", "Este leitor não permite controlo externo de pausa."); return false; }
    }

    private void toggleCallMonitor() {
        boolean enabled = prefs.getBoolean(ABMForegroundService.KEY_CALL_MONITOR, false);
        if (enabled) {
            prefs.edit().putBoolean(ABMForegroundService.KEY_CALL_MONITOR, false).apply();
            startVisibleService();
            append("ABM", "Avisos de chamadas desativados. O serviço deixará de observar o estado de chamadas.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, REQ_PHONE); return;
        }
        prefs.edit().putBoolean(ABMForegroundService.KEY_CALL_MONITOR, true).apply();
        startVisibleService(); append("ABM", "Avisos de chamadas ativados. Vou avisar quando o telefone tocar; não atendo nem falo pela chamada.");
    }

    private void requestDeviceAuthentication() {
        try {
            KeyguardManager km = (KeyguardManager)getSystemService(KEYGUARD_SERVICE);
            Intent auth = km.createConfirmDeviceCredentialIntent("Confirmar identidade", "Usa o PIN, padrão ou palavra-passe do telefone.");
            if (auth != null) startActivity(auth);
            else append("ABM", "O telefone não disponibilizou um pedido de autenticação do sistema.");
        } catch (Exception e) { append("ABM", "Não foi possível abrir a autenticação oficial: " + e.getMessage()); }
    }

    private boolean launchAppByName(String requested) {
        String wanted = requested.toLowerCase(new Locale("pt", "PT")).trim();
        try {
            for (android.content.pm.ApplicationInfo info : getPackageManager().getInstalledApplications(0)) {
                CharSequence label = getPackageManager().getApplicationLabel(info);
                if (label != null && label.toString().toLowerCase(new Locale("pt", "PT")).contains(wanted)) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(info.packageName);
                    if (launch != null && !info.packageName.equals(getPackageName())) {
                        startActivity(launch);
                        append("ABM", "A abrir " + label + ".");
                        return true;
                    }
                }
            }
        } catch (Exception ignored) { }
        return false;
    }

    private String copyUriToCache(Uri uri, String prefix) throws Exception {
        File out = new File(getCacheDir(), prefix + "_" + System.currentTimeMillis());
        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream stream = new FileOutputStream(out)) {
            if (in == null) throw new IllegalStateException("Não foi possível ler o ficheiro escolhido.");
            byte[] buffer = new byte[8192]; int count;
            while ((count = in.read(buffer)) != -1) stream.write(buffer, 0, count);
        }
        return out.getAbsolutePath();
    }

    private void chooseAccessProfile() {
        ABMUniversalAccessEngine.Profile[] profiles = ABMUniversalAccessEngine.profiles();
        String[] labels = new String[profiles.length];
        for (int i = 0; i < profiles.length; i++) labels[i] = profiles[i].title + " — " + profiles[i].guidance;
        String current = prefs.getString("abm_access_profile", ABMUniversalAccessEngine.Profile.STANDARD.name());
        int checked = 0;
        for (int i = 0; i < profiles.length; i++) if (profiles[i].name().equals(current)) checked = i;
        new AlertDialog.Builder(this).setTitle("Como preferes utilizar o ABM?")
            .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                ABMUniversalAccessEngine.Profile selected = profiles[which];
                prefs.edit().putString("abm_access_profile", selected.name()).apply();
                append("Acessibilidade", "Perfil selecionado: " + selected.title + ". " + selected.guidance + ". As opções podem ser combinadas; este perfil não ativa sensores nem permissões sozinho.");
                speak("Perfil selecionado: " + selected.title);
                dialog.dismiss();
            }).setNegativeButton("Fechar", null).show();
    }

    private void openCommunicationBoard() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(12, 8, 12, 8);
        TextView intro = new TextView(this);
        intro.setText("Escolhe uma frase. O ABM apresenta-a no ecrã e pode dizê-la em voz alta.");
        intro.setTextSize(16);
        panel.addView(intro);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (ABMUniversalAccessEngine.Phrase phrase : ABMUniversalAccessEngine.phrases()) {
            Button b = new Button(this);
            b.setText(phrase.category + " • " + phrase.label);
            b.setTextSize(16);
            b.setMinHeight(56);
            b.setContentDescription(phrase.category + ". " + phrase.label + ". Ativar para comunicar esta frase.");
            b.setOnClickListener(v -> {
                append("Comunicação", phrase.spoken);
                speak(phrase.spoken);
            });
            list.addView(b, new LinearLayout.LayoutParams(-1, -2));
        }
        Button custom = new Button(this);
        custom.setText("Escrever uma frase própria");
        custom.setTextSize(16);
        custom.setOnClickListener(v -> {
            EditText text = new EditText(this);
            text.setHint("Escreve o que queres comunicar");
            new AlertDialog.Builder(this).setTitle("Mensagem personalizada").setView(text)
                .setPositiveButton("Comunicar", (d, w) -> {
                    String value = text.getText().toString().trim();
                    if (!value.isEmpty()) { append("Comunicação", value); speak(value); }
                }).setNegativeButton("Cancelar", null).show();
        });
        list.addView(custom);
        scroll.addView(list);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        new AlertDialog.Builder(this).setTitle("ABM — Comunicação alternativa")
            .setView(panel).setNegativeButton("Fechar", null).show();
    }

    private void openAccessibilitySettings() {
        new AlertDialog.Builder(this)
            .setTitle("Acessibilidade do ABM")
            .setMessage("1. Ativa ‘ABM — controlo assistivo’ para permitir voltar, ir ao início e abrir notificações.\n\n2. Usa ‘Modo mãos livres’ para falar com o ABM sem tocar repetidamente no botão do microfone. A audição contínua funciona apenas enquanto a aplicação está aberta e pode ser desligada a qualquer momento.\n\n3. Para controlar mais elementos do Android, instala/ativa Voice Access ou Switch Access se forem compatíveis com o teu telefone. Cada autorização é escolhida por ti.")
            .setPositiveButton("Abrir definições", (d, w) -> {
                try { startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
                catch (Exception e) { append("ABM", "Não consegui abrir as definições de acessibilidade."); }
            })
            .setNegativeButton("Cancelar", null).show();
    }

    private void sendAccessibilityAction(String command) {
        Intent intent = new Intent(ABMAccessibilityService.ACTION);
        intent.setPackage(getPackageName());
        intent.putExtra("command", command);
        sendBroadcast(intent, "com.forla.abm.permission.CONTROL_ACCESSIBILITY");
        append("ABM", "Pedido enviado. Se o serviço assistivo não estiver ativado, abre Acessibilidade nas definições.");
    }

    private void launchPackage(String packageName) {
        Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
        if (i == null) { append("ABM", "Essa aplicação não está instalada ou não pode ser aberta."); return; }
        startActivity(i);
    }

    private void showHelp() {
        append("ABM", "Para acessibilidade por voz, diz: ativa cursor, desativa cursor ou seleciona. O cursor deve estar ativo e o serviço ABM autorizado. Podes pedir tarefas em linguagem natural: cria uma nota, mostra as notas, abre uma aplicação, abre a câmara, pesquisa na Internet ou pausa a música. Também podes usar /capacidades, /tarefa [pedido], /executar [ID], /aprovar [ID], /estado e /guardar. A execução depende das ferramentas e permissões disponíveis. Para acessibilidade: usa Comunicação para frases prontas, Perfil adaptativo para escolher preferências, ou os comandos ‘volta’, ‘vai para início’, ‘abre notificações’ e ‘abre definições rápidas’ (requer serviço ABM ativado).");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQ_SPEECH) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) { append("Tu (voz)", results.get(0)); runCommand(results.get(0)); }
        } else if (requestCode == REQ_FILE) {
            Uri uri = data.getData();
            if (uri != null) {
                Intent view = new Intent(Intent.ACTION_VIEW); view.setData(uri);
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivity(Intent.createChooser(view, "Abrir com")); }
                catch (Exception e) { append("ABM", "Não existe uma aplicação compatível para abrir este ficheiro."); }
            }
        } else if (requestCode == REQ_VIDEO_ANALYSIS) {
            Uri uri = data.getData();
            if (uri != null) analyzeVideo(uri);
        } else if (requestCode == REQ_IMAGE || requestCode == REQ_WAV) {
            Uri uri = data.getData();
            if (uri != null && bridge != null) {
                try {
                    String path = copyUriToCache(uri, requestCode == REQ_IMAGE ? "abm_image" : "abm_audio");
                    String result = bridge.callAttr(requestCode == REQ_IMAGE ? "analyze_image" : "analyze_wav", path).toString();
                    if (requestCode == REQ_IMAGE) {
                        analyzeImageWithMlKit(path);
                    } else append("ABM", result);
                } catch (Exception e) {
                    append("ABM", "Não consegui analisar o ficheiro: " + e.getMessage());
                }
            }
        } else if (requestCode == REQ_CAMERA) {
            Object thumb = data.getExtras() == null ? null : data.getExtras().get("data");
            if (thumb instanceof Bitmap) analyzeBitmapWithMlKit((Bitmap) thumb, "Fotografia da câmara");
            else append("ABM", "A câmara terminou, mas não devolveu uma miniatura analisável.");
        }
    }

    private void analyzeImageWithMlKit(String path) {
        try {
            Bitmap bitmap = android.graphics.BitmapFactory.decodeFile(path);
            if (bitmap == null) { append("ABM EYES", "Não consegui descodificar esta imagem."); return; }
            analyzeBitmapWithMlKit(bitmap, "Imagem selecionada");
        } catch (Exception e) { append("ABM EYES", "Falha ao abrir imagem: " + e.getMessage()); }
    }

    private void analyzeBitmapWithMlKit(Bitmap bitmap, String source) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        ImageLabelerOptions labelOptions = new ImageLabelerOptions.Builder().setConfidenceThreshold(0.55f).build();
        com.google.mlkit.vision.label.ImageLabeler labeler = ImageLabeling.getClient(labelOptions);
        ObjectDetectorOptions objectOptions = new ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE)
                .enableMultipleObjects().enableClassification().build();
        com.google.mlkit.vision.objects.ObjectDetector objectDetector = ObjectDetection.getClient(objectOptions);
        FaceDetectorOptions faceOptions = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build();
        com.google.mlkit.vision.face.FaceDetector faceDetector = FaceDetection.getClient(faceOptions);
        final StringBuilder report = new StringBuilder(source).append(" — ");
        final int[] completed = {0};
        labeler.process(image).addOnSuccessListener(labels -> {
            report.append("Rótulos: ");
            if (labels.isEmpty()) report.append("não identificados; ");
            for (int i=0; i<Math.min(8, labels.size()); i++) report.append(labels.get(i).getText()).append(" (").append(Math.round(labels.get(i).getConfidence()*100)).append("%), ");
        }).addOnFailureListener(e -> report.append("Rótulos indisponíveis; ")).addOnCompleteListener(t -> {
            completed[0]++; if (completed[0] == 3) showVisionReport(report);
        });
        objectDetector.process(image).addOnSuccessListener(objects -> {
            report.append("Objetos: ");
            if (objects.isEmpty()) report.append("nenhum objeto detetado; ");
            for (int i=0; i<Math.min(8, objects.size()); i++) {
                report.append("objeto").append(i+1);
                if (!objects.get(i).getLabels().isEmpty()) report.append(" [").append(objects.get(i).getLabels().get(0).getText()).append("]");
                report.append("; ");
            }
        }).addOnFailureListener(e -> report.append("Deteção de objetos indisponível; ")).addOnCompleteListener(t -> {
            completed[0]++; if (completed[0] == 3) showVisionReport(report);
        });
        faceDetector.process(image).addOnSuccessListener(faces -> {
            report.append("Rostos detetados: ").append(faces.size()).append(". ");
            if (!faces.isEmpty()) {
                int smiles = 0, eyesOpen = 0;
                for (com.google.mlkit.vision.face.Face face : faces) {
                    if (face.getSmilingProbability() != null && face.getSmilingProbability() > 0.7f) smiles++;
                    if (face.getRightEyeOpenProbability() != null && face.getLeftEyeOpenProbability() != null
                            && face.getRightEyeOpenProbability() > 0.7f && face.getLeftEyeOpenProbability() > 0.7f) eyesOpen++;
                }
                report.append("Possíveis sorrisos: ").append(smiles).append("; olhos abertos: ").append(eyesOpen).append(". ");
            }
            report.append("Não identifica a identidade das pessoas.");
        }).addOnFailureListener(e -> report.append("Análise facial indisponível; ")).addOnCompleteListener(t -> {
            completed[0]++; if (completed[0] == 3) showVisionReport(report);
        });
    }

    private void showVisionReport(StringBuilder report) {
        runOnUiThread(() -> append("ABM EYES", report.toString()));
    }

    private void analyzeVideo(Uri uri) {
        append("ABM EYES", "A analisar amostras do vídeo. O processamento pode demorar.");
        new Thread(() -> {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            try {
                retriever.setDataSource(this, uri);
                String durationValue = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                long durationMs = durationValue == null ? 0 : Long.parseLong(durationValue);
                if (durationMs <= 0) throw new IllegalArgumentException("Duração de vídeo inválida.");
                int frames = 0;
                for (int i=0; i<5; i++) {
                    long timeUs = Math.min(durationMs * 1000L - 1, (durationMs * 1000L * (i+1)) / 6L);
                    Bitmap frame = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    if (frame != null) {
                        frames++;
                        final Bitmap sample = frame;
                        final int frameNumber = i+1;
                        runOnUiThread(() -> { append("ABM EYES", "Quadro de vídeo " + frameNumber + ":"); analyzeBitmapWithMlKit(sample, "Vídeo, quadro " + frameNumber); });
                    }
                }
                final int count = frames;
                runOnUiThread(() -> append("ABM EYES", "Foram extraídos " + count + " quadros de amostra. Não é análise contínua de cada fotograma."));
            } catch (Exception e) { runOnUiThread(() -> append("ABM EYES", "Não consegui analisar o vídeo: " + e.getMessage())); }
            finally { try { retriever.release(); } catch (Exception ignored) {} }
        }).start();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_MIC) {
            append("ABM", granted ? "Microfone autorizado." : "Microfone não autorizado; podes continuar por texto.");
            boolean resumeSingle = pendingSingleSpeech;
            boolean resumeContinuous = pendingContinuousListening;
            pendingSingleSpeech = false;
            pendingContinuousListening = false;
            if (granted && resumeSingle) startSpeech();
            else if (granted && resumeContinuous) toggleContinuousListening();
        }
        if (requestCode == REQ_PHONE) {
            if (granted) {
                prefs.edit().putBoolean(ABMForegroundService.KEY_CALL_MONITOR, true).apply();
                startVisibleService(); append("ABM", "Avisos de chamadas ativados.");
            } else append("ABM", "Permissão de estado de chamadas recusada; os avisos não estarão disponíveis.");
        }
    }

    @Override protected void onPause() {
        if (avatar3D != null) avatar3D.onPause();
        super.onPause();
        // Reconhecimento em contínuo é intencionalmente limitado à aplicação visível.
        if (continuousListening) {
            stopContinuousListening();
            append("Sistema", "Audição pausada porque a aplicação deixou de estar visível.");
        }
    }

    @Override protected void onResume() { super.onResume(); if (avatar3D != null) avatar3D.onResume(); }

    @Override protected void onDestroy() {
        stopContinuousListening();
        if (bridge != null) { try { bridge.callAttr("save"); } catch (Exception ignored) { } }
        if (tts != null) { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) { } }
        super.onDestroy();
    }
}
