"""
ABM_UNIFICADO_COMPLETO_3_3.py
Artificial Brain Machine — Versão 3.3 (Arquitetura Unificada, Espacial 3D e Fisiológica)

Biblioteca padrão do Python; sem dependências externas.
Implementa rigorosamente a unificação da rede LIF/Hodgkin-Huxley espacial,
metabolismo, biomecânica, sono glinfático, STDP, Q-learning, objetivos,
persistência robusta sem fugas de memória (janelas deslizantes nos logs) e testes automatizados.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from collections import defaultdict, deque, Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import json
import math
import re
import time
import tempfile
import random


# ---------------------------------------------------------------------------
# CONSTANTES GLOBAIS E CONFIGURAÇÕES
# ---------------------------------------------------------------------------

TOTAL_VIRTUAL_NEURONS = 86_000_000_000
ABM_VERSION = "3.4"
VALID_SENSES = {"vision", "hearing", "touch", "smell", "taste"}
VALID_TRANSMITTERS = {
    "glutamate", "gaba", "dopamine", "serotonin",
    "acetylcholine", "noradrenaline"
}
REGIONS = {
    "cortex", "hippocampus", "amygdala", "thalamus",
    "hypothalamus", "cerebellum", "basal_ganglia",
    "brainstem", "olfactory_bulb", "prefrontal", "motor",
    "somatosensory", "visual", "auditory", "language", "insula",
    "cingulate", "cerebellar_cortex", "striatum", "thalamic_nucleus",
    "hypothalamic_nucleus", "midbrain", "pons", "medulla"
}
LOBE_TO_REGION = {
    "frontal": "cortex", "parietal": "cortex",
    "temporal": "cortex", "occipital": "cortex",
    "cingulate": "cortex", "entorhinal": "hippocampus",
    "mammillary_bodies": "hypothalamus"
}


def _now() -> float:
    return time.time()


def _tokens(text: str) -> List[str]:
    return re.findall(r"[a-zA-ZÀ-ÿ0-9_]+", str(text).lower())


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))


# ---------------------------------------------------------------------------
# 1. NÚCLEO NEURONAL ESPACIAL 3D & BIOFÍSICA
# ---------------------------------------------------------------------------

@dataclass
class Neuron3D:
    neuron_id: int
    region: str = "cortex"
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    potential: float = -70.0
    threshold: float = -55.0
    resting: float = -70.0
    tau: float = 20.0
    refractory_steps: int = 2
    refractory_left: int = 0
    last_spike: int = -1
    spikes: int = 0
    neurotransmitter: str = "glutamate"
    # Parâmetros Hodgkin-Huxley / ATP
    v_membrane: float = -65.0
    g_na: float = 120.0
    g_k: float = 36.0
    g_l: float = 0.3
    v_na: float = 50.0
    v_k: float = -77.0
    v_l: float = -54.38
    model: str = "lif"
    m_gate: float = 0.05
    h_gate: float = 0.60
    n_gate: float = 0.32

    def step_hh(self, current: float, tick: int, available_atp: float, dt: float = 0.01) -> bool:
        """Integração Hodgkin-Huxley clássica por Euler explícito (dt em ms)."""
        if not 0 < dt <= 0.05:
            raise ValueError("dt HH deve estar entre 0 e 0.05 ms para estabilidade.")
        if available_atp < 0.05:
            self.v_membrane = self.resting
            self.potential = self.resting
            return False
        if self.refractory_left > 0:
            self.refractory_left -= 1
            return False
        v = self.v_membrane
        def exprel(x: float) -> float:
            return x / (math.exp(x) - 1.0) if abs(x) > 1e-7 else 1.0
        # Taxas clássicas HH, com V em mV e tempo em ms.
        am = 0.1 * exprel(-(v + 40.0) / 10.0)
        bm = 4.0 * math.exp(-(v + 65.0) / 18.0)
        ah = 0.07 * math.exp(-(v + 65.0) / 20.0)
        bh = 1.0 / (math.exp(-(v + 35.0) / 10.0) + 1.0)
        an = 0.01 * exprel(-(v + 55.0) / 10.0)
        bn = 0.125 * math.exp(-(v + 65.0) / 80.0)
        self.m_gate = _clamp(self.m_gate + dt * (am * (1-self.m_gate) - bm*self.m_gate), 0, 1)
        self.h_gate = _clamp(self.h_gate + dt * (ah * (1-self.h_gate) - bh*self.h_gate), 0, 1)
        self.n_gate = _clamp(self.n_gate + dt * (an * (1-self.n_gate) - bn*self.n_gate), 0, 1)
        ina = self.g_na * (self.m_gate**3) * self.h_gate * (v-self.v_na)
        ik = self.g_k * (self.n_gate**4) * (v-self.v_k)
        il = self.g_l * (v-self.v_l)
        dv = (float(current) - ina - ik - il) * dt
        self.v_membrane += dv
        self.potential = self.v_membrane
        if self.v_membrane >= 0.0:
            self.last_spike = tick
            self.spikes += 1
            self.refractory_left = self.refractory_steps
            self.v_membrane = self.resting
            self.potential = self.resting
            return True
        return False

    def step_lif(self, current: float, tick: int, available_atp: float) -> bool:
        if available_atp < 0.05:
            self.potential = self.resting
            return False
        if self.refractory_left > 0:
            self.refractory_left -= 1
            self.potential = self.resting
            return False
        self.potential += (self.resting - self.potential + current) / max(1.0, self.tau)
        if self.potential >= self.threshold:
            self.potential = self.resting
            self.refractory_left = self.refractory_steps
            self.last_spike = tick
            self.spikes += 1
            return True
        return False


@dataclass
class Synapse3D:
    source: int
    target: int
    weight: float = 1.0
    delay_steps: int = 1
    transmitter: str = "glutamate"
    enabled: bool = True
    euclidean_distance: float = 0.0


class SpatialNeuralNetwork:
    """Rede neuronal espacial 3D com atrasos dependentes da distância e limites de log."""
    def __init__(self, total_virtual: int = TOTAL_VIRTUAL_NEURONS, max_log_size: int = 5000):
        self.total_virtual = int(total_virtual)
        self.max_log_size = int(max_log_size)
        self.neurons: Dict[int, Neuron3D] = {}
        self.outgoing: Dict[int, List[Synapse3D]] = defaultdict(list)
        self.pending: Dict[int, List[Tuple[int, float, str]]] = defaultdict(list)
        self.tick = 0
        self.spike_log: deque[int] = deque(maxlen=self.max_log_size)

    def create_neuron(self, neuron_id: int, region: str = "cortex",
                      x: float = 0.0, y: float = 0.0, z: float = 0.0,
                      threshold: float = -55.0, neurotransmitter: str = "glutamate",
                      model: str = "lif") -> Neuron3D:
        if not 0 <= int(neuron_id) < self.total_virtual:
            raise ValueError("ID neuronal fora do espaço virtual.")
        if region not in REGIONS:
            raise ValueError(f"Região desconhecida: {region}")
        if neurotransmitter not in VALID_TRANSMITTERS:
            raise ValueError("Neurotransmissor desconhecido.")
        if model not in {"lif", "hh"}:
            raise ValueError("Modelo neuronal deve ser lif ou hh.")
        if neuron_id not in self.neurons:
            self.neurons[neuron_id] = Neuron3D(
                int(neuron_id), region=region, x=float(x), y=float(y), z=float(z),
                threshold=float(threshold), neurotransmitter=neurotransmitter, model=model
            )
        return self.neurons[neuron_id]

    def connect(self, source: int, target: int, weight: float = 1.0,
                base_delay: int = 1, transmitter: str = "glutamate",
                conduction_speed: float = 10.0) -> Synapse3D:
        if source not in self.neurons or target not in self.neurons:
            raise KeyError("Crie os dois neurónios antes de ligar a sinapse.")
        
        n1 = self.neurons[source]
        n2 = self.neurons[target]
        dist = math.sqrt((n1.x - n2.x)**2 + (n1.y - n2.y)**2 + (n1.z - n2.z)**2)
        
        # Atraso dinâmico baseado na distância euclidiana e velocidade de condução
        distance_delay = max(1, int(dist / max(0.1, conduction_speed)))
        total_delay = int(base_delay) + distance_delay

        if transmitter not in VALID_TRANSMITTERS:
            raise ValueError("Neurotransmissor desconhecido.")
        
        syn = Synapse3D(source, target, float(weight), total_delay, transmitter, True, dist)
        self.outgoing[source].append(syn)
        return syn

    def inject(self, neuron_id: int, current: float) -> None:
        if neuron_id not in self.neurons:
            raise KeyError("Neurónio não materializado.")
        self.pending[self.tick].append((neuron_id, float(current), "external"))

    def step(self, external: Optional[Dict[int, float]] = None, available_atp: float = 1.0) -> List[int]:
        if external:
            for nid, current in external.items():
                self.inject(nid, current)
        currents: Dict[int, float] = defaultdict(float)
        for target, current, transmitter in self.pending.pop(self.tick, []):
            sign = -1.0 if transmitter == "gaba" else 1.0
            currents[target] += float(current) * sign
        
        fired = []
        for nid, neuron in list(self.neurons.items()):
            did_fire = (neuron.step_hh(currents[nid], self.tick, available_atp)
                        if neuron.model == "hh" else
                        neuron.step_lif(currents[nid], self.tick, available_atp))
            if did_fire:
                fired.append(nid)
                for syn in self.outgoing.get(nid, []):
                    if syn.enabled:
                        self.pending[self.tick + syn.delay_steps].append(
                            (syn.target, syn.weight, syn.transmitter)
                        )
        
        for f in fired:
            self.spike_log.append(f)
        self.tick += 1
        return fired

    def status(self) -> Dict[str, Any]:
        return {
            "virtual_neuron_ids": self.total_virtual,
            "materialized_neurons": len(self.neurons),
            "synapses": sum(map(len, self.outgoing.values())),
            "tick": self.tick,
            "pending_events": sum(map(len, self.pending.values())),
            "spikes_recorded": len(self.spike_log),
        }


# ---------------------------------------------------------------------------
# 2. SISTEMAS FISIOLÓGICOS, METABÓLICOS E BIOMECÂNICOS UNIFICADOS
# ---------------------------------------------------------------------------

class UnifiedPhysiologySystem:
    """Integra metabolismo avançado, sistema cardiorrespiratório e homeostase."""
    def __init__(self):
        self.energy = 1.0
        self.arousal = 0.5
        self.stress = 0.0
        self.atp_level = 1.0
        self.blood_glucose = 90.0
        self.oxygen_saturation = 0.98
        self.lactate = 0.0
        self.heart_rate_bpm = 72.0
        self.systolic_bp = 120.0
        self.diastolic_bp = 80.0
        self.respiratory_rate = 14.0
        self.gut_microbiome = 0.85
        self.gut_serotonin = 0.8
        self.pro_inflammatory = 0.1

    def update(self, workload: float = 0.0, threat: float = 0.0, rest: float = 0.0) -> dict:
        self.energy = _clamp(self.energy - 0.01 * max(0, workload) + 0.02 * max(0, rest), 0, 1)
        self.stress = _clamp(self.stress + 0.04 * max(0, threat) - 0.02 * max(0, rest), 0, 1)
        self.arousal = _clamp(self.arousal + 0.03 * workload + 0.04 * threat - 0.03 * rest, 0, 1)
        
        atp_drain = 0.02 * max(0, workload) + 0.01 * self.stress
        self.atp_level = _clamp(self.atp_level - atp_drain + 0.03 * max(0, rest), 0.0, 1.0)

        if workload > 5.0:
            self.lactate = _clamp(self.lactate + 0.05 * workload, 0.0, 5.0)
        else:
            self.lactate = _clamp(self.lactate - 0.02, 0.0, 5.0)

        self.heart_rate_bpm = 60.0 + (self.stress * 40.0) + (workload * 5.0)
        self.systolic_bp = 110.0 + (self.stress * 30.0)
        self.respiratory_rate = 12.0 + (self.stress * 10.0)

        if self.stress > 0.7:
            self.pro_inflammatory = _clamp(self.pro_inflammatory + 0.02, 0.0, 1.0)
        else:
            self.pro_inflammatory = _clamp(self.pro_inflammatory - 0.01, 0.0, 1.0)

        return self.state()

    def state(self) -> dict:
        return {
            "energy": self.energy,
            "arousal": self.arousal,
            "stress": self.stress,
            "atp_level": self.atp_level,
            "blood_glucose": self.blood_glucose,
            "oxygen_sat": self.oxygen_saturation,
            "lactate": self.lactate,
            "heart_rate_bpm": self.heart_rate_bpm,
            "systolic_bp": self.systolic_bp,
            "diastolic_bp": self.diastolic_bp,
            "blood_pressure": f"{int(self.systolic_bp)}/{int(self.diastolic_bp)}",
            "cytokines": self.pro_inflammatory,
            "gut_serotonin": self.gut_serotonin
        }


class UnifiedBiomechanicalBody:
    """Simula músculos, fadiga, cinemática articular e recetores somatossensoriais."""
    def __init__(self, max_history: int = 100):
        self.max_history = int(max_history)
        self.joint_angles: Dict[str, float] = {"neck": 0.0, "arm_right": 0.0, "leg_right": 0.0}
        self.muscle_tension: Dict[str, float] = {"biceps_r": 0.1, "quadriceps_r": 0.1, "core": 0.3}
        self.fatigue = 0.0
        self.motor_state = "idle"
        self.last_command: Optional[dict] = None
        self.command_history: deque[dict] = deque(maxlen=self.max_history)

    def prepare_action(self, action: str, target: Optional[str] = None, intensity: float = 0.5) -> dict:
        cmd = {
            "action": str(action),
            "target": target,
            "intensity": _clamp(intensity, 0, 1),
            "status": "prepared_not_executed",
            "timestamp": _now()
        }
        self.last_command = cmd
        self.motor_state = "prepared"
        self.command_history.append(cmd)
        return cmd

    def apply_muscle_force(self, muscle: str, force: float, duration: float) -> dict:
        if muscle in self.muscle_tension:
            self.muscle_tension[muscle] = _clamp(force, 0.0, 1.0)
            self.fatigue = _clamp(self.fatigue + (force * duration * 0.05), 0.0, 1.0)
        return {"muscle_status": self.muscle_tension, "body_fatigue": self.fatigue}

    def state(self) -> dict:
        return {
            "joint_angles": self.joint_angles,
            "muscle_tension": self.muscle_tension,
            "fatigue": self.fatigue,
            "motor_state": self.motor_state,
            "last_command": self.last_command
        }


class UnifiedSleepGlymphatic:
    """Ciclo circadiano, pressão de sono e depuração glinfática."""
    def __init__(self):
        self.cycle_hours = 24.0
        self.phase_hours = 8.0
        self.sleep_pressure = 0.2
        self.state_name = "awake"
        self.last_sleep_quality = 0.5
        self.glymphatic_clearance = 0.2

    def advance(self, hours: float = 1.0, sleep: bool = False) -> dict:
        if hours < 0:
            raise ValueError("O tempo não pode recuar.")
        self.phase_hours = (self.phase_hours + hours) % self.cycle_hours
        if sleep:
            self.state_name = "sleep"
            self.sleep_pressure = _clamp(self.sleep_pressure - 0.12 * hours, 0, 1)
            self.last_sleep_quality = _clamp(0.5 + 0.5 * (1 - self.sleep_pressure), 0, 1)
            self.glymphatic_clearance = 0.95 if self.sleep_pressure > 0.4 else 0.5
        else:
            self.state_name = "awake"
            self.sleep_pressure = _clamp(self.sleep_pressure + 0.035 * hours, 0, 1)
            self.glymphatic_clearance = 0.15
        return self.state()

    def state(self) -> dict:
        return {
            "phase_hours": self.phase_hours,
            "sleep_pressure": self.sleep_pressure,
            "state": self.state_name,
            "last_sleep_quality": self.last_sleep_quality,
            "glymphatic_clearance": self.glymphatic_clearance
        }


# ---------------------------------------------------------------------------
# 3. MÓDULOS COGNITIVOS, MEMÓRIA E PLASTICIDADE (VERSÕES 3.0 & 3.1)
# ---------------------------------------------------------------------------

@dataclass
class MemoryItem:
    item_id: int
    content: str
    timestamp: float
    importance: float = 0.5
    tags: List[str] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    strength: float = 1.0
    confirmations: int = 1


class WorkingMemory:
    def __init__(self, capacity: int = 7, decay: float = 0.96):
        self.capacity = max(1, int(capacity))
        self.decay = _clamp(decay, 0.0, 1.0)
        self.items: List[MemoryItem] = []
        self._next_id = 1

    def add(self, content: str, importance: float = 0.5,
            tags: Optional[List[str]] = None, context: Optional[dict] = None) -> MemoryItem:
        item = MemoryItem(self._next_id, str(content), _now(),
                          _clamp(importance, 0, 1), list(tags or []), dict(context or {}))
        self._next_id += 1
        self.items.append(item)
        if len(self.items) > self.capacity:
            self.items.sort(key=lambda x: (x.importance * x.strength, x.timestamp), reverse=True)
            self.items = self.items[:self.capacity]
        return item

    def tick(self) -> None:
        for item in self.items:
            item.strength *= self.decay
        self.items = [x for x in self.items if x.strength > 0.02]

    def retrieve(self, query: str, limit: int = 5) -> List[MemoryItem]:
        q = set(_tokens(query))
        ranked = []
        for item in self.items:
            overlap = len(q & set(_tokens(item.content + " " + " ".join(item.tags))))
            score = overlap + item.importance + item.strength
            if score > 1.0:
                ranked.append((score, item))
        return [x[1] for x in sorted(ranked, key=lambda x: x[0], reverse=True)[:limit]]


class EpisodicMemory:
    def __init__(self):
        self.items: Dict[int, MemoryItem] = {}
        self._next_id = 1

    def store(self, content: str, importance: float = 0.5,
              tags: Optional[List[str]] = None, context: Optional[dict] = None) -> MemoryItem:
        item = MemoryItem(self._next_id, str(content), _now(),
                          _clamp(importance, 0, 1), list(tags or []), dict(context or {}))
        self.items[item.item_id] = item
        self._next_id += 1
        return item

    def retrieve(self, query: str, limit: int = 5) -> List[MemoryItem]:
        q = set(_tokens(query))
        ranked = []
        for item in self.items.values():
            words = set(_tokens(item.content + " " + " ".join(item.tags)))
            overlap = len(q & words)
            if overlap:
                age_days = max(0, (_now() - item.timestamp) / 86400)
                score = overlap * item.strength + item.importance - min(age_days / 365, 0.5)
                ranked.append((score, item))
        return [x[1] for x in sorted(ranked, key=lambda x: x[0], reverse=True)[:limit]]


class SemanticMemory:
    def __init__(self):
        self.facts: List[Dict[str, Any]] = []

    def add_fact(self, subject: str, relation: str, obj: str,
                 source_episode: Optional[int] = None, confidence: float = 0.7) -> Dict[str, Any]:
        fact = {"subject": str(subject), "relation": str(relation), "object": str(obj),
                "source_episode": source_episode, "confidence": _clamp(confidence, 0, 1)}
        for old in self.facts:
            if (old["subject"], old["relation"], old["object"]) == (
                fact["subject"], fact["relation"], fact["object"]):
                old["confidence"] = max(old["confidence"], fact["confidence"])
                return old
        self.facts.append(fact)
        return fact

    def query(self, subject: Optional[str] = None,
              relation: Optional[str] = None, obj: Optional[str] = None) -> List[dict]:
        return [f for f in self.facts
                if (subject is None or f["subject"].lower() == subject.lower())
                and (relation is None or f["relation"].lower() == relation.lower())
                and (obj is None or f["object"].lower() == obj.lower())]


class AssociativeLearning:
    def __init__(self):
        self.weights: Dict[str, float] = {}

    @staticmethod
    def key(a: str, b: str) -> str:
        return "|".join(sorted((str(a).lower(), str(b).lower())))

    def reinforce(self, a: str, b: str, feedback: float = 1.0) -> float:
        k = self.key(a, b)
        self.weights[k] = _clamp(self.weights.get(k, 0.0) + 0.1 * feedback, -1, 1)
        return self.weights[k]

    def strength(self, a: str, b: str) -> float:
        return self.weights.get(self.key(a, b), 0.0)


class MemoryConsolidator:
    def __init__(self, episodic: EpisodicMemory, semantic: SemanticMemory,
                 threshold: int = 2):
        self.episodic = episodic
        self.semantic = semantic
        self.threshold = max(1, int(threshold))
        self.candidates: Dict[Tuple[str, str, str], int] = defaultdict(int)

    def observe_fact(self, subject: str, relation: str, obj: str,
                     episode_id: int, confirmed: bool = False) -> bool:
        key = (subject, relation, obj)
        self.candidates[key] += 1
        if confirmed or self.candidates[key] >= self.threshold:
            self.semantic.add_fact(subject, relation, obj, episode_id, 0.9 if confirmed else 0.75)
            return True
        return False


class ContextualRetriever:
    def __init__(self, working: WorkingMemory, episodic: EpisodicMemory,
                 semantic: SemanticMemory):
        self.working, self.episodic, self.semantic = working, episodic, semantic

    def retrieve(self, query: str, limit: int = 10) -> Dict[str, Any]:
        facts = []
        q = set(_tokens(query))
        for fact in self.semantic.facts:
            text = " ".join([fact["subject"], fact["relation"], fact["object"]])
            score = len(q & set(_tokens(text))) + fact["confidence"]
            if score > 1:
                facts.append((score, fact))
        return {
            "working": [asdict(x) for x in self.working.retrieve(query, limit)],
            "episodic": [asdict(x) for x in self.episodic.retrieve(query, limit)],
            "semantic": [x[1] for x in sorted(facts, key=lambda z: z[0], reverse=True)[:limit]],
        }


class STDPPlasticity:
    def __init__(self, a_plus: float = 0.015, a_minus: float = 0.012,
                 trace_decay: float = 0.90, min_weight: float = -5.0,
                 max_weight: float = 5.0):
        self.a_plus = float(a_plus)
        self.a_minus = float(a_minus)
        self.trace_decay = _clamp(trace_decay, 0.0, 1.0)
        self.min_weight = float(min_weight)
        self.max_weight = float(max_weight)
        self.pre_trace: Dict[int, float] = defaultdict(float)
        self.post_trace: Dict[int, float] = defaultdict(float)
        self.updates = 0

    def update(self, network: SpatialNeuralNetwork, fired: List[int]) -> None:
        fired_set = set(fired)
        for source in fired_set:
            for syn in network.outgoing.get(source, []):
                if syn.target in self.post_trace:
                    syn.weight = _clamp(
                        syn.weight + self.a_plus * self.post_trace[syn.target],
                        self.min_weight, self.max_weight
                    )
                    self.updates += 1

        incoming = []
        for source, synapses in network.outgoing.items():
            for syn in synapses:
                if syn.target in fired_set and self.pre_trace.get(source, 0.0) > 0:
                    incoming.append((source, syn))
        for source, syn in incoming:
            syn.weight = _clamp(
                syn.weight - self.a_minus * self.pre_trace[source],
                self.min_weight, self.max_weight
            )
            self.updates += 1

        for key in list(self.pre_trace):
            self.pre_trace[key] *= self.trace_decay
            if self.pre_trace[key] < 1e-6:
                del self.pre_trace[key]
        for key in list(self.post_trace):
            self.post_trace[key] *= self.trace_decay
            if self.post_trace[key] < 1e-6:
                del self.post_trace[key]
        for neuron_id in fired_set:
            self.pre_trace[neuron_id] += 1.0
            self.post_trace[neuron_id] += 1.0

    def state(self) -> dict:
        return {
            "a_plus": self.a_plus, "a_minus": self.a_minus,
            "trace_decay": self.trace_decay,
            "min_weight": self.min_weight, "max_weight": self.max_weight,
            "pre_trace": {str(k): float(v) for k, v in self.pre_trace.items()},
            "post_trace": {str(k): float(v) for k, v in self.post_trace.items()},
            "updates": self.updates
        }

    def load_state(self, data: dict) -> None:
        self.a_plus = data["a_plus"]
        self.a_minus = data["a_minus"]
        self.trace_decay = data["trace_decay"]
        self.min_weight = data["min_weight"]
        self.max_weight = data["max_weight"]
        self.pre_trace = defaultdict(float, {
            int(k): float(v) for k, v in data.get("pre_trace", {}).items()
        })
        self.post_trace = defaultdict(float, {
            int(k): float(v) for k, v in data.get("post_trace", {}).items()
        })
        self.updates = int(data.get("updates", 0))


class RewardLearning:
    def __init__(self, alpha: float = 0.15, gamma: float = 0.90,
                 epsilon: float = 0.10):
        self.alpha = _clamp(alpha, 0.001, 1.0)
        self.gamma = _clamp(gamma, 0.0, 1.0)
        self.epsilon = _clamp(epsilon, 0.0, 1.0)
        self.q_values: Dict[str, Dict[str, float]] = defaultdict(dict)
        self.updates = 0

    def value(self, state: str, action: str) -> float:
        return float(self.q_values.get(str(state), {}).get(str(action), 0.0))

    def choose(self, state: str, actions: List[str],
               explore: bool = False) -> Optional[str]:
        if not actions:
            return None
        state = str(state)
        values = self.q_values.get(state, {})
        if explore and random.random() < self.epsilon:
            return random.choice(actions)
        return max(actions, key=lambda a: values.get(str(a), 0.0))

    def update(self, state: str, action: str, reward: float,
               next_state: str, next_actions: Optional[List[str]] = None) -> float:
        state, action, next_state = str(state), str(action), str(next_state)
        old = self.value(state, action)
        next_actions = list(next_actions or [])
        future = max((self.value(next_state, a) for a in next_actions), default=0.0)
        target = float(reward) + self.gamma * future
        new_value = old + self.alpha * (target - old)
        self.q_values[state][action] = new_value
        self.updates += 1
        return new_value

    def state(self) -> dict:
        return {"alpha": self.alpha, "gamma": self.gamma,
                "epsilon": self.epsilon, "q_values": self.q_values,
                "updates": self.updates}

    def load_state(self, data: dict) -> None:
        self.alpha = data["alpha"]
        self.gamma = data["gamma"]
        self.epsilon = data["epsilon"]
        self.q_values = defaultdict(dict, {
            str(k): {str(a): float(v) for a, v in val.items()}
            for k, val in data.get("q_values", {}).items()
        })
        self.updates = int(data.get("updates", 0))


class GoalManager:
    def __init__(self):
        self.goals: Dict[str, dict] = {}

    def add(self, goal_id: str, description: str,
            steps: Optional[List[str]] = None) -> dict:
        if goal_id in self.goals:
            raise ValueError("Já existe um objetivo com esse identificador.")
        self.goals[str(goal_id)] = {
            "description": str(description),
            "steps": [{"name": str(s), "done": False} for s in (steps or [])],
            "status": "active", "created_at": _now()
        }
        return self.goals[str(goal_id)]

    def complete_step(self, goal_id: str, step_name: str) -> dict:
        if goal_id not in self.goals:
            raise KeyError("Objetivo não encontrado.")
        goal = self.goals[goal_id]
        match = next((s for s in goal["steps"] if s["name"] == step_name), None)
        if match is None:
            raise KeyError("Passo não encontrado.")
        match["done"] = True
        if all(s["done"] for s in goal["steps"]):
            goal["status"] = "completed"
        return goal

    def list(self) -> List[dict]:
        return [{"id": k, **v} for k, v in self.goals.items()]


class LanguageProcessor:
    def __init__(self, retriever: ContextualRetriever):
        self.retriever = retriever

    def analyze(self, text: str) -> dict:
        words = _tokens(text)
        return {"text": str(text), "tokens": words, "token_count": len(words),
                "question": str(text).strip().endswith("?"),
                "memory_context": self.retriever.retrieve(text, 5)}

    def respond(self, text: str) -> str:
        analysis = self.analyze(text)
        if not analysis["tokens"]:
            return "Não recebi conteúdo suficiente para processar."
        memories = analysis["memory_context"]
        known = []
        for group in ("semantic", "episodic", "working"):
            known.extend(memories[group])
        if known:
            return "Encontrei informação relacionada na memória. " + str(known[0])
        return ("Texto processado por análise simbólica: " +
                ", ".join(analysis["tokens"][:12]))


class SensoryPathwaySystem:
    PATHWAYS = {
        "vision": ("thalamus", "occipital"),
        "hearing": ("thalamus", "temporal"),
        "touch": ("thalamus", "parietal"),
        "smell": ("olfactory_bulb", "temporal"),
        "taste": ("brainstem", "insula"),
    }

    def __init__(self, max_history: int = 100):
        self.max_history = int(max_history)
        self.routes: deque[dict] = deque(maxlen=self.max_history)
        self.last_inputs: Dict[str, dict] = {}

    def route(self, sense: str, features: Any, confidence: float = 1.0) -> dict:
        if sense not in VALID_SENSES:
            raise ValueError("Sentido não suportado.")
        relay, destination = self.PATHWAYS[sense]
        result = {
            "sense": sense,
            "relay": relay,
            "destination": destination,
            "features": features,
            "confidence": _clamp(confidence, 0, 1),
            "timestamp": _now()
        }
        self.routes.append(result)
        self.last_inputs[sense] = result
        return result


# ---------------------------------------------------------------------------
# 4. FACHADA UNIFICADA COMPLETA (ABM 3.3)
# ---------------------------------------------------------------------------

class ABM33:
    """
    Fachada única totalmente unificada: Rede Espacial 3D, STDP, Q-Learning,
    Fisiologia, Metabolismo, Biomecânica, Sono, Memórias e Persistência Robusta.
    """
    def __init__(self, total_virtual_neurons: int = TOTAL_VIRTUAL_NEURONS):
        self.version = "3.4"
        self.network = SpatialNeuralNetwork(total_virtual_neurons)
        self.physiology = UnifiedPhysiologySystem()
        self.body = UnifiedBiomechanicalBody()
        self.sleep_glymphatic = UnifiedSleepGlymphatic()
        
        self.stdp = STDPPlasticity()
        self.reward_learning = RewardLearning()
        self.goal_manager = GoalManager()
        
        self.working_memory = WorkingMemory()
        self.episodic_memory = EpisodicMemory()
        self.semantic_memory = SemanticMemory()
        self.associative_learning = AssociativeLearning()
        self.consolidator = MemoryConsolidator(self.episodic_memory, self.semantic_memory)
        self.retriever = ContextualRetriever(self.working_memory, self.episodic_memory, self.semantic_memory)
        
        self.sensory_pathways = SensoryPathwaySystem()
        self.language = LanguageProcessor(self.retriever)
        self.architecture_assignments: Dict[str, str] = {}

    def assign_region(self, label: str, region: str) -> None:
        if region not in REGIONS and region not in LOBE_TO_REGION:
            raise ValueError("Região não reconhecida.")
        self.architecture_assignments[str(label)] = region

    def perceive(self, sense: str, features: Any, confidence: float = 1.0) -> dict:
        routed = self.sensory_pathways.route(sense, features, confidence)
        self.working_memory.add(
            f"rota sensorial {sense} para {routed['destination']}",
            importance=confidence, tags=[sense, routed["destination"]],
            context={"relay": routed["relay"]}
        )
        return routed

    def remember(self, content: str, importance: float = 0.5,
                 tags: Optional[List[str]] = None, context: Optional[dict] = None) -> int:
        episode = self.episodic_memory.store(content, importance, tags, context)
        self.working_memory.add(content, importance, tags, context)
        return episode.item_id

    def learn_fact(self, subject: str, relation: str, obj: str,
                   episode_id: Optional[int] = None, confirmed: bool = False) -> bool:
        if episode_id is None:
            episode_id = self.remember(f"{subject} {relation} {obj}", 0.7, tags=[subject, relation, obj])
        return self.consolidator.observe_fact(subject, relation, obj, episode_id, confirmed)

    def learn_from_reward(self, state: str, action: str, reward: float,
                          next_state: str = "terminal",
                          next_actions: Optional[List[str]] = None) -> float:
        val = self.reward_learning.update(state, action, reward, next_state, next_actions)
        self.associative_learning.reinforce(state, action, reward)
        return val

    def choose_action(self, state: str, actions: List[str], explore: bool = False) -> Optional[str]:
        return self.reward_learning.choose(state, actions, explore)

    def regulate(self, workload: float = 0.0, threat: float = 0.0,
                 rest: float = 0.0, sleep_hours: float = 0.0) -> dict:
        physio = self.physiology.update(workload, threat, rest)
        sleep = self.sleep_glymphatic.advance(
            sleep_hours if sleep_hours > 0 else 1.0, sleep=(sleep_hours > 0)
        )
        return {"physiology": physio, "sleep": sleep}

    def step(self, count: int = 1, external: Optional[Dict[int, float]] = None) -> List[List[int]]:
        if count < 0:
            raise ValueError("count não pode ser negativo.")
        results = []
        for index in range(count):
            ext = external if index == 0 else None
            atp = self.physiology.atp_level
            fired = self.network.step(ext, available_atp=atp)
            self.stdp.update(self.network, fired)
            self.brain.update_activity(fired)
            results.append(fired)
        self.working_memory.tick()
        self.physiology.update(workload=count)
        return results

    def status(self) -> dict:
        return {
            "version": self.version,
            "network": self.network.status(),
            "memory": {
                "working": len(self.working_memory.items),
                "episodic": len(self.episodic_memory.items),
                "semantic_facts": len(self.semantic_memory.facts),
                "associations": len(self.associative_learning.weights),
            },
            "physiology": self.physiology.state(),
            "sleep": self.sleep_glymphatic.state(),
            "body": self.body.state(),
            "scientific_limit": "Modelo experimental unificado; não é cérebro humano nem consciência."
        }

    def save(self, filepath: str) -> None:
        data = {
            "version": self.version,
            "total_virtual_neurons": self.network.total_virtual,
            "network": {
                "tick": self.network.tick,
                "neurons": [asdict(n) for n in self.network.neurons.values()],
                "synapses": [asdict(s) for group in self.network.outgoing.values() for s in group],
                "pending": {str(k): v for k, v in self.network.pending.items()},
                "spike_log": list(self.network.spike_log),
            },
            "architecture": self.architecture_assignments,
            "physiology": self.physiology.state(),
            "body": {
                "joint_angles": self.body.joint_angles,
                "muscle_tension": self.body.muscle_tension,
                "fatigue": self.body.fatigue,
                "motor_state": self.body.motor_state,
                "last_command": self.body.last_command,
                "command_history": list(self.body.command_history)
            },
            "sleep_glymphatic": self.sleep_glymphatic.state(),
            "stdp": self.stdp.state(),
            "reward_learning": self.reward_learning.state(),
            "goals": self.goal_manager.goals,
            "working_memory": [asdict(x) for x in self.working_memory.items],
            "working_next_id": self.working_memory._next_id,
            "episodic_memory": [asdict(x) for x in self.episodic_memory.items.values()],
            "episodic_next_id": self.episodic_memory._next_id,
            "semantic_facts": self.semantic_memory.facts,
            "associations": self.associative_learning.weights,
            "consolidation_candidates": [[list(k), v] for k, v in self.consolidator.candidates.items()],
            "sensory_routes": list(self.sensory_pathways.routes),
            "sensory_last_inputs": self.sensory_pathways.last_inputs,
        }
        Path(filepath).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, filepath: str) -> "ABM33":
        data = json.loads(Path(filepath).read_text(encoding="utf-8"))
        abm = cls(data.get("total_virtual_neurons", TOTAL_VIRTUAL_NEURONS))
        net = data["network"]
        abm.network.tick = net["tick"]
        abm.network.neurons = {
            n["neuron_id"]: Neuron3D(**n) for n in net["neurons"]
        }
        for s in net["synapses"]:
            syn = Synapse3D(**s)
            abm.network.outgoing[syn.source].append(syn)
        abm.network.pending = defaultdict(list, {
            int(k): [tuple(x) for x in v] for k, v in net["pending"].items()
        })
        abm.network.spike_log = deque(net["spike_log"], maxlen=abm.network.max_log_size)
        
        abm.architecture_assignments = data.get("architecture", {})
        
        physio = data.get("physiology", {})
        for k, v in physio.items():
            if hasattr(abm.physiology, k) and k != "blood_pressure":
                setattr(abm.physiology, k, v)
        
        body_data = data.get("body", {})
        abm.body.joint_angles = body_data.get("joint_angles", abm.body.joint_angles)
        abm.body.muscle_tension = body_data.get("muscle_tension", abm.body.muscle_tension)
        abm.body.fatigue = body_data.get("fatigue", 0.0)
        abm.body.motor_state = body_data.get("motor_state", "idle")
        abm.body.last_command = body_data.get("last_command")
        abm.body.command_history = deque(body_data.get("command_history", []), maxlen=abm.body.max_history)
        
        sleep_data = data.get("sleep_glymphatic", {})
        for k, v in sleep_data.items():
            if hasattr(abm.sleep_glymphatic, k) and k != "state":
                setattr(abm.sleep_glymphatic, k, v)
        if "state" in sleep_data:
            abm.sleep_glymphatic.state_name = sleep_data["state"]

        if "stdp" in data:
            abm.stdp.load_state(data["stdp"])
        if "reward_learning" in data:
            abm.reward_learning.load_state(data["reward_learning"])
        
        abm.goal_manager.goals = data.get("goals", {})
        abm.working_memory.items = [MemoryItem(**x) for x in data.get("working_memory", [])]
        abm.working_memory._next_id = data.get("working_next_id", 1)
        abm.episodic_memory.items = {
            x["item_id"]: MemoryItem(**x) for x in data.get("episodic_memory", [])
        }
        abm.episodic_memory._next_id = data.get("episodic_next_id", 1)
        abm.semantic_memory.facts = data.get("semantic_facts", [])
        abm.associative_learning.weights = data.get("associations", {})
        abm.consolidator.candidates = defaultdict(int, {
            tuple(k): v for k, v in data.get("consolidation_candidates", [])
        })
        abm.sensory_pathways.routes = deque(data.get("sensory_routes", []), maxlen=abm.sensory_pathways.max_history)
        abm.sensory_pathways.last_inputs = data.get("sensory_last_inputs", {})
        return abm


# ---------------------------------------------------------------------------
# 5. SUÍTE DE TESTES AUTOMATIZADOS RIGOROSOS
# ---------------------------------------------------------------------------

def run_comprehensive_tests() -> dict:
    results = {}
    
    # Teste 1: Rede Espacial 3D e Atrasos Dependentes da Distância
    net = SpatialNeuralNetwork(1000)
    net.create_neuron(1, region="cortex", x=0, y=0, z=0, threshold=-69.9)
    net.create_neuron(2, region="cortex", x=100, y=0, z=0, threshold=-69.9)
    syn = net.connect(1, 2, weight=100.0, base_delay=1, conduction_speed=50.0)
    assert syn.euclidean_distance == 100.0
    assert syn.delay_steps > 1
    net.inject(1, 1000)
    net.step()
    net.step() # ciclo 1
    net.step() # ciclo 2
    fired = net.step() # evento chega no ciclo 3
    assert 2 in fired
    results["spatial_network_and_delays"] = "PASSOU"

    # Teste 2: Estabilidade de Logs com Janela Deslizante (Memory Leak Prevention)
    net_log = SpatialNeuralNetwork(100, max_log_size=5)
    net_log.create_neuron(1, x=0, y=0, z=0, threshold=-75.0)
    for _ in range(10):
        net_log.spike_log.append(1)
    assert len(net_log.spike_log) == 5
    results["log_memory_leak_fix"] = "PASSOU"

    # Teste 3: Fisiologia, Metabolismo e Biomecânica Unificados
    abm = ABM33(1000)
    abm.network.create_neuron(10, x=10, y=10, z=10)
    abm.network.create_neuron(11, x=20, y=20, z=20)
    abm.network.connect(10, 11, weight=1.5)
    reg = abm.regulate(workload=4.0, threat=0.5, sleep_hours=0)
    assert reg["physiology"]["atp_level"] < 1.0
    body_cmd = abm.body.prepare_action("lift", target="box", intensity=0.7)
    assert body_cmd["status"] == "prepared_not_executed"
    results["physiology_biomechanics_integration"] = "PASSOU"

    # Teste 4: STDP, Q-Learning e Objetivos (Versões 3.0/3.1)
    abm.learn_from_reward("inicio", "agir", 1.0, "fim")
    assert abm.choose_action("inicio", ["agir"]) == "agir"
    abm.goal_manager.add("g1", "Teste", ["passo1"])
    abm.goal_manager.complete_step("g1", "passo1")
    assert abm.goal_manager.goals["g1"]["status"] == "completed"
    results["cognition_learning_goals"] = "PASSOU"

    # Teste 5: Persistência Robusta Completa (JSON Round-Trip)
    with tempfile.TemporaryDirectory() as folder:
        path = str(Path(folder) / "abm33_state.json")
        abm.remember("Memória de teste persistente", 0.9, ["teste"])
        abm.learn_fact("Sistema", "versao", "3.3", confirmed=True)
        abm.save(path)
        
        loaded = ABM33.load(path)
        assert loaded.version == "3.4"
        assert loaded.status()["memory"]["episodic"] == 2
        assert loaded.semantic_memory.query(subject="Sistema")
        assert len(loaded.network.neurons) == 2
    results["robust_json_persistence"] = "PASSOU"

    # Teste 6: Hodgkin-Huxley real e selecionável
    hh = SpatialNeuralNetwork(10)
    hhn = hh.create_neuron(1, model="hh")
    initial_v = hhn.v_membrane
    for _ in range(2000):
        hh.step({1: 50.0}, available_atp=1.0)
    assert hhn.model == "hh" and math.isfinite(hhn.v_membrane)
    assert hhn.v_membrane != initial_v and hhn.spikes > 0
    results["hodgkin_huxley_dynamics"] = "PASSOU"

    # Teste 7: Persistência dos parâmetros fisiológicos e das entradas sensoriais
    with tempfile.TemporaryDirectory() as folder:
        path = str(Path(folder) / "abm34_state.json")
        abm.physiology.systolic_bp = 132.0
        abm.physiology.diastolic_bp = 86.0
        abm.perceive("vision", {"object": "teste"}, 0.8)
        abm.save(path)
        loaded = ABM33.load(path)
        assert loaded.physiology.systolic_bp == 132.0
        assert loaded.physiology.diastolic_bp == 86.0
        assert "vision" in loaded.sensory_pathways.last_inputs
    results["physiology_and_sensory_persistence"] = "PASSOU"

    return {
        "status": "PASSOU_TOTALMENTE",
        "tests_executed": len(results),
        "module_results": results
    }


# ---------------------------------------------------------------------------
# ABM 4.1 — CAMADA FUNCIONAL MULTISSISTEMA (extensão compatível com 3.4)
# ---------------------------------------------------------------------------

ABM_VERSION = "4.1"

class BrainArchitecture:
    """Regiões funcionais ligadas por sinapses reais entre neurónios materializados.

    As regiões são abstrações computacionais, não uma reconstrução anatómica integral.
    """
    REGION_ROLES = {
        "prefrontal": "planeamento, controlo executivo e decisão",
        "motor": "planeamento e comando motor simulado",
        "somatosensory": "integração tátil e proprioceptiva",
        "visual": "processamento de características visuais",
        "auditory": "processamento de características auditivas",
        "hippocampus": "formação e recuperação episódica",
        "amygdala": "avaliação de saliência e ameaça",
        "thalamus": "encaminhamento sensorial",
        "hypothalamus": "homeostase e regulação autonómica simulada",
        "cerebellum": "ajuste e previsão motora",
        "basal_ganglia": "seleção de ações e aprendizagem por recompensa",
        "brainstem": "ritmos vitais simulados",
        "language": "processamento simbólico de linguagem",
        "insula": "integração interoceptiva e gustativa simulada",
        "cingulate": "monitorização de conflito e saliência",
    }
    NETWORK_REGION = {
        "prefrontal":"prefrontal", "motor":"motor", "somatosensory":"somatosensory",
        "visual":"visual", "auditory":"auditory", "hippocampus":"hippocampus",
        "amygdala":"amygdala", "thalamus":"thalamus", "hypothalamus":"hypothalamus",
        "cerebellum":"cerebellum", "basal_ganglia":"basal_ganglia",
        "brainstem":"brainstem", "language":"language", "insula":"insula", "cingulate":"cingulate"
    }
    def __init__(self, network):
        self.network = network
        self.regions = {k: {"role":v, "neurons":[], "activity":0.0, "last_fired":0} for k,v in self.REGION_ROLES.items()}
        self.projections=[]
        self._next_neuron=0
        self._connected_pairs=set()
        self._build_interregional_routes()

    def _build_interregional_routes(self):
        links=[("thalamus","visual"),("thalamus","auditory"),("thalamus","somatosensory"),
          ("visual","hippocampus"),("auditory","hippocampus"),("somatosensory","hippocampus"),
          ("hippocampus","prefrontal"),("amygdala","prefrontal"),("prefrontal","basal_ganglia"),
          ("basal_ganglia","motor"),("motor","cerebellum"),("cerebellum","motor"),
          ("hypothalamus","brainstem"),("prefrontal","language"),("language","hippocampus"),
          ("insula","amygdala"),("cingulate","prefrontal"),("thalamus","insula")]
        for a,b in links:
            self.projections.append({"source":a,"target":b,"weight":400.0,"signals":0,"synapses":0})

    def _connect_available_projection(self, projection):
        src=self.regions[projection["source"]]["neurons"]
        dst=self.regions[projection["target"]]["neurons"]
        if not src or not dst: return
        # Sparse deterministic connectivity: up to two targets per source.
        for i,sid in enumerate(src):
            for offset in range(min(2,len(dst))):
                tid=dst[(i+offset)%len(dst)]
                key=(sid,tid)
                if key in self._connected_pairs: continue
                self.network.connect(sid,tid,weight=projection["weight"],base_delay=1,
                                     transmitter="glutamate",conduction_speed=10.0)
                self._connected_pairs.add(key); projection["synapses"]+=1

    def activate(self, region, level):
        if region not in self.regions: raise ValueError(f"Região cerebral desconhecida: {region}")
        level=_clamp(level,0,1); self.regions[region]["activity"]=level
        neurons=self.regions[region]["neurons"]
        if neurons and level>0:
            current=level*400.0
            for nid in neurons: self.network.inject(nid,current)
        return level

    def materialize_population(self, region, count=8, model="lif"):
        if region not in self.regions: raise ValueError("Região desconhecida")
        if not isinstance(count,int) or count<1 or count>10000: raise ValueError("count deve estar entre 1 e 10000")
        created=[]
        for _ in range(count):
            while self._next_neuron in self.network.neurons: self._next_neuron+=1
            nid=self._next_neuron; self._next_neuron+=1
            self.network.create_neuron(nid,region=self.NETWORK_REGION[region],model=model)
            self.regions[region]["neurons"].append(nid); created.append(nid)
        for projection in self.projections:
            if projection["source"]==region or projection["target"]==region:
                self._connect_available_projection(projection)
        return created

    def update_activity(self, fired):
        fired=set(fired)
        for name,data in self.regions.items():
            hits=sum(1 for nid in data["neurons"] if nid in fired)
            if hits:
                data["last_fired"]+=hits
                data["activity"]=_clamp(.7*data["activity"]+.3*hits/max(1,len(data["neurons"])),0,1)
            else:
                data["activity"]*=.98
        for p in self.projections:
            source_ids=set(self.regions[p["source"]]["neurons"])
            p["signals"]+=sum(1 for nid in fired if nid in source_ids)

    def state(self):
        return {"regions":self.regions,"projections":self.projections,"next_neuron":self._next_neuron,
                "connected_pairs":[list(x) for x in sorted(self._connected_pairs)]}


class AdvancedMemory:
    """Memória autobiográfica, esquecimento seletivo, associação e recuperação."""
    def __init__(self, abm):
        self.abm=abm; self.autobiographical=[]; self.links=defaultdict(set); self.max_items=10000
    def encode_event(self, event, context=None, importance=.5, emotional_salience=0.0):
        context=dict(context or {}); context["emotional_salience"]=_clamp(emotional_salience,0,1)
        eid=self.abm.remember(event, max(importance, emotional_salience*.8), tags=_tokens(event)[:12], context=context)
        self.autobiographical.append({"episode_id":eid,"event":str(event),"time":_now(),"context":context})
        if len(self.autobiographical)>self.max_items: self.autobiographical=self.autobiographical[-self.max_items:]
        words=set(_tokens(event))
        for w in words: self.links[w].add(eid)
        return eid
    def associate(self, episode_a, episode_b):
        ids=set(self.abm.episodic_memory.items)
        if episode_a not in ids or episode_b not in ids: raise KeyError("Episódio inexistente")
        self.links[f"episode:{episode_a}"].add(episode_b); self.links[f"episode:{episode_b}"].add(episode_a)
        return True
    def forget(self, min_strength=.05, max_importance=.25):
        removed=[]
        for eid,item in list(self.abm.episodic_memory.items.items()):
            if item.strength < min_strength and item.importance <= max_importance:
                removed.append(eid); del self.abm.episodic_memory.items[eid]
        self.autobiographical=[x for x in self.autobiographical if x["episode_id"] not in removed]
        removed_set=set(removed)
        for key, linked in list(self.links.items()):
            linked.difference_update(removed_set)
            if key.startswith("episode:") and int(key.split(":",1)[1]) in removed_set:
                del self.links[key]
            elif not linked:
                del self.links[key]
        return removed
    def retrieve(self, query, limit=5):
        if limit < 1: return []
        base=self.abm.retriever.retrieve(query, max(limit,limit*2))
        seeds={int(item["item_id"]) for item in base.get("episodic",[])}
        expanded=set(seeds)
        for eid in seeds:
            expanded.update(self.links.get(f"episode:{eid}",set()))
        ranked=[]
        for eid in expanded:
            item=self.abm.episodic_memory.items.get(eid)
            if item is None: continue
            linked_bonus=.25 if eid not in seeds else 0.0
            ranked.append((item.importance*item.strength+linked_bonus,item))
        ranked.sort(key=lambda x:x[0],reverse=True)
        return [item for _,item in ranked[:limit]]


class ReasoningEngine:
    """Raciocínio simbólico verificável; não é um modelo linguístico geral."""
    def __init__(self, abm): self.abm=abm; self.error_log=deque(maxlen=1000)
    def infer(self, subject=None):
        facts=self.abm.semantic_memory.facts
        by_subject=defaultdict(list)
        for f in facts: by_subject[f["subject"]].append(f)
        return by_subject.get(subject,[]) if subject else list(facts)
    def solve_arithmetic(self, expression):
        if not re.fullmatch(r"[0-9+*/().% \-]+", str(expression)): raise ValueError("Expressão contém símbolos não permitidos")
        try: return eval(expression,{"__builtins__":{}},{})
        except Exception as e: self.error_log.append({"input":expression,"error":str(e)}); raise ValueError("Expressão matemática inválida")
    def plan(self, goal, actions):
        if not actions: return {"goal":goal,"plan":[],"status":"no_actions"}
        ranked=sorted(actions,key=lambda a:self.abm.reward_learning.value(goal,a),reverse=True)
        return {"goal":str(goal),"plan":ranked,"status":"planned"}
    def evaluate(self, expected, actual):
        ok=expected==actual
        if not ok: self.error_log.append({"expected":expected,"actual":actual,"time":_now()})
        return {"correct":ok,"error":None if ok else {"expected":expected,"actual":actual}}


class MultisensoryProcessor:
    """Entrada multimodal baseada em características; reconhecedores externos são opcionais."""
    def __init__(self, abm): self.abm=abm; self.last_motion=None
    def vision(self, features, confidence=.8):
        if not isinstance(features,(dict,list,tuple,str)): raise TypeError("Forneça características visuais estruturadas")
        r=self.abm.perceive("vision",features,confidence); self.abm.brain.activate("visual",confidence); return r
    def hearing(self, features, confidence=.8, transcript=None):
        payload={"features":features,"transcript":transcript}
        r=self.abm.perceive("hearing",payload,confidence); self.abm.brain.activate("auditory",confidence)
        if transcript: self.abm.language.analyze(transcript)
        return r
    def speech_text(self, text, confidence=.9):
        if not str(text).strip(): raise ValueError("Texto de fala vazio")
        return self.hearing({"speech_text":str(text)},confidence,transcript=str(text))
    def motion(self, position):
        if not isinstance(position,(list,tuple)) or len(position)!=3: raise ValueError("position deve ter 3 coordenadas")
        p=tuple(float(x) for x in position); speed=0.0
        if self.last_motion is not None: speed=math.sqrt(sum((a-b)**2 for a,b in zip(p,self.last_motion)))
        self.last_motion=p
        self.abm.perceive("touch",{"position":p,"displacement":speed},.8)
        return {"position":p,"displacement":speed}


class EmotionMotivation:
    def __init__(self): self.emotions={"joy":0.0,"fear":0.0,"sadness":0.0,"anger":0.0,"curiosity":.3,"calm":.5}; self.drives={"exploration":.5,"safety":.8,"learning":.6}
    def update(self, reward=0.0, threat=0.0, novelty=0.0, fatigue=0.0):
        e=self.emotions
        e["joy"]=_clamp(e["joy"]*.9+max(0,reward)*.1,0,1); e["fear"]=_clamp(e["fear"]*.9+threat*.1,0,1)
        e["anger"]=_clamp(e["anger"]*.9+max(0,threat-reward)*.05,0,1); e["curiosity"]=_clamp(e["curiosity"]*.9+novelty*.1,0,1)
        e["sadness"]=_clamp(e["sadness"]*.95+fatigue*.05,0,1); e["calm"]=_clamp(1-max(e["fear"],e["anger"]),0,1)
        self.drives["exploration"]=_clamp(.5+novelty*.3-fatigue*.2,0,1); self.drives["safety"]=_clamp(.5+threat*.5,0,1)
        return self.state()
    def state(self): return {"emotions":dict(self.emotions),"drives":dict(self.drives)}


class AutonomicEndocrineSystem:
    """Modelo didático de regulação autonómica/hormonal, não fisiologia clínica."""
    def __init__(self): self.sympathetic=.3; self.parasympathetic=.6; self.hormones={"cortisol":.2,"adrenaline":.1,"melatonin":.2,"dopamine":.5,"serotonin":.5}
    def update(self, stress, arousal, sleep_phase, reward=0):
        self.sympathetic=_clamp(.2+.7*stress,0,1); self.parasympathetic=_clamp(1-self.sympathetic+.1*(1-arousal),0,1)
        self.hormones["cortisol"]=_clamp(.8* self.hormones["cortisol"]+.2*stress,0,1)
        self.hormones["adrenaline"]=_clamp(.7*self.hormones["adrenaline"]+.3*arousal,0,1)
        self.hormones["melatonin"]=_clamp(.8*self.hormones["melatonin"]+.2*(1 if sleep_phase else 0),0,1)
        self.hormones["dopamine"]=_clamp(.9*self.hormones["dopamine"]+.1*(.5+reward),0,1)
        self.hormones["serotonin"]=_clamp(.95*self.hormones["serotonin"]+.05*(1-stress),0,1)
        return self.state()
    def state(self): return {"sympathetic":self.sympathetic,"parasympathetic":self.parasympathetic,"hormones":dict(self.hormones)}


class SleepArchitecture:
    def __init__(self): self.stage="awake"; self.elapsed=0.0; self.cycles=0; self.stages={"awake":0.0,"n1":0.0,"n2":0.0,"n3":0.0,"rem":0.0}
    def advance(self, hours, sleeping):
        if hours<0: raise ValueError("hours não pode ser negativo")
        if not sleeping: self.stage="awake"
        else:
            self.elapsed+=hours; phase=(self.elapsed%1.5)/1.5
            self.stage="n1" if phase<.08 else "n2" if phase<.45 else "n3" if phase<.72 else "rem"
            self.cycles=int(self.elapsed//1.5)
        self.stages[self.stage]+=hours
        return self.state()
    def state(self): return {"stage":self.stage,"elapsed_hours":self.elapsed,"cycles":self.cycles,"stage_hours":dict(self.stages)}


class ParallelExecutor:
    """Execução paralela segura para tarefas independentes de Python."""
    def map(self, fn, items, workers=2):
        from concurrent.futures import ThreadPoolExecutor
        if workers<1 or workers>32: raise ValueError("workers deve estar entre 1 e 32")
        with ThreadPoolExecutor(max_workers=workers) as pool: return list(pool.map(fn,items))


class ABM40(ABM33):
    """Fachada ABM 4.1: integra módulos cerebrais, cognitivos, sensoriais e corporais."""
    def __init__(self, total_virtual_neurons=TOTAL_VIRTUAL_NEURONS):
        super().__init__(total_virtual_neurons); self.version="4.1"
        self.brain=BrainArchitecture(self.network); self.advanced_memory=AdvancedMemory(self)
        self.reasoning=ReasoningEngine(self); self.senses=MultisensoryProcessor(self)
        self.emotion=EmotionMotivation(); self.autonomic=AutonomicEndocrineSystem()
        self.sleep_architecture=SleepArchitecture(); self.executor=ParallelExecutor()
        self.diagnostics=deque(maxlen=2000); self.experience_count=0

    def experience(self, event, reward=0.0, threat=0.0, novelty=.5, context=None):
        eid=self.advanced_memory.encode_event(event,context,importance=max(.2,abs(reward)),emotional_salience=max(threat,novelty)*.5)
        emo=self.emotion.update(reward,threat,novelty,self.body.fatigue)
        self.brain.activate("hippocampus",.8); self.brain.activate("amygdala",threat)
        self.learn_from_reward("experience",str(event),reward,"after_experience")
        self.experience_count+=1
        return {"episode_id":eid,"emotion":emo,"learned":True}

    def decide(self, state, actions, explore=False):
        if not actions: return None
        self.brain.activate("prefrontal",.8); self.brain.activate("basal_ganglia",.7)
        return self.choose_action(state,actions,explore) or self.reasoning.plan(state,actions)["plan"][0]

    def regulate(self, workload=0.0, threat=0.0, rest=0.0, sleep_hours=0.0):
        result=super().regulate(workload,threat,rest,sleep_hours)
        result["autonomic_endocrine"]=self.autonomic.update(self.physiology.stress,self.physiology.arousal,sleep_hours>0)
        result["sleep_stages"]=self.sleep_architecture.advance(sleep_hours if sleep_hours else 1.0,sleep_hours>0)
        result["emotion"]=self.emotion.update(threat=threat,novelty=workload*.05,fatigue=self.body.fatigue)
        return result

    def step(self,count=1,external=None):
        out=super().step(count,external)
        workload=sum(len(x) for x in out)/max(1,count)
        self.autonomic.update(self.physiology.stress,self.physiology.arousal,self.sleep_glymphatic.state_name=="sleep")
        self.diagnostics.append({"tick":self.network.tick,"fired":sum(map(len,out)),"atp":self.physiology.atp_level})
        return out

    def status(self):
        s=super().status(); s.update({"version":"4.1","brain_regions":len(self.brain.regions),"interregional_routes":len(self.brain.projections),
            "autobiographical_events":len(self.advanced_memory.autobiographical),"experiences":self.experience_count,
            "emotion":self.emotion.state(),"autonomic_endocrine":self.autonomic.state(),"sleep_architecture":self.sleep_architecture.state(),
            "diagnostic_samples":len(self.diagnostics),"capabilities_note":"Visão/áudio recebem características ou transcrição; reconhecimento bruto requer modelos externos. Simulações fisiológicas são didáticas."})
        return s

    def save(self, filepath):
        super().save(filepath)
        data=json.loads(Path(filepath).read_text(encoding="utf-8"))
        data["abm40"]={"brain":self.brain.state(),"autobiographical":self.advanced_memory.autobiographical,
            "memory_links":{k:list(v) for k,v in self.advanced_memory.links.items()},"emotion":self.emotion.state(),
            "autonomic":self.autonomic.state(),"sleep_architecture":self.sleep_architecture.state(),
            "experience_count":self.experience_count,"diagnostics":list(self.diagnostics),
            "reasoning_errors":list(self.reasoning.error_log),"last_motion":self.senses.last_motion}
        Path(filepath).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")

    @classmethod
    def load(cls, filepath):
        base=ABM33.load(filepath); obj=cls(base.network.total_virtual)
        # Transfere os objetos já restaurados para não perder estado validado da versão 3.4.
        for name in ("network","physiology","body","sleep_glymphatic","stdp","reward_learning","goal_manager","working_memory","episodic_memory","semantic_memory","associative_learning","consolidator","retriever","sensory_pathways","language","architecture_assignments"):
            setattr(obj,name,getattr(base,name))
        d=json.loads(Path(filepath).read_text(encoding="utf-8")).get("abm40",{})
        if d:
            b=d.get("brain",{}); obj.brain.regions=b.get("regions",obj.brain.regions); obj.brain.projections=b.get("projections",obj.brain.projections); obj.brain._next_neuron=b.get("next_neuron",obj.brain._next_neuron); obj.brain._connected_pairs=set(tuple(x) for x in b.get("connected_pairs",[]))
            obj.advanced_memory.autobiographical=d.get("autobiographical",[]); obj.advanced_memory.links=defaultdict(set,{k:set(v) for k,v in d.get("memory_links",{}).items()})
            e=d.get("emotion",{}); obj.emotion.emotions.update(e.get("emotions",{})); obj.emotion.drives.update(e.get("drives",{}))
            a=d.get("autonomic",{}); obj.autonomic.sympathetic=a.get("sympathetic",.3); obj.autonomic.parasympathetic=a.get("parasympathetic",.6); obj.autonomic.hormones.update(a.get("hormones",{}))
            sl=d.get("sleep_architecture",{}); obj.sleep_architecture.stage=sl.get("stage","awake"); obj.sleep_architecture.elapsed=sl.get("elapsed_hours",0); obj.sleep_architecture.cycles=sl.get("cycles",0); obj.sleep_architecture.stages.update(sl.get("stage_hours",{}))
            obj.experience_count=d.get("experience_count",0); obj.diagnostics=deque(d.get("diagnostics",[]),maxlen=2000); obj.reasoning.error_log=deque(d.get("reasoning_errors",[]),maxlen=1000); obj.senses.last_motion=d.get("last_motion")
        return obj


def run_abm40_tests():
    a=ABM40(100000)
    assert len(a.brain.regions)>=13 and len(a.brain.projections)>=10
    ids=a.brain.materialize_population("visual",3); assert len(ids)==3 and all(i in a.network.neurons for i in ids)
    a.senses.vision({"objects":["tree"],"brightness":.7}); a.senses.speech_text("olá mundo"); assert a.brain.regions["visual"]["activity"]>0
    m1=a.advanced_memory.encode_event("Conheci uma pessoa na escola",context={"place":"escola"},importance=.8)
    m2=a.advanced_memory.encode_event("Aprendi matemática na escola",importance=.7); assert a.advanced_memory.associate(m1,m2)
    assert a.advanced_memory.retrieve("escola")
    assert a.reasoning.solve_arithmetic("(12+8)*2")==40
    assert a.reasoning.plan("meta",["a","b"])["status"]=="planned"
    a.experience("Resolvi um problema",reward=1,novelty=.8); assert a.experience_count==1
    reg=a.regulate(threat=.5,workload=1,sleep_hours=2); assert "autonomic_endocrine" in reg and a.sleep_architecture.stage!="awake"
    assert a.emotion.state()["emotions"]["fear"]>0
    assert a.executor.map(lambda x:x*x,[1,2,3],workers=2)==[1,4,9]
    a.step(3); assert len(a.diagnostics)>0
    with tempfile.TemporaryDirectory() as folder:
        p=str(Path(folder)/"abm40.json"); a.save(p); b=ABM40.load(p)
        assert b.version=="4.1" and b.experience_count==1 and len(b.brain.regions)>=13
        assert len(b.advanced_memory.autobiographical)==3
    # Teste 11: projeções inter-regionais criam sinapses efetivas e transmitem atividade
    b=ABM40(1000)
    src=b.brain.materialize_population("thalamus",2)
    dst=b.brain.materialize_population("visual",2)
    route=next(p for p in b.brain.projections if p["source"]=="thalamus" and p["target"]=="visual")
    assert route["synapses"]>0 and sum(len(v) for v in b.network.outgoing.values())>0
    b.brain.activate("thalamus",1.0)
    first=b.step(1)
    assert any(src_id in first[0] for src_id in src)
    propagated=[]
    for _ in range(4): propagated.extend(b.step(1)[0])
    assert any(dst_id in propagated for dst_id in dst)
    # Teste 12: regiões são preservadas no tipo neuronal e conexões não duplicam
    assert all(b.network.neurons[n].region=="thalamus" for n in src)
    before=sum(len(v) for v in b.network.outgoing.values())
    b.brain.materialize_population("visual",1)
    assert sum(len(v) for v in b.network.outgoing.values())>=before
    # Teste 13: pesos negativos são inibitórios e o sinal não é descartado
    ni=SpatialNeuralNetwork(10); ni.create_neuron(1); ni.create_neuron(2)
    sn=ni.connect(1,2,weight=-2.0,transmitter="glutamate")
    assert sn.weight==-2.0
    # Teste 14: remoção de memória limpa referências associativas
    c=ABM40(1000); e1=c.advanced_memory.encode_event("evento raro alfa",importance=.1)
    e2=c.advanced_memory.encode_event("evento raro beta",importance=.1)
    c.advanced_memory.associate(e1,e2); c.episodic_memory.items[e1].strength=.001
    removed=c.advanced_memory.forget(min_strength=.01,max_importance=.2)
    assert e1 in removed and e1 not in c.episodic_memory.items
    assert all(e1 not in values for values in c.advanced_memory.links.values())
    # Teste 15: persistência conserva topologia cerebral e sinapses inter-regionais
    with tempfile.TemporaryDirectory() as folder:
        path=str(Path(folder)/"abm41_network.json")
        b.save(path); restored=ABM40.load(path)
        assert restored.brain.projections and restored.brain._connected_pairs
        assert sum(len(v) for v in restored.network.outgoing.values())>0
    return {"status":"PASSOU_TOTALMENTE","tests_executed":15,"modules":["arquitetura cerebral e rotas","populações neuronais sob procura","entradas sensoriais estruturadas","memória autobiográfica e associação","recuperação associativa","raciocínio aritmético e planeamento simbólico","aprendizagem por experiência","emoção e motivação","regulação autonómica/hormonal e sono","diagnóstico e paralelismo","sinapses inter-regionais efetivas","mapeamento de regiões neuronais","sinal sináptico assinado","limpeza de referências de memória","propagação entre regiões","persistência da topologia inter-regional"]}




# ============================================================================
# ABM 5.0 — CAMADA DE INTEGRAÇÃO EXPERIMENTAL
# Esta camada amplia a arquitetura anterior sem alegar equivalência biológica.
# ============================================================================

ABM_VERSION = "5.0"

class DetailedBrainArchitecture(BrainArchitecture):
    """Mapa funcional detalhado; subdivisões são abstrações, não anatomia celular."""
    EXTRA_REGIONS = {
        "frontal_dorsolateral": ("controlo executivo e memória de trabalho", "prefrontal"),
        "frontal_ventromedial": ("avaliação de valor e decisão", "prefrontal"),
        "orbitofrontal": ("avaliação de resultados", "prefrontal"),
        "premotor": ("preparação motora", "motor"),
        "supplementary_motor": ("sequenciação motora", "motor"),
        "primary_motor": ("comando motor simulado", "motor"),
        "primary_somatosensory": ("características somatossensoriais", "somatosensory"),
        "visual_primary": ("características visuais", "visual"),
        "visual_association": ("associação visual", "visual"),
        "auditory_primary": ("características auditivas", "auditory"),
        "auditory_association": ("associação auditiva", "auditory"),
        "entorhinal": ("interface de memória", "hippocampus"),
        "dentate_gyrus": ("separação de padrões", "hippocampus"),
        "ca_fields": ("associação e recuperação", "hippocampus"),
        "basolateral_amygdala": ("saliência emocional", "amygdala"),
        "central_amygdala": ("resposta defensiva simulada", "amygdala"),
        "thalamic_relay": ("retransmissão sensorial", "thalamus"),
        "suprachiasmatic": ("ritmo circadiano", "hypothalamus"),
        "hypothalamic_autonomic": ("regulação autonómica", "hypothalamus"),
        "cerebellar_cortex": ("ajuste motor", "cerebellum"),
        "striatum": ("seleção de ação", "basal_ganglia"),
        "substantia_nigra": ("modulação dopaminérgica abstrata", "basal_ganglia"),
        "pons": ("ponte e regulação simulada", "brainstem"),
        "medulla": ("funções vitais simuladas", "brainstem"),
        "insula_interoceptive": ("estado corporal", "insula"),
        "anterior_cingulate": ("monitorização de conflito", "cingulate"),
        "posterior_cingulate": ("integração contextual", "cingulate"),
    }
    def __init__(self, network):
        super().__init__(network)
        for name, (role, base_region) in self.EXTRA_REGIONS.items():
            self.regions[name] = {"role": role, "neurons": [], "activity": 0.0,
                                  "last_fired": 0, "base_region": base_region,
                                  "hemisphere": "bilateral_abstract"}
            self.NETWORK_REGION[name] = base_region
        # Rotas adicionais explícitas para as subdivisões funcionais.
        extra_links = [
            ("thalamus", "thalamic_relay"), ("thalamic_relay", "visual_primary"),
            ("thalamic_relay", "auditory_primary"), ("visual_primary", "visual_association"),
            ("auditory_primary", "auditory_association"),
            ("visual_association", "entorhinal"), ("auditory_association", "entorhinal"),
            ("entorhinal", "dentate_gyrus"), ("dentate_gyrus", "ca_fields"),
            ("ca_fields", "frontal_dorsolateral"),
            ("frontal_dorsolateral", "frontal_ventromedial"),
            ("frontal_ventromedial", "orbitofrontal"),
            ("orbitofrontal", "striatum"), ("striatum", "substantia_nigra"),
            ("striatum", "premotor"), ("premotor", "supplementary_motor"),
            ("supplementary_motor", "primary_motor"),
            ("primary_motor", "cerebellar_cortex"), ("cerebellar_cortex", "primary_motor"),
            ("primary_somatosensory", "insula_interoceptive"),
            ("insula_interoceptive", "basolateral_amygdala"),
            ("basolateral_amygdala", "central_amygdala"),
            ("central_amygdala", "hypothalamic_autonomic"),
            ("suprachiasmatic", "hypothalamus"), ("hypothalamic_autonomic", "pons"),
            ("pons", "medulla"), ("anterior_cingulate", "frontal_dorsolateral"),
            ("posterior_cingulate", "entorhinal"),
        ]
        known = {(p["source"], p["target"]) for p in self.projections}
        for src, dst in extra_links:
            if (src, dst) not in known:
                self.projections.append({"source":src,"target":dst,"weight":180.0,
                                         "signals":0,"synapses":0})

    def activate(self, region, level):
        if region not in self.regions:
            raise ValueError(f"Região cerebral desconhecida: {region}")
        level = _clamp(level, 0, 1)
        data = self.regions[region]
        data["activity"] = level
        ids = data["neurons"]
        if ids and level > 0:
            current = level * 400.0
            for nid in ids:
                self.network.inject(nid, current)
        return level

    def materialize_population(self, region, count=8, model="lif"):
        if region not in self.regions:
            raise ValueError("Região desconhecida")
        if not isinstance(count, int) or count < 1 or count > 10000:
            raise ValueError("count deve estar entre 1 e 10000")
        created=[]
        base_region=self.NETWORK_REGION.get(region, region)
        for _ in range(count):
            while self._next_neuron in self.network.neurons:
                self._next_neuron += 1
            nid=self._next_neuron; self._next_neuron += 1
            self.network.create_neuron(nid, region=base_region, model=model)
            self.regions[region]["neurons"].append(nid); created.append(nid)
        for p in self.projections:
            if p["source"] == region or p["target"] == region:
                self._connect_available_projection(p)
        return created


class LogicKnowledgeEngine:
    """Pequena base de factos e regras Horn; inferência determinística limitada."""
    def __init__(self):
        self.facts=set(); self.rules=[]; self.max_inferences=10000
    def add_fact(self, *fact):
        if not fact: raise ValueError("Facto vazio")
        self.facts.add(tuple(map(str,fact))); return True
    def add_rule(self, premises, conclusion):
        premises=[tuple(map(str,p)) for p in premises]
        conclusion=tuple(map(str,conclusion))
        if not conclusion: raise ValueError("Conclusão vazia")
        self.rules.append((premises,conclusion)); return True
    @staticmethod
    def _unify(pattern, fact, env):
        if len(pattern)!=len(fact): return None
        out=dict(env)
        for p,v in zip(pattern,fact):
            if p.startswith("?"):
                if p in out and out[p]!=v: return None
                out[p]=v
            elif p!=v: return None
        return out
    def infer(self, max_rounds=20):
        added=[]
        for _ in range(max_rounds):
            new=[]
            for premises, conclusion in self.rules:
                envs=[{}]
                for premise in premises:
                    next_envs=[]
                    for env in envs:
                        for fact in tuple(self.facts):
                            matched=self._unify(premise,fact,env)
                            if matched is not None: next_envs.append(matched)
                    envs=next_envs
                    if not envs: break
                for env in envs:
                    result=tuple(env.get(x,x) if x.startswith("?") else x for x in conclusion)
                    if not any(x.startswith("?") for x in result) and result not in self.facts:
                        new.append(result)
                        if len(added)+len(new)>=self.max_inferences: break
            if not new: break
            self.facts.update(new); added.extend(new)
            if len(added)>=self.max_inferences: break
        return added


class SensoryFeatureEngine:
    """Extrai descritores simples de matrizes de pixels e amostras de áudio.
    Não é um reconhecedor semântico nem substitui modelos treinados."""
    @staticmethod
    def image_features(pixels):
        if not isinstance(pixels,(list,tuple)) or not pixels:
            raise ValueError("pixels deve ser uma matriz não vazia")
        flat=[]
        for row in pixels:
            if not isinstance(row,(list,tuple)): raise ValueError("Matriz de pixels inválida")
            for px in row:
                vals=px if isinstance(px,(list,tuple)) else (px,)
                if len(vals) not in (1,3,4): raise ValueError("Pixel deve ter 1, 3 ou 4 canais")
                rgb=[_clamp(float(v),0,255) for v in vals[:3]]
                if len(rgb)==1: rgb=rgb*3
                flat.append(rgb)
        if not flat: raise ValueError("Imagem sem pixels")
        brightness=sum(sum(p)/3 for p in flat)/len(flat)/255.0
        means=[sum(p[i] for p in flat)/len(flat)/255.0 for i in range(3)]
        return {"width":max(len(r) for r in pixels),"height":len(pixels),
                "pixel_count":len(flat),"brightness":brightness,
                "mean_rgb":means,"contrast":math.sqrt(sum((sum(p)/3-brightness*255)**2 for p in flat)/len(flat))/255.0}
    @staticmethod
    def audio_features(samples, sample_rate=16000):
        if not isinstance(samples,(list,tuple)) or not samples:
            raise ValueError("samples deve conter amostras")
        values=[float(x) for x in samples]
        if any(not math.isfinite(x) for x in values): raise ValueError("Áudio contém valor não finito")
        rms=math.sqrt(sum(x*x for x in values)/len(values))
        crossings=sum(1 for a,b in zip(values,values[1:]) if (a<0<=b) or (b<0<=a))
        return {"sample_rate":int(sample_rate),"samples":len(values),"duration_s":len(values)/float(sample_rate),
                "rms":rms,"zero_crossing_rate":crossings/max(1,len(values)-1),"peak":max(abs(x) for x in values)}


class BodySystemsModel:
    """Modelo didático de órgãos e homeostase; não é simulador médico."""
    def __init__(self):
        self.heart_rate=72.0; self.stroke_volume=70.0; self.systolic=120.0; self.diastolic=80.0
        self.ventilation=7.0; self.oxygen=0.98; self.co2=40.0; self.glucose=90.0
        self.temperature=37.0; self.hydration=1.0; self.muscle_fatigue=0.0
        self.insulin=0.3; self.glucagon=0.3; self.cortisol=0.2; self.last_motor=None
    def update(self, workload=0.0, threat=0.0, rest=0.0, sleep=False):
        w=_clamp(workload,0,10); t=_clamp(threat,0,1); r=_clamp(rest,0,10)
        target_hr=68+5.5*w+28*t-2*r
        self.heart_rate=_clamp(.85*self.heart_rate+.15*target_hr,35,220)
        self.stroke_volume=_clamp(70+3*w-8*t,20,150)
        self.systolic=_clamp(110+.7*(self.heart_rate-70)+12*t,70,220)
        self.diastolic=_clamp(75+.25*(self.heart_rate-70)+5*t,40,140)
        target_vent=6+1.1*w+5*t-0.5*r
        self.ventilation=_clamp(.8*self.ventilation+.2*target_vent,2,30)
        self.co2=_clamp(self.co2+.15*(w-self.ventilation/7),20,70)
        self.oxygen=_clamp(self.oxygen+.01*(.98-self.oxygen)-.002*w+.001*r,0.5,1.0)
        self.glucose=_clamp(self.glucose-.3*w+.15*r+(0.2 if sleep else 0),40,250)
        self.insulin=_clamp(.8*self.insulin+.2*max(0,(self.glucose-90)/100),0,1)
        self.glucagon=_clamp(.8*self.glucagon+.2*max(0,(90-self.glucose)/50),0,1)
        self.cortisol=_clamp(.9*self.cortisol+.1*t,0,1)
        self.temperature=_clamp(self.temperature+.002*w-.003*r,35,40)
        self.hydration=_clamp(self.hydration-.001*w+.001*r,0,1)
        self.muscle_fatigue=_clamp(self.muscle_fatigue+.03*w-.04*r,0,1)
        return self.state()
    def state(self):
        return {k:getattr(self,k) for k in ("heart_rate","stroke_volume","systolic","diastolic","ventilation","oxygen","co2","glucose","temperature","hydration","muscle_fatigue","insulin","glucagon","cortisol")}


class MotorController:
    """Gera comandos motores simulados; não controla hardware físico."""
    def __init__(self, body): self.body=body; self.actions=deque(maxlen=1000)
    def command(self, action, target="body", intensity=.5, duration=1.0):
        if duration<=0: raise ValueError("duration deve ser positiva")
        cmd=self.body.prepare_action(action,target,intensity)
        cmd["duration"]=float(duration); cmd["status"]="simulated"
        self.body.motor_state="simulated"
        self.actions.append(dict(cmd))
        return dict(cmd)
    def move_joint(self, joint, delta):
        if joint not in self.body.joint_angles: self.body.joint_angles[joint]=0.0
        self.body.joint_angles[joint]=_clamp(self.body.joint_angles[joint]+float(delta),-180,180)
        return self.body.joint_angles[joint]


class SocialInteractionModel:
    """Modelo computacional simples de turnos, confiança e intenção percebida."""
    def __init__(self): self.people={}; self.turn_count=0
    def observe(self, person_id, message, sentiment=0.0, cooperative=True):
        p=self.people.setdefault(str(person_id),{"interactions":0,"trust":.5,"sentiment":0.0})
        p["interactions"]+=1; p["sentiment"]=_clamp(.8*p["sentiment"]+.2*float(sentiment),-1,1)
        p["trust"]=_clamp(p["trust"]+(.02 if cooperative else -.03)+.01*p["sentiment"],0,1)
        self.turn_count+=1
        return {"person_id":str(person_id),**p,"message_length":len(str(message))}


class ABM50(ABM40):
    """ABM 5.0: integração experimental ampliada sobre a base 4.1."""
    def __init__(self, total_virtual_neurons=TOTAL_VIRTUAL_NEURONS):
        super().__init__(total_virtual_neurons)
        self.version="5.0"
        self.brain=DetailedBrainArchitecture(self.network)
        self.logic=LogicKnowledgeEngine()
        self.feature_engine=SensoryFeatureEngine()
        self.body_systems=BodySystemsModel()
        self.motor=MotorController(self.body)
        self.social=SocialInteractionModel()
        self.integration_events=deque(maxlen=5000)
        self.cycle_count=0
        self._last_sleep_stage="awake"

    def process_image_pixels(self, pixels, confidence=.8):
        features=self.feature_engine.image_features(pixels)
        self.senses.vision(features,confidence)
        self.brain.activate("visual_primary",confidence)
        self.brain.activate("visual_association",confidence*.7)
        self.integration_events.append({"type":"vision_features","tick":self.network.tick,"features":features})
        return features

    def process_audio_samples(self, samples, sample_rate=16000, confidence=.8):
        features=self.feature_engine.audio_features(samples,sample_rate)
        self.senses.hearing(features,confidence)
        self.brain.activate("auditory_primary",confidence)
        self.brain.activate("auditory_association",confidence*.7)
        self.integration_events.append({"type":"audio_features","tick":self.network.tick,"features":features})
        return features

    def process_text(self, text, confidence=.9):
        if not str(text).strip(): raise ValueError("Texto vazio")
        self.senses.speech_text(str(text),confidence)
        self.brain.activate("language",confidence)
        eid=self.advanced_memory.encode_event(str(text),context={"modality":"text"},importance=confidence)
        self.integration_events.append({"type":"text","tick":self.network.tick,"episode_id":eid})
        return {"episode_id":eid,"tokens":_tokens(text)}

    def experience(self, event, reward=0.0, threat=0.0, novelty=.5, context=None):
        result=super().experience(event,reward,threat,novelty,context)
        # Atualiza o modelo corporal e envia atividade às regiões de integração.
        self.body_systems.update(workload=novelty*2,threat=threat,rest=0)
        self.brain.activate("anterior_cingulate",min(1,abs(reward)+threat*.5))
        self.integration_events.append({"type":"experience","tick":self.network.tick,"episode_id":result["episode_id"]})
        return result

    def step(self,count=1,external=None):
        if not isinstance(count,int) or count<0: raise ValueError("count deve ser inteiro não negativo")
        results=[]
        for i in range(count):
            ext=external if i==0 else None
            fired=self.network.step(ext,available_atp=self.physiology.atp_level)
            self.stdp.update(self.network,fired)
            self.brain.update_activity(fired)
            # Plasticidade homeostática simples: atenua excesso de atividade local.
            for region,data in self.brain.regions.items():
                if data["activity"]>.95:
                    for nid in data["neurons"]:
                        for syn in self.network.outgoing.get(nid,[]):
                            syn.weight=_clamp(syn.weight*.999, -1000, 1000)
            results.append(fired)
            self.cycle_count+=1
        if count:
            fired_total=sum(len(x) for x in results)
            workload=min(10.0,fired_total/max(1,count))
            sleeping=self.sleep_architecture.stage!="awake"
            body_state=self.body_systems.update(workload=workload,threat=self.physiology.stress,
                                                rest=0.2 if sleeping else 0,sleep=sleeping)
            self.physiology.update(workload=workload,threat=self.physiology.stress,rest=.2 if sleeping else 0)
            self.autonomic.update(self.physiology.stress,self.physiology.arousal,sleeping)
            self.diagnostics.append({"tick":self.network.tick,"fired":fired_total,
                                     "atp":self.physiology.atp_level,"body":body_state})
        self.working_memory.tick()
        return results

    def regulate(self, workload=0.0, threat=0.0, rest=0.0, sleep_hours=0.0):
        base=super().regulate(workload,threat,rest,sleep_hours)
        body=self.body_systems.update(workload=workload,threat=threat,rest=rest,sleep=sleep_hours>0)
        base["body_systems"]=body
        return base

    def consolidate_during_sleep(self, max_items=20):
        if self.sleep_architecture.stage not in {"n2","n3","rem"}:
            return {"consolidated":0,"reason":"deep_or_rem_sleep_required"}
        items=sorted(self.episodic_memory.items.values(),key=lambda x:x.importance*x.strength,reverse=True)[:max_items]
        count=0
        for item in items:
            item.strength=_clamp(item.strength+.02*item.importance,0,2)
            count+=1
        self.integration_events.append({"type":"sleep_consolidation","tick":self.network.tick,"count":count})
        return {"consolidated":count,"reason":"sleep_replay_strengthening_model"}

    def observe_social(self, person_id, message, sentiment=0.0, cooperative=True):
        result=self.social.observe(person_id,message,sentiment,cooperative)
        self.advanced_memory.encode_event(str(message),context={"person_id":str(person_id),"social":True},importance=.4)
        self.brain.activate("insula_interoceptive",.3+abs(float(sentiment))*.3)
        return result

    def status(self):
        s=super().status()
        s.update({"version":"5.0","brain_regions":len(self.brain.regions),
                  "brain_materialized_populations":sum(bool(x["neurons"]) for x in self.brain.regions.values()),
                  "logic_facts":len(self.logic.facts),"logic_rules":len(self.logic.rules),
                  "body_systems":self.body_systems.state(),"social_profiles":len(self.social.people),
                  "integration_events":len(self.integration_events),"simulation_cycles":self.cycle_count,
                  "limits":["visão: descritores básicos de pixels, sem reconhecimento semântico treinado",
                            "áudio: descritores de sinal, sem reconhecimento automático de fala",
                            "corpo e emoções: modelos didáticos, não fisiologia clínica",
                            "não é cérebro humano, consciência ou inteligência geral"]})
        return s

    def save(self, filepath):
        super().save(filepath)
        path=Path(filepath); data=json.loads(path.read_text(encoding="utf-8"))
        data["abm50"]={"brain":self.brain.state(),"logic_facts":[list(x) for x in self.logic.facts],
                       "logic_rules":[[ [list(p) for p in premises],list(conclusion)] for premises,conclusion in self.logic.rules],
                       "body_systems":self.body_systems.state(),"social_people":self.social.people,
                       "social_turn_count":self.social.turn_count,"integration_events":list(self.integration_events),
                       "cycle_count":self.cycle_count}
        temp=path.with_suffix(path.suffix+".tmp")
        temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
        temp.replace(path)

    @classmethod
    def load(cls, filepath):
        base=ABM40.load(filepath)
        obj=cls(base.network.total_virtual)
        obj.__dict__.update(base.__dict__)
        obj.version = "5.0"
        # Recria os componentes específicos e restaura os dados serializados.
        obj.brain=DetailedBrainArchitecture(obj.network)
        d=json.loads(Path(filepath).read_text(encoding="utf-8")).get("abm50",{})
        b=d.get("brain",{})
        if b:
            for name,region_data in b.get("regions",{}).items():
                if name not in obj.brain.regions: obj.brain.regions[name]=region_data
                else: obj.brain.regions[name].update(region_data)
            obj.brain.projections=b.get("projections",obj.brain.projections)
            obj.brain._next_neuron=b.get("next_neuron",obj.brain._next_neuron)
            obj.brain._connected_pairs=set(tuple(x) for x in b.get("connected_pairs",[]))
        obj.logic=LogicKnowledgeEngine(); obj.logic.facts=set(tuple(x) for x in d.get("logic_facts",[]))
        obj.logic.rules=[([tuple(p) for p in r[0]],tuple(r[1])) for r in d.get("logic_rules",[])]
        obj.body_systems=BodySystemsModel()
        for k,v in d.get("body_systems",{}).items(): setattr(obj.body_systems,k,v)
        obj.motor=MotorController(obj.body)
        obj.social=SocialInteractionModel(); obj.social.people=d.get("social_people",{}); obj.social.turn_count=d.get("social_turn_count",0)
        obj.integration_events=deque(d.get("integration_events",[]),maxlen=5000)
        obj.cycle_count=d.get("cycle_count",0)
        return obj


def run_abm50_tests():
    results={}
    # 1 Anatomia funcional e populações separadas.
    a=ABM50(100000)
    assert a.version=="5.0" and len(a.brain.regions)>=40
    visual=a.brain.materialize_population("visual_primary",3)
    assoc=a.brain.materialize_population("visual_association",3)
    assert all(a.network.neurons[n].region=="visual" for n in visual+assoc)
    assert sum(len(v) for v in a.network.outgoing.values())>0
    results["detailed_brain_architecture"]="PASSOU"
    # 2 Encadeamento inter-regional com disparo e chegada de eventos.
    a.brain.activate("visual_primary",1.0)
    fired=a.step(1)
    assert any(n in fired[0] for n in visual)
    arrived=[]
    for _ in range(5): arrived.extend(a.step(1)[0])
    assert any(n in arrived for n in assoc)
    results["interregional_signal_propagation"]="PASSOU"
    # 3 Motor e corpo atualizam estado de forma verificável.
    cmd=a.motor.command("flex", "arm_right", .7, 1.0)
    angle=a.motor.move_joint("arm_right",15)
    body=a.regulate(workload=2,threat=.3)
    assert cmd["status"]=="simulated" and angle==15 and body["body_systems"]["heart_rate"]>0
    results["body_and_motor_models"]="PASSOU"
    # 4 Processamento numérico de matriz de pixels e áudio.
    img=a.process_image_pixels([[(0,0,0),(255,255,255)],[(100,50,25),(20,30,40)]])
    aud=a.process_audio_samples([0,.5,-.5,0,.25,-.25],sample_rate=8000)
    assert img["pixel_count"]==4 and 0<=img["brightness"]<=1
    assert aud["samples"]==6 and aud["rms"]>0
    results["raw_sensor_feature_extraction"]="PASSOU"
    # 5 Inferência por regras Horn.
    a.logic.add_fact("parent","ana","bia")
    a.logic.add_fact("parent","bia","caio")
    a.logic.add_rule([("parent","?x","?y"),("parent","?y","?z")],("grandparent","?x","?z"))
    inferred=a.logic.infer()
    assert ("grandparent","ana","caio") in inferred
    results["symbolic_rule_inference"]="PASSOU"
    # 6 Experiência, memória e associação.
    exp=a.experience("Evento integrado de teste",reward=.8,threat=.1,novelty=.9)
    assert a.advanced_memory.retrieve("Evento integrado")
    results["experience_memory_learning"]="PASSOU"
    # 7 Sono e consolidação.
    a.sleep_architecture.advance(1.0,True)
    a.sleep_architecture.stage="n3"
    a.remember("Memória para consolidação",.9,["sono"])
    con=a.consolidate_during_sleep()
    assert con["consolidated"]>=1
    results["sleep_memory_consolidation"]="PASSOU"
    # 8 Social behavior state.
    social=a.observe_social("pessoa-1","Olá",sentiment=.5,cooperative=True)
    assert social["interactions"]==1 and social["trust"]>.5
    results["social_interaction_model"]="PASSOU"
    # 9 Save/load roundtrip of ABM 5.0 state.
    with tempfile.TemporaryDirectory() as folder:
        p=str(Path(folder)/"abm50.json"); a.save(p); b=ABM50.load(p)
        assert b.version=="5.0" and len(b.brain.regions)>=40
        assert len(b.logic.facts)>=2 and b.social.turn_count==1
        assert b.body_systems.heart_rate==a.body_systems.heart_rate
        assert len(b.network.outgoing)>0
    results["complete_state_roundtrip"]="PASSOU"
    # 10 Inputs inválidos são rejeitados e limites preservados.
    for bad in ([],None):
        try: a.feature_engine.image_features(bad)
        except (ValueError,TypeError): pass
        else: raise AssertionError("Imagem inválida aceite")
    try: a.feature_engine.audio_features([0,float("nan")])
    except ValueError: pass
    else: raise AssertionError("Áudio não finito aceite")
    results["input_validation"]="PASSOU"
    return {"status":"PASSOU_TOTALMENTE","tests_executed":len(results),"results":results,
            "scope_note":"Testes funcionais de software; não validam equivalência biológica, consciência ou inteligência geral."}


# ============================================================================
# ABM 5.1 — CAMADA INTERATIVA UNIFICADA
# ============================================================================
class ABMInteractive(ABM50):
    """Interface integrada de conversa, memória, raciocínio e objetivos.
    É um agente experimental local, não um LLM nem um cérebro biológico.
    """
    def __init__(self, total_virtual_neurons=TOTAL_VIRTUAL_NEURONS):
        super().__init__(total_virtual_neurons)
        self.version = "5.1"
        self.dialogue_count = 0
        self.user_profile = {}
        self.learned_responses = {}
        self.chat_history = deque(maxlen=2000)

    def teach(self, question, answer):
        q = str(question).strip()
        a = str(answer).strip()
        if not q or not a:
            raise ValueError("Pergunta e resposta não podem estar vazias.")
        key = " ".join(_tokens(q))
        self.learned_responses[key] = a
        self.experience("Aprendizagem supervisionada: " + q + " => " + a,
                        reward=1.0, novelty=.6, context={"type":"user_teaching"})
        return {"learned": True, "key": key}

    def add_goal(self, description, steps=None, goal_id=None):
        description = str(description).strip()
        if not description:
            raise ValueError("O objetivo não pode estar vazio.")
        gid = str(goal_id or "goal_" + str(int(time.time()*1000)))
        return {"id":gid, **self.goal_manager.add(gid, description, steps or [])}

    def _memory_answer(self, text):
        hits = self.advanced_memory.retrieve(text, limit=3)
        if hits:
            return "Encontrei isto na minha memória: " + str(hits[0].content)
        return None

    def _arithmetic_answer(self, text):
        candidates = re.findall(r'(?<![\w.])(?:\d+(?:\.\d+)?(?:\s*[+\-*/%]\s*\d+(?:\.\d+)?|\s*[()+*/%\-])*)', text)
        for expr in sorted(candidates, key=len, reverse=True):
            expr = expr.strip()
            if re.fullmatch(r'[\d\s.+*/()%\-]+', expr) and re.search(r'[+*/%\-]', expr):
                try:
                    value = self.reasoning.solve_arithmetic(expr)
                    if isinstance(value, (int, float)) and math.isfinite(float(value)):
                        return f"O resultado é {value}."
                except (ValueError, TypeError, ZeroDivisionError):
                    pass
        return None

    def chat(self, message, person_id="user"):
        text = str(message).strip()
        if not text:
            raise ValueError("A mensagem não pode estar vazia.")
        self.dialogue_count += 1
        self.process_text(text)
        tokens = _tokens(text)
        normalized = " ".join(tokens)
        lower = text.casefold()

        self.observe_social(person_id, text, sentiment=0.0, cooperative=True)
        answer = self.learned_responses.get(normalized)

        if answer is None:
            answer = self._arithmetic_answer(text)

        if answer is None and any(x in lower for x in ("quem sou eu", "o que sabes sobre mim", "o que sabe sobre mim")):
            answer = ("Ainda só sei o que foi guardado nesta sessão ou ensinado explicitamente. "
                      "Não vou inventar dados pessoais.")

        if answer is None and any(x in lower for x in ("objetivos", "listar objetivos", "mostra os objetivos")):
            goals = self.goal_manager.list()
            answer = ("Ainda não existem objetivos registados." if not goals else
                      "Objetivos registados: " + "; ".join(g["description"] + " [" + g["status"] + "]" for g in goals))

        if answer is None:
            answer = self._memory_answer(text)

        if answer is None:
            inferred = self.logic.infer()
            if inferred:
                answer = "Tenho factos simbólicos guardados: " + "; ".join(map(str, inferred[:4]))
        if answer is None:
            answer = ("Recebi e processei a tua mensagem. Consigo usar memória local, regras lógicas "
                      "e cálculos simples, mas ainda não tenho conhecimento geral como um grande modelo "
                      "de linguagem. Podes ensinar-me uma resposta com teach(pergunta, resposta).")

        self.working_memory.add(text, importance=.7, tags=tokens[:12], context={"speaker":person_id})
        self.chat_history.append({"user":text,"assistant":answer,"time":_now()})
        self.experience("Diálogo: " + text, reward=.1, novelty=.3,
                        context={"type":"dialogue","response":answer})
        self.step(1)
        return {"response":answer, "turn":self.dialogue_count,
                "memory_hits":len(self.advanced_memory.retrieve(text,3)),
                "simulation_tick":self.network.tick}

    def process_image_file(self, filepath):
        try:
            from PIL import Image
        except ImportError as exc:
            raise RuntimeError("Para abrir imagens, instala Pillow no Pydroid 3: pip install pillow") from exc
        with Image.open(filepath) as im:
            im = im.convert("RGB")
            im.thumbnail((256,256))
            pixels = [list(im.crop((0,y,im.width,min(y+1,im.height))).getdata()) for y in range(im.height)]
        return self.process_image_pixels(pixels)

    def process_wav_file(self, filepath):
        import wave, struct
        with wave.open(str(filepath), "rb") as wf:
            channels, width, rate, frames = wf.getnchannels(), wf.getsampwidth(), wf.getframerate(), wf.getnframes()
            raw = wf.readframes(frames)
        if width not in (1,2,4):
            raise ValueError("Formato WAV: apenas PCM de 8, 16 ou 32 bits.")
        fmt = {1:"B",2:"h",4:"i"}[width]
        count = len(raw)//width
        vals = struct.unpack("<"+fmt*count, raw)
        scale = float(2**(8*width-1))
        samples = [((v-128) if width==1 else v)/scale for v in vals]
        if channels > 1:
            samples = [sum(samples[i:i+channels])/channels for i in range(0,len(samples),channels)]
        return self.process_audio_samples(samples, sample_rate=rate)

    def speak(self, text):
        try:
            from plyer import tts
            tts.speak(str(text))
            return {"status":"spoken"}
        except Exception as exc:
            return {"status":"unavailable","reason":str(exc),
                    "note":"A voz depende do motor TTS instalado no Android; a conversa por texto funciona sem isso."}

    def status(self):
        result = super().status()
        result.update({"version":"5.1","dialogue_turns":self.dialogue_count,
                       "learned_answers":len(self.learned_responses),
                       "chat_history":len(self.chat_history),
                       "goals":len(self.goal_manager.goals),
                       "interactive_features":["chat local","memória episódica","ensino pergunta-resposta",
                                               "aritmética segura","objetivos","entrada WAV","entrada de imagem opcional",
                                               "voz Android opcional"]})
        return result

    def save(self, filepath):
        super().save(filepath)
        path = Path(filepath)
        data = json.loads(path.read_text(encoding="utf-8"))
        data["abm51"] = {"dialogue_count":self.dialogue_count,
                         "user_profile":self.user_profile,
                         "learned_responses":self.learned_responses,
                         "chat_history":list(self.chat_history),
                         "goals":self.goal_manager.goals}
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
        tmp.replace(path)

    @classmethod
    def load(cls, filepath):
        base = ABM50.load(filepath)
        obj = cls(base.network.total_virtual)
        obj.__dict__.update(base.__dict__)
        obj.version = "5.1"
        d = json.loads(Path(filepath).read_text(encoding="utf-8")).get("abm51",{})
        obj.dialogue_count = d.get("dialogue_count",0)
        obj.user_profile = d.get("user_profile",{})
        obj.learned_responses = d.get("learned_responses",{})
        obj.chat_history = deque(d.get("chat_history",[]),maxlen=2000)
        obj.goal_manager.goals = d.get("goals",{})
        return obj


def run_abm51_tests():
    a = ABMInteractive(2000)
    r = a.chat("Olá, ABM")
    assert r["turn"] == 1 and r["response"]
    a.teach("Qual é a capital de Moçambique?", "Maputo.")
    assert "Maputo" in a.chat("Qual é a capital de Moçambique?")["response"]
    assert "42" in a.chat("Quanto é 6 * 7?")["response"]
    a.add_goal("Aprender Python", ["Estudar variáveis", "Fazer exercícios"], "python")
    assert len(a.goal_manager.list()) == 1
    a.logic.add_fact("gosta","utilizador","Python")
    assert ("gosta","utilizador","Python") in a.logic.facts
    with tempfile.TemporaryDirectory() as folder:
        path = str(Path(folder)/"abm51.json")
        a.save(path)
        b = ABMInteractive.load(path)
        assert b.version == "5.1"
        assert b.dialogue_count == a.dialogue_count
        assert b.learned_responses == a.learned_responses
        assert "python" in b.goal_manager.goals
    try:
        a.chat("")
    except ValueError:
        pass
    else:
        raise AssertionError("Mensagem vazia aceite")
    return {"status":"PASSOU_TOTALMENTE","tests_executed":6,
            "results":{"chat_pipeline":"PASSOU","teaching_and_recall":"PASSOU",
                       "safe_arithmetic":"PASSOU","goal_management":"PASSOU",
                       "symbolic_reasoning":"PASSOU","persistence_roundtrip":"PASSOU"},
            "limitations":["Não é um LLM nem possui conhecimento geral automático.",
                           "Reconhecimento semântico de imagens e fala exige modelos externos.",
                           "Voz depende do TTS do Android; movimentos são simulados."]}



# =============================================================================
# ABM 5.2 — CAMADA DE COMPANHEIRO DIGITAL E INTEGRAÇÃO ANDROID
# Esta camada acrescenta orquestração, perfil, eventos, segurança e adaptadores.
# Não contorna permissões nem mantém microfone/câmara ocultos.
# =============================================================================

import os
import platform
import subprocess
import urllib.parse
from datetime import datetime


class ABMConsent:
    """Regista permissões funcionais concedidas explicitamente pelo utilizador."""
    DEFAULTS = {
        "voice_input": False, "voice_output": False, "camera": False,
        "microphone_background": False, "notifications": False,
        "contacts": False, "call_actions": False, "location": False,
        "external_actions": False, "social_context": False
    }

    def __init__(self, data=None):
        self.permissions = dict(self.DEFAULTS)
        if isinstance(data, dict):
            for key in self.permissions:
                if key in data:
                    self.permissions[key] = bool(data[key])

    def set(self, name, enabled):
        if name not in self.permissions:
            raise ValueError("Permissão desconhecida: " + str(name))
        self.permissions[name] = bool(enabled)
        return self.permissions[name]

    def allowed(self, name):
        return bool(self.permissions.get(name, False))

    def export(self):
        return dict(self.permissions)


class ABMAndroidBridge:
    """
    Adaptador opcional para Pydroid/Android.
    Usa androidhelper quando instalado. Fora do Android, devolve diagnóstico.
    Não desbloqueia o dispositivo, não atende chamadas e não controla outras
    aplicações sem APIs/permissões específicas.
    """
    def __init__(self, consent=None):
        self.consent = consent or ABMConsent()
        self.droid = None
        self.last_error = None
        try:
            import androidhelper
            self.droid = androidhelper.Android()
        except Exception as exc:
            self.last_error = str(exc)

    @property
    def available(self):
        return self.droid is not None

    def status(self):
        return {
            "android_bridge": self.available,
            "platform": platform.platform(),
            "androidhelper_error": self.last_error,
            "limitations": [
                "Pydroid não é um serviço Android permanente.",
                "O Android controla acesso ao microfone, câmara, chamadas e bloqueio.",
                "Ações protegidas exigem permissões e confirmação do sistema."
            ]
        }

    def speak(self, text):
        if not self.consent.allowed("voice_output"):
            return {"ok": False, "reason": "Voz desativada nas permissões do ABM."}
        if not self.available:
            return {"ok": False, "reason": "androidhelper não está disponível."}
        try:
            self.droid.ttsSpeak(str(text))
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "reason": str(exc)}

    def listen_once(self):
        if not self.consent.allowed("voice_input"):
            return {"ok": False, "reason": "Ativa primeiro a entrada de voz."}
        if not self.available:
            return {"ok": False, "reason": "Reconhecimento Android indisponível."}
        try:
            result = self.droid.recognizeSpeech("Fala com o ABM")
            value = getattr(result, "result", None)
            if isinstance(value, dict):
                value = value.get("text") or value.get("result")
            return {"ok": bool(value), "text": value or ""}
        except Exception as exc:
            return {"ok": False, "reason": str(exc)}

    def open_url(self, url):
        if not self.consent.allowed("external_actions"):
            return {"ok": False, "reason": "Ação externa não autorizada."}
        if not self.available:
            return {"ok": False, "reason": "Integração Android indisponível."}
        try:
            self.droid.startActivity("android.intent.action.VIEW", str(url))
            return {"ok": True, "target": str(url)}
        except Exception as exc:
            return {"ok": False, "reason": str(exc)}

    def choose_file(self, mime="*/*"):
        if not self.consent.allowed("external_actions"):
            return {"ok": False, "reason": "Ação externa não autorizada."}
        if not self.available:
            return {"ok": False, "reason": "Gestor de ficheiros Android indisponível."}
        try:
            self.droid.startActivity(
                "android.intent.action.GET_CONTENT", None, mime, None, None
            )
            return {"ok": True, "message": "Seletor de ficheiros solicitado."}
        except Exception as exc:
            return {"ok": False, "reason": str(exc)}

    def view_media(self, path):
        if not self.consent.allowed("external_actions"):
            return {"ok": False, "reason": "Ação externa não autorizada."}
        if not self.available:
            return {"ok": False, "reason": "Integração Android indisponível."}
        try:
            uri = "file://" + os.path.abspath(path)
            self.droid.startActivity("android.intent.action.VIEW", uri)
            return {"ok": True, "path": os.path.abspath(path)}
        except Exception as exc:
            return {"ok": False, "reason": str(exc)}


class ABMEventBus:
    """Eventos explícitos enviados por módulos autorizados."""
    def __init__(self):
        self.handlers = defaultdict(list)
        self.events = deque(maxlen=500)

    def subscribe(self, event_name, callback):
        self.handlers[str(event_name)].append(callback)

    def publish(self, event_name, payload=None):
        event = {"name": str(event_name), "payload": payload or {},
                 "time": _now()}
        self.events.append(event)
        results = []
        for callback in list(self.handlers.get(str(event_name), [])):
            try:
                results.append(callback(event))
            except Exception as exc:
                results.append({"error": str(exc)})
        return results


class ABMSafety:
    """Política de segurança para ações sociais e do dispositivo."""
    THREAT_WORDS = ("vou bater", "vou matar", "ameaça", "agredir", "perseguir")
    INSULT_WORDS = ("burro", "idiota", "estúpido", "imbecil", "palhaço")

    def assess_social_context(self, text):
        t = str(text).lower()
        threat = any(w in t for w in self.THREAT_WORDS)
        insult = any(w in t for w in self.INSULT_WORDS)
        if threat:
            level = "alto"
            response = ("Vamos afastar-nos e procurar imediatamente um professor "
                        "ou adulto de confiança. Não vou provocar nem ameaçar ninguém.")
        elif insult:
            level = "moderado"
            response = ("Peço que falem com respeito. Se continuar, vamos pedir "
                        "ajuda a um professor ou à direção.")
        else:
            level = "normal"
            response = None
        return {"level": level, "suggested_response": response,
                "requires_human_judgment": True}

    def authorize_action(self, action, consent, confirmation=False):
        protected = {"send_message", "make_call", "answer_call", "share_location",
                     "delete_file", "record_audio", "record_video", "unlock_phone"}
        if action == "unlock_phone":
            return {"allowed": False,
                    "reason": "Só o bloqueio biométrico/PIN oficial pode desbloquear o telefone."}
        if action in protected and not confirmation:
            return {"allowed": False, "reason": "É necessária confirmação explícita."}
        if action in {"record_audio", "record_video"}:
            return {"allowed": False,
                    "reason": "Gravação ambiental oculta não é permitida pelo ABM."}
        return {"allowed": True}


class ABMCompanion(ABMInteractive):
    """
    Orquestrador ABM 5.2. Reutiliza ABM 5.1 e adiciona perfil, eventos,
    comandos de dispositivo e gestão explícita de consentimento.
    """
    def __init__(self, total_virtual_neurons=2000, state_path="abm_companion.json"):
        super().__init__(total_virtual_neurons)
        self.version = "5.2"
        self.state_path = str(state_path)
        self.consent = ABMConsent()
        self.safety = ABMSafety()
        self.events = ABMEventBus()
        self.android = ABMAndroidBridge(self.consent)
        self.companion_profile = {
            "display_name": "ABM",
            "owner_name": "",
            "friends": {},
            "preferences": {},
            "personality": "calmo, atento, respeitador e solidário"
        }
        self.activity_context = deque(maxlen=300)
        self.pending_action = None
        self.events.subscribe("incoming_call_notice", self._on_call_notice)
        self.events.subscribe("social_context", self._on_social_context)

    def configure_permission(self, name, enabled):
        result = self.consent.set(name, enabled)
        self.android.consent = self.consent
        return {"permission": name, "enabled": result}

    def introduce_person(self, name, relation="conhecido", notes=""):
        name = str(name).strip()
        if not name:
            raise ValueError("Indica o nome da pessoa.")
        self.companion_profile["friends"][name.lower()] = {
            "name": name, "relation": str(relation), "notes": str(notes)
        }
        return "Conheci a informação sobre " + name + ". Só a vou usar como contexto."

    def remember_context(self, text, category="experiência"):
        item = {"text": str(text), "category": str(category), "time": _now()}
        self.activity_context.append(item)
        self.remember(str(text), importance=0.65, tags=[str(category)], context={"category": category})
        return item

    def _on_call_notice(self, event):
        info = event.get("payload", {})
        return {"message": "Recebeste uma chamada.",
                "caller": info.get("caller", "número não identificado"),
                "action": "O ABM pode avisar; atender ou devolver chamada exige controlo Android autorizado."}

    def _on_social_context(self, event):
        text = event.get("payload", {}).get("text", "")
        return self.safety.assess_social_context(text)

    def observe_social_text(self, text):
        """Analisa texto que o utilizador introduz ou um módulo autorizado fornece."""
        if not self.consent.allowed("social_context"):
            return {"ok": False, "reason": "Contexto social ainda não autorizado."}
        self.remember_context(text, "contexto social")
        return {"ok": True, **self.safety.assess_social_context(text)}

    def handle_command(self, text):
        raw = str(text).strip()
        low = raw.lower()
        if not raw:
            raise ValueError("Comando vazio.")

        if low.startswith("/permissao "):
            parts = raw.split()
            if len(parts) != 3 or parts[2].lower() not in ("on", "off"):
                return "Usa: /permissao nome on|off"
            try:
                return str(self.configure_permission(parts[1], parts[2].lower() == "on"))
            except ValueError as exc:
                return str(exc)

        if low.startswith("/nome "):
            self.companion_profile["owner_name"] = raw[6:].strip()
            return "Vou tratar-te por " + self.companion_profile["owner_name"] + "."

        if low.startswith("/conhecer "):
            payload = raw[len("/conhecer "):]
            bits = [x.strip() for x in payload.split("|")]
            return self.introduce_person(bits[0], bits[1] if len(bits)>1 else "amigo",
                                         bits[2] if len(bits)>2 else "")

        if low in ("/estado", "estado do abm"):
            return json.dumps({"version": self.version,
                               "android": self.android.status(),
                               "permissions": self.consent.export(),
                               "memory_items": len(self.chat_history),
                               "known_people": len(self.companion_profile["friends"])},
                              ensure_ascii=False, indent=2)

        if any(k in low for k in ("abre os meus ficheiros", "abrir gestor de ficheiros",
                                  "abre gestor de ficheiros")):
            return str(self.android.choose_file("*/*"))

        if low.startswith("abre o site ") or low.startswith("abre o endereço "):
            target = raw.split(" ", 2)[-1].strip()
            if not target.startswith(("https://", "http://")):
                target = "https://" + target
            return str(self.android.open_url(target))

        if low.startswith("toca ") or low.startswith("abre o vídeo ") or low.startswith("abre a música "):
            return ("Para reproduzir offline, escolhe o ficheiro no gestor de ficheiros. "
                    "Para procurar online, indica o nome e o serviço; o ABM não descarrega "
                    "nem reproduz conteúdo protegido sem autorização.")

        if low.startswith("pára ") or low.startswith("para ") or "troca de vídeo" in low:
            return ("Posso abrir o seletor ou leitor, mas parar/trocar conteúdo noutra "
                    "aplicação depende dos controlos de multimédia que essa aplicação expõe.")

        if low in ("/ouvir", "ouve-me"):
            result = self.android.listen_once()
            if result.get("ok"):
                return self.chat(result["text"])["response"]
            return str(result)

        if low.startswith("/falar "):
            message = raw[len("/falar "):]
            return str(self.android.speak(message))

        if low.startswith("/social "):
            return json.dumps(self.observe_social_text(raw[len("/social "):]),
                              ensure_ascii=False)

        if low.startswith("/objetivo "):
            self.add_goal(raw[len("/objetivo "):], [], "geral")
            return "Objetivo registado."

        if low == "/guardar":
            self.save_companion()
            return "Estado e memória guardados."

        if low == "/sair":
            self.save_companion()
            return "Até já. Guardei o estado."

        # Contexto e conversa passam pelo cérebro preexistente.
        self.remember_context(raw, "conversa")
        answer = self.chat(raw)["response"]
        return answer

    def save_companion(self, filepath=None):
        target = Path(filepath or self.state_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "version": self.version,
            "consent": self.consent.export(),
            "profile": self.companion_profile,
            "activity_context": list(self.activity_context),
            "pending_action": self.pending_action
        }
        temp = target.with_suffix(target.suffix + ".tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(target)
        # Preserva também a persistência nativa do ABM 5.1.
        brain_path = target.with_suffix(".brain.json")
        super().save(str(brain_path))
        return str(target)

    def load_companion(self, filepath=None):
        target = Path(filepath or self.state_path)
        if not target.exists():
            return False
        data = json.loads(target.read_text(encoding="utf-8"))
        self.consent = ABMConsent(data.get("consent"))
        self.android.consent = self.consent
        self.companion_profile.update(data.get("profile", {}))
        self.activity_context = deque(data.get("activity_context", []), maxlen=300)
        self.pending_action = data.get("pending_action")
        brain_path = target.with_suffix(".brain.json")
        if brain_path.exists():
            saved_state_path = self.state_path
            loaded = ABMInteractive.load(str(brain_path))
            self.__dict__.update(loaded.__dict__)
            self.state_path = saved_state_path
            # A carga do núcleo 5.1 não pode rebaixar a versão do orquestrador 5.2.
            self.version = "5.2"
            self.consent = ABMConsent(data.get("consent"))
            self.android = ABMAndroidBridge(self.consent)
            self.safety = ABMSafety()
            self.events = ABMEventBus()
        return True


def run_abm52_tests():
    a = ABMCompanion(1000)
    assert a.version == "5.2"
    assert not a.consent.allowed("voice_input")
    a.configure_permission("voice_input", True)
    assert a.consent.allowed("voice_input")
    a.introduce_person("Ana", "amiga")
    assert "ana" in a.companion_profile["friends"]
    assert a.safety.assess_social_context("és burro")["level"] == "moderado"
    assert a.safety.assess_social_context("vou bater")["level"] == "alto"
    assert not a.safety.authorize_action("unlock_phone", a.consent)["allowed"]
    assert not a.safety.authorize_action("send_message", a.consent)["allowed"]
    assert a.safety.authorize_action("send_message", a.consent, True)["allowed"]
    with tempfile.TemporaryDirectory() as folder:
        path = str(Path(folder) / "companion.json")
        a.save_companion(path)
        b = ABMCompanion(1000, path)
        assert b.load_companion(path)
        assert b.consent.allowed("voice_input")
        assert "ana" in b.companion_profile["friends"]
        assert b.state_path == path
        b.save_companion()
    assert "permiss" in a.handle_command("/permissao camera on").lower()
    return {"status": "PASSOU_TOTALMENTE", "tests_executed": 10,
            "results": {"permissions": "PASSOU", "profile": "PASSOU",
                        "social_safety": "PASSOU", "protected_actions": "PASSOU",
                        "persistence": "PASSOU", "command_router": "PASSOU"},
            "limitations": [
                "Não existe escuta ou câmara secreta em segundo plano.",
                "Pydroid não substitui uma aplicação Android nativa com serviço foreground.",
                "Atendimento de chamadas, desbloqueio e controlo universal não são concedidos por Python.",
                "Voz, visão e reconhecimento de pessoas exigem modelos e permissões próprios."
            ]}


# CLI ABM 5.2
if __name__ == "__main__":
    import argparse as _abm_argparse
    _cli = _abm_argparse.ArgumentParser(description="ABM 5.2 — Companheiro Digital Experimental")
    _cli.add_argument("--all-tests", action="store_true")
    _cli.add_argument("--test52", action="store_true")
    _cli.add_argument("--chat", action="store_true")
    _cli.add_argument("--state", default="abm_companion.json")
    _args = _cli.parse_args()
    if _args.all_tests:
        print(json.dumps({"base_34": run_comprehensive_tests(),
                          "base_41": run_abm40_tests(),
                          "abm_50": run_abm50_tests(),
                          "abm_51": run_abm51_tests(),
                          "abm_52": run_abm52_tests()},
                         ensure_ascii=False, indent=2))
    elif _args.test52:
        print(json.dumps(run_abm52_tests(), ensure_ascii=False, indent=2))
    else:
        agent = ABMCompanion(state_path=_args.state)
        agent.load_companion()
        print("ABM 5.2 iniciado. /estado /ouvir /falar texto /guardar /sair")
        print("Permissões começam DESATIVADAS. Configura apenas o que autorizas.")
        while True:
            try:
                message = input("Tu: ").strip()
                response = agent.handle_command(message)
                print("ABM:", response)
                if message.lower() == "/sair":
                    break
            except (KeyboardInterrupt, EOFError):
                agent.save_companion()
                print("\nABM: Estado guardado.")
                break
            except Exception as exc:
                print("ABM: Ocorreu um erro controlado:", str(exc))
