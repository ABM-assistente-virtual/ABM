"""Ponte Android <-> ABM. Expõe APIs pequenas e testáveis à Activity Java."""
from pathlib import Path
import json
from ABM_UNIFICADO_5_2 import ABMCompanion
from abm_modules import Brain, Ears, Eyes, Voice, Body, Social, Autonomy, Security
from abm_modules.task_engine import GeneralTaskEngine
from abm_modules.tool_connector import UniversalToolConnector
from abm_modules.tool_engine import UniversalToolEngine
from abm_modules.unified_system import UnifiedABM
from abm_modules.memory_store import LocalMemoryStore
from abm_modules.adaptive_learning import AdaptiveLearning
from abm_modules.contextual_memory import ContextualMemory
from abm_modules.self_recovery import SelfRecoveryEngine
from abm_modules.continuous_operation import ContinuousOperationEngine
from abm_modules.intelligent_decision import IntelligentDecisionEngine
from abm_modules.context_understanding import ContextUnderstandingEngine
from abm_modules.adaptive_intelligence import AdaptiveIntelligenceEngine
from abm_modules.predictive_intelligence import PredictiveIntelligenceEngine
from abm_modules.universal_knowledge import UniversalKnowledgeEngine
from abm_modules.cross_department import CrossDepartmentEngine
from abm_modules.universal_interaction import UniversalInteractionEngine
from abm_modules.android_execution_bridge import AndroidExecutionBridge
from abm_modules.accessibility_intelligence import AccessibilityIntelligenceEngine
from abm_modules.device_control import UniversalDeviceControl
from abm_modules.system_unification import ABMSystemUnification
from abm_modules.voice_access_controller import VoiceAccessibilityController
from abm_modules.runtime_audit import RuntimeAudit

_agent = None
_modules = None
_data_dir = None
_secure_store = None

_STATE_MARKER = "@abm-keystore-json-v1"

def _secure_json_read(path, key, secure_store):
    """Lê JSON protegido; migra automaticamente ficheiros legados em texto simples."""
    path = Path(path)
    if secure_store is None:
        if not path.exists(): return None
        try: return json.loads(path.read_text(encoding="utf-8"))
        except Exception: return None
    if path.exists():
        raw = path.read_text(encoding="utf-8")
        if raw == _STATE_MARKER:
            stored = secure_store.getString(key, None)
            if stored is None: return None
            try: return json.loads(str(stored))
            except Exception: return None
        try:
            data = json.loads(raw)
            secure_store.putString(key, json.dumps(data, ensure_ascii=False, separators=(",", ":")))
            path.write_text(_STATE_MARKER, encoding="utf-8")
            return data
        except Exception:
            return None
    stored = secure_store.getString(key, None)
    if stored is None: return None
    try: return json.loads(str(stored))
    except Exception: return None

def _secure_json_write(path, key, data, secure_store):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    if secure_store is None:
        temp = path.with_suffix(path.suffix + ".tmp")
        temp.write_text(raw, encoding="utf-8"); temp.replace(path)
        return
    secure_store.putString(key, raw)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(_STATE_MARKER, encoding="utf-8"); temp.replace(path)

def _install_secure_companion_persistence(agent, root, secure_store):
    """Protege o estado JSON do companheiro e o snapshot neuronal legado."""
    state = Path(root) / "abm_companion.json"
    brain = state.with_suffix(".brain.json")
    runtime_state = Path(root) / ".abm_runtime_state.json"
    runtime_brain = runtime_state.with_suffix(".brain.json")
    state_data = _secure_json_read(state, "abm.core.companion.v1", secure_store)
    brain_data = _secure_json_read(brain, "abm.core.brain.v1", secure_store)
    if state_data is not None:
        runtime_state.write_text(json.dumps(state_data, ensure_ascii=False), encoding="utf-8")
        if brain_data is not None:
            runtime_brain.write_text(json.dumps(brain_data, ensure_ascii=False), encoding="utf-8")
        agent.load_companion(str(runtime_state))
        runtime_state.unlink(missing_ok=True); runtime_brain.unlink(missing_ok=True)
        # Regrava no formato protegido, consolidando também eventuais dados legados.
        save_original = agent.save_companion
    else:
        save_original = agent.save_companion
    def protected_save(filepath=None):
        result = save_original(str(runtime_state))
        if runtime_state.exists():
            try: _secure_json_write(state, "abm.core.companion.v1", json.loads(runtime_state.read_text(encoding="utf-8")), secure_store)
            finally: runtime_state.unlink(missing_ok=True)
        if runtime_brain.exists():
            try: _secure_json_write(brain, "abm.core.brain.v1", json.loads(runtime_brain.read_text(encoding="utf-8")), secure_store)
            finally: runtime_brain.unlink(missing_ok=True)
        return str(state)
    agent.state_path = str(state)
    agent.save_companion = protected_save
    if state_data is not None:
        protected_save()


def initialize(data_dir, secure_store=None):
    global _agent, _modules, _data_dir, _secure_store
    root = Path(str(data_dir))
    root.mkdir(parents=True, exist_ok=True)
    _data_dir = root
    _secure_store = secure_store
    state = root / "abm_companion.json"
    _agent = ABMCompanion(total_virtual_neurons=2000, state_path=str(state))
    try:
        if secure_store is not None:
            _install_secure_companion_persistence(_agent, root, secure_store)
        else:
            _agent.load_companion()
    except Exception:
        backup = state.with_suffix(".corrupt.json")
        if state.exists() and not backup.exists():
            state.replace(backup)
        _agent = ABMCompanion(total_virtual_neurons=2000, state_path=str(state))
        if secure_store is not None:
            _install_secure_companion_persistence(_agent, root, secure_store)
    _modules = {
        "brain": Brain(_agent), "ears": Ears(), "eyes": Eyes(),
        "voice": Voice(), "body": Body(), "social": Social(),
        "autonomy": Autonomy(), "security": Security(),
    }
    _modules["tool_connector"] = UniversalToolConnector(str(root))
    _modules["tool_engine"] = UniversalToolEngine(_modules["tool_connector"], _modules["security"], root / "abm_execution_history.sqlite3", secure_store=secure_store)
    _modules["self_recovery"] = SelfRecoveryEngine(_modules["tool_engine"], root / "abm_recovery.sqlite3", secure_store=secure_store)
    _modules["continuous_operation"] = ContinuousOperationEngine(root / "abm_workflows.sqlite3", _modules["self_recovery"], secure_store=secure_store)
    _modules["decision_engine"] = IntelligentDecisionEngine(_modules["tool_engine"])
    _modules["memory_store"] = LocalMemoryStore(root / "abm_memory.sqlite3", secure_store=secure_store)
    _modules["adaptive_learning"] = AdaptiveLearning(root / "abm_learning.sqlite3", secure_store=secure_store)
    _modules["contextual_memory"] = ContextualMemory(root / "abm_contextual_memory.sqlite3", secure_store=secure_store)
    _modules["context_understanding"] = ContextUnderstandingEngine(_modules["contextual_memory"])
    _modules["adaptive_intelligence"] = AdaptiveIntelligenceEngine(_modules["context_understanding"], _modules["adaptive_learning"])
    _modules["predictive_intelligence"] = PredictiveIntelligenceEngine(_modules["context_understanding"], _modules["adaptive_learning"])
    _modules["knowledge"] = UniversalKnowledgeEngine(root / "abm_knowledge.sqlite3", secure_store=secure_store)
    _modules["cross_department"] = CrossDepartmentEngine(root / "abm_cross_department.sqlite3", secure_store=secure_store)
    _modules["interaction"] = UniversalInteractionEngine(root / "abm_interaction.sqlite3", secure_store=secure_store)
    _modules["android_bridge"] = AndroidExecutionBridge()
    _modules["accessibility_intelligence"] = AccessibilityIntelligenceEngine(root / "abm_accessibility_profile.sqlite3", secure_store=secure_store)
    _modules["device_control"] = UniversalDeviceControl(root / "abm_device_control.sqlite3", _modules["android_bridge"], secure_store=secure_store)
    _modules["task_engine"] = GeneralTaskEngine(_modules["body"], _modules["autonomy"], _modules["tool_connector"])
    _modules["agent"] = _agent
    _modules["save_callback"] = save
    _modules["unified"] = UnifiedABM(_modules["task_engine"], _modules)
    _modules["cloud_status"] = {"configured": False, "runtime_connected": False}  # adaptador de estado; não declara cloud ativo.
    _modules["voice_access"] = VoiceAccessibilityController()  # interpreta transcrições; não captura áudio.
    _modules["system_unification"] = ABMSystemUnification(_modules)
    _modules["runtime_audit"] = RuntimeAudit(_modules, root)
    module_state = root / "abm_modules.json"
    try:
        saved = _secure_json_read(module_state, "abm.core.modules.v1", secure_store)
        if saved:
            _modules["security"].permissions.update(saved.get("permissions", {}))
            _modules["autonomy"].goals.update(saved.get("goals", {}))
            _modules["autonomy"].pending.update(saved.get("pending", {}))
    except Exception:
        pass
    return "ABM 8.0.0: núcleo Python, motor de ferramentas, memória e registo dos 15 departamentos inicializados. A prontidão real de cada departamento está disponível em /abm departamentos."


def _require():
    if _agent is None or _modules is None:
        raise RuntimeError("O núcleo ABM ainda não foi inicializado.")


def command(text):
    _require()
    raw = str(text).strip()
    low = raw.casefold()
    if not raw:
        raise ValueError("Comando vazio.")
    if low in ("/diagnostico", "/diagnóstico", "/abm diagnostico", "/abm diagnóstico"):
        return json.dumps(_modules["runtime_audit"].report(), ensure_ascii=False, indent=2)
    if low in ("/abm sistema", "/abm departamentos"):
        return json.dumps(_modules["system_unification"].status(), ensure_ascii=False, indent=2)
    if low == "/unificacao validar":
        return json.dumps(_modules["system_unification"].validate(), ensure_ascii=False, indent=2)
    if low in ("/estado", "estado do abm") or low.startswith(("/nome ", "/conhecer ", "/falar ")) or low in ("/guardar", "/sair"):
        return str(_agent.handle_command(raw))
    if low.startswith("/memoria "):
        # /memoria guardar <texto> exige pedido explícito; /memoria procurar <termos>
        parts = raw.split(" ", 2)
        if len(parts) < 3:
            return "Usa: /memoria guardar <texto> | procurar <termos> | listar | estado"
        action, value = parts[1].casefold(), parts[2]
        if action == "guardar":
            result = _modules["memory_store"].remember(value, consent=True)
        elif action == "procurar":
            result = _modules["memory_store"].search(value)
        elif action == "estado":
            result = _modules["memory_store"].status()
        else:
            return "Ação de memória desconhecida. Usa guardar, procurar ou estado."
        return json.dumps(result, ensure_ascii=False, indent=2)
    if low.startswith("/aprender "):
        # /aprender corregir <tema> | <pedido original> | <correção>
        # /aprender preferencia <chave> | <valor>
        parts = raw.split(" ", 2)
        if len(parts) < 3:
            return "Usa: /aprender corrigir <tema> | <pedido> | <correção> ou /aprender preferencia <chave> | <valor>"
        mode, payload = parts[1].casefold(), parts[2]
        fields = [x.strip() for x in payload.split("|", 2)]
        if mode == "corrigir" and len(fields) == 3:
            result = _modules["adaptive_learning"].learn_feedback(fields[0], fields[1], fields[2], consent=True)
        elif mode == "preferencia" and len(fields) == 2:
            result = _modules["adaptive_learning"].set_preference(fields[0], fields[1], consent=True)
        elif mode == "estado":
            result = _modules["adaptive_learning"].status()
        else:
            return "Formato inválido. Usa corrigir, preferencia ou estado."
        return json.dumps(result, ensure_ascii=False, indent=2)
    if low == "/android ponte estado":
        return json.dumps(_modules["android_bridge"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/android ponte permissao "):
        value = raw[len("/android ponte permissao "):].strip().casefold()
        if value not in ("sim", "não", "nao"):
            return "Usa: /android ponte permissao sim|nao — informa o estado confirmado nas definições Android."
        return json.dumps(_modules["android_bridge"].update_service_state(value == "sim"), ensure_ascii=False, indent=2)
    if low.startswith("/android ponte validar "):
        fields = raw[len("/android ponte validar "):].split("|", 1)
        confirmed = len(fields) == 2 and fields[1].strip().casefold() == "confirmar"
        result = _modules["android_bridge"].validate(fields[0], user_confirmed=confirmed)
        return json.dumps({"accepted": result.accepted, "action": result.action, "reason": result.reason}, ensure_ascii=False, indent=2)
    if low == "/acessibilidade inteligente estado":
        return json.dumps(_modules["accessibility_intelligence"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/acessibilidade perfil "):
        # /acessibilidade perfil preferidas=voice,switch | disponiveis=voice,switch | confirmar
        fields = [x.strip() for x in raw[len("/acessibilidade perfil "):].split("|")]
        if len(fields) != 3 or fields[2].casefold() != "confirmar":
            return "Usa: /acessibilidade perfil voice,switch | voice,switch | confirmar"
        def parse_field(value, prefix):
            if not value.startswith(prefix): raise ValueError("Campo inválido: " + prefix)
            return [x.strip() for x in value[len(prefix):].split(",") if x.strip()]
        try:
            result = _modules["accessibility_intelligence"].set_profile(parse_field(fields[0], "preferidas="), parse_field(fields[1], "disponiveis="), consent=True)
        except Exception as exc: return "Perfil não aceite: " + str(exc)
        return json.dumps(result, ensure_ascii=False, indent=2)
    if low.startswith("/acessibilidade recomendar "):
        fields = raw[len("/acessibilidade recomendar "):].split("|")
        try: result = _modules["accessibility_intelligence"].recommend(fields[0].strip(), float(fields[1]) if len(fields)>1 else 1.0)
        except Exception as exc: return "Não foi possível recomendar: " + str(exc)
        return json.dumps(result, ensure_ascii=False, indent=2)
    if low.startswith("/acessibilidade feedback "):
        fields = raw[len("/acessibilidade feedback "):].split("|")
        if len(fields) != 2 or fields[1].strip().casefold() not in ("sim", "não", "nao"):
            return "Usa: /acessibilidade feedback modalidade | sim|nao"
        try: result = _modules["accessibility_intelligence"].feedback(fields[0].strip(), fields[1].strip().casefold()=="sim", consent=True)
        except Exception as exc: return "Feedback não aceite: " + str(exc)
        return json.dumps(result, ensure_ascii=False, indent=2)
    if low == "/acessibilidade limpar confirmar":
        return json.dumps(_modules["accessibility_intelligence"].clear(confirmed=True), ensure_ascii=False, indent=2)
    if low == "/dispositivo estado":
        return json.dumps(_modules["device_control"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/dispositivo preparar "):
        return json.dumps(_modules["device_control"].prepare(raw[len("/dispositivo preparar "):]), ensure_ascii=False, indent=2)
    if low.startswith("/dispositivo autorizar "):
        fields=raw[len("/dispositivo autorizar "):].split()
        if len(fields) not in (1,2) or (len(fields)==2 and fields[1].casefold()!="confirmar"):
            return "Usa: /dispositivo autorizar ID [confirmar]"
        return json.dumps(_modules["device_control"].approve(fields[0], confirmed=(len(fields)==2)), ensure_ascii=False, indent=2)
    if low.startswith("/dispositivo cancelar "):
        return json.dumps(_modules["device_control"].cancel(raw[len("/dispositivo cancelar "):].strip()), ensure_ascii=False, indent=2)
    if low == "/interacao estado":
        return json.dumps(_modules["interaction"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/interacao entrada "):
        # /interacao entrada modalidade | conteúdo | origem [| confiança]
        fields=raw[len("/interacao entrada "):].split("|",3)
        if len(fields)<2: return "Usa: /interacao entrada modalidade | conteúdo | origem [| confiança]"
        try:
            confidence=float(fields[3]) if len(fields)>3 else 1.0
            result=_modules["interaction"].submit(fields[0].strip(),fields[1].strip(),fields[2].strip() if len(fields)>2 else "user",confidence,consent=True)
        except Exception as exc: return "Entrada não aceite: "+str(exc)
        return json.dumps(result,ensure_ascii=False,indent=2)
    if low == "/interacao proxima":
        return json.dumps(_modules["interaction"].next_event(),ensure_ascii=False,indent=2)
    if low.startswith("/interacao confirmar "):
        fields=raw[len("/interacao confirmar "):].split("|",1)
        if len(fields)!=2 or fields[1].strip().casefold() not in ("sim","nao","não"):
            return "Usa: /interacao confirmar ID | sim|nao"
        return json.dumps(_modules["interaction"].acknowledge(fields[0].strip(),fields[1].strip().casefold()=="sim"),ensure_ascii=False,indent=2)
    if low == "/departamentos-compartilhamento estado":
        return json.dumps(_modules["cross_department"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/departamento enviar "):
        # /departamento enviar origem | destino | tópico | JSON [| correlação]
        fields=raw[len("/departamento enviar "):].split("|",4)
        if len(fields)<4: return "Usa: /departamento enviar origem | destino | tópico | JSON [| correlação]"
        try: payload=json.loads(fields[3]); result=_modules["cross_department"].publish(fields[0],fields[1],fields[2],payload,fields[4] if len(fields)>4 else None)
        except Exception as exc: return "Não foi possível enviar: "+str(exc)
        return json.dumps(result,ensure_ascii=False,indent=2)
    if low.startswith("/departamento receber "):
        dept=raw[len("/departamento receber "):].strip()
        return json.dumps(_modules["cross_department"].receive(dept),ensure_ascii=False,indent=2)
    if low.startswith("/departamento confirmar "):
        fields=raw[len("/departamento confirmar "):].split("|",1)
        if len(fields)!=2: return "Usa: /departamento confirmar ID | departamento"
        return json.dumps(_modules["cross_department"].acknowledge(fields[0].strip(),fields[1].strip()),ensure_ascii=False,indent=2)
    if low.startswith("/contexto partilhar "):
        fields=raw[len("/contexto partilhar "):].split("|",3)
        if len(fields)!=4: return "Usa: /contexto partilhar correlação | departamento | chave | valor"
        return json.dumps(_modules["cross_department"].share_context(fields[0],fields[1],fields[2],fields[3],consent=True),ensure_ascii=False,indent=2)
    if low.startswith("/contexto consultar "):
        fields=raw[len("/contexto consultar "):].split("|",1)
        if len(fields)!=2: return "Usa: /contexto consultar correlação | departamento"
        return json.dumps(_modules["cross_department"].get_context(fields[0],fields[1]),ensure_ascii=False,indent=2)
    if low == "/conhecimento estado":
        return json.dumps(_modules["knowledge"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/conhecimento guardar "):
        fields=raw[len("/conhecimento guardar "):].split("|",3)
        if len(fields)<3: return "Usa: /conhecimento guardar assunto | relação | informação [| origem]"
        result=_modules["knowledge"].add_fact(fields[0],fields[1],fields[2],fields[3] if len(fields)>3 else "user",consent=True)
        return json.dumps(result,ensure_ascii=False,indent=2)
    if low.startswith("/conhecimento procurar "):
        return json.dumps(_modules["knowledge"].search(raw[len("/conhecimento procurar "):]),ensure_ascii=False,indent=2)
    if low.startswith("/conhecimento relacionado "):
        return json.dumps(_modules["knowledge"].related(raw[len("/conhecimento relacionado "):]),ensure_ascii=False,indent=2)
    if low == "/previsao estado":
        return json.dumps(_modules["predictive_intelligence"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/prever "):
        request = raw[len("/prever "):].strip()
        return json.dumps(_modules["predictive_intelligence"].predict(request), ensure_ascii=False, indent=2)
    if low.startswith("/padrao autorizar "):
        pattern = raw[len("/padrao autorizar "):].strip()
        return json.dumps(_modules["predictive_intelligence"].record_explicit_pattern(pattern, consent=True), ensure_ascii=False, indent=2)
    if low == "/inteligencia estado":
        return json.dumps(_modules["adaptive_intelligence"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/adaptar "):
        request = raw[len("/adaptar "):].strip()
        return json.dumps(_modules["adaptive_intelligence"].analyze(request), ensure_ascii=False, indent=2)
    if low == "/compreensao estado":
        return json.dumps(_modules["context_understanding"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/compreender "):
        request = raw[len("/compreender "):].strip()
        return json.dumps(_modules["context_understanding"].understand(request), ensure_ascii=False, indent=2)
    if low == "/decisao estado":
        return json.dumps(_modules["decision_engine"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/decidir "):
        request = raw[len("/decidir "):].strip()
        return json.dumps(_modules["decision_engine"].decide(request), ensure_ascii=False, indent=2)
    if low.startswith("/departamentos"):
        return json.dumps(_modules["unified"].department_summary(), ensure_ascii=False, indent=2)
    if low.startswith("/departamento "):
        # Formato: /departamento <id> <ação> [JSON]
        parts = raw.split(" ", 3)
        if len(parts) < 3:
            return "Usa: /departamento <id> <ação> [JSON]"
        payload = {}
        if len(parts) == 4:
            try:
                payload = json.loads(parts[3])
            except Exception as exc:
                return "JSON inválido: " + str(exc)
        result = _modules["unified"].dispatch(parts[1], parts[2], payload)
        return json.dumps(result, ensure_ascii=False, indent=2, default=str)
    if low == "/ferramentas":
        return json.dumps(_modules["tool_engine"].discover(), ensure_ascii=False, indent=2)
    if low.startswith("/ferramenta procurar "):
        query = raw[len("/ferramenta procurar "):].strip()
        return json.dumps(_modules["tool_engine"].discover(query), ensure_ascii=False, indent=2)
    if low.startswith("/ferramenta preparar "):
        parts = raw.split(" ", 3)
        if len(parts) < 3:
            return "Usa: /ferramenta preparar nome.da.ferramenta {\"request\":\"texto\"}"
        try:
            args = json.loads(parts[3]) if len(parts) == 4 else {}
        except Exception as exc:
            return "JSON inválido: " + str(exc)
        result = _modules["tool_engine"].prepare(parts[2], args)
        return json.dumps(result, ensure_ascii=False, indent=2, default=str)
    if low.startswith("/ferramenta preparar-persistente "):
        parts = raw.split(" ", 3)
        if len(parts) < 3:
            return "Usa: /ferramenta preparar-persistente nome.da.ferramenta {\"request\":\"texto\"}"
        try:
            args = json.loads(parts[3]) if len(parts) == 4 else {}
        except Exception as exc:
            return "JSON inválido: " + str(exc)
        return json.dumps(_modules["tool_engine"].prepare(parts[2], args, persist_context=True), ensure_ascii=False, indent=2, default=str)
    if low == "/fluxos" or low == "/fluxo estado":
        return json.dumps({"status":_modules["continuous_operation"].status(),"workflows":_modules["continuous_operation"].list()}, ensure_ascii=False, indent=2)
    if low.startswith("/fluxo criar "):
        try:
            payload=json.loads(raw[len("/fluxo criar "):])
            return json.dumps(_modules["continuous_operation"].create(payload["title"],payload["steps"]),ensure_ascii=False,indent=2)
        except Exception as exc: return "Não foi possível criar o fluxo: "+str(exc)
    if low.startswith("/fluxo ver "):
        return json.dumps(_modules["continuous_operation"].get(raw[len("/fluxo ver "):].strip()),ensure_ascii=False,indent=2)
    if low.startswith("/fluxo proximo "):
        return json.dumps(_modules["continuous_operation"].next_step(raw[len("/fluxo proximo "):].strip()),ensure_ascii=False,indent=2)
    if low.startswith("/fluxo pausar "):
        return json.dumps(_modules["continuous_operation"].pause(raw[len("/fluxo pausar "):].strip()),ensure_ascii=False,indent=2)
    if low.startswith("/fluxo retomar "):
        return json.dumps(_modules["continuous_operation"].resume(raw[len("/fluxo retomar "):].strip()),ensure_ascii=False,indent=2)
    if low.startswith("/fluxo cancelar "):
        return json.dumps(_modules["continuous_operation"].cancel(raw[len("/fluxo cancelar "):].strip()),ensure_ascii=False,indent=2)
    if low.startswith("/fluxo confirmar "):
        parts=raw.split(" ",4)
        if len(parts)<4 or parts[3].casefold() not in ("sim","nao","não"): return "Usa: /fluxo confirmar ID_ETAPA sim|nao [resultado]"
        wid=parts[2].split(":",1)[0]; sid=parts[2].split(":",1)[1] if ":" in parts[2] else ""
        if not sid:return "Usa: /fluxo confirmar ID:ETAPA sim|nao [resultado]"
        return json.dumps(_modules["continuous_operation"].confirm_step(wid,sid,parts[3].casefold()=="sim",parts[4] if len(parts)>4 else ""),ensure_ascii=False,indent=2)
    if low == "/recuperacao" or low == "/recuperacao estado":
        return json.dumps(_modules["self_recovery"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/recuperacao diagnosticar "):
        execution_id = raw[len("/recuperacao diagnosticar "):].strip()
        return json.dumps(_modules["self_recovery"].diagnose(execution_id), ensure_ascii=False, indent=2)
    if low.startswith("/recuperacao preparar "):
        parts=raw.split()
        if len(parts) not in (3,4): return "Usa: /recuperacao preparar ID [confirmar]"
        result=_modules["self_recovery"].prepare_recovery(parts[2], user_confirmed=(len(parts)==4 and parts[3].casefold()=="confirmar"))
        return json.dumps(result, ensure_ascii=False, indent=2, default=str)
    if low.startswith("/recuperacao eventos "):
        parts=raw.split()
        if len(parts) not in (3,4): return "Usa: /recuperacao eventos ID [limite]"
        return json.dumps(_modules["self_recovery"].events(parts[2], int(parts[3]) if len(parts)==4 else 50), ensure_ascii=False, indent=2)
    if low == "/execucoes" or low.startswith("/execucoes "):
        return json.dumps(_modules["tool_engine"].list_history(), ensure_ascii=False, indent=2, default=str)
    if low.startswith("/execucao retomar "):
        parts = raw.split()
        if len(parts) not in (3, 4): return "Usa: /execucao retomar ID [confirmar]"
        return json.dumps(_modules["tool_engine"].resume_execution(parts[2], confirmed=(len(parts)==4 and parts[3].casefold()=="confirmar")), ensure_ascii=False, indent=2, default=str)
    if low.startswith("/execucao eventos "):
        parts = raw.split()
        if len(parts) not in (3, 4): return "Usa: /execucao eventos ID [limite]"
        limit = int(parts[3]) if len(parts) == 4 else 100
        return json.dumps(_modules["tool_engine"].execution_events(parts[2], limit), ensure_ascii=False, indent=2, default=str)
    if low.startswith("/ferramenta executar "):
        parts = raw.split()
        if len(parts) not in (3, 4):
            return "Usa: /ferramenta executar ID [confirmar]"
        confirmed = len(parts) == 4 and parts[3].casefold() == "confirmar"
        result = _modules["tool_engine"].execute(parts[2], confirmed=confirmed)
        return json.dumps(result, ensure_ascii=False, indent=2, default=str)
    if low.startswith("/capacidades"):
        return json.dumps(_modules["task_engine"].status(), ensure_ascii=False, indent=2)
    if low.startswith("/tarefa "):
        request = raw[len("/tarefa "):].strip()
        result = _modules["task_engine"].process(request, lambda value: _modules["brain"].think(value)["response"])
        return _format_task_result(result)
    if low.startswith("/executar "):
        plan_id = raw[len("/executar "):].strip()
        result = _modules["task_engine"].execute(plan_id, lambda value: _modules["brain"].think(value)["response"])
        return _format_execution_result(result)
    if low.startswith("/aprovar "):
        plan_id = raw[len("/aprovar "):].strip()
        result = _modules["task_engine"].execute(plan_id, lambda value: _modules["brain"].think(value)["response"], approved=True)
        return _format_execution_result(result)
    if low.startswith("/executar-agora "):
        request = raw[len("/executar-agora "):].strip()
        planned = _modules["task_engine"].process(request, lambda value: _modules["brain"].think(value)["response"])
        if planned.get("status") != "planned":
            return str(planned.get("response", planned.get("message", "Não foi possível preparar a tarefa.")))
        result = _modules["task_engine"].execute(planned["plan"]["id"], lambda value: _modules["brain"].think(value)["response"])
        return _format_execution_result(result)
    if low.startswith("/social "):
        result = _modules["social"].analyze_text(raw[len("/social "):])
        _agent.remember_context(raw[len("/social "):], "texto social fornecido pelo utilizador")
        return ("Avaliação: " + result["level"] + ". " + result["suggested_response"] +
                " Esta é uma análise automática limitada; confirma o contexto antes de agir.")
    if low.startswith("/objetivo "):
        goal = _modules["autonomy"].add_goal(raw[len("/objetivo "):])
        _agent.add_goal(goal["description"], [s["text"] for s in goal["steps"]], goal["id"])
        return "Objetivo registado: " + goal["description"]
    if low.startswith("/permissao "):
        parts = raw.split()
        if len(parts) != 3 or parts[2].casefold() not in ("on", "off"):
            return "Usa: /permissao nome on|off"
        enabled = parts[2].casefold() == "on"
        _modules["security"].set_permission(parts[1], enabled)
        _agent.configure_permission(parts[1], enabled)
        return "Permissão " + parts[1] + (" ativada." if enabled else " desativada.")
    if low.startswith("/plano-avancado "):
        plan = _modules["unified"].advanced_plan(raw[len("/plano-avancado "):])
        return json.dumps(plan, ensure_ascii=False, default=str)
    if low.startswith("/plano "):
        plan = _modules["body"].plan(raw[len("/plano "):])
        return json.dumps(plan, ensure_ascii=False)
    if low.startswith("/analisar-wav "):
        return json.dumps(_modules["ears"].analyze_wav(raw[len("/analisar-wav "):].strip()), ensure_ascii=False)
    if low.startswith("/analisar-imagem "):
        return json.dumps(_modules["eyes"].analyze_image(raw[len("/analisar-imagem "):].strip()), ensure_ascii=False)
    result = _modules["unified"].plan_task(raw, lambda value: _modules["brain"].think(value)["response"])
    return _format_task_result(result)


def _format_execution_result(result):
    lines = [str(result.get("message", result.get("status", "Resultado da execução."))),
             "Estado: " + str(result.get("status", "desconhecido"))]
    for item in result.get("results", []):
        lines.append("Concluído — " + item.get("capability", "capacidade") + ": " +
                     json.dumps(item.get("result", item), ensure_ascii=False, default=str))
    for item in result.get("blocked", []):
        lines.append("Pendente — " + item.get("capability", "capacidade") + ": " + item.get("reason", "sem detalhe"))
    return "\n".join(lines)


def _format_task_result(result):
    if result.get("status") == "conversation":
        return str(result.get("response", ""))
    if result.get("status") == "needs_input":
        return str(result.get("message", "Preciso de mais informação."))
    plan = result.get("plan", {})
    lines = [str(result.get("response", "Plano preparado.")), "Objetivo: " + str(plan.get("request", "")), "Etapas:"]
    for step in plan.get("steps", []):
        lines.append(str(step.get("number", "")) + ". " + str(step.get("description", "")))
    if result.get("confirmation_required"):
        lines.append("Confirmação necessária para: " + ", ".join(result["confirmation_required"]))
    lines.append("ID do plano: " + str(plan.get("id", "")))
    return "\n".join(lines)


def advanced_plan(text, profile_id="default", include_memory=False):
    """Cria um plano multi-etapas; não executa operações Android."""
    _require()
    result = _modules["unified"].advanced_plan(
        text, profile_id=profile_id, include_memory=bool(include_memory))
    return json.dumps(result, ensure_ascii=False, default=str)


def verify_advanced_plan_step(plan_id, step_id, success, evidence, confirmed=False):
    """Regista evidência enviada pelo executor Android; não observa o dispositivo."""
    _require()
    result = _modules["unified"].verify_plan_step(
        plan_id, step_id, success, evidence, confirmed=confirmed)
    return json.dumps(result, ensure_ascii=False, default=str)


def dispatch_department(department, action, payload_json="{}"):
    """API comum para a interface Android chamar qualquer departamento."""
    _require()
    payload = json.loads(str(payload_json or "{}"))
    if not isinstance(payload, dict):
        raise ValueError("payload_json deve conter um objeto JSON.")
    result = _modules["unified"].dispatch(department, action, payload)
    return json.dumps(result, ensure_ascii=False, default=str)


def discover_tools(query=""):
    _require()
    return json.dumps(_modules["tool_engine"].discover(query), ensure_ascii=False, default=str)


def prepare_tool(name, arguments_json="{}", persist_context=False):
    _require()
    args = json.loads(str(arguments_json or "{}"))
    return json.dumps(_modules["tool_engine"].prepare(name, args, persist_context=bool(persist_context)), ensure_ascii=False, default=str)


def execute_tool(execution_id, confirmed=False):
    _require()
    return json.dumps(_modules["tool_engine"].execute(execution_id, confirmed=bool(confirmed)), ensure_ascii=False, default=str)


def register_capability(name, description):
    _require()
    return _modules["task_engine"].register_capability(name, description)



def coordinate_request(text, source="text", confirmed=False):
    """Coordena vários departamentos e devolve um plano sem executar Android."""
    _require()
    result = _modules["unified"].coordinate_request(text, source=source, confirmed=confirmed)
    return json.dumps(result, ensure_ascii=False, default=str)


def process_task(text):
    _require()
    result = _modules["unified"].plan_task(text, lambda value: _modules["brain"].think(value)["response"])
    return json.dumps(result, ensure_ascii=False, default=str)


def execute_task(plan_id):
    _require()
    result = _modules["task_engine"].execute(plan_id, lambda value: _modules["brain"].think(value)["response"])
    return json.dumps(result, ensure_ascii=False, default=str)


def process_and_execute(text):
    """Processa pedido novo, executa ferramentas locais e devolve ações Android para a Activity."""
    _require()
    if str(text).strip().startswith("/"):
        return json.dumps({"status": "legacy_command", "message": "Usa a interface de comandos existente."}, ensure_ascii=False)
    brain = lambda value: _modules["brain"].think(value)["response"]
    planned = _modules["unified"].plan_task(text, brain)
    if planned.get("status") != "planned":
        return json.dumps(planned, ensure_ascii=False, default=str)
    execution = _modules["task_engine"].execute(planned["plan"]["id"], brain)
    return json.dumps({"status": execution.get("status"), "plan": planned.get("plan"),
                       "execution": execution, "response": planned.get("response")},
                      ensure_ascii=False, default=str)



def execute_registered_tool(execution_id, confirmed=False):
    """Executa um plano do catálogo 4.8; ações Android ficam pendentes de confirmação do adaptador."""
    _require()
    result = _modules["tool_engine"].execute(str(execution_id), confirmed=bool(confirmed))
    return json.dumps(result, ensure_ascii=False, default=str)


def record_android_tool_result(execution_id, accepted, detail=""):
    """Regista aceitação/rejeição do Intent pelo Android, sem alegar conclusão na app externa."""
    _require()
    result = _modules["tool_engine"].record_android_result(str(execution_id), bool(accepted), str(detail))
    return json.dumps(result, ensure_ascii=False, default=str)


def record_android_target_outcome(execution_id, outcome, evidence=""):
    """Regista feedback explícito do utilizador sobre o resultado na aplicação-alvo."""
    _require()
    result = _modules["tool_engine"].record_target_outcome(str(execution_id), str(outcome), str(evidence))
    return json.dumps(result, ensure_ascii=False, default=str)


def get_tool_execution_status(execution_id):
    _require()
    result = _modules["tool_engine"].get_execution_status(str(execution_id))
    return json.dumps(result, ensure_ascii=False, default=str)


def memory_dispatch(action, payload_json="{}"):
    """API de memória: gravação exige consent=true; apagar exige confirmed=true."""
    _require()
    payload = json.loads(str(payload_json or "{}"))
    if not isinstance(payload, dict):
        raise ValueError("payload_json deve conter um objeto JSON.")
    result = _modules["unified"].dispatch("memory", action, payload)
    return json.dumps(result, ensure_ascii=False, default=str)


def learning_dispatch(action, payload_json="{}"):
    """API de aprendizagem local; todas as gravações exigem consentimento explícito."""
    _require()
    payload = json.loads(str(payload_json or "{}"))
    if not isinstance(payload, dict):
        raise ValueError("payload_json deve conter um objeto JSON.")
    engine = _modules["adaptive_learning"]
    if action == "feedback":
        result = engine.learn_feedback(payload.get("topic"), payload.get("input"), payload.get("correction"), consent=bool(payload.get("consent", False)))
    elif action == "preference":
        result = engine.set_preference(payload.get("key"), payload.get("value"), consent=bool(payload.get("consent", False)))
    elif action == "preferences":
        result = engine.get_preferences()
    elif action == "suggestions":
        result = engine.suggestions(payload.get("text", ""), limit=payload.get("limit", 5))
    elif action == "pattern":
        result = engine.record_pattern(payload.get("key"), consent=bool(payload.get("consent", False)))
    elif action == "status":
        result = engine.status()
    elif action == "export":
        result = {"json": engine.export_json()}
    elif action == "forget_feedback":
        result = engine.forget_feedback(payload.get("id", ""), confirmed=bool(payload.get("confirmed", False)))
    elif action == "clear":
        result = engine.clear(confirmed=bool(payload.get("confirmed", False)))
    else:
        raise ValueError("Ação de aprendizagem desconhecida: " + str(action))
    return json.dumps(result, ensure_ascii=False, default=str)


def status():
    _require()
    return json.dumps({"brain": _modules["brain"].status(),
                       "modules": {name: "ready" for name in _modules},
                       "security": _modules["security"].export(),
                       "goals": len(_modules["autonomy"].goals),
                       "pending_actions": len(_modules["autonomy"].pending),
                       "task_engine": _modules["task_engine"].status(),
                       "unified_system": _modules["unified"].health(),
                       "adaptive_learning": _modules["adaptive_learning"].status(),
                       "contextual_memory": _modules["contextual_memory"].status(),
                       "departments": _modules["unified"].department_summary()},
                      ensure_ascii=False, default=str)


def plan_action(text):
    _require()
    return json.dumps(_modules["body"].plan(text), ensure_ascii=False)


def analyze_social(text):
    _require()
    return json.dumps(_modules["social"].analyze_text(text), ensure_ascii=False)


def analyze_image(filepath):
    _require()
    return json.dumps(_modules["eyes"].analyze_image(filepath), ensure_ascii=False)


def analyze_wav(filepath):
    _require()
    return json.dumps(_modules["ears"].analyze_wav(filepath), ensure_ascii=False)


def prepare_voice(text):
    _require()
    return json.dumps(_modules["voice"].prepare(text), ensure_ascii=False)


def introduce(name, relation="conhecido", notes=""):
    _require()
    return str(_agent.introduce_person(name, relation, notes))


def save():
    _require()
    result = _agent.save_companion()
    payload = {"permissions": _modules["security"].permissions,
               "goals": _modules["autonomy"].goals,
               "pending": _modules["autonomy"].pending}
    target = _data_dir / "abm_modules.json"
    temp = target.with_suffix(".tmp")
    _secure_json_write(target, "abm.core.modules.v1", payload, _secure_store)
    return str(result)


def list_execution_history(limit=50):
    _require()
    return json.dumps(_modules["tool_engine"].list_history(limit), ensure_ascii=False, default=str)


def resume_tool_execution(execution_id, confirmed=False):
    _require()
    return json.dumps(_modules["tool_engine"].resume_execution(str(execution_id), confirmed=bool(confirmed)), ensure_ascii=False, default=str)
