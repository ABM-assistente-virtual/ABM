"""Módulos especializados do ABM Android. Sem dependências externas obrigatórias."""
from .brain import Brain
from .ears import Ears
from .eyes import Eyes
from .voice import Voice
from .body import Body
from .social import Social
from .autonomy import Autonomy
from .security import Security
from .task_engine import GeneralTaskEngine, CapabilityRegistry
from .tool_connector import UniversalToolConnector
from .tool_engine import UniversalToolEngine, ToolSpec
from .execution_history import ExecutionHistoryStore

__all__ = ["Brain", "Ears", "Eyes", "Voice", "Body", "Social", "Autonomy", "Security", "GeneralTaskEngine", "CapabilityRegistry", "UniversalToolConnector", "UniversalToolEngine", "ToolSpec", "ExecutionHistoryStore", "ContinuousOperationEngine", "UnifiedABM", "DEPARTMENTS"]

from .unified_system import UnifiedABM, DEPARTMENTS

from .self_recovery import SelfRecoveryEngine

from .continuous_operation import ContinuousOperationEngine
from .intelligent_decision import IntelligentDecisionEngine
__all__.append("IntelligentDecisionEngine")

from .context_understanding import ContextUnderstandingEngine
__all__.append("ContextUnderstandingEngine")

from .adaptive_intelligence import AdaptiveIntelligenceEngine
__all__.append("AdaptiveIntelligenceEngine")

from .predictive_intelligence import PredictiveIntelligenceEngine
__all__.append("PredictiveIntelligenceEngine")

from .universal_knowledge import UniversalKnowledgeEngine
__all__.append("UniversalKnowledgeEngine")

from .cross_department import CrossDepartmentEngine
__all__.append("CrossDepartmentEngine")

from .universal_interaction import UniversalInteractionEngine
__all__.append("UniversalInteractionEngine")

from .android_execution_bridge import AndroidExecutionBridge
__all__.append("AndroidExecutionBridge")

from .voice_access_controller import VoiceAccessibilityController, VoiceAccessIntent
__all__.extend(["VoiceAccessibilityController", "VoiceAccessIntent"])
