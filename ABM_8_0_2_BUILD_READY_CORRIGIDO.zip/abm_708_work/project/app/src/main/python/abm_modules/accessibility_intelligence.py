"""Perfil adaptativo de acessibilidade; recomenda configuração, não diagnostica utilizadores."""
from pathlib import Path
import json
import sqlite3
import time
from .secure_fields import SecureFieldVault, MARKER

MODALITIES = {"touch", "voice", "head", "eye", "switch", "braille", "aac", "keyboard"}

class AccessibilityIntelligenceEngine:
    VERSION = "6.2.0"
    def __init__(self, db_path, secure_store=None):
        self.vault = SecureFieldVault(secure_store, "abm.accessibility.profile.v1")
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            db.execute("CREATE TABLE IF NOT EXISTS profiles (id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL, updated REAL NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS feedback (id INTEGER PRIMARY KEY AUTOINCREMENT, modality TEXT NOT NULL, useful INTEGER NOT NULL, created REAL NOT NULL)")
        if self.vault.encrypted:
            self._migrate_legacy_rows()

    def _migrate_legacy_rows(self):
        """Migra perfil e modalidade de feedback antes de qualquer leitura."""
        with self._db() as db:
            profile = db.execute("SELECT data FROM profiles WHERE id=1").fetchone()
            if profile and profile["data"] != MARKER:
                self.vault.pack("profile", json.loads(profile["data"]))
                db.execute("UPDATE profiles SET data=? WHERE id=1", (MARKER,))
            rows = db.execute("SELECT id, modality FROM feedback WHERE modality != ?", (MARKER,)).fetchall()
            for row in rows:
                self.vault.pack(f"feedback.{row['id']}", {"modality": row["modality"]})
                db.execute("UPDATE feedback SET modality=? WHERE id=?", (MARKER, row["id"]))

    def _db(self):
        db = sqlite3.connect(self.db_path)
        db.row_factory = sqlite3.Row
        return db

    def set_profile(self, preferred, available=None, consent=False):
        if not consent:
            return {"ok": False, "reason": "consent_required"}
        preferred = list(dict.fromkeys(str(x).lower().strip() for x in preferred))
        available = list(dict.fromkeys(str(x).lower().strip() for x in (available or preferred)))
        invalid = (set(preferred) | set(available)) - MODALITIES
        if invalid:
            raise ValueError("Modalidades desconhecidas: " + ", ".join(sorted(invalid)))
        if not preferred or not set(preferred).issubset(set(available)):
            raise ValueError("Escolhe pelo menos uma modalidade preferida que esteja disponível.")
        data = {"preferred": preferred, "available": available}
        packed = self.vault.pack("profile", data)
        with self._db() as db:
            db.execute("INSERT INTO profiles(id,data,updated) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data, updated=excluded.updated", (packed, time.time()))
        return {"ok": True, "profile": data, "saved": True, "encrypted_at_rest": self.vault.encrypted}

    def recommend(self, task_type="general", confidence=1.0):
        if not 0 <= float(confidence) <= 1:
            raise ValueError("A confiança deve estar entre 0 e 1.")
        with self._db() as db:
            row = db.execute("SELECT data FROM profiles WHERE id=1").fetchone()
            if not row:
                return {"status": "profile_missing", "requires_user_choice": True, "recommendations": []}
            profile = self.vault.unpack("profile", row["data"]) if row["data"] == MARKER else json.loads(row["data"])
            if not isinstance(profile, dict) or "preferred" not in profile:
                return {"status": "protected_profile_unavailable", "requires_user_choice": True, "recommendations": []}
            feedback_rows = db.execute("SELECT id, modality, useful FROM feedback").fetchall()
        counts = {}
        for row in feedback_rows:
            if row["modality"] == MARKER:
                value = self.vault.unpack(f"feedback.{row['id']}", MARKER)
                modality = value.get("modality") if isinstance(value, dict) else None
            else:
                modality = row["modality"]
            if modality in MODALITIES:
                good, bad = counts.get(modality, (0, 0))
                counts[modality] = (good + int(bool(row["useful"])), bad + int(not bool(row["useful"])))
        ranked = []
        for modality in profile["preferred"]:
            good, bad = counts.get(modality, (0, 0))
            score = (good + 1) / (good + bad + 2)
            ranked.append({"modality": modality, "score": round(score, 3), "available": modality in profile["available"]})
        ranked.sort(key=lambda x: (-x["score"], profile["preferred"].index(x["modality"])))
        return {"status": "recommendations_ready", "task_type": str(task_type), "input_confidence": float(confidence), "recommendations": ranked, "automatic_switch": False, "diagnosis_inferred": False}

    def feedback(self, modality, useful, consent=False):
        modality = str(modality).lower().strip()
        if modality not in MODALITIES: raise ValueError("Modalidade desconhecida.")
        if not consent: return {"ok": False, "reason": "consent_required"}
        with self._db() as db:
            exists = db.execute("SELECT data FROM profiles WHERE id=1").fetchone()
            if not exists:
                raise ValueError("Configura primeiro o perfil de acessibilidade.")
            profile = self.vault.unpack("profile", exists["data"]) if exists["data"] == MARKER else json.loads(exists["data"])
            if not isinstance(profile, dict) or modality not in profile.get("preferred", []):
                raise ValueError("A modalidade não pertence ao perfil escolhido.")
            cursor = db.execute("INSERT INTO feedback(modality,useful,created) VALUES(?,?,?)", (MARKER if self.vault.encrypted else modality, int(bool(useful)), time.time()))
            feedback_id = cursor.lastrowid
            if self.vault.encrypted:
                self.vault.pack(f"feedback.{feedback_id}", {"modality": modality})
        return {"ok": True, "recorded": True, "modality": modality, "useful": bool(useful), "encrypted_at_rest": self.vault.encrypted}

    def clear(self, confirmed=False):
        if not confirmed: return {"ok": False, "reason": "confirmation_required"}
        with self._db() as db:
            ids = [row[0] for row in db.execute("SELECT id FROM feedback").fetchall()]
            db.execute("DELETE FROM profiles")
            db.execute("DELETE FROM feedback")
        self.vault.remove("profile")
        for feedback_id in ids:
            self.vault.remove(f"feedback.{feedback_id}")
        return {"ok": True, "cleared": True}

    def status(self):
        with self._db() as db:
            row = db.execute("SELECT data,updated FROM profiles WHERE id=1").fetchone()
            n = db.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
        profile = None
        if row:
            profile = self.vault.unpack("profile", row["data"]) if row["data"] == MARKER else json.loads(row["data"])
        return {"version": self.VERSION, "profile_configured": bool(row), "profile": profile, "feedback_records": n, "automatic_control": False, "diagnosis": False, "encrypted_at_rest": self.vault.encrypted, "feedback_modalities_encrypted": self.vault.encrypted}
