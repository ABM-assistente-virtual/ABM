"""ABM 5.5.0 — inteligência adaptativa baseada em feedback explícito.

Combina análise contextual, exemplos de correção e preferências consentidas.
Não treina redes neurais, não inventa dados e não executa ferramentas.
"""
from __future__ import annotations
from datetime import datetime, timezone

class AdaptiveIntelligenceEngine:
    def __init__(self, context_engine, learning_engine):
        self.context = context_engine
        self.learning = learning_engine

    def analyze(self, request, *, profile_id="default", prior_context=None, limit=5):
        understood = self.context.understand(request, profile_id=profile_id, prior_context=prior_context)
        examples = self.learning.suggestions(request, limit=limit)
        prefs = self.learning.get_preferences()
        # Exemplos são apresentados como referências, nunca aplicados silenciosamente.
        safe_examples = [{"id": x["id"], "topic": x["topic"],
                          "original": x["input_text"], "user_correction": x["correction"],
                          "match_score": x["match_score"]} for x in examples]
        return {"engine":"ABM Adaptive Intelligence 5.5.0",
                "context_analysis": understood,
                "relevant_user_corrections": safe_examples,
                "preferences": prefs,
                "personalization_available": bool(safe_examples or prefs),
                "corrections_auto_applied": False,
                "neural_training_performed": False,
                "execution_performed": False,
                "confirmation_required_before_action": True,
                "timestamp":datetime.now(timezone.utc).isoformat()}

    def status(self):
        return {"version":"5.5.0", "context_engine_connected":True,
                "explicit_feedback_store_connected":True,
                "uses_local_consent_based_examples":True,
                "automatic_neural_training":False, "auto_execute":False,
                "learning_status":self.learning.status()}
