"""ABM Adaptive Learning 4.4: aprendizagem local por feedback autorizado.

Isto não treina pesos de uma rede neural. Guarda correções/preferências explícitas,
conta padrões consentidos e disponibiliza contexto recuperável ao orquestrador.
"""
from __future__ import annotations
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .secure_fields import SecureFieldVault, MARKER


class AdaptiveLearning:
    def __init__(self, database_path, secure_store=None):
        self.vault = SecureFieldVault(secure_store, "abm.learning.v1")
        self.path = Path(str(database_path))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
        if self.vault.encrypted:
            self._migrate_legacy_rows()

    def _db(self):
        db = sqlite3.connect(str(self.path), timeout=10)
        db.row_factory = sqlite3.Row
        return db

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()

    def _init_db(self):
        with self._db() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS feedback (
                id TEXT PRIMARY KEY, topic TEXT NOT NULL, input_text TEXT NOT NULL,
                correction TEXT NOT NULL, created_at TEXT NOT NULL)""")
            db.execute("""CREATE TABLE IF NOT EXISTS preferences (
                key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL)""")
            db.execute("""CREATE TABLE IF NOT EXISTS patterns (
                key TEXT PRIMARY KEY, count INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL)""")

    def _migrate_legacy_rows(self):
        with self._db() as db:
            rows = db.execute("SELECT id,topic,input_text,correction FROM feedback WHERE correction != ?", (MARKER,)).fetchall()
            for row in rows:
                payload = {"topic": row["topic"], "input_text": row["input_text"], "correction": row["correction"]}
                self.vault.pack("feedback." + row["id"], payload)
                db.execute("UPDATE feedback SET topic=?,input_text=?,correction=? WHERE id=?", (MARKER, MARKER, MARKER, row["id"]))
            prefs = db.execute("SELECT key,value FROM preferences WHERE value != ?", (MARKER,)).fetchall()
            for row in prefs:
                self.vault.pack("preference." + row["key"], {"value": row["value"]})
                db.execute("UPDATE preferences SET value=? WHERE key=?", (MARKER, row["key"]))

    def _decode_feedback(self, row):
        item = dict(row)
        if item.get("correction") == MARKER:
            payload = self.vault.unpack("feedback." + item["id"], MARKER)
            for field in ("topic", "input_text", "correction"):
                item[field] = payload.get(field, "[conteúdo protegido indisponível]")
        return item

    def learn_feedback(self, topic, input_text, correction, *, consent=False):
        if not consent:
            return {"learned": False, "reason": "consent_required"}
        topic, source, corrected = (str(topic or "general").strip()[:80],
                                    str(input_text or "").strip(), str(correction or "").strip())
        if not source or not corrected:
            raise ValueError("Indica o pedido original e a correção desejada.")
        if len(source) > 2000 or len(corrected) > 2000:
            raise ValueError("Cada texto pode ter no máximo 2000 caracteres.")
        item_id, now = uuid.uuid4().hex, self._now()
        payload = {"topic": topic or "general", "input_text": source, "correction": corrected}
        self.vault.pack("feedback." + item_id, payload)
        stored = (MARKER, MARKER, MARKER) if self.vault.encrypted else (topic or "general", source, corrected)
        with self._db() as db:
            db.execute("INSERT INTO feedback VALUES (?, ?, ?, ?, ?)",
                       (item_id, *stored, now))
        return {"learned": True, "id": item_id, "topic": topic or "general", "created_at": now,
                "note": "Correção guardada como exemplo local; não alterou pesos de um modelo neural."}

    def set_preference(self, key, value, *, consent=False):
        if not consent:
            return {"saved": False, "reason": "consent_required"}
        k, v = str(key or "").strip().lower()[:80], str(value or "").strip()
        if not k or not v:
            raise ValueError("A preferência precisa de nome e valor.")
        if len(v) > 500:
            raise ValueError("A preferência pode ter no máximo 500 caracteres.")
        now = self._now()
        self.vault.pack("preference." + k, {"value": v})
        stored_value = MARKER if self.vault.encrypted else v
        with self._db() as db:
            db.execute("INSERT INTO preferences VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                       (k, stored_value, now))
        return {"saved": True, "key": k, "value": v, "updated_at": now,
                "encrypted_at_rest": self.vault.encrypted}

    def get_preferences(self):
        with self._db() as db:
            rows = db.execute("SELECT key, value, updated_at FROM preferences ORDER BY key").fetchall()
        result = []
        for row in rows:
            item = dict(row)
            if item["value"] == MARKER:
                item["value"] = self.vault.unpack("preference." + item["key"], MARKER).get("value", "[conteúdo protegido indisponível]")
            result.append(item)
        return result

    def record_pattern(self, key, *, consent=False):
        if not consent:
            return {"recorded": False, "reason": "consent_required"}
        k = str(key or "").strip().lower()[:100]
        if not k:
            raise ValueError("O padrão não pode estar vazio.")
        now = self._now()
        with self._db() as db:
            db.execute("INSERT INTO patterns VALUES (?, 1, ?) ON CONFLICT(key) DO UPDATE SET count=count+1, updated_at=excluded.updated_at",
                       (k, now))
            row = db.execute("SELECT count FROM patterns WHERE key=?", (k,)).fetchone()
        return {"recorded": True, "key": k, "count": row["count"]}

    def suggestions(self, text, *, limit=5):
        terms = [t.casefold() for t in str(text or "").split() if len(t) > 2]
        limit = max(1, min(10, int(limit)))
        if not terms:
            return []
        with self._db() as db:
            rows = db.execute("SELECT id, topic, input_text, correction, created_at FROM feedback ORDER BY created_at DESC LIMIT 300").fetchall()
        ranked = []
        for row in rows:
            item = self._decode_feedback(row)
            hay = (item["topic"] + " " + item["input_text"]).casefold()
            score = sum(1 for term in terms if term in hay)
            if score:
                ranked.append((score, item))
        ranked.sort(key=lambda x: (x[0], x[1]["created_at"]), reverse=True)
        return [{**item, "match_score": score} for score, item in ranked[:limit]]

    def forget_feedback(self, item_id, *, confirmed=False):
        if not confirmed:
            return {"deleted": False, "reason": "confirmation_required"}
        with self._db() as db:
            cur = db.execute("DELETE FROM feedback WHERE id=?", (str(item_id),))
        if cur.rowcount:
            self.vault.remove("feedback." + str(item_id))
        return {"deleted": cur.rowcount > 0, "id": str(item_id)}

    def clear(self, *, confirmed=False):
        if not confirmed:
            return {"cleared": False, "reason": "confirmation_required"}
        with self._db() as db:
            feedback_ids = [r[0] for r in db.execute("SELECT id FROM feedback").fetchall()]
            preference_keys = [r[0] for r in db.execute("SELECT key FROM preferences").fetchall()]
            a = db.execute("DELETE FROM feedback").rowcount
            b = db.execute("DELETE FROM preferences").rowcount
            c = db.execute("DELETE FROM patterns").rowcount
        for item_id in feedback_ids:
            self.vault.remove("feedback." + item_id)
        for key in preference_keys:
            self.vault.remove("preference." + key)
        return {"cleared": True, "feedback_deleted": a, "preferences_deleted": b, "patterns_deleted": c}

    def export_json(self):
        with self._db() as db:
            feedback_rows = db.execute("SELECT * FROM feedback ORDER BY created_at").fetchall()
            patterns = [dict(r) for r in db.execute("SELECT * FROM patterns ORDER BY key")]
        feedback = [self._decode_feedback(r) for r in feedback_rows]
        return json.dumps({"format": "abm-adaptive-learning-v1", "preferences": self.get_preferences(),
                           "feedback": feedback, "patterns": patterns}, ensure_ascii=False, indent=2)

    def status(self):
        with self._db() as db:
            f = db.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
            p = db.execute("SELECT COUNT(*) FROM preferences").fetchone()[0]
            n = db.execute("SELECT COUNT(*) FROM patterns").fetchone()[0]
        return {"ready": True, "storage": "sqlite_metadata_android_keystore_aes_256_gcm" if self.vault.encrypted else "local_sqlite_unencrypted",
                "encrypted_at_rest": self.vault.encrypted, "feedback_examples": f,
                "preferences": p, "pattern_counters": n, "explicit_consent_required": True,
                "automatic_training": False, "neural_weights_changed": False}
