"""ABM BRAIN ADVANCED 4.6.0.

Planeamento determinístico e auditável: decompõe pedidos conhecidos em etapas,
expõe dependências, riscos e critérios de verificação. Não executa ferramentas.
A execução continua a pertencer aos conectores Android autorizados.
"""
from __future__ import annotations
import re
import uuid
from datetime import datetime, timezone

class AdvancedBrainPlanner:
    DEPARTMENT_ORDER = {
        "ears": 10, "eyes": 20, "memory": 30, "brain": 40,
        "security": 50, "body": 60, "accessibility": 60,
        "voice": 70, "interface": 80,
    }
    SENSITIVE = {"send_message", "make_call", "delete", "share", "purchase", "record"}

    def __init__(self, memory=None):
        self.memory = memory
        self._plans = {}

    @staticmethod
    def _clean(request):
        return re.sub(r"\s+", " ", str(request or "")).strip()

    def _steps_for(self, text):
        low = text.casefold()
        steps = []
        def add(dept, action, description, verify, risk="low", confirmation=False):
            steps.append({"id": len(steps)+1, "department": dept, "action": action,
                          "description": description, "depends_on": [len(steps)] if steps else [],
                          "risk": risk, "confirmation_required": confirmation,
                          "verification": verify, "status": "planned"})
        # Input handling is only included when the wording suggests it.
        if any(x in low for x in ("por voz", "digo", "comando de voz", "ouve", "escuta")):
            add("ears", "transcribe_or_normalize", "Obter ou normalizar a transcrição fornecida pelo Android.",
                "Existe texto transcrito ou uma mensagem clara de que falta permissão/microfone.")
        if any(x in low for x in ("imagem", "fotografia", "foto", "câmara", "camera")):
            add("eyes", "analyze_image_or_open_camera", "Preparar análise de imagem ou abertura da câmara através do Android.",
                "A imagem foi recebida ou o Android confirmou a abertura da câmara.", "medium", True)
        if any(x in low for x in ("lembra", "memória", "memoria", "recorda", "preferência", "preferencia")):
            add("memory", "retrieve_context", "Pesquisar apenas memórias do perfil autorizado.",
                "A pesquisa devolveu correspondências ou uma lista vazia; nenhuma memória nova é criada sem consentimento.")
        add("brain", "interpret_and_plan", "Interpretar o objetivo, os dados disponíveis e as dependências.",
            "O objetivo e os passos estão explícitos e não há pressupostos apresentados como factos.")
        # Common Android intents are prepared, not invoked here.
        if any(x in low for x in ("abre", "abrir", "inicia", "iniciar")):
            add("security", "check_android_permission", "Verificar permissões e limites Android necessários.",
                "A permissão foi concedida pelo sistema ou a operação foi bloqueada.")
            add("body", "request_open_app", "Solicitar ao conector Android a abertura da aplicação indicada.",
                "O Android confirma a abertura ou devolve um erro identificável.", "medium", True)
        if any(x in low for x in ("liga para", "telefonar", "chamada", "faz uma chamada")):
            add("security", "authorize_call", "Exigir confirmação explícita antes de iniciar qualquer chamada.",
                "O utilizador confirmou e o Android abriu o marcador; o ABM não inicia chamada silenciosamente.", "high", True)
            add("body", "open_dialer", "Preparar abertura do marcador com o número fornecido.",
                "O marcador Android abre com o número correto; não marcar automaticamente.", "high", True)
        if any(x in low for x in ("cursor", "varrimento", "interruptor", "acessibilidade")):
            add("accessibility", "prepare_accessibility_action", "Preparar comando para o AccessibilityService autorizado.",
                "O serviço Android está ativo e confirma o comando, ou informa que não está disponível.", "medium", True)
        if any(x in low for x in ("responde em voz", "lê em voz", "fala", "diz em voz")):
            add("voice", "prepare_tts", "Preparar texto para o mecanismo TextToSpeech do Android.",
                "O Android confirma que a fala terminou ou devolve indisponibilidade.")
        add("brain", "verify_and_report", "Comparar os resultados recebidos com os critérios de sucesso e relatar apenas o que foi confirmado.",
            "Cada etapa concluída possui evidência; as restantes ficam pendentes ou bloqueadas.")
        return steps

    def create_plan(self, request, *, profile_id="default", include_memory=False):
        text = self._clean(request)
        if not text:
            return {"status": "needs_input", "message": "Diz o que pretendes fazer."}
        context = []
        if include_memory and self.memory is not None:
            # Memory search is read-only and scoped to a profile.
            context = self.memory.search(text, profile_id=profile_id, limit=3)
        steps = self._steps_for(text)
        plan_id = uuid.uuid4().hex[:12]
        plan = {
            "plan_id": plan_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "request": text,
            "status": "planned",
            "steps": steps,
            "memory_context": [{"id": x.get("id"), "topic": x.get("topic"),
                                "department": x.get("department"), "match_score": x.get("match_score")}
                               for x in context],
            "execution_performed": False,
            "safety_note": "Plano não executado. Ações Android exigem conector real, permissões e confirmação quando indicada."
        }
        self._plans[plan_id] = plan
        return plan

    def record_step_result(self, plan_id, step_id, *, success, evidence, confirmed=False):
        plan = self._plans.get(str(plan_id))
        if plan is None:
            return {"status": "not_found"}
        step = next((x for x in plan["steps"] if x["id"] == int(step_id)), None)
        if step is None:
            return {"status": "step_not_found"}
        if step["confirmation_required"] and not confirmed:
            return {"status": "confirmation_required", "message": "Esta etapa exige confirmação explícita."}
        evidence = self._clean(evidence)
        if success and not evidence:
            return {"status": "evidence_required", "message": "Uma etapa só pode ser concluída com evidência."}
        step["status"] = "completed" if success else "blocked"
        step["evidence"] = evidence[:500]
        step["confirmed"] = bool(confirmed)
        statuses = [x["status"] for x in plan["steps"]]
        if all(x == "completed" for x in statuses):
            plan["status"] = "verified"
        elif any(x == "blocked" for x in statuses):
            plan["status"] = "partially_blocked"
        else:
            plan["status"] = "in_progress"
        return {"status": "recorded", "plan_status": plan["status"], "step": dict(step)}

    def get_plan(self, plan_id):
        plan = self._plans.get(str(plan_id))
        return dict(plan) if plan else None

    def status(self):
        return {"engine": "ABM BRAIN ADVANCED 4.6.0", "plans_created": len(self._plans),
                "planning": True, "evidence_based_verification": True,
                "autonomous_android_execution": False}
