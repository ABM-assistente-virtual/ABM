"""Política segura para pedidos encaminhados à ponte nativa Android."""
from dataclasses import dataclass
from typing import Dict, Any

ALLOWED_ACTIONS = {"back", "home", "notifications", "quick_settings", "scan_start", "scan_next", "scan_select", "scan_stop", "cursor_on", "cursor_off"}

@dataclass
class BridgeResult:
    accepted: bool
    action: str
    reason: str

class AndroidExecutionBridge:
    def __init__(self):
        self.enabled = False
        self.last_action = None

    def update_service_state(self, enabled: bool):
        self.enabled = bool(enabled)
        return {"accessibility_enabled": self.enabled, "requires_user_activation": not self.enabled}

    def validate(self, action: str, user_confirmed: bool = False) -> BridgeResult:
        action = str(action or "").strip().lower()
        if action not in ALLOWED_ACTIONS:
            return BridgeResult(False, action, "Ação fora da lista permitida.")
        if not self.enabled:
            return BridgeResult(False, action, "Serviço de acessibilidade não está ativado pelo utilizador.")
        if action in {"home", "back", "notifications", "quick_settings", "scan_select"} and not user_confirmed:
            return BridgeResult(False, action, "Esta ação exige confirmação explícita.")
        self.last_action = action
        return BridgeResult(True, action, "Pedido autorizado para encaminhamento Android; o resultado ainda precisa de verificação.")

    def status(self) -> Dict[str, Any]:
        return {"service_enabled": self.enabled, "last_action": self.last_action, "allowed_actions": sorted(ALLOWED_ACTIONS), "automatic_execution": False}
