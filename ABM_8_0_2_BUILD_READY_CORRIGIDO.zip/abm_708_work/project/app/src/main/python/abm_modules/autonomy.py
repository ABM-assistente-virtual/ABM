"""ABM AUTONOMY: planos, estados e fila de aprovação humana."""
import time, uuid

class Autonomy:
    def __init__(self):
        self.goals = {}
        self.pending = {}

    def add_goal(self, description, steps=None):
        desc = str(description).strip()
        if not desc:
            raise ValueError("O objetivo não pode estar vazio.")
        gid = uuid.uuid4().hex[:12]
        self.goals[gid] = {"id": gid, "description": desc,
                           "steps": [{"text": str(s), "status": "pending"} for s in (steps or [])],
                           "status": "planned", "created": time.time()}
        return self.goals[gid]

    def propose_action(self, action, args=None, reason=""):
        aid = uuid.uuid4().hex[:12]
        item = {"id": aid, "action": str(action), "args": dict(args or {}),
                "reason": str(reason), "status": "awaiting_confirmation"}
        self.pending[aid] = item
        return item

    def approve(self, action_id):
        item = self.pending.get(str(action_id))
        if not item:
            return {"ok": False, "reason": "Ação pendente não encontrada."}
        item["status"] = "approved_by_user"
        return {"ok": True, "action": item}

    def list_goals(self):
        return list(self.goals.values())
