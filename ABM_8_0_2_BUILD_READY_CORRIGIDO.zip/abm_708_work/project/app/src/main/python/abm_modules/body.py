"""ABM BODY: tradutor seguro de intenções para ações Android permitidas.

A execução efetiva é feita pela Activity Android, não por acesso arbitrário.
"""
class Body:
    ACTIONS = {"open_youtube", "open_whatsapp", "open_settings", "open_file_picker",
               "open_camera_app", "choose_audio", "choose_video", "search_web",
               "pause_media", "request_device_auth", "dial_number"}

    def plan(self, utterance: str) -> dict:
        text = str(utterance).strip()
        low = text.casefold()
        action, args = None, {}
        if "youtube" in low and any(x in low for x in ("abre", "abrir")):
            action = "open_youtube"
        elif "whatsapp" in low and any(x in low for x in ("abre", "abrir")):
            action = "open_whatsapp"
        elif any(x in low for x in ("abre os meus ficheiros", "gestor de ficheiros", "abre o meu código", "abre o meu codigo")):
            action = "open_file_picker"
        elif any(x in low for x in ("abre a câmara", "abre camera", "abre a camera")):
            action = "open_camera_app"
        elif any(x in low for x in ("desbloqueia", "autentica-me")):
            action = "request_device_auth"
        elif low.startswith(("procura música ", "procura musica ", "procura vídeo ", "procura video ", "toca música ", "toca musica ")):
            action = "search_web"; args["query"] = text.split(" ", 2)[-1]
        elif "pausa" in low or "pára a música" in low or "para a música" in low:
            action = "pause_media"
        elif low.startswith("liga para ") or low.startswith("telefonar "):
            action = "dial_number"; args["number"] = text.split(" ", 2)[-1]
        if action:
            return {"action": action, "args": args, "requires_android_execution": True}
        return {"action": None, "args": {}, "requires_android_execution": False}
