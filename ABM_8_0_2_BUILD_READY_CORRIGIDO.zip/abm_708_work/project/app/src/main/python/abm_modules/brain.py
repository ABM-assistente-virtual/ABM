"""ABM BRAIN: fachada para o núcleo ABM 5.2 existente."""
class Brain:
    def __init__(self, agent):
        self.agent = agent

    def think(self, text: str) -> dict:
        result = self.agent.chat(str(text))
        return {"response": str(result.get("response", "")),
                "turn": result.get("turn"), "memory_hits": result.get("memory_hits", 0),
                "simulation_tick": result.get("simulation_tick"),
                "engine": "ABM 5.2 experimental"}

    def status(self) -> dict:
        return self.agent.status()
