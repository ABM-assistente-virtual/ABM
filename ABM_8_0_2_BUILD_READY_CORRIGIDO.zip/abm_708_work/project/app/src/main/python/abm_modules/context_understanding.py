"""ABM 5.4.0 — interpretação contextual determinística e auditável.
Não é um modelo de linguagem: identifica sinais, lacunas e referências explícitas.
Nunca executa ferramentas nem inventa valores em falta.
"""
from __future__ import annotations
import re
from datetime import datetime, timezone

class ContextUnderstandingEngine:
    INTENTS = {
        "open_app": ("abrir", "abre", "iniciar", "entrar na aplicação"),
        "web_search": ("pesquisar", "pesquisa", "procura", "buscar", "pesquisa na internet"),
        "call": ("ligar", "telefonar", "fazer chamada", "chamar"),
        "send_message": ("enviar mensagem", "envia mensagem", "manda mensagem", "mandar mensagem"),
        "take_photo": ("tirar foto", "fotografar", "capturar imagem"),
        "create_note": ("criar nota", "guardar nota", "anotar"),
        "navigate": ("ir para", "rota para", "como chegar", "navegar para"),
        "read_information": ("explica", "explicar", "o que é", "como funciona", "ler")
    }
    APP_NAMES = ("whatsapp", "youtube", "chrome", "telefone", "câmara", "camera", "definições", "galeria")
    REF_WORDS = ("isso", "isto", "essa", "esse", "aquela", "aquele", "o mesmo", "ela", "ele", "lá")

    def __init__(self, memory=None):
        self.memory = memory

    @staticmethod
    def _clean(value):
        return re.sub(r"\s+", " ", str(value or "")).strip()

    def understand(self, request, *, profile_id="default", prior_context=None):
        text=self._clean(request)
        if not text:
            return {"status":"needs_clarification","reason":"Pedido vazio.","execution_performed":False,"intent":None}
        q=text.casefold(); matches=[]
        for intent, phrases in self.INTENTS.items():
            hits=[p for p in phrases if p in q]
            if hits: matches.append((intent,hits))
        intent=matches[0][0] if len(matches)==1 else None
        ambiguous=len(matches)>1
        entities=[]
        for app in self.APP_NAMES:
            if re.search(r"(?<!\w)"+re.escape(app)+r"(?!\w)",q): entities.append({"type":"app","value":app})
        quoted=re.findall(r"[\"“](.+?)[\"”]",text)
        for item in quoted[:5]: entities.append({"type":"quoted_text","value":item})
        slots={"application": next((e["value"] for e in entities if e["type"]=="app"),None),
               "quoted_text": quoted[0] if quoted else None}
        if intent=="open_app" and not slots["application"]:
            slots["application"]=None
        missing=[]
        if intent=="open_app" and not slots["application"]: missing.append("nome da aplicação")
        if intent=="send_message" and not slots["quoted_text"]: missing.append("texto da mensagem")
        if intent=="call" and not re.search(r"\b(?:para|ao|a)\s+[\w+ ]+",q): missing.append("destinatário")
        has_reference=any(re.search(r"(?<!\w)"+re.escape(w)+r"(?!\w)",q) for w in self.REF_WORDS)
        context_used=False; memory_hits=[]
        if has_reference and prior_context:
            context_used=True
            if intent=="open_app" and isinstance(prior_context,dict):
                app=prior_context.get("last_app") or prior_context.get("application")
                if app and not slots["application"]:
                    slots["application"]=str(app).strip().casefold()
                    entities.append({"type":"app","value":slots["application"],"source":"prior_context"})
        elif has_reference and self.memory:
            try:
                memory_hits=self.memory.search(text,profile_id=profile_id,limit=3)
                context_used=bool(memory_hits)
            except Exception: memory_hits=[]
        if intent=="open_app" and slots["application"] and "nome da aplicação" in missing:
            missing.remove("nome da aplicação")
        if ambiguous:
            status="needs_clarification"; reason="O pedido contém sinais de mais de uma intenção; escolha o objetivo."
        elif intent is None:
            status="needs_clarification"; reason="Não foi possível identificar uma intenção única com segurança."
        elif has_reference and not context_used:
            status="needs_context"; reason="O pedido usa uma referência sem antecedente disponível."
        elif missing:
            status="needs_information"; reason="Faltam dados obrigatórios: "+", ".join(missing)+"."
        else:
            status="understood"; reason="Intenção e dados identificáveis; ainda é necessária preparação separada da ferramenta."
        result={"engine":"ABM Context Understanding Engine 5.4.0","status":status,
          "request":text,"intent":intent,"intent_candidates":[{"intent":i,"matched_phrases":h} for i,h in matches],
          "entities":entities,"slots":slots,"missing_information":missing,"contains_reference":has_reference,
          "context_used":context_used,"memory_matches":[{"topic":m.get("topic"),"department":m.get("department")} for m in memory_hits],
          "reason":reason,"execution_performed":False,"tool_prepared":False,
          "confirmation_required_before_action":True,"timestamp":datetime.now(timezone.utc).isoformat()}
        return result

    def status(self):
        return {"version":"5.4.0","mode":"deterministic_context_and_slot_analysis",
                "executes_tools":False,"infers_missing_values":False,"memory_optional":self.memory is not None}
