"""ABM Contextual Memory 4.5.0.

Memória local com isolamento por perfil, âmbito/departamento, expiração opcional,
registo de auditoria e bloqueio básico de segredos óbvios. NÃO cifra a base de dados.
A aplicação deve manter o ficheiro em armazenamento privado Android.
"""
from __future__ import annotations
import re
import sqlite3
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from .secure_fields import SecureFieldVault, MARKER

_SECRET_PATTERNS = [
    re.compile(r"(?i)\b(pin|senha|password|palavra[- ]?passe)\s*[:=]\s*\S+"),
    re.compile(r"\b(?:\d[ -]*?){13,19}\b"),
]

class ContextualMemory:
    def __init__(self, database_path, secure_store=None):
        self.vault = SecureFieldVault(secure_store, "abm.contextual.v1")
        self.path = Path(str(database_path))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
        if self.vault.encrypted:
            self._migrate_legacy_rows()
        try:
            self.path.chmod(0o600)
        except OSError:
            pass

    def _db(self):
        db = sqlite3.connect(str(self.path), timeout=10)
        db.row_factory = sqlite3.Row
        return db

    @staticmethod
    def _now():
        return datetime.now(timezone.utc)

    def _init_db(self):
        with self._db() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS contextual_memories (
                id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, department TEXT NOT NULL,
                topic TEXT NOT NULL, content TEXT NOT NULL, sensitivity TEXT NOT NULL,
                created_at TEXT NOT NULL, expires_at TEXT)""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_context_profile ON contextual_memories(profile_id, department)")
            db.execute("""CREATE TABLE IF NOT EXISTS memory_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id TEXT NOT NULL,
                event TEXT NOT NULL, memory_id TEXT, created_at TEXT NOT NULL)""")

    def _migrate_legacy_rows(self):
        with self._db() as db:
            rows = db.execute("SELECT id,topic,content FROM contextual_memories WHERE content != ?", (MARKER,)).fetchall()
            for row in rows:
                payload = {"topic": row["topic"], "content": row["content"]}
                self.vault.pack(row["id"], payload)
                db.execute("UPDATE contextual_memories SET topic=?, content=? WHERE id=?", (MARKER, MARKER, row["id"]))

    def _decode(self, row):
        item = dict(row)
        if item.get("content") == MARKER:
            payload = self.vault.unpack(item["id"], MARKER)
            item["topic"] = payload.get("topic", "")
            item["content"] = payload.get("content", "[conteúdo protegido indisponível]")
        return item

    @staticmethod
    def _secret_detected(text):
        return any(p.search(text) for p in _SECRET_PATTERNS)

    def _audit(self, db, profile_id, event, memory_id=None):
        db.execute("INSERT INTO memory_audit(profile_id,event,memory_id,created_at) VALUES(?,?,?,?)",
                   (profile_id, event, memory_id, self._now().isoformat()))

    def remember(self, topic, content, *, consent=False, profile_id="default",
                 department="brain", sensitivity="personal", ttl_days=0):
        if not consent:
            return {"stored": False, "reason": "consent_required"}
        profile = str(profile_id or "default").strip()[:80]
        dept = str(department or "brain").strip().lower()[:40]
        subject, body = str(topic or "").strip()[:120], str(content or "").strip()
        if not profile or not subject or not body:
            raise ValueError("Perfil, tema e conteúdo são obrigatórios.")
        if len(body) > 4000:
            raise ValueError("O conteúdo não pode exceder 4000 caracteres.")
        if self._secret_detected(subject + " " + body):
            return {"stored": False, "reason": "possible_secret_rejected",
                    "message": "Não guardamos PINs, senhas ou números longos semelhantes a cartões."}
        if sensitivity not in {"personal", "general"}:
            raise ValueError("sensibilidade deve ser personal ou general.")
        ttl = max(0, min(3650, int(ttl_days)))
        now = self._now()
        expiry = (now + timedelta(days=ttl)).isoformat() if ttl else None
        mid = uuid.uuid4().hex
        with self._db() as db:
            payload = {"topic": subject, "content": body}
            packed = self.vault.pack(mid, payload)
            stored_topic = MARKER if self.vault.encrypted else subject
            stored_content = MARKER if self.vault.encrypted else body
            db.execute("INSERT INTO contextual_memories VALUES(?,?,?,?,?,?,?,?)",
                       (mid, profile, dept, stored_topic, stored_content, sensitivity, now.isoformat(), expiry))
            self._audit(db, profile, "remember", mid)
        return {"stored": True, "id": mid, "profile_id": profile,
                "department": dept, "expires_at": expiry, "encrypted_at_rest": self.vault.encrypted}

    def search(self, query, *, profile_id="default", department=None, limit=5):
        terms = [x.casefold() for x in str(query or "").split() if len(x) > 1]
        if not terms:
            return []
        profile = str(profile_id or "default").strip()[:80]
        lim = max(1, min(20, int(limit)))
        now = self._now().isoformat()
        with self._db() as db:
            if department:
                rows = db.execute("SELECT * FROM contextual_memories WHERE profile_id=? AND department=? AND (expires_at IS NULL OR expires_at>?) ORDER BY created_at DESC LIMIT 500",
                                  (profile, str(department).lower(), now)).fetchall()
            else:
                rows = db.execute("SELECT * FROM contextual_memories WHERE profile_id=? AND (expires_at IS NULL OR expires_at>?) ORDER BY created_at DESC LIMIT 500",
                                  (profile, now)).fetchall()
            self._audit(db, profile, "search")
        ranked = []
        for row in rows:
            item = self._decode(row)
            hay = (item["topic"] + " " + item["content"] + " " + item["department"]).casefold()
            score = sum(1 for term in terms if term in hay)
            if score:
                ranked.append((score, item))
        ranked.sort(key=lambda x: (x[0], x[1]["created_at"]), reverse=True)
        return [{**item, "match_score": score} for score, item in ranked[:lim]]

    def delete(self, memory_id, *, profile_id="default", confirmed=False):
        if not confirmed:
            return {"deleted": False, "reason": "confirmation_required"}
        profile = str(profile_id or "default").strip()[:80]
        with self._db() as db:
            cur = db.execute("DELETE FROM contextual_memories WHERE id=? AND profile_id=?",
                             (str(memory_id), profile))
            if cur.rowcount:
                self._audit(db, profile, "delete", str(memory_id))
        if cur.rowcount:
            self.vault.remove(str(memory_id))
        return {"deleted": cur.rowcount > 0}

    def clear_profile(self, *, profile_id="default", confirmed=False):
        if not confirmed:
            return {"cleared": False, "reason": "confirmation_required"}
        profile = str(profile_id or "default").strip()[:80]
        with self._db() as db:
            ids = [r[0] for r in db.execute("SELECT id FROM contextual_memories WHERE profile_id=?", (profile,)).fetchall()]
            count = db.execute("DELETE FROM contextual_memories WHERE profile_id=?", (profile,)).rowcount
            self._audit(db, profile, "clear_profile")
        for mid in ids:
            self.vault.remove(mid)
        return {"cleared": True, "deleted_count": count}

    def purge_expired(self):
        now = self._now().isoformat()
        with self._db() as db:
            ids = [r[0] for r in db.execute("SELECT id FROM contextual_memories WHERE expires_at IS NOT NULL AND expires_at<=?", (now,)).fetchall()]
            count = db.execute("DELETE FROM contextual_memories WHERE expires_at IS NOT NULL AND expires_at<=?", (now,)).rowcount
            self._audit(db, "system", "purge_expired")
        for mid in ids:
            self.vault.remove(mid)
        return {"purged": count}

    def audit(self, *, profile_id="default", limit=50):
        lim = max(1, min(200, int(limit)))
        with self._db() as db:
            rows = db.execute("SELECT event,memory_id,created_at FROM memory_audit WHERE profile_id=? ORDER BY id DESC LIMIT ?",
                              (str(profile_id or "default")[:80], lim)).fetchall()
        return [dict(r) for r in rows]

    def status(self):
        with self._db() as db:
            count = db.execute("SELECT COUNT(*) FROM contextual_memories").fetchone()[0]
            profiles = db.execute("SELECT COUNT(DISTINCT profile_id) FROM contextual_memories").fetchone()[0]
        return {"ready": True, "records": count, "profiles": profiles,
                "profile_isolation": True, "optional_expiration": True,
                "audit_log": True, "obvious_secret_filter": True,
                "encryption": self.vault.encrypted,
                "storage": "sqlite_metadata_android_keystore_aes_256_gcm" if self.vault.encrypted else "local_sqlite_plaintext"}
