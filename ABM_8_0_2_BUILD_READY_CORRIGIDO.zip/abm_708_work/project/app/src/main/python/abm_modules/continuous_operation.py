"""ABM 5.2.0 — ledger persistente de fluxos; não executa ações externas."""
from __future__ import annotations
import sqlite3, json, uuid
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime, timezone
from .secure_fields import SecureFieldVault, MARKER

class ContinuousOperationEngine:
    STATES={"created","planned","running","waiting_user","blocked","paused","completed","failed","cancelled"}
    def __init__(self, db_path, recovery_engine=None, secure_store=None):
        self.path=Path(db_path); self.path.parent.mkdir(parents=True,exist_ok=True); self.recovery=recovery_engine
        self.vault=SecureFieldVault(secure_store, "abm.workflow.v1")
        with self._db() as db:
            db.execute("CREATE TABLE IF NOT EXISTS workflows(id TEXT PRIMARY KEY,title TEXT NOT NULL,state TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,metadata TEXT NOT NULL DEFAULT '{}')")
            db.execute("CREATE TABLE IF NOT EXISTS workflow_steps(id TEXT PRIMARY KEY,workflow_id TEXT NOT NULL,position INTEGER NOT NULL,title TEXT NOT NULL,department TEXT NOT NULL,tool TEXT NOT NULL,dependencies TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,result_summary TEXT NOT NULL DEFAULT '',retry_class TEXT NOT NULL DEFAULT 'manual_review',execution_id TEXT,FOREIGN KEY(workflow_id) REFERENCES workflows(id),UNIQUE(workflow_id,position))")
        if self.vault.encrypted: self._migrate_legacy_rows()
        try: self.path.chmod(0o600)
        except OSError: pass

    def _migrate_legacy_rows(self):
        with self._db() as db:
            for row in db.execute("SELECT id,metadata FROM workflows WHERE metadata != ?", (MARKER,)).fetchall():
                self.vault.pack("workflow."+row["id"], {"metadata": row["metadata"]})
                db.execute("UPDATE workflows SET metadata=? WHERE id=?", (MARKER,row["id"]))
            for row in db.execute("SELECT id,result_summary FROM workflow_steps WHERE result_summary != ? AND result_summary != ''", (MARKER,)).fetchall():
                self.vault.pack("step."+row["id"], {"result_summary": row["result_summary"]})
                db.execute("UPDATE workflow_steps SET result_summary=? WHERE id=?", (MARKER,row["id"]))
    @contextmanager
    def _db(self):
        db=sqlite3.connect(str(self.path),timeout=10); db.row_factory=sqlite3.Row; db.execute('PRAGMA foreign_keys=ON')
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback(); raise
        finally:
            db.close()
    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()
    def create(self,title,steps):
        if not str(title).strip() or not steps: raise ValueError('Título e pelo menos uma etapa são obrigatórios.')
        wid=uuid.uuid4().hex[:12]; now=self._now()
        metadata = self.vault.pack("workflow."+wid, {"metadata": "{}"}) if self.vault.encrypted else '{}'
        with self._db() as db:
            db.execute('INSERT INTO workflows VALUES(?,?,?,?,?,?)',(wid,str(title).strip(),'planned',now,now,metadata))
            for i,s in enumerate(steps):
                if not isinstance(s,dict) or not str(s.get('title','')).strip(): raise ValueError('Cada etapa precisa de título.')
                deps=s.get('dependencies',[])
                if any(not isinstance(d,int) or d<0 or d>=i for d in deps): raise ValueError('Dependências devem apontar para etapas anteriores.')
                db.execute('INSERT INTO workflow_steps(id,workflow_id,position,title,department,tool,dependencies,status,created_at,updated_at,retry_class) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(uuid.uuid4().hex[:12],wid,i,s['title'].strip(),s.get('department','ABM BRAIN'),s.get('tool',''),json.dumps(deps), 'waiting',now,now,s.get('retry_class','manual_review')))
        return self.get(wid)
    def get(self,wid):
        with self._db() as db:
            w=db.execute('SELECT * FROM workflows WHERE id=?',(str(wid),)).fetchone()
            if not w:return {'status':'not_found','workflow_id':str(wid)}
            steps=db.execute('SELECT * FROM workflow_steps WHERE workflow_id=? ORDER BY position',(str(wid),)).fetchall()
        out=dict(w)
        if out['metadata']==MARKER:
            protected=self.vault.unpack("workflow."+out['id'], MARKER)
            raw_metadata=protected.get('metadata')
            try: out['metadata']=json.loads(raw_metadata) if isinstance(raw_metadata,str) else {"_protected":True}
            except Exception: out['metadata']={"_unavailable":True}
        else:
            try: out['metadata']=json.loads(out['metadata'])
            except Exception: out['metadata']={"_unavailable":True}
        out['steps']=[]
        for r in steps:
            x=dict(r); x['dependencies']=json.loads(x['dependencies'])
            if x.get('result_summary')==MARKER:
                protected=self.vault.unpack("step."+x['id'], MARKER)
                x['result_summary']=protected.get('result_summary','[resultado protegido indisponível]')
            out['steps'].append(x)
        return out
    def list(self,limit=50):
        with self._db() as db: rows=db.execute('SELECT id,title,state,updated_at FROM workflows ORDER BY updated_at DESC LIMIT ?',(max(1,min(int(limit),200)),)).fetchall()
        return [dict(r) for r in rows]
    def _set_state(self,wid,state):
        if state not in self.STATES: raise ValueError('Estado inválido.')
        with self._db() as db:
            cur=db.execute('UPDATE workflows SET state=?,updated_at=? WHERE id=?',(state,self._now(),str(wid)))
            if not cur.rowcount:return {'status':'not_found'}
        return self.get(wid)
    def pause(self,wid):
        w=self.get(wid)
        if w.get('status')=='not_found':return w
        if w['state'] in ('completed','failed','cancelled'):return {'status':'invalid_transition','state':w['state']}
        return self._set_state(wid,'paused')
    def resume(self,wid):
        w=self.get(wid)
        if w.get('status')=='not_found':return w
        if w['state']!='paused':return {'status':'invalid_transition','state':w['state']}
        return self._set_state(wid,'planned')
    def cancel(self,wid):
        w=self.get(wid)
        if w.get('status')=='not_found':return w
        if w['state']=='completed':return {'status':'invalid_transition','state':w['state']}
        with self._db() as db:
            db.execute("UPDATE workflow_steps SET status='cancelled',updated_at=? WHERE workflow_id=? AND status IN ('waiting','ready')",(self._now(),str(wid)))
        return self._set_state(wid,'cancelled')
    def next_step(self,wid):
        w=self.get(wid)
        if w.get('status')=='not_found':return w
        if w['state'] in ('paused','cancelled','completed','failed'):return {'status':'workflow_not_active','state':w['state']}
        steps=w['steps']
        for s in steps:
            if s['status'] in ('done','skipped'):continue
            if s['status']!='waiting':return {'status':'step_already_open','step':s,'execution_performed':False}
            if any(steps[d]['status']!='done' for d in s['dependencies']):return {'status':'dependencies_incomplete','step':s,'execution_performed':False}
            now=self._now()
            with self._db() as db:
                db.execute("UPDATE workflow_steps SET status='waiting_user',updated_at=? WHERE id=?",(now,s['id']))
                db.execute("UPDATE workflows SET state='waiting_user',updated_at=? WHERE id=?",(now,str(wid)))
            return {'status':'waiting_user','step_id':s['id'],'step':s['title'],'message':'Etapa apresentada para ação/validação humana. Nenhuma ferramenta foi executada.','execution_performed':False}
        self._set_state(wid,'completed'); return {'status':'completed','workflow_id':str(wid),'execution_performed':False}
    def confirm_step(self,wid,step_id,success,result_summary=''):
        w=self.get(wid)
        if w.get('status')=='not_found':return w
        step=next((s for s in w['steps'] if s['id']==str(step_id)),None)
        if not step:return {'status':'step_not_found'}
        if step['status']!='waiting_user':return {'status':'step_not_waiting_user','step_status':step['status']}
        now=self._now(); new='done' if success else 'failed'
        summary=str(result_summary)[:500]
        if self.vault.encrypted:
            self.vault.pack("step."+str(step_id), {"result_summary": summary})
            summary=MARKER
        with self._db() as db:
            db.execute('UPDATE workflow_steps SET status=?,result_summary=?,updated_at=? WHERE id=?',(new,summary,now,str(step_id)))
            db.execute('UPDATE workflows SET state=?,updated_at=? WHERE id=?',('planned' if success else 'failed',now,str(wid)))
        return self.get(wid)
    def status(self):return {'version':'5.3.0','workflow_count':len(self.list(200)),'automatic_execution':False,'automatic_retry':False,'sensitive_fields_encrypted':self.vault.encrypted,'storage':'sqlite_metadata_android_keystore_aes_256_gcm' if self.vault.encrypted else 'local_sqlite_plaintext'}
