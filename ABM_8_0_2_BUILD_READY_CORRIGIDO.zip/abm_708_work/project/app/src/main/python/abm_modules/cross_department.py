"""ABM 5.8.0: barramento persistente e controlado entre departamentos."""
import json, sqlite3, time, uuid
from pathlib import Path
from .secure_fields import SecureFieldVault, MARKER

class CrossDepartmentEngine:
    DEPARTMENTS = {"brain","ears","eyes","voice","body","accessibility","autonomy","social","memory","security","connect","system","interface","cloud","developer","knowledge"}
    def __init__(self, db_path, secure_store=None):
        self.vault=SecureFieldVault(secure_store, "abm.cross_department.v1")
        self.db_path=str(db_path); Path(self.db_path).parent.mkdir(parents=True,exist_ok=True)
        with self._db() as db:
            db.executescript("""CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, correlation_id TEXT NOT NULL, sender TEXT NOT NULL, recipient TEXT NOT NULL, topic TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL, created_at REAL NOT NULL, expires_at REAL); CREATE INDEX IF NOT EXISTS idx_msg_corr ON messages(correlation_id); CREATE INDEX IF NOT EXISTS idx_msg_recipient ON messages(recipient,status); CREATE TABLE IF NOT EXISTS shared_context(id INTEGER PRIMARY KEY AUTOINCREMENT, correlation_id TEXT NOT NULL, department TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, consent INTEGER NOT NULL, created_at REAL NOT NULL, UNIQUE(correlation_id,department,key));""")
        if self.vault.encrypted:
            with self._db() as db:
                for row in db.execute("SELECT id,payload FROM messages WHERE payload != ?", (MARKER,)).fetchall():
                    self.vault.pack("message."+row["id"], json.loads(row["payload"]))
                    db.execute("UPDATE messages SET payload=? WHERE id=?", (MARKER,row["id"]))
                for row in db.execute("SELECT id,correlation_id,department,key,value FROM shared_context WHERE value != ?", (MARKER,)).fetchall():
                    item="context."+str(row["id"])
                    self.vault.pack(item, json.loads(row["value"]))
                    db.execute("UPDATE shared_context SET value=? WHERE id=?", (MARKER,row["id"]))
    def _db(self):
        db=sqlite3.connect(self.db_path); db.row_factory=sqlite3.Row; return db
    @classmethod
    def _dept(cls, value):
        v=str(value or '').strip().lower()
        if v not in cls.DEPARTMENTS: raise ValueError('Departamento desconhecido: '+v)
        return v
    def publish(self, sender, recipient, topic, payload, correlation_id=None, ttl_seconds=86400):
        sender=self._dept(sender); recipient=self._dept(recipient); topic=str(topic or '').strip()
        if not topic or len(topic)>120: raise ValueError('Tópico vazio ou demasiado longo.')
        if not isinstance(payload,dict): raise ValueError('Payload deve ser um objeto JSON.')
        encoded=json.dumps(payload,ensure_ascii=False)
        if len(encoded)>12000: raise ValueError('Payload excede 12 KB.')
        corr=str(correlation_id or uuid.uuid4()); mid=str(uuid.uuid4()); now=time.time(); ttl=max(60,min(int(ttl_seconds),604800))
        stored=self.vault.pack("message."+mid, payload)
        with self._db() as db: db.execute('INSERT INTO messages VALUES(?,?,?,?,?,?,?,?,?)',(mid,corr,sender,recipient,topic,stored,'pending',now,now+ttl))
        return {'status':'queued','message_id':mid,'correlation_id':corr,'delivered':False}
    def receive(self, department, limit=20):
        department=self._dept(department); now=time.time()
        with self._db() as db:
            db.execute("UPDATE messages SET status='expired' WHERE recipient=? AND status='pending' AND expires_at<?",(department,now))
            rows=db.execute("SELECT * FROM messages WHERE recipient=? AND status='pending' ORDER BY created_at LIMIT ?",(department,max(1,min(int(limit),100)))).fetchall()
            ids=[r['id'] for r in rows]
            if ids: db.executemany("UPDATE messages SET status='delivered' WHERE id=?",[(x,) for x in ids])
        messages=[]
        for r in rows:
            item=dict(r)
            item['payload']=self.vault.unpack("message."+item['id'], item['payload']) if item['payload']==MARKER else json.loads(item['payload'])
            messages.append(item)
        return {'department':department,'messages':messages}
    def share_context(self, correlation_id, department, key, value, consent=False):
        if not consent: return {'status':'consent_required','stored':False}
        department=self._dept(department); key=str(key or '').strip(); val=json.dumps(value,ensure_ascii=False)
        if not correlation_id or not key or len(key)>120 or len(val)>4000: raise ValueError('Contexto inválido ou demasiado longo.')
        with self._db() as db:
            db.execute('INSERT OR IGNORE INTO shared_context(correlation_id,department,key,value,consent,created_at) VALUES(?,?,?,?,1,?)',(str(correlation_id),department,key,val,time.time()))
            row=db.execute('SELECT id FROM shared_context WHERE correlation_id=? AND department=? AND key=?',(str(correlation_id),department,key)).fetchone()
            item_id="context."+str(row['id'])
            stored=self.vault.pack(item_id, value)
            db.execute('UPDATE shared_context SET value=? WHERE id=?',(stored,row['id']))
        return {'status':'stored','stored':True,'encrypted_at_rest':self.vault.encrypted}
    def get_context(self, correlation_id, requesting_department):
        requester=self._dept(requesting_department)
        with self._db() as db: rows=db.execute('SELECT id,department,key,value,created_at FROM shared_context WHERE correlation_id=? AND consent=1 ORDER BY created_at',(str(correlation_id),)).fetchall()
        items=[]
        for r in rows:
            value=self.vault.unpack("context."+str(r['id']), r['value']) if r['value']==MARKER else json.loads(r['value'])
            items.append({'department':r['department'],'key':r['key'],'value':value,'created_at':r['created_at']})
        return {'correlation_id':str(correlation_id),'requesting_department':requester,'items':items}
    def acknowledge(self, message_id, department):
        department=self._dept(department)
        with self._db() as db: cur=db.execute("UPDATE messages SET status='acknowledged' WHERE id=? AND recipient=? AND status='delivered'",(str(message_id),department))
        return {'status':'acknowledged' if cur.rowcount else 'not_acknowledged','changed':cur.rowcount==1}
    def status(self):
        with self._db() as db:
            counts={r['status']:r['n'] for r in db.execute('SELECT status,COUNT(*) n FROM messages GROUP BY status')}
            contexts=db.execute('SELECT COUNT(*) FROM shared_context WHERE consent=1').fetchone()[0]
        return {'version':'5.8.0','engine':'CrossDepartmentEngine','departments':len(self.DEPARTMENTS),'messages':counts,'shared_context_items':contexts,'storage':'SQLite metadata + Android Keystore AES-GCM' if self.vault.encrypted else 'SQLite local plaintext','encrypted_payloads':self.vault.encrypted,'automatic_execution':False,'external_actions':False}
