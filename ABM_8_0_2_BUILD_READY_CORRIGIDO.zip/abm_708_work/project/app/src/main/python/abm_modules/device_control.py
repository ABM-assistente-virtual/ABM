"""Pedidos de controlo Android; detalhes protegidos via Android Keystore quando disponível."""
import sqlite3, uuid, time
from pathlib import Path
from .secure_fields import SecureFieldVault, MARKER

ACTIONS = {
    'back': {'risk':'low','confirm':False}, 'home': {'risk':'medium','confirm':True},
    'notifications': {'risk':'low','confirm':False}, 'quick_settings': {'risk':'medium','confirm':True},
    'cursor_on': {'risk':'low','confirm':False}, 'cursor_off': {'risk':'low','confirm':False},
    'scan_start': {'risk':'low','confirm':False}, 'scan_next': {'risk':'low','confirm':False},
    'scan_select': {'risk':'high','confirm':True}, 'scan_stop': {'risk':'low','confirm':False}
}

class UniversalDeviceControl:
    def __init__(self, db_path, bridge, secure_store=None):
        self.db_path, self.bridge = str(db_path), bridge
        Path(self.db_path).parent.mkdir(parents=True,exist_ok=True)
        self.vault=SecureFieldVault(secure_store, 'abm.device_control.v1')
        with self._db() as db:
            db.execute("CREATE TABLE IF NOT EXISTS device_tickets(id TEXT PRIMARY KEY, action TEXT NOT NULL, status TEXT NOT NULL, created REAL NOT NULL, confirmed REAL, detail TEXT)")
        if self.vault.encrypted: self._migrate_legacy_rows()
        try: Path(self.db_path).chmod(0o600)
        except OSError: pass

    def _db(self):
        db=sqlite3.connect(self.db_path,timeout=10); db.row_factory=sqlite3.Row; return db

    def _migrate_legacy_rows(self):
        with self._db() as db:
            rows=db.execute('SELECT id,detail FROM device_tickets WHERE detail IS NOT NULL AND detail != ?', (MARKER,)).fetchall()
            for row in rows:
                self.vault.pack('ticket.'+row['id'], {'detail':row['detail']})
                db.execute('UPDATE device_tickets SET detail=? WHERE id=?',(MARKER,row['id']))

    def status(self):
        with self._db() as db:
            counts={r['status']:r['n'] for r in db.execute('SELECT status,COUNT(*) n FROM device_tickets GROUP BY status')}
        return {'actions':sorted(ACTIONS), 'bridge':self.bridge.status(), 'tickets':counts,
                'encrypted_at_rest':self.vault.encrypted,
                'execution_note':'Este motor prepara e autoriza pedidos. A Activity/serviço Android ainda tem de receber e executar o Intent.'}

    def prepare(self, action):
        action=str(action or '').strip().lower()
        if action not in ACTIONS: return {'accepted':False,'reason':'Ação não suportada.'}
        ticket=uuid.uuid4().hex[:12]; detail='Pedido criado pelo utilizador'
        with self._db() as db:
            db.execute('INSERT INTO device_tickets(id,action,status,created,detail) VALUES(?,?,?,?,?)',(ticket,action,'pending',time.time(),MARKER if self.vault.encrypted else detail))
            if self.vault.encrypted: self.vault.pack('ticket.'+ticket,{'detail':detail})
        return {'accepted':True,'ticket':ticket,'action':action,'risk':ACTIONS[action]['risk'],'requires_confirmation':ACTIONS[action]['confirm'],'status':'pending','message':'Pedido preparado; nenhuma ação Android foi executada.'}

    def approve(self, ticket, confirmed=False):
        with self._db() as db:
            row=db.execute('SELECT * FROM device_tickets WHERE id=?',(str(ticket),)).fetchone()
            if not row: return {'accepted':False,'reason':'Pedido não encontrado.'}
            if row['status']!='pending': return {'accepted':False,'reason':'Pedido já processado.'}
            action=row['action']
            if ACTIONS[action]['confirm'] and not confirmed: return {'accepted':False,'reason':'Confirmação explícita necessária.'}
            result=self.bridge.validate(action,user_confirmed=confirmed)
            if not result.accepted: return {'accepted':False,'reason':result.reason,'status':'pending'}
            db.execute('UPDATE device_tickets SET status=?,confirmed=?,detail=? WHERE id=?',('authorized_for_android_dispatch',time.time(),MARKER if self.vault.encrypted else 'Autorizado; aguarda encaminhamento Android',str(ticket)))
            if self.vault.encrypted: self.vault.pack('ticket.'+str(ticket),{'detail':'Autorizado; aguarda encaminhamento Android'})
        return {'accepted':True,'ticket':str(ticket),'action':action,'status':'authorized_for_android_dispatch','dispatched':False,'completed':False,'message':'Autorizado pela política ABM; ainda não enviado ao serviço Android.'}

    def cancel(self,ticket):
        with self._db() as db:
            cur=db.execute("UPDATE device_tickets SET status='cancelled' WHERE id=? AND status='pending'",(str(ticket),))
            if cur.rowcount: self.vault.remove('ticket.'+str(ticket))
        return {'cancelled':cur.rowcount==1}
