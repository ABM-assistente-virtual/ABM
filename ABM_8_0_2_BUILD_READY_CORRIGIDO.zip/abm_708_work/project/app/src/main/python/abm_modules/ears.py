"""ABM EARS: normalização de transcrições e análise acústica WAV offline.

A captação/transcrição do microfone é responsabilidade do Android. Este módulo
não abre microfone por si só nem escuta conversas em segundo plano.
"""
import math, wave, struct
from pathlib import Path

class Ears:
    def normalize_transcript(self, text: str) -> dict:
        raw = str(text).strip()
        if not raw:
            raise ValueError("Transcrição vazia.")
        clean = " ".join(raw.split())
        words = clean.casefold().split()
        return {"text": clean, "words": words, "word_count": len(words),
                "wake_word": bool(words and words[0].strip(",.!?") in {"abm", "abê-eme"})}

    def analyze_wav(self, filepath: str) -> dict:
        with wave.open(str(filepath), "rb") as wf:
            channels, width, rate, frames = wf.getnchannels(), wf.getsampwidth(), wf.getframerate(), wf.getnframes()
            if width not in (1, 2, 4):
                raise ValueError("WAV PCM de 8, 16 ou 32 bits é necessário.")
            raw = wf.readframes(frames)
        fmt = {1: "B", 2: "h", 4: "i"}[width]
        n = len(raw) // width
        vals = struct.unpack("<" + fmt * n, raw) if n else ()
        if width == 1:
            samples = [(v - 128) / 128.0 for v in vals]
        else:
            scale = float(2 ** (8 * width - 1))
            samples = [v / scale for v in vals]
        if channels > 1:
            samples = [sum(samples[i:i+channels]) / channels for i in range(0, len(samples), channels)]
        rms = math.sqrt(sum(x*x for x in samples) / max(1, len(samples)))
        peak = max((abs(x) for x in samples), default=0.0)
        return {"ok": True, "sample_rate": rate, "channels": channels,
                "duration_seconds": round(frames / float(rate or 1), 3),
                "rms": round(rms, 6), "peak": round(peak, 6),
                "classification": "silêncio ou sinal baixo" if rms < 0.01 else "sinal de áudio presente",
                "transcription": None,
                "note": "Análise acústica; não reconhece palavras sem um motor ASR separado."}
