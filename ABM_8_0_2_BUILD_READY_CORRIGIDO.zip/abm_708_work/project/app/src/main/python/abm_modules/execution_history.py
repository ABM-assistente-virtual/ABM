"""Histórico persistente de execuções com campos sensíveis protegidos no Android."""
from __future__ import annotations
import json, sqlite3, hashlib
from pathlib import Path
from datetime import datetime, timezone
from .secure_fields import SecureFieldVault, MARKER

class ExecutionHistoryStore:
    def __init__(self, db_path, secure_store=None):
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.vault = SecureFieldVault(secure_store, "abm.execution.v1")
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS executions (
                execution_id TEXT PRIMARY KEY, tool TEXT NOT NULL, status TEXT NOT NULL,
                platform TEXT, risk TEXT, created_at TEXT, updated_at TEXT,
                target_outcome TEXT, target_outcome_at TEXT, detail TEXT,
                args_json TEXT, args_hash TEXT, persist_consent INTEGER NOT NULL DEFAULT 0
            )""")
            db.execute("""CREATE TABLE IF NOT EXISTS execution_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, execution_id TEXT NOT NULL,
                event TEXT NOT NULL, outcome TEXT, at TEXT NOT NULL
            )""")
        if self.vault.encrypted:
            self._migrate_legacy_rows()
        try: self.path.chmod(0o600)
        except OSError: pass

    def _connect(self):
        db = sqlite3.connect(str(self.path), timeout=10)
        db.row_factory = sqlite3.Row
        return db

    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()

    def _vault_id(self, execution_id): return "execution." + str(execution_id)

    def _migrate_legacy_rows(self):
        with self._connect() as db:
            rows = db.execute("SELECT execution_id,target_outcome,detail,args_json FROM executions WHERE detail != ? OR (args_json IS NOT NULL AND args_json != ?) OR (target_outcome IS NOT NULL AND target_outcome != ?)", (MARKER, MARKER, MARKER)).fetchall()
            for row in rows:
                payload = {"target_outcome": row["target_outcome"], "detail": row["detail"], "args_json": row["args_json"]}
                self.vault.pack(self._vault_id(row["execution_id"]), payload)
                db.execute("UPDATE executions SET target_outcome=?,detail=?,args_json=CASE WHEN args_json IS NULL THEN NULL ELSE ? END WHERE execution_id=?",
                           (MARKER if row["target_outcome"] is not None else None, MARKER, MARKER if row["args_json"] is not None else None, row["execution_id"]))

    def _decode_sensitive(self, row):
        data = dict(row)
        if data.get("detail") == MARKER or data.get("target_outcome") == MARKER or data.get("args_json") == MARKER:
            payload = self.vault.unpack(self._vault_id(data["execution_id"]), MARKER)
            data["detail"] = payload.get("detail", "[detalhe protegido indisponível]")
            data["target_outcome"] = payload.get("target_outcome")
            data["args_json"] = payload.get("args_json")
        return data

    def save(self, record, event="state_saved", outcome=None):
        args = record.get("arguments", {})
        args_json = json.dumps(args, ensure_ascii=False, separators=(",", ":")) if record.get("persist_context") else None
        args_hash = hashlib.sha256(json.dumps(args, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        now = self._now(); execution_id = str(record["execution_id"])
        detail = str(record.get("android_adapter_detail", ""))[:500]
        target = record.get("target_outcome")
        if self.vault.encrypted:
            # Preserva argumentos previamente consentidos quando uma atualização posterior
            # do estado não volta a enviar o contexto.
            if args_json is None:
                with self._connect() as existing_db:
                    previous = existing_db.execute("SELECT args_json,target_outcome FROM executions WHERE execution_id=?", (execution_id,)).fetchone()
                if previous and previous["args_json"] == MARKER:
                    old_payload = self.vault.unpack(self._vault_id(execution_id), MARKER)
                    args_json = old_payload.get("args_json")
                if target is None and previous and previous["target_outcome"] == MARKER:
                    target = old_payload.get("target_outcome") if 'old_payload' in locals() else self.vault.unpack(self._vault_id(execution_id), MARKER).get("target_outcome")
            self.vault.pack(self._vault_id(execution_id), {"detail": detail, "target_outcome": target, "args_json": args_json})
            stored_detail = MARKER
            stored_target = MARKER if target is not None else None
            stored_args = MARKER if args_json is not None else None
        else:
            stored_detail, stored_target, stored_args = detail, target, args_json
        with self._connect() as db:
            db.execute("""INSERT INTO executions
                (execution_id,tool,status,platform,risk,created_at,updated_at,target_outcome,target_outcome_at,detail,args_json,args_hash,persist_consent)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(execution_id) DO UPDATE SET status=excluded.status,updated_at=excluded.updated_at,
                target_outcome=COALESCE(excluded.target_outcome,executions.target_outcome),target_outcome_at=excluded.target_outcome_at,
                detail=excluded.detail,args_json=CASE WHEN excluded.persist_consent=1 THEN excluded.args_json ELSE executions.args_json END,
                args_hash=excluded.args_hash,persist_consent=MAX(executions.persist_consent,excluded.persist_consent)""",
                (execution_id, record["tool"], record.get("status", "unknown"), record.get("platform"),
                 record.get("risk"), record.get("created_at", now), now, stored_target,
                 record.get("target_outcome_at"), stored_detail, stored_args, args_hash, int(bool(record.get("persist_context")))))
            db.execute("INSERT INTO execution_events(execution_id,event,outcome,at) VALUES(?,?,?,?)",
                       (execution_id, event, str(outcome or record.get("status", ""))[:100], now))

    def recover(self):
        with self._connect() as db: rows = db.execute("SELECT * FROM executions ORDER BY created_at").fetchall()
        recovered = []
        for row in rows:
            data = self._decode_sensitive(row)
            try: args = json.loads(data["args_json"]) if data.get("args_json") else {}
            except Exception: args = {}
            original = data["status"]
            can_resume = bool(data.get("persist_consent")) and data.get("args_json") is not None
            status = original
            if original in ("ready", "awaiting_confirmation") and not can_resume: status = "interrupted_requires_reprepare"
            recovered.append({"execution_id": data["execution_id"], "tool": data["tool"],
                "arguments": args, "status": status, "original_status": original,
                "requires_confirmation": original == "awaiting_confirmation", "risk": data.get("risk"),
                "platform": data.get("platform"), "created_at": data.get("created_at"),
                "target_outcome": data.get("target_outcome"), "target_outcome_at": data.get("target_outcome_at"),
                "android_adapter_detail": data.get("detail", ""), "persist_context": can_resume,
                "recovered": True, "resumable": can_resume and original in ("ready", "awaiting_confirmation")})
        return recovered

    def list_history(self, limit=50):
        limit = max(1, min(int(limit), 200))
        with self._connect() as db:
            rows = db.execute("SELECT execution_id,tool,status,platform,risk,created_at,updated_at,target_outcome,target_outcome_at,persist_consent FROM executions ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
        result=[]
        for row in rows:
            item=dict(row)
            if item.get("target_outcome")==MARKER:
                payload=self.vault.unpack(self._vault_id(item["execution_id"]), MARKER)
                item["target_outcome"]=payload.get("target_outcome")
            result.append(item)
        return result

    def events(self, execution_id, limit=100):
        with self._connect() as db:
            rows = db.execute("SELECT event,outcome,at FROM execution_events WHERE execution_id=? ORDER BY id DESC LIMIT ?", (str(execution_id), max(1,min(int(limit),500)))).fetchall()
        return [dict(row) for row in rows]

    def status(self):
        with self._connect() as db:
            count = db.execute("SELECT COUNT(*) FROM executions").fetchone()[0]
            resumable = db.execute("SELECT COUNT(*) FROM executions WHERE persist_consent=1 AND args_json IS NOT NULL AND status IN ('ready','awaiting_confirmation')").fetchone()[0]
        return {"persistent": True, "database": self.path.name, "records": count,
                "resumable_pending": resumable, "arguments_encrypted": self.vault.encrypted,
                "sensitive_fields_encrypted": self.vault.encrypted,
                "storage": "sqlite_metadata_android_keystore_aes_256_gcm" if self.vault.encrypted else "local_sqlite_plaintext",
                "default_persists_arguments": False}
