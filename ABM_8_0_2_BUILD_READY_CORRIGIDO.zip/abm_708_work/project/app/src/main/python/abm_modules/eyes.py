"""ABM EYES: inspeção visual básica de ficheiros de imagem offline.

Não identifica pessoas. Reconhecimento semântico de objetos exige um modelo
visual treinado que não está incluído neste pacote.
"""
class Eyes:
    def analyze_image(self, filepath: str) -> dict:
        try:
            from PIL import Image, ImageStat
        except ImportError as exc:
            raise RuntimeError("Pillow não está instalado; a análise de imagem não está disponível neste ambiente.") from exc
        with Image.open(filepath) as source:
            image = source.convert("RGB")
            width, height = image.size
            image.thumbnail((256, 256))
            stat = ImageStat.Stat(image)
            means = [round(float(v), 2) for v in stat.mean]
            brightness = round(sum(means) / 3.0, 2)
            return {"ok": True, "filename": str(filepath).split("/")[-1],
                    "width": width, "height": height, "format": source.format,
                    "mean_rgb": means, "brightness_0_255": brightness,
                    "orientation": "horizontal" if width > height else "vertical" if height > width else "quadrada",
                    "note": "Análise de propriedades visuais. Não identifica rostos, pessoas ou objetos nesta versão."}
