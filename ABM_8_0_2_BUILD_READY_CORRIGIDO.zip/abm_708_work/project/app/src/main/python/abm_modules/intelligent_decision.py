"""ABM 5.3.0 — apoio determinístico à decisão, sem executar ferramentas."""
from __future__ import annotations
from datetime import datetime, timezone

class IntelligentDecisionEngine:
    RISK_ORDER = {"low": 0, "medium": 1, "high": 2}
    KEYWORDS = {
        "android.open_app": ("abrir", "abre", "aplicação", "app", "whatsapp", "youtube"),
        "android.web_search": ("pesquisar", "pesquisa", "procurar na internet", "buscar"),
        "android.open_camera": ("câmara", "camera", "fotografar", "foto"),
        "android.dial": ("ligar", "telefonar", "chamar"),
        "android.share_text": ("partilhar", "enviar mensagem", "compartilhar"),
        "android.open_maps": ("mapa", "rota", "direções", "localizar"),
        "abm.create_note": ("criar nota", "guardar nota", "anotar"),
        "abm.list_notes": ("listar notas", "mostrar notas", "minhas notas"),
        "abm.read_note": ("ler nota", "abrir nota"),
    }
    def __init__(self, tool_engine):
        if tool_engine is None: raise ValueError("Motor de ferramentas obrigatório.")
        self.tools = tool_engine
        self.last_decision = None

    def decide(self, request, *, context=None, max_risk="medium"):
        text = str(request or "").strip()
        if not text:
            return {"status":"needs_clarification", "reason":"Pedido vazio.", "execution_performed":False}
        if max_risk not in self.RISK_ORDER: raise ValueError("max_risk inválido.")
        q=text.casefold(); candidates=[]
        for name, spec in self.tools.specs.items():
            phrases=self.KEYWORDS.get(name, ())
            hits=[p for p in phrases if p in q]
            if not hits: continue
            risk=spec.risk if spec.risk in self.RISK_ORDER else "high"
            score=min(0.95, 0.55 + 0.12*len(hits))
            blocked=self.RISK_ORDER[risk] > self.RISK_ORDER[max_risk]
            candidates.append({"tool":name,"description":spec.description,"score":round(score,2),"risk":risk,
                "requires_confirmation":bool(spec.requires_confirmation or risk=="high"),"blocked_by_risk_policy":blocked,
                "required_arguments":list(spec.required),"missing_arguments":list(spec.required),"matched_phrases":hits})
        candidates.sort(key=lambda x:(x["blocked_by_risk_policy"],-x["score"],self.RISK_ORDER[x["risk"]],x["tool"]))
        eligible=[c for c in candidates if not c["blocked_by_risk_policy"]]
        if not candidates:
            status="needs_clarification"; recommendation=None; reason="Não encontrei uma ferramenta registada que corresponda claramente ao pedido."
        elif not eligible:
            status="blocked_by_risk"; recommendation=None; reason="As opções encontradas excedem o limite de risco permitido."
        else:
            top=eligible[0]
            ambiguous=len(eligible)>1 and eligible[1]["score"]==top["score"]
            if ambiguous:
                status="needs_clarification"; recommendation=None; reason="Há mais de uma opção com a mesma pontuação; é necessária clarificação."
            elif top["missing_arguments"]:
                status="needs_information"; recommendation=top["tool"]; reason="Faltam argumentos obrigatórios; não preparar nem executar ainda."
            else:
                status="recommendation_only"; recommendation=top["tool"]; reason="Ferramenta candidata selecionada; a preparação e a execução são operações separadas."
        result={"engine":"ABM Intelligent Decision Engine 5.3.0","status":status,"request":text,
            "recommendation":recommendation,"reason":reason,"candidates":candidates,
            "context_used":bool(context),"decision_time":datetime.now(timezone.utc).isoformat(),
            "execution_performed":False,"tool_prepared":False,"requires_user_confirmation":bool(recommendation and next((x["requires_confirmation"] for x in candidates if x["tool"]==recommendation),False))}
        self.last_decision=result
        return result

    def status(self):
        return {"version":"5.3.0","available_tools":len(self.tools.specs),"decision_mode":"deterministic_keyword_scoring",
                "executes_tools":False,"learns_from_decisions":False,"last_decision_available":self.last_decision is not None}
