"""ABM MEMORY: memória local com consentimento explícito.

Em Android, o conteúdo é cifrado individualmente pelo ABMSecureStore (AES-256-GCM
com chave não exportável do Android Keystore); SQLite conserva apenas metadados e
um marcador. Fora do Android, o modo SQLite simples existe para testes locais e
fica explicitamente identificado como não cifrado.
"""
from __future__ import annotations
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path


class LocalMemoryStore:
    _ENCRYPTED_MARKER = "@abm-keystore-v1"
    _KEY_PREFIX = "abm.memory.v1."

    def __init__(self, database_path, secure_store=None):
        self.path = Path(str(database_path))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secure_store = secure_store
        self._init_db()
        if self.secure_store is not None:
            self._migrate_existing_rows_to_keystore()

    def _connect(self):
        db = sqlite3.connect(str(self.path), timeout=10)
        db.row_factory = sqlite3.Row
        return db

    def _key(self, memory_id):
        return self._KEY_PREFIX + str(memory_id)

    def _init_db(self):
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY, category TEXT NOT NULL, content TEXT NOT NULL,
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                importance INTEGER NOT NULL DEFAULT 3)""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_memories_category ON memories(category)")

    def _store_content(self, memory_id, content):
        if self.secure_store is None:
            return str(content)
        # ABMSecureStore usa AES/GCM/NoPadding e Android Keystore.
        self.secure_store.putString(self._key(memory_id), str(content))
        return self._ENCRYPTED_MARKER

    def _read_content(self, memory_id, stored_value):
        if stored_value != self._ENCRYPTED_MARKER:
            return stored_value
        if self.secure_store is None:
            return "[conteúdo protegido pelo Android Keystore]"
        value = self.secure_store.getString(self._key(memory_id), None)
        if value is None:
            return "[conteúdo indisponível: chave protegida ausente ou inválida]"
        return str(value)

    def _migrate_existing_rows_to_keystore(self):
        """Migra conteúdo legado sem o deixar em texto simples no SQLite.

        A escrita no Keystore ocorre antes da substituição do texto no SQLite;
        se a aplicação for interrompida, a migração pode ser repetida com segurança.
        """
        with self._connect() as db:
            rows = db.execute("SELECT id, content FROM memories WHERE content != ?",
                              (self._ENCRYPTED_MARKER,)).fetchall()
            for row in rows:
                marker = self._store_content(row["id"], row["content"])
                db.execute("UPDATE memories SET content = ? WHERE id = ?",
                           (marker, row["id"]))

    def remember(self, content, *, consent=False, category="general", importance=3):
        text = str(content or "").strip()
        if not consent:
            return {"stored": False, "reason": "consent_required"}
        if not text:
            raise ValueError("A memória não pode estar vazia.")
        if len(text) > 4000:
            raise ValueError("Cada memória pode ter no máximo 4000 caracteres.")
        category = str(category or "general").strip().lower()[:40] or "general"
        importance = max(1, min(5, int(importance)))
        now = datetime.now(timezone.utc).isoformat()
        memory_id = uuid.uuid4().hex
        stored_content = self._store_content(memory_id, text)
        try:
            with self._connect() as db:
                db.execute("INSERT INTO memories VALUES (?, ?, ?, ?, ?, ?)",
                           (memory_id, category, stored_content, now, now, importance))
        except Exception:
            if self.secure_store is not None:
                self.secure_store.remove(self._key(memory_id))
            raise
        return {"stored": True, "id": memory_id, "category": category, "created_at": now,
                "encrypted_at_rest": self.secure_store is not None}

    def _public_row(self, row):
        item = dict(row)
        item["content"] = self._read_content(item["id"], item["content"])
        return item

    def search(self, query, *, limit=10):
        terms = [x.casefold() for x in str(query or "").split() if x.strip()]
        if not terms:
            return []
        limit = max(1, min(50, int(limit)))
        with self._connect() as db:
            rows = db.execute("SELECT * FROM memories ORDER BY updated_at DESC LIMIT 500").fetchall()
        ranked = []
        for row in rows:
            item = self._public_row(row)
            hay = (item["category"] + " " + item["content"]).casefold()
            score = sum(1 for term in terms if term in hay)
            if score:
                ranked.append((score, item["importance"], item))
        ranked.sort(key=lambda x: (x[0], x[1], x[2]["updated_at"]), reverse=True)
        return [item[2] for item in ranked[:limit]]

    def list_memories(self, *, limit=50):
        limit = max(1, min(100, int(limit)))
        with self._connect() as db:
            rows = db.execute("SELECT id, category, content, created_at, updated_at, importance FROM memories ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
        return [self._public_row(row) for row in rows]

    def forget(self, memory_id, *, confirmed=False):
        if not confirmed:
            return {"deleted": False, "reason": "confirmation_required"}
        key = self._key(memory_id)
        with self._connect() as db:
            cur = db.execute("DELETE FROM memories WHERE id = ?", (str(memory_id),))
        if cur.rowcount and self.secure_store is not None:
            self.secure_store.remove(key)
        return {"deleted": cur.rowcount > 0, "id": str(memory_id)}

    def clear(self, *, confirmed=False):
        if not confirmed:
            return {"cleared": False, "reason": "confirmation_required"}
        with self._connect() as db:
            ids = [row[0] for row in db.execute("SELECT id FROM memories").fetchall()]
            cur = db.execute("DELETE FROM memories")
        if self.secure_store is not None:
            for memory_id in ids:
                self.secure_store.remove(self._key(memory_id))
        return {"cleared": True, "deleted_count": cur.rowcount}

    def export_json(self):
        return json.dumps({"format": "abm-memory-v1", "memories": self.list_memories(limit=100)},
                          ensure_ascii=False, indent=2)

    def status(self):
        with self._connect() as db:
            count = db.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        encrypted = self.secure_store is not None
        return {"ready": True,
                "storage": "sqlite_metadata_android_keystore_aes_256_gcm" if encrypted else "local_sqlite_unencrypted_test_mode",
                "encrypted_at_rest": encrypted, "count": count,
                "automatic_collection": False, "explicit_consent_required": True}
