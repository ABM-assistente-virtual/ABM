"""ABM 5.6.0 — previsão contextual conservadora.

Gera sugestões a partir de feedback/preferências explicitamente guardados.
Não monitoriza o utilizador, não infere dados sensíveis e nunca executa ações.
"""
from __future__ import annotations
from datetime import datetime, timezone
import re

class PredictiveIntelligenceEngine:
    def __init__(self, context_engine, learning_engine):
        self.context = context_engine
        self.learning = learning_engine

    @staticmethod
    def _tokens(value):
        return {x for x in re.findall(r"[\wÀ-ÿ]+", str(value or "").casefold()) if len(x) > 2}

    def predict(self, request, *, profile_id="default", prior_context=None, limit=3):
        text = str(request or "").strip()
        if not text:
            return {"status":"needs_input", "predictions":[], "execution_performed":False,
                    "reason":"É necessário um pedido ou contexto explícito."}
        understood = self.context.understand(text, profile_id=profile_id, prior_context=prior_context)
        query_tokens = self._tokens(text)
        examples = self.learning.suggestions(text, limit=max(3, min(10, int(limit)*2)))
        candidates = []
        for item in examples:
            correction_tokens = self._tokens(item.get("correction", ""))
            source_tokens = self._tokens(item.get("input_text", ""))
            union = query_tokens | source_tokens
            overlap = len(query_tokens & source_tokens) / max(1, len(query_tokens))
            correction_relevance = len(query_tokens & correction_tokens) / max(1, len(query_tokens))
            score = min(0.95, 0.35 + 0.45 * overlap + 0.15 * correction_relevance)
            if score >= 0.50:
                candidates.append({"suggestion":item["correction"], "basis":"correção anterior autorizada",
                                   "confidence":round(score, 2), "feedback_id":item["id"],
                                   "requires_user_choice":True})
        candidates.sort(key=lambda x:x["confidence"], reverse=True)
        limit = max(1, min(5, int(limit)))
        predictions = candidates[:limit]
        return {"engine":"ABM Predictive Intelligence 5.6.0", "status":"suggestions_available" if predictions else "insufficient_evidence",
                "context_status":understood.get("status", "unknown"), "predictions":predictions,
                "preferences_considered":bool(self.learning.get_preferences()),
                "monitoring_performed":False, "future_behavior_claimed":False,
                "execution_performed":False, "confirmation_required":True,
                "notice":"São sugestões baseadas em exemplos guardados, não previsões certas do comportamento futuro.",
                "timestamp":datetime.now(timezone.utc).isoformat()}

    def record_explicit_pattern(self, pattern, *, consent=False):
        if not consent:
            return {"recorded":False,"reason":"consent_required"}
        return self.learning.record_pattern(pattern, consent=True)

    def status(self):
        learning = self.learning.status()
        return {"version":"5.6.0", "ready":True,
                "evidence_source":"feedback e padrões explicitamente autorizados",
                "pattern_counters":learning.get("pattern_counters",0),
                "background_monitoring":False, "automatic_execution":False,
                "neural_prediction_model":False, "requires_user_confirmation":True}
