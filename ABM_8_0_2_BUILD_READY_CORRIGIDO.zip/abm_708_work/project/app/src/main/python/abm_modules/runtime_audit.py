"""Auditoria de prontidão em runtime; distingue código presente de serviço realmente ativo."""
from pathlib import Path
import importlib.util

class RuntimeAudit:
    def __init__(self, modules, data_dir):
        self.modules = modules
        self.data_dir = Path(data_dir)

    def _module(self, key):
        return key in self.modules and self.modules[key] is not None


    def _memory_status(self):
        module = self.modules.get('memory_store')
        status = getattr(module, 'status', None)
        if callable(status):
            try:
                return status()
            except Exception as exc:
                return {'ready': False, 'error': type(exc).__name__}
        return {'ready': bool(module), 'status': 'module_present_status_unavailable'}

    def report(self):
        cloud = self.modules.get('cloud_status', {})
        if not isinstance(cloud, dict):
            cloud = {'configured': False, 'runtime_connected': False}
        dbs = sorted(p.name for p in self.data_dir.glob('*.sqlite3'))
        history = getattr(self.modules.get('tool_engine'), 'history_store', None)
        history_status = history.status() if history and callable(getattr(history, 'status', None)) else {'sensitive_fields_encrypted': False}
        workflows = self.modules.get('continuous_operation')
        workflow_status = workflows.status() if workflows and callable(getattr(workflows, 'status', None)) else {'sensitive_fields_encrypted': False}
        recovery = self.modules.get('self_recovery')
        recovery_status = recovery.status() if recovery and callable(getattr(recovery, 'status', None)) else {'sensitive_fields_encrypted': False}
        interaction = self.modules.get('interaction')
        interaction_status = interaction.status() if interaction and callable(getattr(interaction, 'status', None)) else {'sensitive_fields_encrypted': False}
        knowledge = self.modules.get('knowledge')
        knowledge_status = knowledge.status() if knowledge and callable(getattr(knowledge, 'status', None)) else {'encrypted_at_rest': False}
        device_control = self.modules.get('device_control')
        device_status = device_control.status() if device_control and callable(getattr(device_control, 'status', None)) else {'encrypted_at_rest': False}
        accessibility = self.modules.get('accessibility_intelligence')
        accessibility_status = accessibility.status() if accessibility and callable(getattr(accessibility, 'status', None)) else {'encrypted_at_rest': False}
        secure_stores = {
            'primary_memory': self._memory_status(),
            'contextual_memory': self.modules.get('contextual_memory').status() if self.modules.get('contextual_memory') else {},
            'adaptive_learning': self.modules.get('adaptive_learning').status() if self.modules.get('adaptive_learning') else {},
            'execution_history': history_status,
            'workflows': workflow_status,
            'recovery': recovery_status,
            'interaction': interaction_status,
            'knowledge': knowledge_status,
            'device_control': device_status,
            'accessibility_profile_and_feedback': accessibility_status,
        }
        protected = [k for k,v in secure_stores.items() if isinstance(v,dict) and v.get('encryption', v.get('sensitive_fields_encrypted', v.get('encrypted_at_rest', False)))]
        return {
            'audit_version': 'FINAL-8.0.0',
            'runtime': {
                'python_core_initialized': self._module('agent'),
                'tool_engine_initialized': self._module('tool_engine'),
                'task_engine_initialized': self._module('task_engine'),
                'memory_engine_initialized': self._module('memory_store'),
                'security_policy_initialized': self._module('security'),
                'android_bridge_initialized': self._module('android_bridge'),
                'native_android_dispatch': 'requires_native_activity_and_user_granted_accessibility',
                'camera_runtime': 'requires_camera_permission_and_visible_camera_session',
                'speech_runtime': 'requires_android_speech_service_and_microphone_permission',
                'tts_runtime': 'requires_installed_android_tts_engine_and_language_data'
            },
            'cloud': {
                'configured': bool(cloud.get('configured', False)),
                'runtime_connected': bool(cloud.get('runtime_connected', False)),
                'deployment_verified': False,
                'reason': 'Deployment, production credentials and external services must be configured and tested.'
            },
            'storage': {
                'database_files': dbs,
                'local_sqlite_encryption': 'field-level protection for sensitive payloads in primary, contextual and adaptive memory, execution history, workflows, recovery, interaction, knowledge, device-control and accessibility profile/feedback when Android Keystore is injected; SQLite structural metadata remains visible; database-wide SQLCipher is not configured',
                'memory_store': self._memory_status(),
                'protected_stores': protected,
                'store_status': secure_stores,
                'other_sqlite_encryption': 'sensitive_companion_state_brain_snapshot_and_module_state_use_keystore_when_injected; structural metadata and non-sensitive counters remain visible',
                'android_cloud_token_storage': 'AES-256-GCM via Android Keystore; fail-closed; device validation pending',
                'core_json_state': 'Android Keystore protected when secure adapter is injected; desktop mode remains plaintext',
                'recommendation': 'Validate Keystore on a physical Android device; enable database-wide SQLCipher only after adding and validating a compatible native dependency.'
            },
            'departments': {
                'registered': self._module('system_unification'),
                'count': 15 if self._module('system_unification') else 0,
                'registration_is_not_proof_of_hardware_operation': True
            },
            'readiness': 'PARTIAL_REQUIRES_DEVICE_AND_CLOUD_VALIDATION'
        }
