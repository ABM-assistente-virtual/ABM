"""Pequeno adaptador de campos cifrados pelo Android Keystore.

SQLite guarda somente o marcador. O conteúdo JSON é cifrado pelo ABMSecureStore.
Sem adaptador Android, o modo local continua explícito e não cifrado.
"""
import json

MARKER = "@abm-keystore-v1"

class SecureFieldVault:
    def __init__(self, secure_store=None, namespace="abm.fields.v1"):
        self.secure_store = secure_store
        self.namespace = str(namespace)

    @property
    def encrypted(self):
        return self.secure_store is not None

    def key(self, item_id):
        return f"{self.namespace}.{item_id}"

    def pack(self, item_id, value):
        raw = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        if not self.encrypted:
            return raw
        self.secure_store.putString(self.key(item_id), raw)
        return MARKER

    def unpack(self, item_id, stored):
        if stored != MARKER:
            try:
                return json.loads(stored)
            except Exception:
                return stored
        if not self.encrypted:
            return {"_protected": True}
        raw = self.secure_store.getString(self.key(item_id), None)
        if raw is None:
            return {"_unavailable": True}
        try:
            return json.loads(str(raw))
        except Exception:
            return {"_unavailable": True}

    def remove(self, item_id):
        if self.encrypted:
            self.secure_store.remove(self.key(item_id))
