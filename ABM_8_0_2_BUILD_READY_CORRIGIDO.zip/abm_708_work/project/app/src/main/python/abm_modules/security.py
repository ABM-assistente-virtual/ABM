"""ABM SECURITY: consentimento, permissões e autorização de ações."""
from dataclasses import dataclass, field
from typing import Dict, Iterable

SENSITIVE_ACTIONS = {
    "send_message", "make_call", "answer_call", "share_location",
    "delete_file", "record_audio", "record_video", "open_camera",
    "read_notifications", "analyze_social_audio", "unlock_device",
}

@dataclass
class Security:
    permissions: Dict[str, bool] = field(default_factory=dict)
    audit: list = field(default_factory=list)

    def set_permission(self, name: str, enabled: bool) -> bool:
        if not name or not isinstance(enabled, bool):
            raise ValueError("Permissão inválida.")
        self.permissions[str(name)] = enabled
        self.audit.append({"event": "permission", "name": str(name), "enabled": enabled})
        return enabled

    def allowed(self, permission: str) -> bool:
        return bool(self.permissions.get(permission, False))

    def authorize(self, action: str, *, confirmed: bool = False, permission: str = None) -> dict:
        action = str(action)
        if action in {"unlock_device", "unlock_phone"}:
            result = {"allowed": False, "reason": "O ABM não desbloqueia o Android; usa PIN, padrão ou biometria oficiais."}
        elif action in {"record_audio", "record_video", "analyze_social_audio"}:
            result = {"allowed": False, "reason": "Não é permitido gravar ou analisar conversas de terceiros às escondidas."}
        elif permission and not self.allowed(permission):
            result = {"allowed": False, "reason": "A permissão necessária não foi concedida: " + permission}
        elif action in SENSITIVE_ACTIONS and not confirmed:
            result = {"allowed": False, "reason": "Esta ação exige confirmação explícita."}
        else:
            result = {"allowed": True, "reason": "Ação dentro das permissões configuradas."}
        self.audit.append({"event": "authorize", "action": action, **result})
        return result

    def export(self) -> dict:
        return {"permissions": dict(self.permissions), "audit_events": len(self.audit)}
