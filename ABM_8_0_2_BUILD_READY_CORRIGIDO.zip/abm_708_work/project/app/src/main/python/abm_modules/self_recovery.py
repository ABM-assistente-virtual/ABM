"""ABM 5.1.0 — análise e recuperação assistida de falhas.

Nunca repete operações automaticamente. Produz diagnóstico e plano de recuperação
para revisão humana; ações Android exigem nova preparação e autorização.
"""
from __future__ import annotations
from datetime import datetime, timezone
import sqlite3
from pathlib import Path
from .secure_fields import SecureFieldVault, MARKER

class SelfRecoveryEngine:
    SAFE_READ_ONLY = {"abm.list_notes", "abm.read_note"}
    NON_RETRYABLE = {"android.dial", "android.share_text", "android.open_camera", "android.choose_file", "abm.create_note"}

    def __init__(self, tool_engine, db_path, secure_store=None):
        if tool_engine is None: raise ValueError("UniversalToolEngine é obrigatório.")
        self.tools = tool_engine
        self.vault = SecureFieldVault(secure_store, "abm.recovery.v1")
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            db.execute("CREATE TABLE IF NOT EXISTS recovery_events (id INTEGER PRIMARY KEY AUTOINCREMENT, execution_id TEXT NOT NULL, event TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT NOT NULL)")
        if self.vault.encrypted: self._migrate_legacy_rows()
        try: self.path.chmod(0o600)
        except OSError: pass

    def _migrate_legacy_rows(self):
        with self._db() as db:
            for row in db.execute("SELECT id,detail FROM recovery_events WHERE detail != ?", (MARKER,)).fetchall():
                self.vault.pack("recovery."+str(row["id"]), {"detail":row["detail"]})
                db.execute("UPDATE recovery_events SET detail=? WHERE id=?", (MARKER,row["id"]))

    def _db(self):
        db=sqlite3.connect(str(self.path), timeout=10)
        db.row_factory=sqlite3.Row
        return db

    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()

    def _record(self, execution_id, event, detail):
        value=str(detail)[:500]
        with self._db() as db:
            cur=db.execute("INSERT INTO recovery_events(execution_id,event,detail,created_at) VALUES(?,?,?,?)",
                           (str(execution_id), event, MARKER if self.vault.encrypted else value, self._now()))
            if self.vault.encrypted:
                self.vault.pack("recovery."+str(cur.lastrowid), {"detail":value})

    def diagnose(self, execution_id):
        rec=self.tools.pending.get(str(execution_id))
        if not rec:
            return {"status":"not_found","execution_id":str(execution_id),"message":"Execução não encontrada."}
        state=str(rec.get("status","unknown"))
        tool=str(rec.get("tool",""))
        outcome=str(rec.get("target_outcome",""))
        if state in ("failed", "rejected", "android_rejected") or outcome=="user_reported_failure":
            category="execution_failure"
            cause=(rec.get("error_type") or rec.get("android_adapter_detail") or rec.get("result",{}).get("reason") or "Falha reportada sem detalhe técnico.")
            advice="Verificar permissões, conectividade e argumentos; depois preparar uma nova tentativa."
        elif state=="interrupted_requires_reprepare":
            category="interrupted_without_saved_arguments"; cause="Argumentos não foram guardados por falta de consentimento."
            advice="Preparar novamente a tarefa; os argumentos antigos não podem ser recuperados."
        elif state in ("dispatched", "android_accepted") and outcome not in ("user_reported_success",):
            category="external_result_unverified"; cause="O Android recebeu/aceitou o pedido, mas a conclusão na aplicação-alvo não foi verificada."
            advice="Verificar o telefone ou pedir feedback ao utilizador; não repetir às cegas."
        elif state in ("completed",) or outcome=="user_reported_success":
            category="no_recovery_needed"; cause="Não há falha registada."; advice="Não repetir a operação."
        else:
            category="not_recoverable_yet"; cause="Estado atual não indica uma falha recuperável."
            advice="Consultar o histórico e aguardar o resultado correto."
        retry_class=("read_only_reprepare_allowed" if tool in self.SAFE_READ_ONLY else
                     "never_automatic_manual_review" if tool in self.NON_RETRYABLE or rec.get("platform")=="android" else
                     "manual_review_required")
        result={"status":"diagnosed","execution_id":str(execution_id),"tool":tool,"execution_state":state,
                "category":category,"cause":str(cause)[:500],"recommendation":advice,
                "retry_policy":retry_class,"automatic_retry":False,"execution_performed":False}
        self._record(execution_id,"diagnosed",category)
        return result

    def prepare_recovery(self, execution_id, *, user_confirmed=False):
        """Cria um novo plano; nunca o executa. Só repete automaticamente? Não: requer confirmação."""
        rec=self.tools.pending.get(str(execution_id))
        if not rec: return {"status":"not_found","message":"Execução não encontrada."}
        diagnosis=self.diagnose(execution_id)
        if diagnosis["category"] in ("no_recovery_needed", "not_recoverable_yet", "external_result_unverified"):
            return {"status":"manual_review_required","diagnosis":diagnosis,"execution_performed":False}
        if not user_confirmed:
            return {"status":"confirmation_required","diagnosis":diagnosis,
                    "message":"Confirma explicitamente antes de preparar uma nova tentativa. Nada foi executado."}
        if rec.get("status")=="interrupted_requires_reprepare" or not rec.get("arguments"):
            return {"status":"reprepare_required","message":"Os argumentos não estão disponíveis. Prepara novamente a operação com os dados necessários."}
        tool=rec.get("tool")
        if tool in self.NON_RETRYABLE or rec.get("platform")=="android":
            return {"status":"manual_reprepare_required","message":"Operação externa ou não idempotente: cria um novo pedido manualmente e confirma os dados. Nenhuma repetição foi preparada.","execution_performed":False}
        if tool not in self.SAFE_READ_ONLY:
            return {"status":"manual_review_required","message":"A ferramenta não está na lista de leitura segura; é necessária revisão manual.","execution_performed":False}
        plan=self.tools.prepare(tool,dict(rec.get("arguments",{})),persist_context=False)
        self._record(execution_id,"recovery_plan_prepared",plan.get("status","unknown"))
        return {"status":"recovery_plan_prepared","original_execution_id":str(execution_id),
                "new_plan":plan.get("plan"),"message":"Novo plano de leitura preparado. Ainda não foi executado.",
                "execution_performed":False}

    def events(self, execution_id, limit=50):
        with self._db() as db:
            rows=db.execute("SELECT id,event,detail,created_at FROM recovery_events WHERE execution_id=? ORDER BY id DESC LIMIT ?",
                            (str(execution_id),max(1,min(int(limit),200)))).fetchall()
        result=[]
        for row in rows:
            item=dict(row)
            if item.get("detail")==MARKER:
                item["detail"]=self.vault.unpack("recovery."+str(item.get("id", "")), MARKER).get("detail", "[detalhe protegido indisponível]")
            result.append(item)
        return {"execution_id":str(execution_id),"events":result}

    def status(self):
        with self._db() as db: count=db.execute("SELECT COUNT(*) FROM recovery_events").fetchone()[0]
        return {"version":"5.2.0","recovery_events":count,"automatic_retry":False,
                "executes_actions":False,"sensitive_fields_encrypted":self.vault.encrypted,
                "storage":"sqlite_metadata_android_keystore_aes_256_gcm" if self.vault.encrypted else "local_sqlite_plaintext",
                "policy":"diagnose_then_human_review"}
