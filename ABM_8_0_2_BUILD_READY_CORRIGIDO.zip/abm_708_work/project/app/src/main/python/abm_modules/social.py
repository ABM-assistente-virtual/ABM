"""ABM SOCIAL: classificador heurístico de texto social, não de áudio ambiente."""
import re

class Social:
    THREATS = ("vou bater", "vou-te bater", "vou te bater", "vou matar", "vou-te matar", "vou te matar", "vou atacar")
    INSULTS = ("és burro", "es burro", "idiota", "estúpido", "estupido", "parvo", "imbecil", "palhaço", "palhaco")

    def analyze_text(self, text: str) -> dict:
        value = " ".join(str(text).casefold().split())
        threat = any(term in value for term in self.THREATS)
        insult = any(term in value for term in self.INSULTS)
        if threat:
            level, recommendation = "alto", "Afasta-te, procura um local seguro e informa um adulto de confiança, professor ou autoridade." 
        elif insult:
            level, recommendation = "moderado", "Podes responder com calma: 'Não aceito insultos. Vamos conversar com respeito.'" 
        else:
            level, recommendation = "não identificado", "O texto não contém indicadores claros nas regras simples do ABM." 
        return {"level": level, "indicators": [x for x in self.THREATS + self.INSULTS if x in value],
                "suggested_response": recommendation, "requires_human_judgment": True,
                "limitation": "Heurística de texto: pode falhar sarcasmo, contexto, dialetos e falsos positivos."}
