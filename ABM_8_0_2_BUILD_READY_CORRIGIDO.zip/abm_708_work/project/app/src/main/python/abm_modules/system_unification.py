"""Camada de unificação: inventário, dependências e diagnóstico dos departamentos ABM.
Não executa ações externas nem concede permissões.
"""
from dataclasses import dataclass
from typing import Dict, Any

@dataclass(frozen=True)
class DepartmentSpec:
    key: str
    label: str
    module_key: str
    purpose: str

DEPARTMENTS = (
    DepartmentSpec('brain','ABM BRAIN','brain','interpretação e raciocínio'),
    DepartmentSpec('ears','ABM EARS','ears','entrada de áudio e transcrição integrada'),
    DepartmentSpec('eyes','ABM EYES','eyes','entrada visual'),
    DepartmentSpec('voice','ABM VOICE','voice','saída de voz'),
    DepartmentSpec('body','ABM BODY','body','operações e capacidades locais'),
    DepartmentSpec('accessibility','ABM ACCESSIBILITY','accessibility_intelligence','preferências e recomendações acessíveis'),
    DepartmentSpec('autonomy','ABM AUTONOMY','autonomy','planeamento assistido'),
    DepartmentSpec('social','ABM SOCIAL','social','interação social'),
    DepartmentSpec('memory','ABM MEMORY','memory_store','memória local'),
    DepartmentSpec('security','ABM SECURITY','security','políticas e permissões'),
    DepartmentSpec('connect','ABM CONNECT','tool_connector','conectores de ferramentas'),
    DepartmentSpec('system','ABM SYSTEM','android_bridge','ponte de integração Android'),
    DepartmentSpec('interface','ABM INTERFACE','interaction','eventos de interação'),
    DepartmentSpec('cloud','ABM CLOUD','cloud_status','estado informativo do backend cloud'),
    DepartmentSpec('developer','ABM DEVELOPER','tool_engine','catálogo e execução controlada de ferramentas'),
)

class ABMSystemUnification:
    VERSION = '8.0.0'
    def __init__(self, modules: Dict[str, Any]):
        self.modules = modules
        self.dependencies = {
            'brain':['context_understanding','knowledge','memory_store'],
            'ears':['interaction','voice_access'],
            'eyes':['interaction','accessibility_intelligence'],
            'voice':['interaction'],
            'body':['tool_engine','device_control'],
            'accessibility':['interaction','android_bridge'],
            'autonomy':['decision_engine','continuous_operation'],
            'social':['memory_store','security'],
            'memory':['knowledge','contextual_memory'],
            'security':['tool_engine','device_control'],
            'connect':['tool_engine','cross_department'],
            'system':['device_control','accessibility_intelligence'],
            'interface':['interaction','voice_access'],
            'cloud':['cloud_status'],
            'developer':['tool_connector','tool_engine'],
        }

    def _present(self, key):
        return key in self.modules and self.modules[key] is not None

    def status(self):
        items=[]
        for spec in DEPARTMENTS:
            present=self._present(spec.module_key)
            dependencies=self.dependencies.get(spec.key, [])
            missing=[name for name in dependencies if not self._present(name)]
            # Availability means the local adapter exists; readiness is reported separately.
            if missing:
                readiness='blocked_missing_dependencies'
            elif spec.key == 'cloud':
                readiness='adapter_only_external_deployment_required'
            elif spec.key in ('ears','eyes','voice','body','accessibility','system'):
                readiness='android_runtime_permission_or_device_required'
            elif spec.key == 'interface':
                readiness='interaction_core_present_avatar_experience_partial'
            else:
                readiness='local_component_initialized'
            items.append({'id':spec.key,'name':spec.label,'module':spec.module_key,
                          'available':present,'dependencies_available':not missing,
                          'missing_dependencies':missing,'readiness':readiness,
                          'purpose':spec.purpose,'dependencies':dependencies})
        available=sum(x['available'] for x in items)
        ready=sum(x['available'] and x['dependencies_available'] and
                  x['readiness']=='local_component_initialized' for x in items)
        return {'version':self.VERSION,'architecture':'single_runtime_department_registry',
                'departments_total':len(items),'departments_available':available,
                'departments_missing':[x['id'] for x in items if not x['available']],
                'departments_with_missing_dependencies':[x['id'] for x in items if x['missing_dependencies']],
                'departments_locally_initialized':ready,
                'departments':items,'safety':{
                    'external_actions_auto_executed':False,
                    'permissions_granted_automatically':False,
                    'android_execution_requires_native_dispatch_and_result_verification':True},
                'integration_note':'Disponível significa que o adaptador está registado. A prontidão distingue núcleo local, permissões/dispositivo Android e implantação externa; não equivale a funcionamento completo.'}

    def validate(self):
        state=self.status()
        checks={
            'all_15_departments_registered':state['departments_total']==15,
            'all_department_modules_present':state['departments_available']==15,
            'all_department_dependencies_present':not state['departments_with_missing_dependencies'],
            'device_control_registered':self._present('device_control'),
            'interaction_registered':self._present('interaction'),
            'security_registered':self._present('security'),
            'tool_engine_registered':self._present('tool_engine'),
            'cloud_is_not_claimed_active':not self._present('cloud_runtime'),
            'cloud_adapter_is_not_misreported_as_deployed':self.modules.get('cloud_status',{}).get('runtime_connected',False) is False,
        }
        return {'version':self.VERSION,'passed':all(checks.values()),'checks':checks,
                'available':state['departments_available'],'total':state['departments_total'],
                'locally_initialized':state['departments_locally_initialized'],
                'missing_dependencies':state['departments_with_missing_dependencies']}
