"""ABM GENERAL TASK ENGINE.

Planeador extensível de tarefas em linguagem natural. Descobre capacidades
registadas em runtime, prepara planos e distingue planeamento de execução.
Não afirma executar ferramentas que não estejam ligadas ao Android.
Compatível com Python 3.11 / Chaquopy.
"""
from __future__ import annotations

import re
import time
import uuid
from typing import Any, Callable, Dict, Optional


class CapabilityRegistry:
    def __init__(self):
        self._items: Dict[str, dict] = {}

    def register(self, name: str, description: str, handler: Optional[Callable] = None,
                 needs_confirmation: bool = False, platforms=None):
        key = str(name).strip().lower()
        if not key:
            raise ValueError("A capacidade precisa de um nome.")
        self._items[key] = {
            "name": key, "description": str(description), "handler": handler,
            "needs_confirmation": bool(needs_confirmation),
            "platforms": list(platforms or ["android"]),
        }
        return key

    def get(self, name):
        return self._items.get(str(name).lower())

    def describe(self):
        return [{k: v for k, v in item.items() if k != "handler"}
                for item in self._items.values()]

    def names(self):
        return list(self._items.keys())


class GeneralTaskEngine:
    ACTION_WORDS = re.compile(
        r"\b(faz|fazer|cria|criar|abre|abrir|procura|procurar|pesquisa|pesquisar|"
        r"organiza|organizar|explica|explicar|analisa|analisar|resume|resumir|"
        r"traduz|traduzir|escreve|escrever|edita|editar|envia|enviar|guarda|guardar|"
        r"calcula|calcular|instala|instalar|prepara|preparar|planeia|planear|"
        r"ajuda-me|preciso que|quero que|podes)\b", re.I)

    def __init__(self, body=None, autonomy=None, connector=None):
        self.body = body
        self.autonomy = autonomy
        self.connector = connector
        self.registry = CapabilityRegistry()
        self.history = []
        self._brain = None
        self._register_native_capabilities()

    def _register_native_capabilities(self):
        if self.connector is not None:
            for capability in self.connector.capabilities():
                name = capability["name"]
                self.registry.register(name, capability["description"],
                    handler=lambda context, cap=name: self.connector.execute(cap, context),
                    needs_confirmation=(name == "android.dial"), platforms=["android"] if name.startswith("android.") else ["local"])
        else:
            self.registry.register("android.open_app", "Abrir uma aplicação instalada pelo nome.", platforms=["android"])
            self.registry.register("android.open_camera", "Abrir a aplicação de câmara.", platforms=["android"])
            self.registry.register("android.choose_file", "Selecionar ficheiros com o seletor oficial do Android.", platforms=["android"])
        self.registry.register("android.speech_to_text", "Converter fala em texto pelo serviço de voz do Android.", platforms=["android"])
        self.registry.register("android.text_to_speech", "Ler respostas em voz alta pelo Android.", platforms=["android"])
        if self.connector is None:
            self.registry.register("android.web_search", "Abrir pesquisa na Web.", platforms=["android"])
            self.registry.register("android.dial", "Abrir o marcador; a chamada é confirmada manualmente.", needs_confirmation=True, platforms=["android"])
        self.registry.register("abm.analyze_image", "Analisar imagem com os módulos de visão disponíveis.")
        self.registry.register("abm.analyze_audio", "Analisar áudio fornecido pelo utilizador.")
        self.registry.register("abm.create_goal", "Guardar um objetivo e dividir o trabalho em passos.",
                              handler=self._handle_create_goal)
        self.registry.register("abm.task_planning", "Decompor um pedido novo em etapas e requisitos.",
                              handler=self._handle_task_planning)
        self.registry.register("abm.conversation", "Conversar e raciocinar com o núcleo ABM.",
                              handler=self._handle_conversation)
        self.registry.register("abm.calculate", "Efetuar cálculos aritméticos simples com avaliação segura.",
                              handler=self._handle_calculate)

    def register_capability(self, name, description, handler=None, needs_confirmation=False, platforms=None):
        """Permite acrescentar novas ferramentas sem editar o motor central."""
        return self.registry.register(name, description, handler, needs_confirmation, platforms)

    @staticmethod
    def _clean(text):
        return re.sub(r"\s+", " ", str(text or "")).strip()

    def _infer_capabilities(self, request):
        low = request.casefold()
        found = []
        if re.search(r"\b(calcula|calcular|quanto e|quanto é|resolve)\b", low) and re.search(r"[0-9]", low):
            found.append("abm.calculate")
        if re.search(r"\b(?:abre|abrir|inicia|iniciar|executa|executar)\b", low):
            if "câmara" in low or "camera" in low:
                found.append("android.open_camera")
            elif any(x in low for x in ("ficheiro", "ficheiros", "documento", "documentos")):
                found.append("android.choose_file")
            elif any(x in low for x in ("youtube", "whatsapp", "chrome", "definições", "configurações")) or re.search(r"\bapp\b|aplica", low):
                found.append("android.open_app")
        if any(x in low for x in ("pesquisa", "pesquisar", "procura na internet", "procura na web", "busca na internet")):
            found.append("android.web_search")
        if any(x in low for x in ("pausa a música", "para a música", "pausar música", "pausa a musica")):
            found.append("android.pause_media")
        if any(x in low for x in ("liga para", "telefonar", "fazer chamada para")):
            found.append("android.dial")
        if re.search(r"https?://", low):
            found.append("android.open_url")
        if any(x in low for x in ("mapa", "localiza", "onde fica")):
            found.append("android.open_maps")
        if any(x in low for x in ("partilha", "compartilha", "partilhar", "compartilhar")):
            found.append("android.share_text")
        if "definições" in low or "configurações" in low:
            found.append("android.open_settings")
        if any(x in low for x in ("cria uma nota", "guarda esta nota", "anota isto", "escreve uma nota")):
            found.append("abm.create_note")
        if any(x in low for x in ("lista as notas", "mostrar notas", "mostra as notas", "listar notas")):
            found.append("abm.list_notes")
        if "lê a nota" in low or "le a nota" in low:
            found.append("abm.read_note")
        if re.search(r"\b(abr(e|ir)|inicia|abre)\b", low):
            if "câmara" in low or "camera" in low:
                found.append("android.open_camera")
            elif re.search(r"\b(aplicativo|aplicação|app|programa)\b", low):
                found.append("android.open_app")
            elif "youtube" in low or "whatsapp" in low:
                found.append("android.open_app")
        if any(x in low for x in ("fotografia", "imagem", "fotografia", "foto", "fotograma")):
            if any(x in low for x in ("analisa", "identifica", "descreve", "vê", "ve")):
                found.append("abm.analyze_image")
        if any(x in low for x in ("áudio", "audio", "gravação", "gravacao", "wav")):
            if any(x in low for x in ("analisa", "ouve", "escuta", "transcreve")):
                found.append("abm.analyze_audio")
        if any(x in low for x in ("pesquisa", "procura na internet", "procura na web", "pesquisar na web")):
            found.append("android.web_search")
        if any(x in low for x in ("liga para", "telefonar", "fazer chamada")):
            found.append("android.dial")
        if any(x in low for x in ("objetivo", "plano de trabalho", "planeia", "planear", "organiza", "organizar", "prepara", "preparar", "quero fazer", "preciso de fazer")):
            found.append("abm.create_goal")
        if self.ACTION_WORDS.search(request):
            found.append("abm.task_planning")
        if not found:
            found.append("abm.conversation")
        # preservar ordem sem duplicados
        return list(dict.fromkeys(found))

    def _handle_create_goal(self, context):
        if self.autonomy is None:
            return {"ok": False, "reason": "O módulo AUTONOMY não está disponível."}
        goal = self.autonomy.add_goal(context["request"], context.get("step_descriptions", []))
        return {"ok": True, "goal_id": goal["id"], "description": goal["description"]}

    def _handle_task_planning(self, context):
        return {"ok": True, "request": context["request"],
                "steps": context.get("step_descriptions", []), "note": "Plano preparado; não representa execução externa."}

    def _handle_conversation(self, context):
        brain = context.get("brain")
        if callable(brain):
            return {"ok": True, "response": str(brain(context["request"]))}
        return {"ok": False, "reason": "O cérebro não foi ligado ao executor."}

    def _handle_calculate(self, context):
        # Parser aritmético restrito: apenas números e operadores, sem eval/exec.
        import ast
        expression = context["request"]
        expression = re.sub(r"(?i)^.*?\b(?:calcula|calcular|quanto é|quanto e|resolve)\b", "", expression).strip(" :?=")
        expression = expression.replace("×", "*").replace("÷", "/").replace("^", "**")
        try:
            if not expression or len(expression) > 120:
                raise ValueError("Expressão vazia ou demasiado longa.")
            tree = ast.parse(expression, mode="eval")
            if sum(1 for _ in ast.walk(tree)) > 80:
                raise ValueError("Expressão demasiado complexa.")
            allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Constant, ast.Add, ast.Sub,
                       ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow, ast.USub, ast.UAdd, ast.Load)
            if any(not isinstance(node, allowed) for node in ast.walk(tree)):
                raise ValueError("Expressão não permitida.")
            if any(isinstance(node, ast.Constant) and (not isinstance(node.value, (int, float)) or isinstance(node.value, bool)) for node in ast.walk(tree)):
                raise ValueError("Só são permitidos números.")
            if any(isinstance(node, ast.Pow) for node in ast.walk(tree)):
                for node in ast.walk(tree):
                    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Pow) and (not isinstance(node.right, ast.Constant) or abs(float(node.right.value)) > 100):
                        raise ValueError("Expoente acima do limite permitido.")
            value = eval(compile(tree, "<abm-calculation>", "eval"), {"__builtins__": {}}, {})
            if isinstance(value, complex) or abs(float(value)) > 1e100:
                raise ValueError("Resultado fora do limite permitido.")
            return {"ok": True, "expression": expression, "result": value}
        except Exception as exc:
            return {"ok": False, "reason": "Não consegui calcular essa expressão: " + str(exc)}

    def execute(self, plan_id, brain=None, approved=False):
        record = next((item for item in self.history if item["id"] == str(plan_id)), None)
        if record is None:
            return {"status": "not_found", "message": "Plano não encontrado nesta sessão."}
        if record.get("status") == "completed":
            return {"status": "completed", "results": record.get("results", [])}
        results = []
        context = {"request": record["request"], "brain": brain,
                   "step_descriptions": [step["description"] for step in record["steps"]]}
        blocked = []
        for cap in record["capabilities"]:
            item = self.registry.get(cap)
            if item is None:
                blocked.append({"capability": cap, "reason": "Capacidade não registada."})
                continue
            if item["needs_confirmation"] and not approved:
                blocked.append({"capability": cap, "reason": "Esta ação exige confirmação explícita."})
                continue
            handler = item.get("handler")
            if not callable(handler):
                blocked.append({"capability": cap, "reason": "Ferramenta ainda não ligada ao executor Android."})
                continue
            try:
                result = handler(context)
                results.append({"capability": cap, "result": result})
            except Exception as exc:
                results.append({"capability": cap, "ok": False, "error": str(exc)})
                blocked.append({"capability": cap, "reason": "A ferramenta devolveu um erro."})
        record["results"] = results
        record["blocked"] = blocked
        record["status"] = "completed" if not blocked else ("partially_completed" if results else "blocked")
        return {"status": record["status"], "plan_id": record["id"],
                "results": results, "blocked": blocked,
                "message": "Execução concluída." if not blocked else "Algumas etapas não foram executadas; veja os motivos."}

    def _make_steps(self, request, capabilities):
        steps = [{"number": 1, "description": "Interpretar o objetivo e identificar os dados necessários.", "status": "ready"}]
        for cap in capabilities:
            item = self.registry.get(cap)
            if cap == "abm.conversation":
                steps.append({"number": len(steps)+1, "description": "Usar o cérebro ABM para responder ou decompor o pedido.", "status": "ready"})
            else:
                steps.append({"number": len(steps)+1, "description": item["description"], "capability": cap,
                              "status": "requires_android_or_module"})
        steps.append({"number": len(steps)+1, "description": "Verificar o resultado e informar o utilizador do que foi realmente concluído.", "status": "ready"})
        return steps

    def process(self, request, brain=None):
        self._brain = brain
        text = self._clean(request)
        if not text:
            return {"status": "needs_input", "message": "Diz-me o que queres realizar."}
        capabilities = self._infer_capabilities(text)
        actionable = bool(self.ACTION_WORDS.search(text)) or len(capabilities) > 1 or capabilities[0] != "abm.conversation"
        if not actionable:
            answer = brain(text) if callable(brain) else "Estou a analisar o que disseste."
            return {"status": "conversation", "response": str(answer), "goal": text,
                    "capabilities": capabilities}

        missing = [c for c in capabilities if self.registry.get(c) is None]
        steps = self._make_steps(text, capabilities)
        plan_id = uuid.uuid4().hex[:12]
        record = {"id": plan_id, "request": text, "created_at": time.time(),
                  "status": "planned", "capabilities": capabilities, "steps": steps,
                  "missing_capabilities": missing}
        self.history.append(record)
        # Objetivos são persistidos no módulo AUTONOMY; a execução é separada.
        if len(capabilities) == 1 and capabilities[0] == "abm.conversation":
            response = brain(text) if callable(brain) else "Posso ajudar a planear isso."
            record["status"] = "answered"
            return {"status": "conversation", "response": str(response), "plan": record}
        confirmations = [c for c in capabilities if self.registry.get(c) and self.registry.get(c)["needs_confirmation"]]
        response = ("Compreendi o objetivo e preparei um plano. Ainda não vou afirmar que executei a tarefa: "
                    "cada etapa depende da ferramenta correspondente e, quando necessário, da tua confirmação.")
        return {"status": "planned", "response": response, "plan": record,
                "available_capabilities": self.registry.describe(),
                "confirmation_required": confirmations,
                "next_step": "Ligar cada capacidade ao executor Android e testar o resultado."}

    def status(self):
        executable = [name for name in self.registry.names() if callable(self.registry.get(name).get("handler"))]
        return {"engine": "ABM Execution Engine 1.4.0", "registered_capabilities": self.registry.names(),
                "executable_capabilities": executable, "plans_created": len(self.history),
                "extensible": True, "execution_requires_real_tool": True}
