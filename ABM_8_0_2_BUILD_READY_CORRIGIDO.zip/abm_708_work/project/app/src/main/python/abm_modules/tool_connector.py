"""ABM Universal Tool Connector 1.5.0.
Liga pedidos em linguagem natural a ferramentas locais e a pedidos de ação Android.
Ações Android são devolvidas à Activity para execução através de APIs oficiais.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Any


class UniversalToolConnector:
    def __init__(self, data_dir: str):
        self.root = Path(data_dir) / "abm_workspace"
        self.notes = self.root / "notes"
        self.notes.mkdir(parents=True, exist_ok=True)
        self.handlers = {}
        self.descriptions = {}
        self._register_defaults()

    def register(self, name: str, description: str, handler):
        key = str(name).strip().lower()
        if not key or not callable(handler):
            raise ValueError("Ferramenta precisa de nome e função executável.")
        self.handlers[key] = handler
        self.descriptions[key] = str(description)
        return key

    def _register_defaults(self):
        self.register("android.open_app", "Abrir uma aplicação instalada", self._open_app)
        self.register("android.open_camera", "Abrir a câmara do telefone", lambda c: self._android("open_camera"))
        self.register("android.choose_file", "Abrir seletor de ficheiros", lambda c: self._android("choose_file"))
        self.register("android.web_search", "Pesquisar na Internet no navegador", self._web_search)
        self.register("android.pause_media", "Pedir pausa ao leitor de multimédia", lambda c: self._android("pause_media"))
        self.register("android.dial", "Abrir marcador de telefone; chamada manual", self._dial)
        self.register("android.open_url", "Abrir um endereço Web no navegador", self._open_url)
        self.register("android.share_text", "Partilhar texto através do seletor Android", self._share_text)
        self.register("android.open_maps", "Abrir pesquisa de localizações no mapa", self._open_maps)
        self.register("android.open_settings", "Abrir definições Android", lambda c: self._android("open_settings"))
        self.register("abm.create_note", "Criar uma nota no espaço privado do ABM", self._create_note)
        self.register("abm.list_notes", "Listar notas guardadas pelo ABM", self._list_notes)
        self.register("abm.read_note", "Ler uma nota guardada pelo ABM", self._read_note)

    @staticmethod
    def _android(action: str, **args):
        return {"ok": True, "dispatch": "android", "action": action, "args": args,
                "message": "Pedido enviado à aplicação Android para execução."}

    def _open_app(self, context):
        request = context["request"]
        match = re.search(r"\b(?:abre|abrir|inicia|iniciar|executa|executar)\s+(?:o\s+|a\s+|os\s+|as\s+)?(.+)$", request, re.I)
        app = (match.group(1) if match else request).strip(" .!?\"'")
        if not app:
            return {"ok": False, "reason": "Indica o nome da aplicação."}
        return self._android("open_app", app_name=app)

    def _web_search(self, context):
        request = context["request"]
        query = re.sub(r"(?i)^.*?\b(?:pesquisa|pesquisar|procura|procurar|busca|buscar)\b", "", request).strip(" :? ")
        if not query:
            query = request
        return self._android("web_search", query=query)

    def _dial(self, context):
        request = context["request"]
        number = re.sub(r"(?i)^.*?\b(?:liga para|telefonar|fazer chamada para)\b", "", request).strip()
        return self._android("dial", number=number)

    def _open_url(self, context):
        request = context["request"].strip()
        match = re.search(r"https?://[^\s]+", request)
        url = match.group(0).rstrip(".,!?)]}") if match else ""
        if not url:
            return {"ok": False, "reason": "Indica um endereço que comece por https:// ou http://."}
        return self._android("open_url", url=url)

    def _share_text(self, context):
        return self._android("share_text", text=context["request"][:5000])

    def _open_maps(self, context):
        query = context["request"].strip()
        query = re.sub(r"(?i)^.*?\b(?:mapa|mapas|localiza|localizar|onde fica)\b", "", query).strip(" :? ")
        if not query:
            return {"ok": False, "reason": "Indica o local que queres procurar."}
        return self._android("open_maps", query=query[:300])

    def _create_note(self, context):
        body = context["request"].strip()
        name = "nota_" + str(__import__('time').time_ns()) + ".txt"
        path = self.notes / name
        path.write_text(body, encoding="utf-8")
        return {"ok": True, "file": name, "path": str(path), "characters": len(body)}

    def _list_notes(self, context):
        files = sorted(p.name for p in self.notes.glob("*.txt"))
        return {"ok": True, "notes": files, "count": len(files)}

    def _read_note(self, context):
        requested = context.get("note_name", "")
        if not requested:
            m = re.search(r"(?i)(?:nota\s+)([\w.-]+)", context["request"])
            requested = m.group(1) if m else ""
        # Apenas nomes simples dentro da pasta de notas; impede traversal.
        if not requested or Path(requested).name != requested:
            return {"ok": False, "reason": "Indica o nome exato da nota, sem caminhos."}
        path = self.notes / requested
        if not path.is_file() or path.suffix.lower() != ".txt":
            return {"ok": False, "reason": "Nota não encontrada."}
        return {"ok": True, "file": requested, "content": path.read_text(encoding="utf-8")[:20000]}

    def execute(self, capability: str, context: dict) -> dict:
        handler = self.handlers.get(str(capability).lower())
        if handler is None:
            return {"ok": False, "reason": "Ferramenta não registada."}
        return handler(context)

    def capabilities(self):
        return [{"name": k, "description": v} for k, v in self.descriptions.items()]
