"""ABM 4.7.0 — motor seguro de descoberta e execução de ferramentas registadas.
Não importa código arbitrário nem executa ferramentas desconhecidas.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from uuid import uuid4
from datetime import datetime, timezone
from typing import Any
from .execution_history import ExecutionHistoryStore


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    required: tuple[str, ...] = ()
    optional: tuple[str, ...] = ()
    platform: str = "local"
    risk: str = "low"
    requires_confirmation: bool = False
    enabled: bool = True


class UniversalToolEngine:
    """Catálogo, pesquisa, validação, aprovação e despacho auditável."""
    def __init__(self, connector, security=None, history_path=None, secure_store=None):
        if connector is None:
            raise ValueError("UniversalToolConnector é obrigatório.")
        self.connector = connector
        self.security = security
        self.specs: dict[str, ToolSpec] = {}
        self.pending: dict[str, dict] = {}
        self.audit: list[dict] = []
        self.history_store = ExecutionHistoryStore(history_path, secure_store=secure_store) if history_path else None
        self._load_connector_tools()
        if self.history_store:
            for recovered in self.history_store.recover():
                self.pending[recovered["execution_id"]] = recovered

    def _load_connector_tools(self):
        policies = {
            "android.dial": ("android", "high", True, ("request",), ()),
            "android.share_text": ("android", "medium", True, ("request",), ()),
            "android.open_app": ("android", "low", False, ("request",), ()),
            "android.open_camera": ("android", "medium", True, (), ()),
            "android.choose_file": ("android", "medium", True, (), ()),
            "android.web_search": ("android", "low", False, ("request",), ()),
            "android.pause_media": ("android", "low", False, (), ()),
            "android.open_url": ("android", "low", False, ("request",), ()),
            "android.open_maps": ("android", "low", False, ("request",), ()),
            "android.open_settings": ("android", "low", False, (), ()),
            "abm.create_note": ("local", "low", False, ("request",), ()),
            "abm.list_notes": ("local", "low", False, (), ()),
            "abm.read_note": ("local", "low", False, ("note_name",), ()),
        }
        for item in self.connector.capabilities():
            name = item["name"]
            platform, risk, confirm, required, optional = policies.get(
                name, ("local", "medium", True, (), ()))
            self.register(ToolSpec(name, item.get("description", name), required,
                                   optional, platform, risk, confirm, True))

    def register(self, spec: ToolSpec):
        if not isinstance(spec, ToolSpec) or not spec.name or not spec.description:
            raise ValueError("Definição de ferramenta inválida.")
        key = spec.name.strip().lower()
        if key not in self.connector.handlers:
            raise ValueError("Só é possível registar ferramentas com handler local previamente registado.")
        self.specs[key] = spec
        return key

    def discover(self, query: str = ""):
        q = str(query or "").strip().casefold()
        rows = []
        for spec in self.specs.values():
            haystack = (spec.name + " " + spec.description + " " + spec.platform).casefold()
            if not q or q in haystack:
                rows.append(asdict(spec))
        return {"count": len(rows), "tools": rows,
                "discovery": "registered_handlers_only", "executes_nothing": True}

    def prepare(self, name: str, arguments: dict[str, Any] | None = None, *, persist_context: bool = False):
        key = str(name or "").strip().lower()
        spec = self.specs.get(key)
        if spec is None or not spec.enabled:
            return {"status": "not_found", "message": "Ferramenta não registada ou desativada."}
        args = arguments or {}
        if not isinstance(args, dict):
            return {"status": "invalid_arguments", "message": "Os argumentos devem ser um objeto JSON."}
        missing = [field for field in spec.required if field not in args or args[field] in (None, "")]
        allowed = set(spec.required) | set(spec.optional)
        unknown = sorted(set(args) - allowed)
        if missing or unknown:
            return {"status": "invalid_arguments", "missing": missing, "unknown": unknown,
                    "allowed": sorted(allowed)}
        execution_id = uuid4().hex
        record = {"execution_id": execution_id, "tool": key, "arguments": dict(args),
                  "status": "awaiting_confirmation" if spec.requires_confirmation else "ready",
                  "requires_confirmation": spec.requires_confirmation,
                  "risk": spec.risk, "platform": spec.platform,
                  "created_at": datetime.now(timezone.utc).isoformat(),
                  "persist_context": bool(persist_context)}
        self.pending[execution_id] = record
        self._audit("prepared", execution_id, key, record["status"])
        return {"status": record["status"], "plan": dict(record),
                "message": "Plano preparado; nenhuma ferramenta foi executada.",
                "persistence": ("argumentos guardados localmente por consentimento explícito; base não cifrada" if persist_context
                                else "apenas metadados persistidos; argumentos não serão recuperáveis após reinício")}

    def execute(self, execution_id: str, *, confirmed: bool = False):
        record = self.pending.get(str(execution_id))
        if not record:
            return {"status": "not_found", "message": "Plano de ferramenta não encontrado."}
        if record["status"] in ("completed", "dispatched", "android_accepted", "android_rejected"):
            return {"status": "already_executed", "message": "Este plano já foi executado ou encaminhado."}
        spec = self.specs[record["tool"]]
        if spec.requires_confirmation and not confirmed:
            return {"status": "confirmation_required", "message": "Confirma explicitamente antes de executar.",
                    "execution_id": execution_id}
        if spec.risk == "high" and self.security:
            auth = self.security.authorize("make_call", confirmed=confirmed, permission="phone")
            if not auth.get("allowed"):
                return {"status": "blocked", "authorization": auth, "execution_id": execution_id}
        context = dict(record["arguments"])
        context.setdefault("request", "")
        try:
            result = self.connector.execute(record["tool"], context)
        except Exception as exc:
            record["status"] = "failed"
            self._audit("failed", execution_id, record["tool"], type(exc).__name__)
            return {"status": "failed", "message": "A ferramenta devolveu um erro controlado.",
                    "error_type": type(exc).__name__}
        record["result"] = result
        if result.get("dispatch") == "android":
            record["status"] = "dispatched"
            self._audit("android_dispatched", execution_id, record["tool"], "awaiting_device_result")
            return {"status": "dispatched", "execution_id": execution_id,
                    "tool": record["tool"], "result": result, "external_execution": True,
                    "message": "Pedido encaminhado à Activity Android; aguarda resultado do adaptador no dispositivo."}
        record["status"] = "completed" if result.get("ok") else "rejected"
        self._audit("executed", execution_id, record["tool"], "ok" if result.get("ok") else "rejected")
        return {"status": record["status"], "execution_id": execution_id,
                "tool": record["tool"], "result": result, "external_execution": False,
                "message": "Ferramenta local executada."}

    def record_android_result(self, execution_id: str, accepted: bool, detail: str = ""):
        """Regista se o adaptador Android aceitou/iniciou o Intent; não prova a conclusão na app-alvo."""
        record = self.pending.get(str(execution_id))
        if not record:
            return {"status": "not_found", "message": "Execução não encontrada."}
        if record.get("status") != "dispatched":
            return {"status": "invalid_state", "message": "A execução não está à espera de resultado Android."}
        record["status"] = "android_accepted" if bool(accepted) else "android_rejected"
        record["android_adapter_detail"] = str(detail)[:500]
        self._audit("android_result", execution_id, record["tool"], record["status"])
        return {"status": record["status"], "message": (
            "O Android aceitou o pedido de abertura/ação; a conclusão dentro da aplicação não foi verificada."
            if accepted else "O adaptador Android não conseguiu iniciar a ação.")}

    def record_target_outcome(self, execution_id: str, outcome: str, evidence: str = ""):
        """Regista feedback explícito do utilizador; não o confunde com verificação automática."""
        record = self.pending.get(str(execution_id))
        if not record:
            return {"status": "not_found", "message": "Execução não encontrada."}
        if record.get("status") != "android_accepted":
            return {"status": "invalid_state", "message": "Só é possível avaliar uma ação aceite pelo adaptador Android."}
        if record.get("target_outcome"):
            return {"status": "invalid_state", "message": "O resultado desta execução já foi registado."}
        value = str(outcome or "").strip().lower()
        allowed = {"success", "failure", "unknown"}
        if value not in allowed:
            return {"status": "invalid_outcome", "allowed": sorted(allowed)}
        labels = {"success": "user_reported_success", "failure": "user_reported_failure", "unknown": "unverified"}
        record["target_outcome"] = labels[value]
        record["target_evidence"] = str(evidence or "")[:500]
        record["target_outcome_at"] = datetime.now(timezone.utc).isoformat()
        self._audit("target_outcome_reported", execution_id, record["tool"], labels[value])
        messages = {
            "success": "O utilizador informou que a tarefa foi concluída. Isto é feedback do utilizador, não verificação automática do Android.",
            "failure": "O utilizador informou que a tarefa não foi concluída. O ABM registou a falha reportada.",
            "unknown": "O resultado final permanece por verificar. O ABM não vai afirmar que a tarefa foi concluída."
        }
        return {"status": labels[value], "message": messages[value], "execution_id": str(execution_id)}

    def get_execution_status(self, execution_id: str):
        """Devolve um resumo seguro do estado sem expor argumentos potencialmente privados."""
        record = self.pending.get(str(execution_id))
        if not record:
            return {"status": "not_found", "message": "Execução não encontrada."}
        return {"status": record.get("status"), "execution_id": str(execution_id),
                "tool": record.get("tool"), "target_outcome": record.get("target_outcome", "unverified"),
                "created_at": record.get("created_at"), "target_outcome_at": record.get("target_outcome_at")}

    def _audit(self, event, execution_id, tool, outcome):
        item = {"event": event, "execution_id": execution_id, "tool": tool,
                "outcome": outcome, "at": datetime.now(timezone.utc).isoformat()}
        self.audit.append(item)
        if self.history_store and execution_id in self.pending:
            self.history_store.save(self.pending[execution_id], event=event, outcome=outcome)

    def list_history(self, limit=50):
        if not self.history_store:
            return {"persistent": False, "records": []}
        return {"persistent": True, "records": self.history_store.list_history(limit)}

    def execution_events(self, execution_id, limit=100):
        if not self.history_store:
            return {"persistent": False, "events": []}
        return {"persistent": True, "events": self.history_store.events(execution_id, limit)}

    def resume_execution(self, execution_id, *, confirmed=False):
        record = self.pending.get(str(execution_id))
        if not record:
            return {"status": "not_found", "message": "Execução não encontrada no histórico."}
        if record.get("status") == "interrupted_requires_reprepare":
            return {"status": "reprepare_required", "message": "A operação foi interrompida. Os argumentos não foram guardados; prepara novamente para proteger os teus dados."}
        if not record.get("recovered"):
            return {"status": "not_interrupted", "message": "Esta execução ainda pertence à sessão atual."}
        if record.get("status") in ("dispatched", "android_accepted", "android_rejected", "completed", "rejected", "failed"):
            return {"status": "recovered_status", "execution": self.get_execution_status(execution_id),
                    "message": "Estado recuperado. Não foi repetida nenhuma ação automaticamente."}
        record.pop("recovered", None)
        return self.execute(str(execution_id), confirmed=confirmed)

    def status(self):
        return {"registered_tools": len(self.specs), "pending_plans": sum(
            x["status"] in ("ready", "awaiting_confirmation") for x in self.pending.values()),
            "audit_events": len(self.audit), "unknown_code_imports": False,
            "auto_execution": False,
            "persistent_history": self.history_store.status() if self.history_store else {"persistent": False}}
