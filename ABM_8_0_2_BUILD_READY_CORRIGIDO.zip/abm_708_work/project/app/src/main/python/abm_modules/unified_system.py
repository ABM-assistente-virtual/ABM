"""ABM 4.1: barramento comum entre departamentos, com limites explícitos."""
from __future__ import annotations
from datetime import datetime, timezone
from .advanced_brain import AdvancedBrainPlanner

DEPARTMENTS = [
    {"id": "brain", "name": "ABM BRAIN", "area": "inteligência e raciocínio", "status": "integrated", "runtime": "Brain + ABM 5.2"},
    {"id": "ears", "name": "ABM EARS", "area": "áudio e análise WAV; STT via Android", "status": "prototype", "runtime": "Ears + SpeechRecognizer Android"},
    {"id": "eyes", "name": "ABM EYES", "area": "análise de imagem e visão ML Kit", "status": "prototype", "runtime": "Eyes + ML Kit"},
    {"id": "voice", "name": "ABM VOICE", "area": "preparação de respostas e TTS Android", "status": "prototype", "runtime": "Voice + TextToSpeech Android"},
    {"id": "body", "name": "ABM BODY", "area": "ferramentas e ações Android permitidas", "status": "prototype", "runtime": "Body + UniversalToolConnector"},
    {"id": "accessibility", "name": "ABM ACCESSIBILITY", "area": "cursor, gestos, varrimento e interruptores", "status": "prototype", "runtime": "Android AccessibilityService"},
    {"id": "autonomy", "name": "ABM AUTONOMY", "area": "objetivos e planeamento", "status": "integrated", "runtime": "Autonomy + GeneralTaskEngine"},
    {"id": "social", "name": "ABM SOCIAL", "area": "análise social heurística", "status": "prototype", "runtime": "Social"},
    {"id": "memory", "name": "ABM MEMORY", "area": "estado local e histórico", "status": "prototype", "runtime": "ABMCompanion JSON"},
    {"id": "security", "name": "ABM SECURITY", "area": "permissões e confirmações", "status": "integrated", "runtime": "Security"},
    {"id": "connect", "name": "ABM CONNECT", "area": "conectores e API cloud", "status": "prototype", "runtime": "UniversalToolConnector + CloudApiClient"},
    {"id": "system", "name": "ABM SYSTEM", "area": "integração Android", "status": "prototype", "runtime": "Android APIs"},
    {"id": "interface", "name": "ABM INTERFACE", "area": "interface, voz e cursor", "status": "prototype", "runtime": "MainActivity + overlays"},
    {"id": "cloud", "name": "ABM CLOUD", "area": "contas, fila, tarefas e API", "status": "prototype", "runtime": "FastAPI + PostgreSQL/Redis opcionais"},
    {"id": "developer", "name": "ABM DEVELOPER", "area": "registo extensível de capacidades", "status": "prototype", "runtime": "CapabilityRegistry"},
]

class UnifiedABM:
    """Entrada única e barramento explícito para chamadas entre departamentos."""
    def __init__(self, task_engine, modules=None):
        if task_engine is None:
            raise ValueError("GeneralTaskEngine é obrigatório.")
        self.task_engine = task_engine
        self.modules = modules or {}
        self.dispatch_count = 0
        self.last_dispatch = None
        self.advanced_brain = AdvancedBrainPlanner(self.modules.get("contextual_memory"))

    def departments(self):
        return [dict(item) for item in DEPARTMENTS]

    def department_summary(self):
        counts = {"integrated": 0, "prototype": 0, "planned": 0}
        for item in DEPARTMENTS:
            counts[item["status"]] += 1
        return {"total": len(DEPARTMENTS), "counts": counts, "departments": self.departments()}

    def plan_task(self, request, brain=None):
        if not str(request or "").strip():
            raise ValueError("O pedido não pode estar vazio.")
        result = self.task_engine.process(request, brain)
        result["orchestrator"] = "ABM_UNIFIED_4.7.0"
        result["department_catalog"] = "15_departments"
        return result

    def advanced_plan(self, request, profile_id="default", include_memory=False):
        """Cria plano multi-etapas auditável; não executa ações externas."""
        result = self.advanced_brain.create_plan(request, profile_id=profile_id,
                                                 include_memory=include_memory)
        if result.get("plan_id"):
            result["orchestrator"] = "ABM_UNIFIED_4.7.0"
            result["departments_available"] = [x["id"] for x in DEPARTMENTS]
        return result

    def verify_plan_step(self, plan_id, step_id, success, evidence, confirmed=False):
        return self.advanced_brain.record_step_result(
            plan_id, step_id, success=bool(success), evidence=evidence, confirmed=bool(confirmed))

    def advanced_brain_status(self):
        return self.advanced_brain.status()

    def dispatch(self, department, action, payload=None):
        """Executa apenas operações locais explícitas; pontes externas ficam pendentes."""
        dept, op = str(department).strip().lower(), str(action).strip().lower()
        data = payload if isinstance(payload, dict) else {}
        known = {d["id"] for d in DEPARTMENTS}
        if dept not in known:
            raise ValueError("Departamento desconhecido: " + dept)
        result = self._route(dept, op, data)
        self.dispatch_count += 1
        self.last_dispatch = {"department": dept, "action": op, "status": result.get("status"),
                              "at": datetime.now(timezone.utc).isoformat()}
        result.update({"department": dept, "action": op, "dispatch_id": self.dispatch_count})
        return result

    def _route(self, dept, op, data):
        m = self.modules
        if dept == "brain" and op == "think":
            return {"status": "ok", "result": m["brain"].think(data.get("text", ""))}
        if dept == "ears" and op == "transcript":
            return {"status": "ok", "result": m["ears"].normalize_transcript(data.get("text", ""))}
        if dept == "ears" and op == "analyze_wav":
            return {"status": "ok", "result": m["ears"].analyze_wav(data["path"])}
        if dept == "eyes" and op == "analyze_image":
            return {"status": "ok", "result": m["eyes"].analyze_image(data["path"])}
        if dept == "voice" and op == "prepare":
            return {"status": "ok", "result": m["voice"].prepare(data.get("text", ""))}
        if dept == "body" and op == "plan":
            return {"status": "ok", "result": m["body"].plan(data.get("text", ""))}
        if dept == "accessibility" and op in {"start_scan", "next", "select", "stop_scan", "show_cursor", "hide_cursor"}:
            return {"status": "needs_android_bridge", "result": {"command": op, "payload": data,
                    "message": "Pedido preparado; a execução depende do AccessibilityService Android ativo e do consentimento do utilizador."}}
        if dept == "autonomy" and op == "add_goal":
            return {"status": "ok", "result": m["autonomy"].add_goal(data.get("description", ""), data.get("steps"))}
        if dept == "social" and op == "analyze_text":
            return {"status": "ok", "result": m["social"].analyze_text(data.get("text", ""))}
        if dept == "memory" and op == "learn_feedback":
            result = m["adaptive_learning"].learn_feedback(data.get("topic"), data.get("input"), data.get("correction"), consent=bool(data.get("consent", False)))
            return {"status": "ok" if result.get("learned") else "consent_required", "result": result}
        if dept == "memory" and op == "set_preference":
            result = m["adaptive_learning"].set_preference(data.get("key"), data.get("value"), consent=bool(data.get("consent", False)))
            return {"status": "ok" if result.get("saved") else "consent_required", "result": result}
        if dept == "memory" and op == "get_preferences":
            return {"status": "ok", "result": m["adaptive_learning"].get_preferences()}
        if dept == "memory" and op == "learning_suggestions":
            return {"status": "ok", "result": m["adaptive_learning"].suggestions(data.get("text", ""), limit=data.get("limit", 5))}
        if dept == "memory" and op == "learning_status":
            return {"status": "ok", "result": m["adaptive_learning"].status()}
        if dept == "memory" and op == "context_remember":
            result = m["contextual_memory"].remember(
                data.get("topic"), data.get("content"), consent=bool(data.get("consent", False)),
                profile_id=data.get("profile_id", "default"), department=data.get("source_department", "brain"),
                sensitivity=data.get("sensitivity", "personal"), ttl_days=data.get("ttl_days", 0))
            return {"status": "ok" if result.get("stored") else "consent_required_or_rejected", "result": result}
        if dept == "memory" and op == "context_search":
            return {"status": "ok", "result": m["contextual_memory"].search(
                data.get("query", ""), profile_id=data.get("profile_id", "default"),
                department=data.get("source_department"), limit=data.get("limit", 5))}
        if dept == "memory" and op == "context_delete":
            return {"status": "ok", "result": m["contextual_memory"].delete(
                data.get("id", ""), profile_id=data.get("profile_id", "default"),
                confirmed=bool(data.get("confirmed", False)))}
        if dept == "memory" and op == "context_clear_profile":
            return {"status": "ok", "result": m["contextual_memory"].clear_profile(
                profile_id=data.get("profile_id", "default"), confirmed=bool(data.get("confirmed", False)))}
        if dept == "memory" and op == "context_audit":
            return {"status": "ok", "result": m["contextual_memory"].audit(
                profile_id=data.get("profile_id", "default"), limit=data.get("limit", 50))}
        if dept == "memory" and op == "context_purge_expired":
            return {"status": "ok", "result": m["contextual_memory"].purge_expired()}
        if dept == "memory" and op == "learning_clear":
            return {"status": "ok", "result": m["adaptive_learning"].clear(confirmed=bool(data.get("confirmed", False)))}
        if dept == "memory" and op == "remember":
            result = m["memory_store"].remember(data.get("text", ""),
                consent=bool(data.get("consent", False)), category=data.get("category", "general"),
                importance=data.get("importance", 3))
            return {"status": "ok" if result.get("stored") else "consent_required", "result": result}
        if dept == "memory" and op == "search":
            return {"status": "ok", "result": m["memory_store"].search(data.get("query", ""), limit=data.get("limit", 10))}
        if dept == "memory" and op == "list":
            return {"status": "ok", "result": m["memory_store"].list_memories(limit=data.get("limit", 50))}
        if dept == "memory" and op == "forget":
            return {"status": "ok", "result": m["memory_store"].forget(data.get("id", ""), confirmed=bool(data.get("confirmed", False)))}
        if dept == "memory" and op == "clear":
            return {"status": "ok", "result": m["memory_store"].clear(confirmed=bool(data.get("confirmed", False)))}
        if dept == "memory" and op == "export":
            return {"status": "ok", "result": {"json": m["memory_store"].export_json()}}
        if dept == "security" and op == "authorize":
            return {"status": "ok", "result": m["security"].authorize(data.get("action", ""),
                    confirmed=bool(data.get("confirmed", False)), permission=data.get("permission"))}
        if dept == "connect" and op == "list_tools":
            engine = m.get("tool_engine")
            return {"status": "ok", "result": engine.discover() if engine else m["tool_connector"].capabilities()}
        if dept == "connect" and op == "search_tools":
            return {"status": "ok", "result": m["tool_engine"].discover(data.get("query", ""))}
        if dept == "connect" and op == "prepare_tool":
            return {"status": "ok", "result": m["tool_engine"].prepare(data.get("name", ""), data.get("arguments", {}), persist_context=bool(data.get("persist_context", False)))}
        if dept == "connect" and op == "execute_tool":
            return {"status": "ok", "result": m["tool_engine"].execute(
                data.get("execution_id", ""), confirmed=bool(data.get("confirmed", False)))}
        if dept == "connect" and op == "tool_status":
            return {"status": "ok", "result": m["tool_engine"].status()}
        if dept == "connect" and op == "execution_history":
            return {"status": "ok", "result": m["tool_engine"].list_history(data.get("limit", 50))}
        if dept == "connect" and op == "resume_execution":
            return {"status": "ok", "result": m["tool_engine"].resume_execution(
                data.get("execution_id", ""), confirmed=bool(data.get("confirmed", False)))}
        if dept == "connect" and op == "execution_events":
            return {"status": "ok", "result": m["tool_engine"].execution_events(
                data.get("execution_id", ""), data.get("limit", 100))}
        if dept == "system" and op == "status":
            return {"status": "bridge_required", "result": {"platform": "Android", "message": "Estado detalhado requer consulta à camada Java/Android."}}
        if dept == "interface" and op == "prepare_response":
            return {"status": "ok", "result": m["voice"].prepare(data.get("text", ""))}
        if dept == "cloud" and op == "status":
            return {"status": "not_deployed", "result": {"configured": False, "message": "A presença do código cloud não significa que exista servidor publicado ou ligado."}}
        if dept == "developer" and op == "register_capability":
            name = self.task_engine.register_capability(data.get("name", ""), data.get("description", ""),
                    needs_confirmation=bool(data.get("needs_confirmation", False)), platforms=data.get("platforms", ["local"]))
            return {"status": "ok", "result": {"registered": name}}
        if op == "status":
            meta = next(item for item in DEPARTMENTS if item["id"] == dept)
            return {"status": "catalogued", "result": {"name": meta["name"],
                    "maturity": meta["status"], "runtime": meta["runtime"],
                    "note": "Estado do catálogo; não comprova serviço Android/cloud ativo."}}
        raise ValueError("Operação não suportada para " + dept + ": " + op)

    def coordinate_request(self, request, *, source="text", confirmed=False):
        """Coordena EARS -> BRAIN -> BODY/SECURITY -> MEMORY opcional -> VOICE.

        É um plano coordenado, não executa ações Android. A Activity precisa
        receber a ação e respeitar permissões/confirmacões do sistema.
        """
        raw = str(request or "").strip()
        if not raw:
            raise ValueError("O pedido não pode estar vazio.")
        trace = []
        normalized = raw
        if source == "voice":
            ears_result = self.modules["ears"].normalize_transcript(raw)
            normalized = ears_result["text"]
            trace.append({"department": "ears", "status": "ok", "result": ears_result})
        elif source != "text":
            raise ValueError("source deve ser 'text' ou 'voice'.")

        brain_result = self.modules["brain"].think(normalized)
        trace.append({"department": "brain", "status": "ok", "result": brain_result})
        body_result = self.modules["body"].plan(normalized)
        trace.append({"department": "body", "status": "ok", "result": body_result})

        authorization = None
        action = body_result.get("action")
        if action:
            security_action = {
                "dial_number": "make_call",
                "open_camera_app": "open_camera",
                "request_device_auth": "unlock_device",
            }.get(action, action)
            authorization = self.modules["security"].authorize(
                security_action, confirmed=bool(confirmed),
                permission={"make_call": "phone", "open_camera": "camera"}.get(security_action))
            trace.append({"department": "security", "status": "ok", "result": authorization})

        # A resposta de voz é preparada para Android TTS; não é reproduzida aqui.
        response_text = brain_result.get("response", "Pedido analisado.")
        if action and authorization and not authorization.get("allowed"):
            response_text = "Encontrei a ação " + action + ", mas ela ainda não pode ser executada: " + authorization.get("reason", "falta autorização")
        elif action:
            response_text = "Plano preparado para " + action + ". A execução depende da ponte Android."
        adaptive_context = {"preferences": self.modules["adaptive_learning"].get_preferences(),
                            "relevant_corrections": self.modules["adaptive_learning"].suggestions(normalized, limit=3),
                            "relevant_memories": self.modules["contextual_memory"].search(normalized, limit=3)}
        voice_result = self.modules["voice"].prepare(response_text)
        trace.append({"department": "voice", "status": "prepared", "result": voice_result})

        return {
            "status": "planned" if action else "conversation",
            "request": normalized,
            "action": body_result,
            "authorization": authorization,
            "response": response_text,
            "voice": voice_result,
            "adaptive_context": adaptive_context,
            "trace": trace,
            "execution_performed": False,
            "limitations": ["Não executa ações Android neste motor Python.",
                            "A Activity Android deve validar novamente permissões e confirmação."]
        }

    def health(self):
        return {"orchestrator": "ready", "version": "4.7.0",
                "task_engine": "ready", "registered_capabilities": len(self.task_engine.registry.names()),
                "memory": self.modules["memory_store"].status() if "memory_store" in self.modules else {"ready": False},
                "adaptive_learning": self.modules["adaptive_learning"].status() if "adaptive_learning" in self.modules else {"ready": False},
                "tool_engine": self.modules["tool_engine"].status() if "tool_engine" in self.modules else {"ready": False},
                "department_summary": self.department_summary()["counts"],
                "dispatch_count": self.dispatch_count, "last_dispatch": self.last_dispatch}
