"""ABM 5.9.0 — normalização de entradas acessíveis multimodais.
Não captura sensores: recebe eventos fornecidos por adaptadores Android consentidos.
"""
import json, sqlite3, time, uuid, hashlib
from pathlib import Path
from .secure_fields import SecureFieldVault, MARKER

class UniversalInteractionEngine:
    MODALITIES = {"text", "voice", "camera", "head", "gaze", "switch", "braille", "aac"}
    def __init__(self, db_path, secure_store=None):
        self.db_path=str(db_path); Path(self.db_path).parent.mkdir(parents=True,exist_ok=True)
        self.vault=SecureFieldVault(secure_store, "abm.interaction.v1")
        with self._db() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS interaction_events(
                id TEXT PRIMARY KEY, modality TEXT NOT NULL, content TEXT NOT NULL,
                source TEXT NOT NULL, confidence REAL NOT NULL, consent INTEGER NOT NULL,
                status TEXT NOT NULL, created_at REAL NOT NULL, dedupe_key TEXT NOT NULL)""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_interaction_status ON interaction_events(status,created_at)")
        if self.vault.encrypted: self._migrate_legacy_rows()
        try: Path(self.db_path).chmod(0o600)
        except OSError: pass

    def _migrate_legacy_rows(self):
        with self._db() as db:
            rows=db.execute("SELECT id,content,source,dedupe_key FROM interaction_events WHERE content != ? OR source != ?", (MARKER,MARKER)).fetchall()
            for row in rows:
                self.vault.pack("interaction."+row["id"], {"content":row["content"],"source":row["source"]})
                digest=hashlib.sha256(str(row["dedupe_key"]).encode("utf-8")).hexdigest()
                db.execute("UPDATE interaction_events SET content=?,source=?,dedupe_key=? WHERE id=?",(MARKER,MARKER,digest,row["id"]))
    def _db(self):
        db=sqlite3.connect(self.db_path); db.row_factory=sqlite3.Row; return db
    def submit(self, modality, content, source="user", confidence=1.0, consent=False, metadata=None):
        modality=str(modality or "").strip().lower()
        if modality not in self.MODALITIES: raise ValueError("Modalidade não suportada.")
        if not consent: return {"status":"consent_required","stored":False,"modality":modality}
        if not isinstance(content,str) or not content.strip() or len(content)>4000: raise ValueError("Conteúdo vazio ou demasiado longo.")
        if modality in {"camera","voice"} and len(content)>1000: raise ValueError("Para áudio/vídeo, envie uma transcrição ou descrição curta, não o ficheiro bruto.")
        confidence=max(0.0,min(1.0,float(confidence)))
        source=str(source or "user")[:80]
        # Não guardar imagens, áudio ou vídeo brutos; apenas texto/transcrição/descrição fornecida pelo adaptador.
        safe_meta={k:v for k,v in (metadata or {}).items() if k in {"locale","duration_ms","adapter_version","input_method"} and isinstance(v,(str,int,float,bool))}
        normalized={"modality":modality,"content":content.strip(),"source":source,"metadata":safe_meta}
        dedupe=json.dumps(normalized,ensure_ascii=False,sort_keys=True)
        dedupe_key=hashlib.sha256(dedupe.encode("utf-8")).hexdigest() if self.vault.encrypted else dedupe
        now=time.time()
        with self._db() as db:
            old=db.execute("SELECT id FROM interaction_events WHERE dedupe_key=? AND created_at>? ORDER BY created_at DESC LIMIT 1",(dedupe_key,now-2)).fetchone()
            if old: return {"status":"duplicate_ignored","event_id":old["id"],"stored":False}
            eid=str(uuid.uuid4())
            if self.vault.encrypted:
                self.vault.pack("interaction."+eid,{"content":content.strip(),"source":source})
                stored_content=stored_source=MARKER
            else: stored_content,stored_source=content.strip(),source
            db.execute("INSERT INTO interaction_events VALUES(?,?,?,?,?,?,?,?,?)",(eid,modality,stored_content,stored_source,confidence,1,"pending",now,dedupe_key))
        return {"status":"accepted","event_id":eid,"modality":modality,"confidence":confidence,"stored":True,"raw_media_stored":False}
    def next_event(self, min_confidence=0.0):
        with self._db() as db:
            row=db.execute("SELECT * FROM interaction_events WHERE status='pending' AND confidence>=? ORDER BY CASE modality WHEN 'switch' THEN 0 WHEN 'aac' THEN 1 WHEN 'braille' THEN 2 WHEN 'voice' THEN 3 WHEN 'text' THEN 4 WHEN 'head' THEN 5 WHEN 'gaze' THEN 6 ELSE 7 END, created_at LIMIT 1",(max(0,min(1,float(min_confidence))),)).fetchone()
            if not row:return {"status":"empty"}
            db.execute("UPDATE interaction_events SET status='delivered' WHERE id=?",(row['id'],))
            content,source=row['content'],row['source']
            if content==MARKER or source==MARKER:
                payload=self.vault.unpack("interaction."+row['id'],MARKER)
                content=payload.get("content","[conteúdo protegido indisponível]")
                source=payload.get("source","[origem protegida indisponível]")
            return {"status":"delivered","event":{"id":row['id'],"modality":row['modality'],"content":content,"source":source,"confidence":row['confidence'],"created_at":row['created_at']}}
    def acknowledge(self,event_id, accepted=True):
        status='acknowledged' if accepted else 'rejected'
        with self._db() as db:
            cur=db.execute("UPDATE interaction_events SET status=? WHERE id=? AND status='delivered'",(status,str(event_id)))
        return {"status":status if cur.rowcount else "not_updated","changed":cur.rowcount==1}
    def status(self):
        with self._db() as db:
            counts={r['status']:r['n'] for r in db.execute('SELECT status,COUNT(*) n FROM interaction_events GROUP BY status')}
            by_modality={r['modality']:r['n'] for r in db.execute('SELECT modality,COUNT(*) n FROM interaction_events GROUP BY modality')}
        return {"version":"6.0.0","engine":"UniversalInteractionEngine","modalities":sorted(self.MODALITIES),"events":counts,"by_modality":by_modality,"persistent_storage":"SQLite local","sensitive_fields_encrypted":self.vault.encrypted,"storage":"sqlite_metadata_android_keystore_aes_256_gcm" if self.vault.encrypted else "local_sqlite_plaintext","raw_audio_video_images_saved":False,"sensor_capture":False,"automatic_external_actions":False}
