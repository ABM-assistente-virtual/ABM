"""Base de conhecimento local com proteção de campos via Android Keystore."""
import json, sqlite3, time, re, hashlib
from pathlib import Path
from .secure_fields import SecureFieldVault, MARKER

class UniversalKnowledgeEngine:
    def __init__(self, db_path, secure_store=None):
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self.vault = SecureFieldVault(secure_store, "abm.knowledge.v1")
        with self._db() as db:
            db.execute("CREATE TABLE IF NOT EXISTS facts(id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT NOT NULL, relation TEXT NOT NULL, object TEXT NOT NULL, source TEXT NOT NULL, confidence REAL NOT NULL, consent INTEGER NOT NULL, created_at REAL NOT NULL, fingerprint TEXT NOT NULL DEFAULT '')")
            cols={r['name'] for r in db.execute('PRAGMA table_info(facts)').fetchall()}
            if 'fingerprint' not in cols:
                db.execute("ALTER TABLE facts ADD COLUMN fingerprint TEXT NOT NULL DEFAULT ''")
            indexes=db.execute('PRAGMA index_list(facts)').fetchall()
            if any(int(ix['unique']) for ix in indexes):
                db.execute("CREATE TABLE facts_new(id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT NOT NULL, relation TEXT NOT NULL, object TEXT NOT NULL, source TEXT NOT NULL, confidence REAL NOT NULL, consent INTEGER NOT NULL, created_at REAL NOT NULL, fingerprint TEXT NOT NULL DEFAULT '')")
                db.execute("INSERT INTO facts_new(id,subject,relation,object,source,confidence,consent,created_at,fingerprint) SELECT id,subject,relation,object,source,confidence,consent,created_at,fingerprint FROM facts")
                db.execute('DROP TABLE facts'); db.execute('ALTER TABLE facts_new RENAME TO facts')
            db.execute("CREATE INDEX IF NOT EXISTS idx_facts_consent ON facts(consent,created_at)")
        if self.vault.encrypted: self._migrate_legacy_rows()
        try: Path(self.db_path).chmod(0o600)
        except OSError: pass

    def _db(self):
        db=sqlite3.connect(self.db_path, timeout=10); db.row_factory=sqlite3.Row; return db

    @staticmethod
    def _clean(value, limit=500):
        value=re.sub(r'\s+',' ',str(value or '')).strip()
        if not value or len(value)>limit: raise ValueError('Campo vazio ou demasiado longo.')
        return value

    def _migrate_legacy_rows(self):
        with self._db() as db:
            rows=db.execute('SELECT id,subject,relation,object,source FROM facts WHERE subject != ? OR relation != ? OR object != ? OR source != ?', (MARKER,MARKER,MARKER,MARKER)).fetchall()
            for row in rows:
                payload={k:row[k] for k in ('subject','relation','object','source')}
                self.vault.pack('fact.'+str(row['id']), payload)
                fp=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
                db.execute('UPDATE facts SET subject=?,relation=?,object=?,source=?,fingerprint=? WHERE id=?',(MARKER,MARKER,MARKER,MARKER,fp,row['id']))

    def _decode(self, row):
        item=dict(row)
        if item['subject']==MARKER:
            payload=self.vault.unpack('fact.'+str(item['id']),MARKER)
            for key in ('subject','relation','object','source'):
                item[key]=payload.get(key,'[dado protegido indisponível]')
        return item

    def add_fact(self, subject, relation, obj, source='user', confidence=1.0, consent=False):
        if not consent: return {'status':'consent_required','stored':False}
        subject=self._clean(subject,160); relation=self._clean(relation,100); obj=self._clean(obj,500); source=self._clean(source,160)
        confidence=max(0.0,min(1.0,float(confidence)))
        with self._db() as db:
            cur=db.execute('INSERT INTO facts(subject,relation,object,source,confidence,consent,created_at,fingerprint) VALUES(?,?,?,?,?,?,?,?)', (MARKER if self.vault.encrypted else subject,MARKER if self.vault.encrypted else relation,MARKER if self.vault.encrypted else obj,MARKER if self.vault.encrypted else source,confidence,1,time.time(),''))
            fact_id=cur.lastrowid
            if self.vault.encrypted:
                payload={'subject':subject,'relation':relation,'object':obj,'source':source}
                self.vault.pack('fact.'+str(fact_id),payload)
                fp=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
                db.execute('UPDATE facts SET fingerprint=? WHERE id=?',(fp,fact_id))
        return {'status':'stored','stored':True,'fact_id':fact_id,'encrypted_at_rest':self.vault.encrypted}

    def search(self, query, limit=20):
        q=self._clean(query,300).casefold(); terms=[x for x in re.findall(r'[\wÀ-ÿ]+',q) if len(x)>1]
        if not terms: return {'status':'needs_query','facts':[]}
        with self._db() as db: rows=db.execute('SELECT * FROM facts WHERE consent=1 ORDER BY confidence DESC,created_at DESC LIMIT 2000').fetchall()
        scored=[]
        for raw in rows:
            row=self._decode(raw); hay=' '.join((row['subject'],row['relation'],row['object'])).casefold()
            score=sum(1 for term in terms if term in hay)
            if score: scored.append((score,row))
        scored.sort(key=lambda x:(-x[0],-x[1]['confidence'],-x[1]['created_at']))
        return {'status':'ok' if scored else 'no_match','query':query,'facts':[r for _,r in scored[:max(1,min(int(limit),50))]],'execution_performed':False}

    def related(self, subject, limit=20):
        subject=self._clean(subject,160).casefold()
        with self._db() as db: rows=db.execute('SELECT * FROM facts WHERE consent=1 ORDER BY confidence DESC,created_at DESC LIMIT 2000').fetchall()
        matches=[self._decode(r) for r in rows]
        matches=[r for r in matches if r['subject'].casefold()==subject or r['object'].casefold()==subject]
        return {'status':'ok','subject':subject,'facts':matches[:max(1,min(int(limit),50))]}

    def forget_source(self, source, consent=False):
        if not consent: return {'status':'consent_required','deleted':0}
        source=self._clean(source,160)
        with self._db() as db: rows=db.execute('SELECT * FROM facts WHERE consent=1').fetchall()
        ids=[self._decode(r)['id'] for r in rows if self._decode(r)['source']==source]
        with self._db() as db:
            for fact_id in ids:
                self.vault.remove('fact.'+str(fact_id)); db.execute('DELETE FROM facts WHERE id=?',(fact_id,))
        return {'status':'deleted','deleted':len(ids)}

    def status(self):
        with self._db() as db: count=db.execute('SELECT COUNT(*) FROM facts WHERE consent=1').fetchone()[0]
        return {'version':'7.0.10','engine':'UniversalKnowledgeEngine','facts':count,'storage':'SQLite metadata + Android Keystore AES-256-GCM' if self.vault.encrypted else 'SQLite local plaintext (desktop/test mode)','encrypted_at_rest':self.vault.encrypted,'external_sources_accessed':False,'automatic_execution':False}
