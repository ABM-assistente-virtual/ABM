"""ABM VOICE: prepara respostas faladas; síntese é executada pelo Android TTS."""
class Voice:
    def prepare(self, text: str, max_chars: int = 3500) -> dict:
        value = " ".join(str(text).split()).strip()
        if not value:
            raise ValueError("Não há texto para falar.")
        if len(value) > max_chars:
            value = value[:max_chars].rsplit(" ", 1)[0] + "…"
        return {"text": value, "engine": "Android TextToSpeech", "requires_android_tts": True}
