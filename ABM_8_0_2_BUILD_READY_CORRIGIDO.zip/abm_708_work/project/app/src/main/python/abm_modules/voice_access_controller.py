"""Controlador seguro que liga transcrições de voz a ações assistivas conhecidas.
Não captura áudio: recebe texto produzido pelo adaptador Android SpeechRecognizer.
"""
from dataclasses import dataclass
import re

@dataclass(frozen=True)
class VoiceAccessIntent:
    action: str
    requires_confirmation: bool
    confidence: float
    source_text: str

class VoiceAccessibilityController:
    ACTIONS = {
        "back": ("volta", "voltar", "regressa", "retroceder"),
        "home": ("início", "inicio", "ecrã inicial", "ecra inicial", "vai para casa"),
        "notifications": ("abre notificações", "abre notificacoes", "mostrar notificações", "mostrar notificacoes"),
        "quick_settings": ("abre definições rápidas", "abre definicoes rapidas", "definições rápidas", "definicoes rapidas"),
        "cursor_on": ("ativa cursor", "ligar cursor", "mostrar cursor"),
        "cursor_off": ("desativa cursor", "desligar cursor", "esconder cursor"),
        "scan_start": ("inicia varrimento", "começa varrimento", "comeca varrimento"),
        "scan_next": ("próximo elemento", "proximo elemento", "seguinte elemento"),
        "scan_select": ("seleciona elemento", "selecionar elemento", "confirma seleção", "confirma selecao"),
        "scan_stop": ("para varrimento", "termina varrimento", "cancelar varrimento"),
        "select": ("toca aqui", "seleciona", "clicar", "carrega aqui"),
    }
    CONFIRM = {"select", "scan_select"}

    @staticmethod
    def _norm(text):
        text = (text or "").strip().lower()
        return re.sub(r"\s+", " ", text)

    def interpret(self, transcript, confidence=0.75):
        raw = (transcript or "").strip()
        text = self._norm(raw)
        if not text:
            return None
        if confidence < 0.55:
            return None
        for action, phrases in self.ACTIONS.items():
            if text in phrases:
                return VoiceAccessIntent(action, action in self.CONFIRM, min(1.0, max(0.0, float(confidence))), raw)
        return None

    def status(self):
        return {"module": "voice_access_controller", "available_actions": len(self.ACTIONS),
                "confirmation_required_for": sorted(self.CONFIRM),
                "captures_audio": False, "executes_android_actions": False}
