# ABM GLOBAL — documentação atual

A documentação da versão atual está em `README_ABM_GLOBAL_2_0_0.md`.

A versão 2.0.0 inclui API, contas/memória PostgreSQL, fila de admissão Redis com roteamento por shards, tasks/workers, proteções operacionais, integração HTTPS Android e modelo Kubernetes.

Consulte também `../docs/ABM_GLOBAL_2_0_0_ARQUITETURA.md`.

**Aviso:** 30 milhões de pessoas em espera é uma meta de capacidade, não um resultado já comprovado. Esta entrega não foi implantada numa infraestrutura cloud real nem submetida a teste de carga de 30 milhões. O ambiente Docker Compose incluído é apenas um laboratório de um shard.
