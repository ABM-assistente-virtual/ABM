# ABM GLOBAL 1.8.0 — PostgreSQL e preparação para escala horizontal

## O que muda
- PostgreSQL 16 passa a ser o armazenamento recomendado para contas e memórias.
- Pool de ligações configurável (`ABM_DB_POOL_MIN` / `ABM_DB_POOL_MAX`).
- SQLite continua disponível apenas como fallback de desenvolvimento numa única instância.
- Metadados de região e shard (`ABM_REGION`, `ABM_QUEUE_SHARD`) para preparar deployments regionais.
- Docker Compose inicia PostgreSQL, Redis e API com verificações de saúde.

## Executar localmente
1. Copie `.env.example` para `.env`.
2. Defina `ABM_TOKEN_SECRET` e `ABM_POSTGRES_PASSWORD` com valores aleatórios fortes. Não reutilize exemplos.
3. Execute `docker compose up --build -d`.
4. Verifique `GET http://localhost:8000/health` e `GET /v1/capacity`.

## Importante sobre 30 milhões
Esta versão **não foi testada para 30 milhões de pessoas** e não promete essa capacidade. PostgreSQL e Redis no Compose são uma instalação inicial de um único ambiente, não uma infraestrutura global distribuída. A fila Redis atual continua sendo um único shard lógico. Para escala global real, o próximo trabalho de engenharia inclui:
- balanceador/API stateless com múltiplas réplicas em Kubernetes ou serviço gerido;
- Redis Cluster ou filas regionais particionadas, com roteamento consistente;
- PostgreSQL gerido com réplicas de leitura, backups, recuperação pontual e particionamento;
- limites de taxa, proteção contra abuso, observabilidade, alertas e recuperação de desastre;
- testes de carga graduais (1k, 10k, 100k, 1M sessões) e modelação antes de metas maiores.

## Segurança operacional
- Mantenha `.env` fora do Git e nunca publique segredos.
- Use TLS/HTTPS num proxy ou load balancer na produção.
- Faça backups e teste restauração antes de guardar dados reais.
- Configure política de retenção e eliminação de dados pessoais.
- Não exponha PostgreSQL nem Redis diretamente à Internet.

## Endpoints
Os endpoints de contas, login e memória permanecem compatíveis com 1.7.0. A API informa a região, shard e tipo de banco em `/health` e `/v1/capacity`.
