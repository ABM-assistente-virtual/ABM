# ABM GLOBAL 2.0.0 — plataforma distribuível

Esta versão reúne a base de contas/memória, fila de admissão, roteamento estável por shards, despacho de tarefas, worker, limites de pedidos, métricas e modelos de implantação. É uma **base de engenharia para escalar**, não uma prova de 30 milhões de utilizadores suportados.

## Componentes incluídos

- **API stateless:** FastAPI; pode executar em várias réplicas atrás de um load balancer HTTPS.
- **Contas e memória:** PostgreSQL quando `ABM_DATABASE_URL` está definido; SQLite só para desenvolvimento local.
- **Fila de admissão:** Redis, tickets com proprietário, idempotência de entrada e scripts atómicos.
- **Roteamento por shard:** rendezvous hashing de `user_id` para `ABM_QUEUE_SHARDS`; IDs de tickets/tarefas incluem um prefixo de shard para continuar a localizar recursos existentes depois de alterações de roteamento, desde que o shard antigo continue configurado.
- **Compatibilidade Redis Cluster:** todos os dados de cada shard usam o mesmo hash tag Redis `{shard}`. Defina `ABM_REDIS_CLUSTER=true` e use uma URL de seed do Redis Cluster.
- **Tarefas assíncronas:** Redis Streams, estado por utilizador e workers separados.
- **Proteções operacionais:** rate limit básico por IP, `X-Request-ID`, health/readiness, métricas Prometheus simples e endpoint administrativo protegido.
- **Operação:** Docker Compose para laboratório e manifesto Kubernetes com Deployment, HPA e PodDisruptionBudget como ponto de partida.

## Execução de laboratório

1. Extraia este projeto e entre na pasta `cloud`.
2. Copie `.env.example` para `.env`.
3. Gere segredos fortes e diferentes para `ABM_POSTGRES_PASSWORD`, `ABM_TOKEN_SECRET` (mínimo 32 caracteres) e `ABM_ADMIN_API_KEY`. Nunca publique os valores.
4. Execute `docker compose up --build -d`.
5. Consulte `http://localhost:8000/health`, `/ready`, `/v1/capacity` e `/metrics`.
6. Registe uma conta em `/v1/accounts/register`, faça login em `/v1/accounts/login` e use o token Bearer.
7. Para testar a fila, chame `/v1/queue/join`, consulte o ticket e depois `/v1/queue/leave`.
8. Para testar workers, submeta `POST /v1/tasks` com `{"task_type":"math.add","payload":{"a":2,"b":3}}`; consulte `GET /v1/tasks/{task_id}`.

## Multi-shard

Configure, por exemplo, `ABM_QUEUE_SHARDS=queue-a,queue-b,queue-c`. O mesmo conjunto tem de ser usado por API e workers. O roteamento escolhe um shard por conta; IDs de ticket/tarefa identificam o shard de origem. Ao retirar um shard, espere os tickets/tarefas expirarem ou migre os dados antes de o remover. Para Redis Cluster, configure `ABM_REDIS_CLUSTER=true` e a URL do cluster. A configuração de Compose incluída usa **um Redis único e um shard**, apenas para desenvolvimento; não é implantação global nem tolerante a falhas.

## Deploy Kubernetes

`deploy/kubernetes/api.yaml` é um modelo inicial. Antes de aplicar:

- substitua `YOUR_REGISTRY/abm-global:2.0.0` pela imagem publicada;
- crie `abm-global-secrets` com `ABM_DATABASE_URL`, `ABM_REDIS_URL`, `ABM_REDIS_CLUSTER`, `ABM_TOKEN_SECRET` e `ABM_ADMIN_API_KEY`;
- use PostgreSQL e Redis Cluster geridos, multi-zona, privados e com TLS;
- configure Ingress/Load Balancer HTTPS, WAF, DNS, certificados e políticas de rede;
- configure backup PostgreSQL, point-in-time recovery, retenção, restauração testada e monitorização;
- aplique migrations numa etapa controlada antes de disponibilizar novas versões;
- configure workers como Deployment separado e aumente réplicas conforme profundidade/idade da fila.

## Limitações que continuam reais

- **30 milhões não foram testados nem garantidos.** O número de utilizadores registados, utilizadores em espera e pedidos simultâneos são métricas diferentes. Esta versão permite particionar a fila logicamente e distribuir chaves no Redis Cluster, mas não inclui contas de cloud, DNS global, clusters reais, CDN/WAF, failover multi-região, SRE 24/7, nem orçamento de infraestrutura.
- O worker contém apenas handlers de demonstração (`system.ping`, `math.add`). Para tarefas de IA, imagem, áudio ou ações de dispositivo, cada handler precisa de integração real com modelos/provedores e políticas de execução.
- O rate limiter é um limitador básico por IP; em produção precisa de política por conta/API key, IP confiável no proxy e proteção anti-bot.
- O token atual é HMAC simples; para produto público devem ser acrescentados refresh-token rotativo, revogação, recuperação de conta, verificação de email, MFA e gestão de sessões.
- A API não substitui observabilidade completa. Integre Prometheus/Grafana, logs centralizados, tracing distribuído, alertas e runbooks.
- O manifesto Kubernetes é modelo e não foi aplicado num cluster real. Não existe teste de carga de 30M nesta entrega.

## Plano de capacidade

Executar testes progressivos (100, 1k, 10k, 100k, 1M sessões simuladas) por região e shard; medir RPS, p95/p99, erros, memória, CPU, conexões PostgreSQL, latência Redis, idade da fila e custo. Só depois dimensionar para 30M em espera. Definir SLOs, limites, estratégia de backpressure, proteção contra rajadas e orçamento antes de aumentar tráfego.

## Testes de carga controlados

Instale `pip install -r requirements-loadtest.txt` e execute, contra um ambiente de teste isolado: `locust -f loadtest/locustfile.py --host https://URL-DE-TESTE`. Comece com poucos utilizadores virtuais e aumente gradualmente. Não execute testes agressivos contra produção nem contra serviços de terceiros.


## ABM 2.1.0 — Inteligência e ferramentas

A API inclui endpoints autenticados para: conversa com um modelo externo compatível com Chat Completions (`POST /v1/agent/ask`), pesquisa Web com Tavily e síntese baseada nas fontes (`POST /v1/agent/research`), planos de aprendizagem (`POST /v1/agent/learn`) e geração de um projeto inicial Web editável (`POST /v1/agent/create-web-app`). `GET /v1/agent/capabilities` informa se os fornecedores externos estão configurados.

Configure `ABM_LLM_BASE_URL`, `ABM_LLM_API_KEY`, `ABM_LLM_MODEL` e `ABM_TAVILY_API_KEY` no servidor, nunca no APK. Sem essas chaves, os endpoints de IA/pesquisa respondem com indisponibilidade clara; não simulam uma resposta. O gerador de aplicação cria apenas um starter Web HTML/CSS/JS, não um APK nem um produto publicado.
