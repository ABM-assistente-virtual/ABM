"""ABM Global Cloud starter."""
