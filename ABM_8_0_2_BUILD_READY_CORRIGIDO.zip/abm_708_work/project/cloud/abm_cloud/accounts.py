"""Account and private-memory store for ABM Global starter deployment.

SQLite is suitable for local/single-instance evaluation only. For horizontal
production scale, replace this adapter with PostgreSQL before running replicas.
"""
import hashlib, hmac, json, os, secrets, sqlite3, time
from pathlib import Path
from typing import Optional

DB_PATH = os.getenv('ABM_DB_PATH', '/data/abm_global.sqlite3')
TOKEN_SECRET = os.getenv('ABM_TOKEN_SECRET', '')
TOKEN_TTL = max(300, int(os.getenv('ABM_TOKEN_TTL_SECONDS', '86400')))

class AccountError(Exception):
    def __init__(self, message: str, status: int = 400):
        self.message, self.status = message, status
        super().__init__(message)

class AccountStore:
    def __init__(self, path: str = DB_PATH, secret: str = TOKEN_SECRET):
        if not secret or len(secret) < 32:
            raise ValueError('ABM_TOKEN_SECRET must contain at least 32 characters')
        self.path, self.secret = path, secret.encode('utf-8')
        if path != ':memory:': Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE,
                salt BLOB NOT NULL, password_hash BLOB NOT NULL,
                created_at INTEGER NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY, user_id TEXT NOT NULL, content TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)''')
            db.execute('CREATE INDEX IF NOT EXISTS idx_memories_user ON memories(user_id, created_at)')

    def _db(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        if self.path != ':memory:': db.execute('PRAGMA journal_mode=WAL')
        return db

    @staticmethod
    def _derive(password: str, salt: bytes) -> bytes:
        return hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 310_000, dklen=32)

    def register(self, email: str, password: str):
        email = email.strip().lower()
        if len(email) > 254 or '@' not in email or email.startswith('@') or email.endswith('@'):
            raise AccountError('Endereço de email inválido')
        if len(password) < 10 or len(password) > 128:
            raise AccountError('A palavra-passe deve ter entre 10 e 128 caracteres')
        salt = secrets.token_bytes(16); uid = secrets.token_hex(16); now = int(time.time())
        try:
            with self._db() as db:
                db.execute('INSERT INTO users VALUES(?,?,?,?,?)', (uid,email,salt,self._derive(password,salt),now))
        except sqlite3.IntegrityError as exc:
            raise AccountError('Esta conta já existe', 409) from exc
        return {'user_id': uid, 'email': email, 'created_at': now}

    def login(self, email: str, password: str):
        with self._db() as db:
            row = db.execute('SELECT * FROM users WHERE email=?', (email.strip().lower(),)).fetchone()
        # Same response for unknown email and wrong password.
        valid = bool(row) and hmac.compare_digest(self._derive(password, row['salt']), row['password_hash'])
        if not valid: raise AccountError('Credenciais inválidas', 401)
        now = int(time.time()); payload = {'sub': row['id'], 'iat': now, 'exp': now + TOKEN_TTL}
        body = self._b64(json.dumps(payload,separators=(',',':')).encode())
        sig = self._b64(hmac.new(self.secret, body.encode(), hashlib.sha256).digest())
        return {'access_token': body + '.' + sig, 'token_type': 'bearer', 'expires_in': TOKEN_TTL}

    @staticmethod
    def _b64(raw: bytes) -> str:
        import base64
        return base64.urlsafe_b64encode(raw).rstrip(b'=').decode()

    def verify(self, token: str) -> str:
        try:
            body, sig = token.split('.',1)
            expected = self._b64(hmac.new(self.secret, body.encode(), hashlib.sha256).digest())
            if not hmac.compare_digest(sig, expected): raise ValueError()
            import base64
            raw = base64.urlsafe_b64decode(body + '=' * (-len(body) % 4))
            payload = json.loads(raw)
            if int(payload['exp']) <= int(time.time()) or not payload.get('sub'): raise ValueError()
            return str(payload['sub'])
        except Exception as exc:
            raise AccountError('Token inválido ou expirado', 401) from exc

    def profile(self, user_id: str):
        with self._db() as db:
            row = db.execute('SELECT id,email,created_at FROM users WHERE id=?',(user_id,)).fetchone()
        if not row: raise AccountError('Conta não encontrada',404)
        return dict(row)

    def add_memory(self, user_id: str, content: str):
        if not content.strip() or len(content) > 4000: raise AccountError('Memória deve ter entre 1 e 4000 caracteres')
        mid, now = secrets.token_hex(16), int(time.time())
        with self._db() as db:
            if not db.execute('SELECT 1 FROM users WHERE id=?',(user_id,)).fetchone(): raise AccountError('Conta não encontrada',404)
            db.execute('INSERT INTO memories VALUES(?,?,?,?)',(mid,user_id,content.strip(),now))
        return {'memory_id':mid,'content':content.strip(),'created_at':now}

    def list_memories(self, user_id: str, limit: int = 100):
        with self._db() as db:
            rows = db.execute('SELECT id,content,created_at FROM memories WHERE user_id=? ORDER BY created_at DESC LIMIT ?', (user_id,min(max(limit,1),100))).fetchall()
        return [dict(r) for r in rows]

    def delete_memory(self, user_id: str, memory_id: str):
        with self._db() as db:
            cur = db.execute('DELETE FROM memories WHERE id=? AND user_id=?',(memory_id,user_id))
        if not cur.rowcount: raise AccountError('Memória não encontrada',404)
        return {'deleted':True,'memory_id':memory_id}

class PostgresAccountStore(AccountStore):
    """PostgreSQL-backed account/memory adapter for multi-instance deployments."""
    def __init__(self, database_url: str, secret: str, min_size: int = 2, max_size: int = 20):
        if not secret or len(secret) < 32:
            raise ValueError('ABM_TOKEN_SECRET must contain at least 32 characters')
        try:
            from psycopg_pool import ConnectionPool
            from psycopg.rows import dict_row
        except ImportError as exc:
            raise RuntimeError('Instale psycopg[binary,pool] para usar PostgreSQL') from exc
        self.secret = secret.encode('utf-8')
        self.pool = ConnectionPool(
            conninfo=database_url, min_size=min_size, max_size=max_size,
            kwargs={'row_factory': dict_row}, open=True,
        )
        with self.pool.connection() as conn:
            conn.execute('''CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE,
                salt BYTEA NOT NULL, password_hash BYTEA NOT NULL,
                created_at BIGINT NOT NULL)''')
            conn.execute('''CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                content TEXT NOT NULL, created_at BIGINT NOT NULL)''')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_memories_user_created ON memories(user_id, created_at DESC)')

    def register(self, email: str, password: str):
        email = email.strip().lower()
        if len(email) > 254 or '@' not in email or email.startswith('@') or email.endswith('@'):
            raise AccountError('Endereço de email inválido')
        if len(password) < 10 or len(password) > 128:
            raise AccountError('A palavra-passe deve ter entre 10 e 128 caracteres')
        uid, salt, now = secrets.token_hex(16), secrets.token_bytes(16), int(time.time())
        try:
            with self.pool.connection() as conn:
                conn.execute('INSERT INTO users VALUES(%s,%s,%s,%s,%s)',
                    (uid,email,salt,self._derive(password,salt),now))
        except Exception as exc:
            if getattr(exc, 'sqlstate', None) == '23505':
                raise AccountError('Esta conta já existe', 409) from exc
            raise
        return {'user_id':uid,'email':email,'created_at':now}

    def login(self, email: str, password: str):
        with self.pool.connection() as conn:
            row = conn.execute('SELECT * FROM users WHERE email=%s',(email.strip().lower(),)).fetchone()
        valid = bool(row) and hmac.compare_digest(self._derive(password,row['salt']),row['password_hash'])
        if not valid: raise AccountError('Credenciais inválidas',401)
        now=int(time.time()); payload={'sub':row['id'],'iat':now,'exp':now+TOKEN_TTL}
        body=self._b64(json.dumps(payload,separators=(',',':')).encode())
        sig=self._b64(hmac.new(self.secret,body.encode(),hashlib.sha256).digest())
        return {'access_token':body+'.'+sig,'token_type':'bearer','expires_in':TOKEN_TTL}

    def profile(self, user_id: str):
        with self.pool.connection() as conn:
            row=conn.execute('SELECT id,email,created_at FROM users WHERE id=%s',(user_id,)).fetchone()
        if not row: raise AccountError('Conta não encontrada',404)
        return dict(row)

    def add_memory(self, user_id: str, content: str):
        if not content.strip() or len(content)>4000: raise AccountError('Memória deve ter entre 1 e 4000 caracteres')
        mid,now=secrets.token_hex(16),int(time.time())
        with self.pool.connection() as conn:
            if not conn.execute('SELECT 1 FROM users WHERE id=%s',(user_id,)).fetchone():
                raise AccountError('Conta não encontrada',404)
            conn.execute('INSERT INTO memories VALUES(%s,%s,%s,%s)',(mid,user_id,content.strip(),now))
        return {'memory_id':mid,'content':content.strip(),'created_at':now}

    def list_memories(self, user_id: str, limit: int = 100):
        with self.pool.connection() as conn:
            rows=conn.execute('SELECT id,content,created_at FROM memories WHERE user_id=%s ORDER BY created_at DESC LIMIT %s',
                (user_id,min(max(limit,1),100))).fetchall()
        return [dict(r) for r in rows]

    def delete_memory(self, user_id: str, memory_id: str):
        with self.pool.connection() as conn:
            cur=conn.execute('DELETE FROM memories WHERE id=%s AND user_id=%s',(memory_id,user_id))
        if cur.rowcount == 0: raise AccountError('Memória não encontrada',404)
        return {'deleted':True,'memory_id':memory_id}

    def close(self):
        self.pool.close()
