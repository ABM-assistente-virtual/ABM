"""Safe starter-project generator. Produces editable static web app files, not APKs."""
from __future__ import annotations
import html
import re


def create_web_app(name: str, description: str) -> dict:
    name = re.sub(r'[^\w .-]', '', str(name or '').strip(), flags=re.UNICODE)[:60] or 'Nova aplicação'
    description = str(description or '').strip()[:1000]
    if not description:
        raise ValueError('Descreve a aplicação que pretendes criar.')
    title = html.escape(name)
    desc = html.escape(description)
    html_file = f'''<!doctype html>
<html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title><link rel="stylesheet" href="style.css"></head>
<body><main class="card"><p class="tag">ABM APP STARTER</p><h1>{title}</h1><p>{desc}</p>
<label for="task">Escreve uma nota</label><textarea id="task" placeholder="Começa aqui..."></textarea>
<button id="save">Guardar localmente</button><p id="status" role="status"></p></main><script src="app.js"></script></body></html>'''
    css_file = '''*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#101522;color:#eef2ff;font:16px system-ui;padding:20px}.card{width:min(680px,100%);background:#1b2435;padding:28px;border-radius:20px;box-shadow:0 16px 50px #0005}h1{font-size:clamp(2rem,6vw,3.5rem);margin:.2em 0}.tag{color:#a78bfa;font-weight:700;letter-spacing:.12em}textarea{display:block;width:100%;min-height:130px;margin:10px 0 16px;padding:12px;border-radius:10px;border:1px solid #667085;background:#101522;color:white}button{padding:12px 18px;border:0;border-radius:10px;background:#8b5cf6;color:white;font-weight:700}#status{color:#a7f3d0}'''
    js_file = '''const field=document.querySelector('#task');const status=document.querySelector('#status');field.value=localStorage.getItem('abm-note')||'';document.querySelector('#save').addEventListener('click',()=>{localStorage.setItem('abm-note',field.value);status.textContent='Guardado neste dispositivo.';});'''
    return {'project_type':'static_web_app','files':{'index.html':html_file,'style.css':css_file,'app.js':js_file},
            'instructions':'Guarda os três ficheiros na mesma pasta e abre index.html num navegador. Isto é um projeto inicial editável, não um APK Android nem uma aplicação publicada.'}
