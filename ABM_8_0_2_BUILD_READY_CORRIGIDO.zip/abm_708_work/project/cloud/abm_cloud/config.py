import os

REDIS_URL = os.getenv('ABM_REDIS_URL', 'redis://redis:6379/0')
ACTIVE_CAPACITY = max(1, int(os.getenv('ABM_ACTIVE_CAPACITY', '1000')))
QUEUE_TTL_SECONDS = max(300, int(os.getenv('ABM_QUEUE_TTL_SECONDS', '86400')))
SERVICE_NAME = 'ABM Global Cloud'
API_VERSION = '2.1.0'
DATABASE_URL = os.getenv('ABM_DATABASE_URL', '')
DB_POOL_MIN = max(1, int(os.getenv('ABM_DB_POOL_MIN', '2')))
DB_POOL_MAX = max(DB_POOL_MIN, int(os.getenv('ABM_DB_POOL_MAX', '20')))
REGION = os.getenv('ABM_REGION', 'local')
QUEUE_SHARD = os.getenv('ABM_QUEUE_SHARD', 'default')
RATE_LIMIT_PER_MINUTE = max(10, int(os.getenv('ABM_RATE_LIMIT_PER_MINUTE', '120')))
TASK_STREAM_MAXLEN = max(1000, int(os.getenv('ABM_TASK_STREAM_MAXLEN', '100000')))
ADMIN_API_KEY = os.getenv('ABM_ADMIN_API_KEY', '')
