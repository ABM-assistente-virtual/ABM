"""ABM Intelligence gateway: OpenAI-compatible LLM + Tavily web search.
Secrets stay on the server. No arbitrary shell/code execution is exposed.
"""
from __future__ import annotations
import json
import os
import re
import urllib.error
import urllib.request
from typing import Any


def _https_endpoint(value: str) -> str:
    value = (value or '').strip().rstrip('/')
    if not value:
        return ''
    if not (value.startswith('https://') or value.startswith('http://127.0.0.1') or value.startswith('http://localhost')):
        raise ValueError('O endpoint do fornecedor deve usar HTTPS.')
    return value


class IntelligenceConfig:
    def __init__(self):
        self.base_url = _https_endpoint(os.getenv('ABM_LLM_BASE_URL', ''))
        self.api_key = os.getenv('ABM_LLM_API_KEY', '')
        self.model = os.getenv('ABM_LLM_MODEL', '')
        self.search_key = os.getenv('ABM_TAVILY_API_KEY', '')
        self.timeout = max(5, min(int(os.getenv('ABM_AI_TIMEOUT_SECONDS', '45')), 120))

    @property
    def llm_ready(self):
        return bool(self.base_url and self.api_key and self.model)

    @property
    def research_ready(self):
        return bool(self.search_key)


class IntelligenceService:
    SYSTEM = (
        'És o ABM, um assistente útil, rigoroso e transparente. Responde em português claro '
        'quando o utilizador escreve em português. Não inventes fontes, resultados ou ações. '
        'Distingue factos, incertezas e sugestões. Nunca afirmes que executaste algo sem resultado '
        'confirmado. Não peças nem exponhas segredos.'
    )

    def __init__(self, config: IntelligenceConfig | None = None):
        self.config = config or IntelligenceConfig()

    def _post_json(self, url: str, payload: dict, headers: dict | None = None) -> dict:
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'),
            headers={'Content-Type': 'application/json', **(headers or {})}, method='POST')
        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout) as response:
                raw = response.read(2_000_000)
        except urllib.error.HTTPError as exc:
            detail = exc.read(2000).decode('utf-8', 'replace')
            raise RuntimeError(f'Fornecedor externo respondeu HTTP {exc.code}: {detail}') from exc
        except Exception as exc:
            raise RuntimeError(f'Não foi possível contactar o fornecedor externo: {exc}') from exc
        try:
            return json.loads(raw.decode('utf-8'))
        except Exception as exc:
            raise RuntimeError('O fornecedor devolveu uma resposta inválida.') from exc

    def _chat(self, messages: list[dict], temperature: float = 0.2) -> str:
        if not self.config.llm_ready:
            raise RuntimeError('Motor de IA não configurado. O administrador precisa configurar ABM_LLM_BASE_URL, ABM_LLM_API_KEY e ABM_LLM_MODEL no servidor.')
        url = self.config.base_url
        if not url.endswith('/chat/completions'):
            url += '/chat/completions'
        payload = {'model': self.config.model, 'messages': [{'role':'system','content':self.SYSTEM}] + messages,
                   'temperature': temperature}
        data = self._post_json(url, payload, {'Authorization': 'Bearer ' + self.config.api_key})
        try:
            return str(data['choices'][0]['message']['content']).strip()
        except Exception as exc:
            raise RuntimeError('Resposta do modelo não contém uma mensagem utilizável.') from exc

    def ask(self, question: str, history: list[dict] | None = None) -> dict:
        question = str(question or '').strip()
        if not question or len(question) > 12000:
            raise ValueError('A pergunta deve ter entre 1 e 12000 caracteres.')
        messages = []
        for item in (history or [])[-12:]:
            role = item.get('role')
            content = str(item.get('content', ''))[:6000]
            if role in ('user', 'assistant') and content:
                messages.append({'role': role, 'content': content})
        messages.append({'role':'user','content':question})
        return {'answer': self._chat(messages), 'model': self.config.model}

    def search_web(self, query: str, max_results: int = 5) -> list[dict]:
        query = str(query or '').strip()
        if not query or len(query) > 1000:
            raise ValueError('A pesquisa deve ter entre 1 e 1000 caracteres.')
        if not self.config.research_ready:
            raise RuntimeError('Pesquisa web não configurada. O administrador precisa definir ABM_TAVILY_API_KEY no servidor.')
        data = self._post_json('https://api.tavily.com/search', {
            'api_key': self.config.search_key, 'query': query,
            'search_depth': 'advanced', 'max_results': max(1, min(int(max_results), 8)),
            'include_answer': False, 'include_raw_content': False,
        })
        results = []
        for row in data.get('results', []):
            url = str(row.get('url', ''))
            if not url.startswith('https://'):
                continue
            results.append({'title': str(row.get('title',''))[:300], 'url': url[:2000],
                            'content': str(row.get('content',''))[:5000],
                            'score': float(row.get('score', 0) or 0)})
        return results

    def research(self, query: str, max_results: int = 5) -> dict:
        sources = self.search_web(query, max_results)
        if not sources:
            return {'summary': 'A pesquisa não devolveu fontes utilizáveis.', 'sources': []}
        source_text = '\n\n'.join(
            f"FONTE {i+1}: {s['title']}\nURL: {s['url']}\nEXCERTO: {s['content']}"
            for i, s in enumerate(sources))
        prompt = ('Responde à pergunta usando apenas os excertos fornecidos. Indica quando os excertos '
                  'não permitem concluir algo. Não inventes factos. Usa referências [1], [2], etc.\n\n'
                  f'PERGUNTA: {query}\n\nFONTES:\n{source_text}')
        summary = self._chat([{'role':'user','content':prompt}], temperature=0.1)
        return {'summary': summary, 'sources': [{'title':s['title'],'url':s['url']} for s in sources]}

    def generate_web_app(self, name: str, description: str) -> dict:
        name = str(name or '').strip()[:60]
        description = str(description or '').strip()[:1500]
        if not name or not description:
            raise ValueError('Indica o nome e descreve a aplicação.')
        prompt = ("Cria um pequeno projeto Web funcional em HTML, CSS e JavaScript puro. "
                  "Devolve APENAS JSON válido no formato {\"files\":{\"index.html\":\"...\",\"style.css\":\"...\",\"app.js\":\"...\"}}. "
                  "Não uses dependências externas, não incluas scripts remotos, não peças segredos, "
                  "não uses eval, e inclui interface responsiva e acessível. "
                  f"Nome: {name}. Requisitos: {description}")
        raw = self._chat([{'role':'user','content':prompt}], temperature=0.2)
        raw = re.sub(r'^```(?:json)?\s*|\s*```$', '', raw.strip(), flags=re.I)
        try:
            data = json.loads(raw)
            files = data.get('files', {})
        except Exception as exc:
            raise RuntimeError('O modelo não devolveu um projeto em JSON válido.') from exc
        if not isinstance(files, dict) or not 1 <= len(files) <= 10:
            raise RuntimeError('O projeto gerado não contém um conjunto válido de ficheiros.')
        safe = {}
        total = 0
        allowed_ext = {'.html', '.css', '.js', '.json', '.md', '.txt'}
        for filename, content in files.items():
            filename = str(filename)
            if filename.startswith('/') or '..' in filename or '/' in filename or '\\' in filename:
                raise RuntimeError('O projeto contém um nome de ficheiro não permitido.')
            if os.path.splitext(filename)[1].lower() not in allowed_ext:
                raise RuntimeError('O projeto contém um tipo de ficheiro não permitido.')
            if not isinstance(content, str):
                raise RuntimeError('O conteúdo dos ficheiros deve ser texto.')
            lowered = content.lower()
            if re.search(r"\beval\s*\(|new\s+function\s*\(", content, re.I):
                raise RuntimeError('O projeto gerado contém execução dinâmica de código não permitida.')
            if filename.lower().endswith('.html') and re.search(r"<(?:script|link)[^>]+(?:src|href)\s*=\s*[\"']https?://", content, re.I):
                raise RuntimeError('O projeto tenta carregar scripts/estilos externos não permitidos.')
            if 'javascript:' in lowered:
                raise RuntimeError('O projeto contém um URL javascript não permitido.')
            total += len(content.encode('utf-8'))
            if total > 200_000:
                raise RuntimeError('O projeto gerado excede 200 KB.')
            safe[filename] = content
        if 'index.html' not in safe:
            raise RuntimeError('O projeto precisa de conter index.html.')
        return {'project_type':'generated_web_app','generated_by':'configured_language_model',
                'files':safe,'instructions':'Revê os ficheiros, testa num navegador e só depois publica. O servidor não executa nem publica código gerado.'}

    def learning_plan(self, profession: str, level: str = 'iniciante') -> dict:
        profession = str(profession or '').strip()
        if not profession or len(profession) > 300:
            raise ValueError('Indica a profissão ou competência que queres aprender.')
        prompt = ('Cria um plano de aprendizagem prático e honesto para esta profissão/competência: '
                  f'{profession}. Nível: {level}. Organiza por etapas, competências, exercícios práticos, '
                  'projeto final e formas de avaliar progresso. Não afirmes que a pessoa já está qualificada.')
        return {'profession': profession, 'level': level, 'plan': self._chat([{'role':'user','content':prompt}], 0.2)}


def capabilities_report(config: IntelligenceConfig | None = None) -> dict:
    c = config or IntelligenceConfig()
    return {
        'general_language_model': c.llm_ready,
        'web_research': c.research_ready and c.llm_ready,
        'professional_learning_plans': c.llm_ready,
        'server_side_secrets': True,
        'note': 'Capacidades externas só funcionam depois de configurar as chaves no servidor e validar o fornecedor.'
    }
