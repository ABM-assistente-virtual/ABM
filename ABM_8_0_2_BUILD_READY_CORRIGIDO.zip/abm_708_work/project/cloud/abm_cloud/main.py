from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Request, Depends, Header
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field, EmailStr, field_validator
from redis.asyncio import Redis
from .config import (REDIS_URL, SERVICE_NAME, API_VERSION, ACTIVE_CAPACITY,
    DATABASE_URL, DB_POOL_MIN, DB_POOL_MAX, REGION, QUEUE_SHARD,
    RATE_LIMIT_PER_MINUTE, ADMIN_API_KEY)
from .queue import AdmissionQueue
from .tasks import TaskDispatcher
from .sharding import SHARDS, shard_for_user, shard_for_resource
from .redis_client import create_redis_client
from .accounts import AccountStore, PostgresAccountStore, AccountError
from .intelligence import IntelligenceService, capabilities_report
from .app_factory import create_web_app
import os, uuid, time, hashlib, json

RATE_LUA = """local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],60) end; return n"""

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.redis = create_redis_client(REDIS_URL)
    await app.state.redis.ping()
    app.state.queues = {shard: AdmissionQueue(app.state.redis, shard) for shard in SHARDS}
    app.state.task_dispatchers = {shard: TaskDispatcher(app.state.redis, shard) for shard in SHARDS}
    app.state.intelligence = IntelligenceService()
    app.state.accounts = (PostgresAccountStore(DATABASE_URL, os.getenv('ABM_TOKEN_SECRET',''), DB_POOL_MIN, DB_POOL_MAX) if DATABASE_URL else AccountStore())
    yield
    if hasattr(app.state.accounts, 'close'): app.state.accounts.close()
    await app.state.redis.aclose()

app = FastAPI(title=SERVICE_NAME, version=API_VERSION, lifespan=lifespan)

@app.middleware('http')
async def request_controls(request: Request, call_next):
    request_id = request.headers.get('x-request-id') or uuid.uuid4().hex
    request.state.request_id = request_id
    if request.url.path not in ('/health', '/ready', '/metrics') and hasattr(request.app.state, 'redis'):
        ip = request.client.host if request.client else 'unknown'
        bucket = int(time.time() // 60)
        ip_tag = hashlib.sha256(ip.encode()).hexdigest()[:12]
        key = f"abm:ratelimit:{{rl-{ip_tag}}}:{bucket}"
        try:
            count = int(await request.app.state.redis.eval(RATE_LUA, 1, key))
            if count > RATE_LIMIT_PER_MINUTE:
                return JSONResponse(status_code=429, content={'detail':'Limite temporário de pedidos atingido', 'request_id':request_id}, headers={'Retry-After':'60','X-Request-ID':request_id})
        except Exception:
            return JSONResponse(status_code=503, content={'detail':'Serviço temporariamente indisponível','request_id':request_id}, headers={'X-Request-ID':request_id})
    response = await call_next(request)
    response.headers['X-Request-ID'] = request_id
    return response

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)
class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)
class MemoryRequest(BaseModel):
    content: str = Field(min_length=1, max_length=4000)
class TaskRequest(BaseModel):
    task_type: str = Field(min_length=2, max_length=80, pattern=r'^[a-zA-Z0-9_.-]+$')
    payload: dict = Field(default_factory=dict)

    @field_validator('payload')
    @classmethod
    def payload_size_limit(cls, value):
        if len(json.dumps(value, ensure_ascii=False).encode('utf-8')) > 32768:
            raise ValueError('Payload da tarefa excede 32 KB')
        return value
class AgentAskRequest(BaseModel):
    question: str = Field(min_length=1, max_length=12000)
    history: list[dict] = Field(default_factory=list, max_length=12)

class ResearchRequest(BaseModel):
    query: str = Field(min_length=1, max_length=1000)
    max_results: int = Field(default=5, ge=1, le=8)

class LearningRequest(BaseModel):
    profession: str = Field(min_length=1, max_length=300)
    level: str = Field(default='iniciante', max_length=80)

class AppBuildRequest(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    description: str = Field(min_length=1, max_length=1000)

class LeaveRequest(BaseModel):
    ticket: str = Field(min_length=32, max_length=64, pattern=r'^[a-f0-9]+$')

def account_store(request: Request): return request.app.state.accounts

def current_user(request: Request, authorization: str = Header(default='')):
    if not authorization.startswith('Bearer '): raise HTTPException(status_code=401, detail='Bearer token obrigatório')
    try: return account_store(request).verify(authorization[7:])
    except AccountError as exc: raise HTTPException(status_code=exc.status, detail=exc.message) from exc

def handle_account_error(exc: AccountError): raise HTTPException(status_code=exc.status, detail=exc.message) from exc

def require_admin(x_abm_admin_key: str = Header(default='')):
    if not ADMIN_API_KEY or not x_abm_admin_key or x_abm_admin_key != ADMIN_API_KEY:
        raise HTTPException(status_code=403, detail='Acesso administrativo não autorizado')

@app.get('/health')
async def health(request: Request):
    try:
        await request.app.state.redis.ping()
        return {'status':'ok','service':SERVICE_NAME,'version':API_VERSION,'region':REGION,'queue_shard':QUEUE_SHARD}
    except Exception as exc: raise HTTPException(status_code=503, detail='queue backend unavailable') from exc

@app.get('/ready')
async def ready(request: Request):
    try:
        await request.app.state.redis.ping()
        if DATABASE_URL:
            with request.app.state.accounts.pool.connection() as conn: conn.execute('SELECT 1')
        return {'ready':True,'region':REGION,'shard':QUEUE_SHARD}
    except Exception as exc: raise HTTPException(status_code=503, detail='dependency unavailable') from exc

@app.get('/metrics', response_class=PlainTextResponse)
async def metrics(request: Request):
    try:
        redis = request.app.state.redis
        waiting = sum([await redis.zcard(q.waiting) for q in request.app.state.queues.values()])
        active = sum([await redis.zcard(q.active) for q in request.app.state.queues.values()])
        return f'abm_queue_waiting{{region="{REGION}",shard="{QUEUE_SHARD}"}} {waiting}\nabm_queue_active{{region="{REGION}",shard="{QUEUE_SHARD}"}} {active}\n'
    except Exception as exc: raise HTTPException(status_code=503, detail='metrics unavailable') from exc

@app.get('/v1/capacity')
async def capacity():
    return {'active_capacity_per_shard':ACTIVE_CAPACITY,'region':REGION,'queue_shard':QUEUE_SHARD,
            'database':'postgresql' if DATABASE_URL else 'sqlite-single-instance',
            'queue_backend':'redis-sharded-namespaces', 'configured_shards':list(SHARDS),
            'note':'Configured shard capacity only. Global capacity requires multiple deployed shards and measured load tests.'}

@app.post('/v1/accounts/register', status_code=201)
async def register(body:RegisterRequest, request:Request):
    try: return request.app.state.accounts.register(str(body.email),body.password)
    except AccountError as exc: handle_account_error(exc)

@app.post('/v1/accounts/login')
async def login(body:LoginRequest, request:Request):
    try: return request.app.state.accounts.login(str(body.email),body.password)
    except AccountError as exc: handle_account_error(exc)

@app.get('/v1/accounts/me')
async def me(request:Request, user_id:str=Depends(current_user)):
    try: return request.app.state.accounts.profile(user_id)
    except AccountError as exc: handle_account_error(exc)

@app.post('/v1/memories', status_code=201)
async def add_memory(body:MemoryRequest, request:Request, user_id:str=Depends(current_user)):
    try: return request.app.state.accounts.add_memory(user_id,body.content)
    except AccountError as exc: handle_account_error(exc)

@app.get('/v1/memories')
async def memories(request:Request, limit:int=100, user_id:str=Depends(current_user)):
    return {'items':request.app.state.accounts.list_memories(user_id,limit)}

@app.delete('/v1/memories/{memory_id}')
async def delete_memory(memory_id:str, request:Request, user_id:str=Depends(current_user)):
    try: return request.app.state.accounts.delete_memory(user_id,memory_id)
    except AccountError as exc: handle_account_error(exc)

@app.post('/v1/queue/join')
async def join(request:Request, user_id:str=Depends(current_user), idempotency_key:str=Header(default='',alias='Idempotency-Key')):
    try:
        shard=shard_for_user(user_id)
        return await request.app.state.queues[shard].join(user_id, idempotency_key or None)
    except Exception as exc: raise HTTPException(status_code=503, detail='could not join queue') from exc

@app.get('/v1/queue/{ticket}')
async def status(ticket:str, request:Request, user_id:str=Depends(current_user)):
    if len(ticket)!=32 or any(c not in '0123456789abcdef' for c in ticket): raise HTTPException(status_code=400,detail='invalid ticket')
    try:
        shard=shard_for_resource(ticket) or shard_for_user(user_id)
        if shard not in request.app.state.queues: raise HTTPException(status_code=404,detail='ticket shard not found')
        result=await request.app.state.queues[shard].status(ticket,user_id)
        if result['state'] in ('expired','not_found'): raise HTTPException(status_code=404,detail='ticket expired or not found')
        return result
    except HTTPException: raise
    except Exception as exc: raise HTTPException(status_code=503,detail='queue backend unavailable') from exc

@app.post('/v1/queue/leave')
async def leave(body:LeaveRequest, request:Request, user_id:str=Depends(current_user)):
    try:
        shard=shard_for_resource(body.ticket) or shard_for_user(user_id)
        if shard not in request.app.state.queues: raise HTTPException(status_code=404,detail='ticket shard not found')
        return await request.app.state.queues[shard].leave(body.ticket,user_id)
    except HTTPException: raise
    except Exception as exc: raise HTTPException(status_code=503, detail='could not leave queue') from exc

@app.post('/v1/tasks', status_code=202)
async def submit_task(body:TaskRequest, request:Request, user_id:str=Depends(current_user)):
    try:
        shard=shard_for_user(user_id)
        return await request.app.state.task_dispatchers[shard].submit(user_id,body.task_type,body.payload)
    except Exception as exc: raise HTTPException(status_code=503,detail='task dispatch unavailable') from exc

@app.get('/v1/tasks/{task_id}')
async def task_status(task_id:str, request:Request, user_id:str=Depends(current_user)):
    shard=shard_for_resource(task_id) or shard_for_user(user_id)
    if shard not in request.app.state.task_dispatchers: raise HTTPException(status_code=404,detail='task shard not found')
    result = await request.app.state.task_dispatchers[shard].status(task_id,user_id)
    if not result: raise HTTPException(status_code=404,detail='task not found')
    return result

@app.get('/v1/agent/capabilities')
async def agent_capabilities(user_id: str = Depends(current_user)):
    return capabilities_report()

@app.post('/v1/agent/ask')
async def agent_ask(body: AgentAskRequest, request: Request, user_id: str = Depends(current_user)):
    try:
        # Keep only valid, bounded chat turns; no client-supplied system prompts.
        history = []
        for item in body.history[-12:]:
            if isinstance(item, dict) and item.get('role') in ('user', 'assistant'):
                history.append({'role': item['role'], 'content': str(item.get('content', ''))[:6000]})
        result = await __import__('asyncio').to_thread(request.app.state.intelligence.ask, body.question, history)
        return {'ok': True, **result}
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

@app.post('/v1/agent/research')
async def agent_research(body: ResearchRequest, request: Request, user_id: str = Depends(current_user)):
    try:
        result = await __import__('asyncio').to_thread(request.app.state.intelligence.research, body.query, body.max_results)
        return {'ok': True, **result}
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

@app.post('/v1/agent/learn')
async def agent_learn(body: LearningRequest, request: Request, user_id: str = Depends(current_user)):
    try:
        result = await __import__('asyncio').to_thread(request.app.state.intelligence.learning_plan, body.profession, body.level)
        return {'ok': True, **result}
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

@app.post('/v1/agent/create-web-app')
async def agent_create_web_app(body: AppBuildRequest, request: Request, user_id: str = Depends(current_user)):
    try:
        service = request.app.state.intelligence
        if service.config.llm_ready:
            result = await __import__('asyncio').to_thread(service.generate_web_app, body.name, body.description)
        else:
            result = create_web_app(body.name, body.description)
            result['generated_by'] = 'safe_static_template'
        return {'ok': True, **result}
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

@app.get('/v1/admin/overview', dependencies=[Depends(require_admin)])
async def admin_overview(request:Request):
    redis=request.app.state.redis
    waiting=sum([await redis.zcard(q.waiting) for q in request.app.state.queues.values()])
    active=sum([await redis.zcard(q.active) for q in request.app.state.queues.values()])
    return {'region':REGION,'shards':list(SHARDS),'waiting':waiting,'active':active,
            'redis':(await redis.info('memory')).get('used_memory_human')}
