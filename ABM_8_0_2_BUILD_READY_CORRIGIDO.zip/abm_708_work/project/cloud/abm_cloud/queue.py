from __future__ import annotations
import uuid
"""Redis admission queue designed for one logical shard.

All script keys share a Redis Cluster hash tag. Deploy one queue namespace per
region/shard and route each user to a stable shard at the gateway.
"""
from .sharding import new_resource_id
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from redis.asyncio import Redis
from .config import ACTIVE_CAPACITY, QUEUE_TTL_SECONDS, QUEUE_SHARD

def shard_base(shard: str) -> str:
    tag = '{' + ''.join(c for c in shard if c.isalnum() or c in '-_')[:48] + '}'
    return 'abm:q:' + tag + ':'

JOIN_LUA = r'''
local now = tonumber(redis.call('TIME')[1])
local ttl = tonumber(ARGV[2])
local idem_key = KEYS[6]
local previous = redis.call('GET', idem_key)
if previous then
  local state = redis.call('GET', KEYS[3] .. previous) or 'expired'
  local rank = redis.call('ZRANK', KEYS[2], previous)
  local active = redis.call('ZSCORE', KEYS[4], previous)
  local pos = rank and (rank + 1) or 0
  return {previous, state, pos, redis.call('ZCARD', KEYS[2]), redis.call('ZCARD', KEYS[4]), 'reused'}
end
redis.call('ZREMRANGEBYSCORE', KEYS[4], '-inf', now)
local ticket = ARGV[1]
local seq = redis.call('INCR', KEYS[1])
redis.call('ZADD', KEYS[2], seq, ticket)
redis.call('SET', KEYS[3] .. ticket, 'waiting', 'EX', ttl)
redis.call('SET', KEYS[5] .. ticket, ARGV[4], 'EX', ttl)
redis.call('SET', idem_key, ticket, 'EX', math.min(ttl, 3600))
local active = redis.call('ZCARD', KEYS[4])
local capacity = tonumber(ARGV[3])
while active < capacity do
  local first = redis.call('ZRANGE', KEYS[2], 0, 0)
  if #first == 0 then break end
  local candidate = first[1]
  local candidate_state = redis.call('GET', KEYS[3] .. candidate)
  local candidate_owner = redis.call('GET', KEYS[5] .. candidate)
  redis.call('ZREM', KEYS[2], candidate)
  if candidate_state and candidate_owner then
    redis.call('ZADD', KEYS[4], now + ttl, candidate)
    redis.call('SET', KEYS[3] .. candidate, 'active', 'EX', ttl)
    active = active + 1
  else
    redis.call('DEL', KEYS[3] .. candidate, KEYS[5] .. candidate)
  end
end
local state = redis.call('GET', KEYS[3] .. ticket) or 'expired'
local rank = redis.call('ZRANK', KEYS[2], ticket)
return {ticket, state, state == 'active' and 0 or (rank and rank + 1 or -1), redis.call('ZCARD', KEYS[2]), redis.call('ZCARD', KEYS[4]), 'created'}
'''

STATUS_LUA = r'''
local now = tonumber(redis.call('TIME')[1])
local ttl = tonumber(ARGV[3])
local capacity = tonumber(ARGV[4])
redis.call('ZREMRANGEBYSCORE', KEYS[3], '-inf', now)
local active = redis.call('ZCARD', KEYS[3])
while active < capacity do
  local first = redis.call('ZRANGE', KEYS[2], 0, 0)
  if #first == 0 then break end
  local candidate = first[1]
  local candidate_state = redis.call('GET', KEYS[1] .. candidate)
  local candidate_owner = redis.call('GET', KEYS[4] .. candidate)
  redis.call('ZREM', KEYS[2], candidate)
  if candidate_state and candidate_owner then
    redis.call('ZADD', KEYS[3], now + ttl, candidate)
    redis.call('SET', KEYS[1] .. candidate, 'active', 'EX', ttl)
    active = active + 1
  else
    redis.call('DEL', KEYS[1] .. candidate, KEYS[4] .. candidate)
  end
end
local ticket = ARGV[1]
local owner = redis.call('GET', KEYS[4] .. ticket)
if not owner or owner ~= ARGV[2] then return {'not_found', -1, active} end
local state = redis.call('GET', KEYS[1] .. ticket)
if not state then return {'expired', -1, active} end
if state == 'active' then
  local expiry = redis.call('ZSCORE', KEYS[3], ticket)
  if expiry then return {state, 0, active} end
  return {'expired', -1, active}
end
local rank = redis.call('ZRANK', KEYS[2], ticket)
if not rank then return {'expired', -1, active} end
return {state, rank + 1, active}
'''

LEAVE_LUA = r'''
local now = tonumber(redis.call('TIME')[1])
local ticket = ARGV[1]
local owner = redis.call('GET', KEYS[4] .. ticket)
if not owner or owner ~= ARGV[4] then return {'not_found', -1} end
local ttl = tonumber(ARGV[3])
redis.call('ZREMRANGEBYSCORE', KEYS[3], '-inf', now)
redis.call('ZREM', KEYS[2], ticket)
redis.call('ZREM', KEYS[3], ticket)
redis.call('DEL', KEYS[1] .. ticket)
redis.call('DEL', KEYS[4] .. ticket)
local capacity = tonumber(ARGV[2])
local active = redis.call('ZCARD', KEYS[3])
while active < capacity do
  local first = redis.call('ZRANGE', KEYS[2], 0, 0)
  if #first == 0 then break end
  local next_ticket = first[1]
  local next_state = redis.call('GET', KEYS[1] .. next_ticket)
  local next_owner = redis.call('GET', KEYS[4] .. next_ticket)
  redis.call('ZREM', KEYS[2], next_ticket)
  if next_state and next_owner then
    redis.call('ZADD', KEYS[3], now + ttl, next_ticket)
    redis.call('SET', KEYS[1] .. next_ticket, 'active', 'EX', ttl)
    active = active + 1
  else
    redis.call('DEL', KEYS[1] .. next_ticket, KEYS[4] .. next_ticket)
  end
end
return {'ok', redis.call('ZCARD', KEYS[2]), active}
'''

class AdmissionQueue:
    def __init__(self, redis: Redis, shard: str = QUEUE_SHARD):
        self.redis = redis
        self.shard = shard
        base = shard_base(shard)
        self.seq = base + 'sequence'
        self.waiting = base + 'waiting'
        self.state_prefix = base + 'state:'
        self.active = base + 'active'
        self.owner_prefix = base + 'owner:'
        self.idem_prefix = base + 'idem:'

    async def join(self, user_id: str, idempotency_key: str | None = None):
        ticket = new_resource_id(self.shard)
        idem = (idempotency_key or uuid.uuid4().hex)[:100]
        result = await self.redis.eval(
            JOIN_LUA, 6, self.seq, self.waiting, self.state_prefix, self.active,
            self.owner_prefix, self.idem_prefix + user_id + ':' + idem,
            ticket, QUEUE_TTL_SECONDS, ACTIVE_CAPACITY, user_id,
        )
        values = [v.decode() if isinstance(v, bytes) else v for v in result]
        return {'ticket': values[0], 'state': values[1], 'queue_position': int(values[2]),
                'waiting_users': int(values[3]), 'active_users': int(values[4]),
                'idempotent_reuse': values[5] == 'reused', 'region_shard': self.shard}

    async def status(self, ticket: str, user_id: str):
        result = await self.redis.eval(
            STATUS_LUA, 4, self.state_prefix, self.waiting, self.active,
            self.owner_prefix, ticket, user_id, QUEUE_TTL_SECONDS, ACTIVE_CAPACITY
        )
        state = result[0].decode() if isinstance(result[0], bytes) else result[0]
        if state == 'not_found':
            return {'state': 'not_found', 'queue_position': -1, 'active_users': int(result[2])}
        return {'state': state, 'queue_position': int(result[1]), 'active_users': int(result[2])}

    async def leave(self, ticket: str, user_id: str):
        result = await self.redis.eval(
            LEAVE_LUA, 4, self.state_prefix, self.waiting, self.active,
            self.owner_prefix, ticket, ACTIVE_CAPACITY, QUEUE_TTL_SECONDS, user_id,
        )
        status = result[0].decode() if isinstance(result[0], bytes) else result[0]
        if status == 'not_found':
            return {'left': False, 'reason': 'not_found_or_not_owner'}
        return {'left': True, 'waiting_users': int(result[1]), 'active_users': int(result[2])}
