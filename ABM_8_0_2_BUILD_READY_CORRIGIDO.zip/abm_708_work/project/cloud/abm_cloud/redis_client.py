"""Create a standalone Redis client or a Redis Cluster client by configuration."""
import os
from redis.asyncio import Redis

def create_redis_client(url: str):
    if os.getenv('ABM_REDIS_CLUSTER', 'false').lower() in ('1','true','yes'):
        from redis.asyncio.cluster import RedisCluster
        return RedisCluster.from_url(url, decode_responses=False, health_check_interval=30)
    return Redis.from_url(url, decode_responses=False, health_check_interval=30)
