"""Stable rendezvous routing and resource-to-shard lookup."""
import hashlib, os
from .config import QUEUE_SHARD

SHARDS = tuple(s.strip() for s in os.getenv('ABM_QUEUE_SHARDS', QUEUE_SHARD).split(',') if s.strip()) or (QUEUE_SHARD,)
SHARD_PREFIXES = {hashlib.sha256(s.encode()).hexdigest()[:12]: s for s in SHARDS}
if len(SHARD_PREFIXES) != len(SHARDS):
    raise RuntimeError('Colisão no identificador de shard; escolha nomes diferentes.')

def shard_for_user(user_id: str) -> str:
    if len(SHARDS) == 1: return SHARDS[0]
    return max(SHARDS, key=lambda shard: hashlib.sha256((user_id + ':' + shard).encode()).digest())

def new_resource_id(shard: str) -> str:
    import uuid
    prefix = hashlib.sha256(shard.encode()).hexdigest()[:12]
    return prefix + uuid.uuid4().hex[:20]

def shard_for_resource(resource_id: str):
    if not isinstance(resource_id, str) or len(resource_id) != 32: return None
    return SHARD_PREFIXES.get(resource_id[:12])
