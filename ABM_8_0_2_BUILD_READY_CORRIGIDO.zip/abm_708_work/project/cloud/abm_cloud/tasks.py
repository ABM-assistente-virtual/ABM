from __future__ import annotations
"""Durable task dispatch using Redis Streams; handlers run in separate workers."""
import json, time
from .sharding import new_resource_id
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from redis.asyncio import Redis
from .config import QUEUE_SHARD, TASK_STREAM_MAXLEN

def task_keys(shard: str):
    tag = '{' + ''.join(c for c in shard if c.isalnum() or c in '-_')[:48] + '}'
    return f'abm:tasks:{tag}:stream', f'abm:tasks:{tag}:status:'

class TaskDispatcher:
    def __init__(self, redis: Redis, shard: str = QUEUE_SHARD):
        self.redis = redis
        self.shard = shard
        self.stream, self.status_prefix = task_keys(shard)

    async def submit(self, user_id: str, task_type: str, payload: dict):
        task_id = new_resource_id(self.shard)
        now = int(time.time())
        record = {'task_id': task_id, 'user_id': user_id, 'task_type': task_type,
                  'payload': json.dumps(payload, ensure_ascii=False), 'created_at': str(now)}
        await self.redis.xadd(self.stream, record, maxlen=TASK_STREAM_MAXLEN, approximate=True)
        await self.redis.hset(self.status_prefix + task_id, mapping={'user_id': user_id, 'state': 'queued',
            'task_type': task_type, 'created_at': str(now)})
        await self.redis.expire(self.status_prefix + task_id, 7 * 86400)
        return {'task_id': task_id, 'state': 'queued', 'created_at': now}

    async def status(self, task_id: str, user_id: str):
        data = await self.redis.hgetall(self.status_prefix + task_id)
        if not data: return None
        decoded = {k.decode(): v.decode() for k, v in data.items()}
        if decoded.get('user_id') != user_id: return None
        decoded.pop('user_id', None)
        return {'task_id': task_id, **decoded}
