"""Concurrent Redis Streams workers; one blocking consumer loop per configured shard."""
import asyncio, json, os, re, socket, time
from .sharding import SHARDS
from .tasks import task_keys

GROUP = os.getenv('ABM_WORKER_GROUP', 'abm-workers')
CONSUMER = os.getenv('ABM_WORKER_ID', socket.gethostname())

def select_worker_shards(shards, hostname: str, partitions: int = 1):
    """Assign stable shard subsets to StatefulSet ordinal; replicas share partitions."""
    partitions = max(1, int(partitions))
    match = re.search(r"-(\d+)$", str(hostname or ""))
    if not match or partitions == 1:
        return tuple(shards)
    partition = int(match.group(1)) % partitions
    selected = tuple(shard for index, shard in enumerate(shards) if index % partitions == partition)
    return selected or tuple(shards)

async def handle(task_type: str, payload: dict):
    if task_type == 'system.ping':
        return {'message': 'ABM worker ativo', 'received': payload}
    if task_type == 'math.add':
        a, b = float(payload['a']), float(payload['b'])
        return {'result': a + b}
    if task_type == 'text.count_words':
        text = str(payload.get('text', ''))[:100000]
        return {'characters': len(text), 'words': len(text.split())}
    if task_type == 'json.validate':
        value = payload.get('value')
        return {'valid': isinstance(value, (dict, list, str, int, float, bool)) or value is None}
    raise ValueError(f'No handler registered for task_type={task_type}')

async def process_messages(redis, stream, status_prefix, messages):
    for msg_id, fields in messages:
        if fields and isinstance(next(iter(fields.keys())), bytes):
            fields = {k.decode(): v.decode() for k, v in fields.items()}
        task_id = fields['task_id']; key = status_prefix + task_id
        await redis.hset(key, mapping={'state':'running','worker':CONSUMER,'started_at':str(int(time.time()))})
        try:
            result = await handle(fields['task_type'], json.loads(fields['payload']))
            await redis.hset(key, mapping={'state':'completed','result':json.dumps(result,ensure_ascii=False),'finished_at':str(int(time.time()))})
        except Exception as exc:
            await redis.hset(key, mapping={'state':'failed','error':str(exc)[:500],'finished_at':str(int(time.time()))})
        await redis.xack(stream, GROUP, msg_id)

async def consume_stream(redis, stream, status_prefix):
    try:
        await redis.xgroup_create(stream, GROUP, id='0', mkstream=True)
    except Exception as exc:
        if 'BUSYGROUP' not in str(exc):
            raise
    while True:
        # Recover pending work first, then block only this shard's consumer loop.
        try:
            reclaimed = await redis.xautoclaim(stream, GROUP, CONSUMER, 60000, '0-0', count=20)
            await process_messages(redis, stream, status_prefix, reclaimed[1])
        except Exception:
            await asyncio.sleep(1)
        batches = await redis.xreadgroup(GROUP, CONSUMER, {stream: '>'}, count=20, block=1000)
        for _stream, messages in batches:
            await process_messages(redis, stream, status_prefix, messages)

async def run():
    from .redis_client import create_redis_client
    redis = create_redis_client(os.getenv('ABM_REDIS_URL','redis://redis:6379/0'))
    partitions = int(os.getenv('ABM_WORKER_PARTITIONS', '1'))
    selected_shards = select_worker_shards(SHARDS, CONSUMER, partitions)
    stream_map = {task_keys(shard)[0]: task_keys(shard)[1] for shard in selected_shards}
    try:
        await redis.ping()
        await asyncio.gather(*(consume_stream(redis, stream, prefix) for stream, prefix in stream_map.items()))
    finally:
        await redis.aclose()

if __name__ == '__main__': asyncio.run(run())
