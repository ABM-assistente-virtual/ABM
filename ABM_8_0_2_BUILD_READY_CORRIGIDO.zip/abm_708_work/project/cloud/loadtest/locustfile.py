"""Controlled Locust smoke/load profile. Start small; do not jump to millions."""
from locust import HttpUser, task, between
import os

class ABMUser(HttpUser):
    wait_time = between(1, 3)
    token = None
    @task
    def health_and_capacity(self):
        self.client.get('/health', name='/health')
        self.client.get('/v1/capacity', name='/v1/capacity')
    def on_start(self):
        email = f"load-{os.urandom(8).hex()}@example.test"
        response = self.client.post('/v1/accounts/register', json={'email':email,'password':'LoadTest-Password-123'})
        if response.status_code == 201:
            login = self.client.post('/v1/accounts/login', json={'email':email,'password':'LoadTest-Password-123'})
            if login.ok: self.token = login.json()['access_token']
    @task(2)
    def queue_cycle(self):
        if not self.token: return
        headers={'Authorization':f'Bearer {self.token}'}
        response=self.client.post('/v1/queue/join',headers=headers)
        if response.ok:
            ticket=response.json()['ticket']
            self.client.get(f'/v1/queue/{ticket}',headers=headers)
            self.client.post('/v1/queue/leave',headers=headers,json={'ticket':ticket})
