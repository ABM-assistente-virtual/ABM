-- PostgreSQL baseline migration. Run with a migration tool in production.
CREATE TABLE IF NOT EXISTS schema_migrations (
  version TEXT PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_memories_user_created_id ON memories(user_id, created_at DESC, id);
INSERT INTO schema_migrations(version) VALUES ('001_global_core') ON CONFLICT DO NOTHING;
