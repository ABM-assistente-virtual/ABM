import tempfile, os, unittest
from abm_cloud.accounts import AccountStore, AccountError

class AccountStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.store=AccountStore(os.path.join(self.tmp.name,'db.sqlite3'),'x'*64)
    def tearDown(self): self.tmp.cleanup()
    def test_register_login_and_profile(self):
        user=self.store.register('one@example.com','correct-horse-1')
        token=self.store.login('ONE@example.com','correct-horse-1')['access_token']
        self.assertEqual(self.store.verify(token),user['user_id'])
        self.assertEqual(self.store.profile(user['user_id'])['email'],'one@example.com')
    def test_duplicate_email_rejected(self):
        self.store.register('one@example.com','correct-horse-1')
        with self.assertRaises(AccountError): self.store.register('one@example.com','another-pass-2')
    def test_wrong_password_rejected(self):
        self.store.register('one@example.com','correct-horse-1')
        with self.assertRaises(AccountError): self.store.login('one@example.com','wrong-password')
    def test_memory_isolation(self):
        a=self.store.register('a@example.com','correct-horse-1')['user_id']
        b=self.store.register('b@example.com','correct-horse-2')['user_id']
        item=self.store.add_memory(a,'memória privada A')
        self.assertEqual(len(self.store.list_memories(a)),1)
        self.assertEqual(len(self.store.list_memories(b)),0)
        with self.assertRaises(AccountError): self.store.delete_memory(b,item['memory_id'])
        self.assertTrue(self.store.delete_memory(a,item['memory_id'])['deleted'])
    def test_tampered_token_rejected(self):
        self.store.register('a@example.com','correct-horse-1')
        token=self.store.login('a@example.com','correct-horse-1')['access_token']
        with self.assertRaises(AccountError): self.store.verify(token+'x')

if __name__=='__main__': unittest.main()
