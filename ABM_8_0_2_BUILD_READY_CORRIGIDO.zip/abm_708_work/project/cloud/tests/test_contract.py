import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_api_routes_exist():
    source = (ROOT / "abm_cloud" / "main.py").read_text()
    for route in ['/health', '/v1/capacity', '/v1/queue/join', '/v1/queue/{ticket}', '/v1/queue/leave']:
        assert route in source

def test_queue_is_atomic_and_uses_ordered_queue():
    source = (ROOT / "abm_cloud" / "queue.py").read_text()
    assert "redis.call('INCR'" in source
    assert "redis.call('ZADD'" in source
    assert "redis.call('ZRANK'" in source
    assert "redis.call('ZCARD'" in source

def test_ticket_validation():
    source = (ROOT / "abm_cloud" / "main.py").read_text()
    assert "pattern=r'^[a-f0-9]+$'" in source
    assert 'ticket: str' in source
