import html
from abm_cloud.app_factory import create_web_app
from abm_cloud.intelligence import IntelligenceConfig, IntelligenceService, capabilities_report


def test_web_app_scaffold_contains_three_editable_files():
    result = create_web_app('Minha App', 'Uma aplicação de teste')
    assert set(result['files']) == {'index.html', 'style.css', 'app.js'}
    assert 'Minha App' in result['files']['index.html']
    assert 'localStorage' in result['files']['app.js']


def test_web_app_scaffold_escapes_untrusted_text():
    result = create_web_app('<script>alert(1)</script>', 'descrição')
    assert '<script>alert(1)</script>' not in result['files']['index.html']
    assert 'alert(1)' not in result['files']['index.html']


def test_intelligence_requires_server_configuration():
    cfg = IntelligenceConfig()
    cfg.base_url = ''
    cfg.api_key = ''
    cfg.model = ''
    cfg.search_key = ''
    service = IntelligenceService(cfg)
    try:
        service.ask('Olá')
        assert False, 'Deveria exigir configuração'
    except RuntimeError as exc:
        assert 'não configurado' in str(exc)
    assert capabilities_report(cfg)['general_language_model'] is False


def test_chat_uses_server_model_and_returns_text(monkeypatch):
    cfg = IntelligenceConfig()
    cfg.base_url = 'https://llm.example/v1'
    cfg.api_key = 'server-secret'
    cfg.model = 'model-test'
    service = IntelligenceService(cfg)
    seen = {}
    def fake_post(url, payload, headers=None):
        seen['url'] = url
        seen['payload'] = payload
        seen['headers'] = headers
        return {'choices': [{'message': {'content': 'Resposta de teste'}}]}
    monkeypatch.setattr(service, '_post_json', fake_post)
    result = service.ask('Explica o ABM')
    assert result['answer'] == 'Resposta de teste'
    assert seen['url'].endswith('/chat/completions')
    assert seen['headers']['Authorization'] == 'Bearer server-secret'
    assert 'server-secret' not in str(result)


def test_research_cites_only_returned_sources(monkeypatch):
    cfg = IntelligenceConfig()
    cfg.base_url = 'https://llm.example/v1'; cfg.api_key = 'x'; cfg.model = 'm'; cfg.search_key = 'y'
    service = IntelligenceService(cfg)
    monkeypatch.setattr(service, 'search_web', lambda q, n: [
        {'title':'Fonte A','url':'https://example.org/a','content':'Excerto verificável','score':0.9}
    ])
    monkeypatch.setattr(service, '_chat', lambda messages, temperature=0.1: 'Resumo [1]')
    result = service.research('pergunta')
    assert result['summary'] == 'Resumo [1]'
    assert result['sources'][0]['url'] == 'https://example.org/a'


def test_model_app_generator_accepts_safe_files(monkeypatch):
    cfg = IntelligenceConfig()
    cfg.base_url = 'https://llm.example/v1'; cfg.api_key = 'x'; cfg.model = 'm'
    service = IntelligenceService(cfg)
    monkeypatch.setattr(service, '_chat', lambda messages, temperature=0.2:
        '{"files":{"index.html":"<h1>ABM</h1>","style.css":"body{}","app.js":"console.log(1)"}}')
    result = service.generate_web_app('Teste', 'Uma app simples')
    assert result['generated_by'] == 'configured_language_model'
    assert 'index.html' in result['files']


def test_model_app_generator_rejects_path_traversal(monkeypatch):
    cfg = IntelligenceConfig()
    cfg.base_url = 'https://llm.example/v1'; cfg.api_key = 'x'; cfg.model = 'm'
    service = IntelligenceService(cfg)
    monkeypatch.setattr(service, '_chat', lambda messages, temperature=0.2:
        '{"files":{"../bad.js":"x","index.html":"ok"}}')
    try:
        service.generate_web_app('Teste', 'Uma app')
        assert False, 'Path traversal deveria ser rejeitado'
    except RuntimeError as exc:
        assert 'nome de ficheiro' in str(exc)


def test_worker_new_text_task():
    import asyncio
    from abm_cloud.worker import handle
    result = asyncio.run(handle('text.count_words', {'text': 'ABM global funciona'}))
    assert result == {'characters': 19, 'words': 3}


def test_worker_unknown_task_fails_closed():
    import asyncio
    from abm_cloud.worker import handle
    try:
        asyncio.run(handle('arbitrary.shell', {}))
        assert False, 'Worker não deve executar tarefas arbitrárias'
    except ValueError as exc:
        assert 'No handler registered' in str(exc)


def test_worker_shard_partitioning_is_stable_and_complete():
    from abm_cloud.worker import select_worker_shards
    shards = [f'shard-{i:03d}' for i in range(32)]
    groups = [select_worker_shards(shards, f'abm-worker-{i}', 8) for i in range(8)]
    flattened = [item for group in groups for item in group]
    assert len(flattened) == len(shards)
    assert set(flattened) == set(shards)
    assert groups[0] == select_worker_shards(shards, 'abm-worker-8', 8)


def test_model_app_generator_rejects_remote_script(monkeypatch):
    cfg = IntelligenceConfig()
    cfg.base_url = 'https://llm.example/v1'; cfg.api_key = 'x'; cfg.model = 'm'
    service = IntelligenceService(cfg)
    monkeypatch.setattr(service, '_chat', lambda messages, temperature=0.2:
        '{"files":{"index.html":"<script src=\\\"https://evil.example/x.js\\\"></script>"}}')
    try:
        service.generate_web_app('Teste', 'Uma app')
        assert False, 'Script remoto deveria ser rejeitado'
    except RuntimeError as exc:
        assert 'externos' in str(exc)
