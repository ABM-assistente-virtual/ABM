from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_postgres_adapter_and_pool_are_configured():
    accounts = (ROOT / 'abm_cloud' / 'accounts.py').read_text()
    main = (ROOT / 'abm_cloud' / 'main.py').read_text()
    requirements = (ROOT / 'requirements.txt').read_text()
    assert 'class PostgresAccountStore' in accounts
    assert 'ConnectionPool' in accounts
    assert 'PostgresAccountStore(DATABASE_URL' in main
    assert 'psycopg[binary,pool]' in requirements

def test_compose_has_database_healthcheck_and_persistent_volume():
    compose = (ROOT / 'docker-compose.yml').read_text()
    assert 'postgres:16-alpine' in compose
    assert 'pg_isready' in compose
    assert 'abm-postgres:/var/lib/postgresql/data' in compose
    assert 'ABM_DATABASE_URL:' in compose
