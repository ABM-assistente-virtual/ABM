import asyncio
from abm_cloud.queue import AdmissionQueue
from abm_cloud.tasks import TaskDispatcher, task_keys

class FakeRedis:
    def __init__(self): self.calls=[]; self.hashes={}
    async def eval(self,*args): self.calls.append(args); return [b'ticket123',b'waiting',1,1,0,b'created']
    async def xadd(self,*args,**kwargs): self.calls.append(('xadd',args,kwargs)); return b'1-0'
    async def hset(self,key,mapping): self.hashes[key]=mapping
    async def expire(self,*args): pass
    async def hgetall(self,key): return {b'user_id':b'user-1',b'state':b'queued',b'task_type':b'math.add'}

def test_queue_uses_cluster_hash_tag_and_user_owner():
    redis=FakeRedis(); queue=AdmissionQueue(redis)
    result=asyncio.run(queue.join('user-1','retry-1'))
    assert result['ticket']=='ticket123'
    keys=redis.calls[0][2:8]
    assert len(keys)==6 and all('{' in str(k) and '}' in str(k) for k in keys)
    assert 'owner:' in str(keys[4])

def test_task_dispatch_and_owner_isolation():
    redis=FakeRedis(); dispatcher=TaskDispatcher(redis)
    result=asyncio.run(dispatcher.submit('user-1','math.add',{'a':2,'b':3}))
    assert result['state']=='queued'
    status=asyncio.run(dispatcher.status('abc','user-1'))
    assert status['state']=='queued'
    assert asyncio.run(dispatcher.status('abc','user-2')) is None
    stream, status_prefix = task_keys('shard-a')
    assert stream.startswith('abm:tasks:') and status_prefix.startswith('abm:tasks:')
    assert '{shard-a}' in stream and '{shard-a}' in status_prefix

def test_rendezvous_sharding_is_stable_and_selects_configured_shard(monkeypatch):
    import importlib, os
    monkeypatch.setenv('ABM_QUEUE_SHARDS', 'alpha,beta,gamma')
    import abm_cloud.sharding as sharding
    importlib.reload(sharding)
    first = sharding.shard_for_user('user-123')
    assert first in ('alpha','beta','gamma')
    assert sharding.shard_for_user('user-123') == first
    assert sharding.shard_for_user('another-user') in ('alpha','beta','gamma')
    monkeypatch.delenv('ABM_QUEUE_SHARDS', raising=False)
    importlib.reload(sharding)

def test_ticket_and_task_ids_encode_shard_for_future_status_lookup(monkeypatch):
    import importlib
    monkeypatch.setenv('ABM_QUEUE_SHARDS', 'north,south')
    import abm_cloud.sharding as sharding
    importlib.reload(sharding)
    for shard in sharding.SHARDS:
        resource_id = sharding.new_resource_id(shard)
        assert len(resource_id) == 32
        assert sharding.shard_for_resource(resource_id) == shard
    monkeypatch.delenv('ABM_QUEUE_SHARDS', raising=False)
    importlib.reload(sharding)
