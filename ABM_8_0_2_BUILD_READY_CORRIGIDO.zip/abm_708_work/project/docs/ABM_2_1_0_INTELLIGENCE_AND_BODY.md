# ABM 2.1.0 — Inteligência, ferramentas e limites do Android

## Componentes novos

- `cloud/abm_cloud/intelligence.py`: gateway de LLM compatível com Chat Completions, pesquisa Tavily e síntese com fontes, currículos de aprendizagem e geração de código Web.
- `cloud/abm_cloud/app_factory.py`: starter Web HTML/CSS/JS seguro quando não existe fornecedor LLM configurado.
- `POST /v1/agent/ask`: conversa autenticada com o modelo configurado.
- `POST /v1/agent/research`: pesquisa e resumo com fontes.
- `POST /v1/agent/learn`: plano de aprendizagem por profissão/competência.
- `POST /v1/agent/create-web-app`: projeto Web gerado pelo LLM; se não houver LLM, cria starter template.
- `GET /v1/agent/capabilities`: revela disponibilidade real dos fornecedores.

## Configuração

Definir no ambiente privado do servidor `ABM_LLM_BASE_URL`, `ABM_LLM_API_KEY`, `ABM_LLM_MODEL` e `ABM_TAVILY_API_KEY`. Não colocar chaves no APK, no repositório nem em mensagens. A API LLM deve ser compatível com `/chat/completions`; URL pública deve ser HTTPS. O compose encaminha estas variáveis para a API.

## ABM BODY — acesso amplo, não ilimitado

O BODY tem adaptadores para abrir aplicações instaladas, câmara, seletor de ficheiros, navegador, mapas, partilha de texto, Definições, pausa multimédia e marcador telefónico. O Android continua a decidir o que uma aplicação pode fazer. O ABM não pode ignorar PIN/biometria, permissões, sandbox de outras aplicações, restrições de chamadas, políticas do fabricante ou consentimento de terceiros. Ações sensíveis requerem confirmação e as ações de microfone/câmara têm de ser visíveis.

A audição contínua existente depende da Activity visível e do serviço de reconhecimento de voz disponível no aparelho. Não é uma escuta escondida nem uma garantia de funcionamento com ecrã bloqueado. A análise de ambiente por câmara é iniciada pelo utilizador; não existe vigilância permanente.

## Capacidades entregues vs. não entregues

| Pedido | Estado em 2.1.0 |
|---|---|
| Perguntas abertas | Gateway LLM implementado; exige chave/modelo e não garante resposta infalível |
| Pesquisa Web | Tavily + resumo com fontes; exige chave e não cobre literalmente toda a Internet |
| Tarefas em aplicações | Conectores Android ampliados; não existe controlo universal de todas as apps |
| Aprender profissões | Currículos e exercícios gerados; não substitui prática, supervisão ou certificação |
| Criar aplicações | Gera projetos Web HTML/CSS/JS; não compila/publica APK automaticamente |
| Chamadas | Abre marcador para confirmação humana; não atende nem fala como se fosse o utilizador |
| Perceção contínua | Sensores acionados de forma visível e autorizada; não há monitorização oculta |
| 30 milhões | Arquitetura configurada com 256 shards; precisa de cluster real e ensaios de carga para comprovar |

## 30 milhões — dimensionamento

O Kubernetes é um modelo de implantação com 256 shards lógicos, API HPA até 200 réplicas e workers em StatefulSet particionado por ordinal (16 partições, HPA 16–128 réplicas). É apenas uma configuração inicial: precisa de Redis Cluster gerido, PostgreSQL dimensionado, múltiplas zonas/regiões, WAF/DDoS, backups, object storage, monitorização e testes. Usar `python tools/estimate_scale.py --users 30000000` para ver uma estimativa baseada em premissas editáveis. O valor não é benchmark. Testar em etapas (1k, 10k, 100k, 1M, depois 30M) medindo RAM, latência, throughput e recuperação.
