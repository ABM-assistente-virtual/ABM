# ABM Android 2.5.0 — Adaptive Access Foundation

## O que esta versão acrescenta
- `ABMAdaptiveInputEngine`: núcleo Java independente de interface para entrada adaptativa.
- Entrada de pose da cabeça normalizada (`yaw`, `pitch`) com suavização, zona morta e limites de sensibilidade.
- Seleção por permanência (dwell) configurável.
- Motor de varrimento por interruptor: lista de alvos, avanço temporizado e seleção por um evento de interruptor.
- API de eventos para a interface/serviço de acessibilidade consumir.

## Limites desta entrega
- O motor recebe medições de cabeça; não captura vídeo nem calcula pose facial. É necessário ligar um rastreador de câmara compatível e obter consentimento/permissão antes de ativar a câmara.
- O varrimento é a lógica de seleção; a integração com teclas físicas/Bluetooth/USB e com os elementos reais do ecrã ainda precisa de um adaptador Android e testes em dispositivos.
- Não há rastreamento ocular nesta versão. ML Kit Face Detection pode fornecer alguns indicadores faciais, mas não é um rastreador de direção do olhar calibrado.
- Não substitui Switch Access, Voice Access, TalkBack ou as proteções de segurança do Android.
- Nenhuma funcionalidade desbloqueia o ecrã bloqueado nem contorna PIN/biometria.

## Contrato de integração
1. Obter pose da cabeça de um sensor/tracker com permissão explícita.
2. Normalizar yaw e pitch para [-1, 1].
3. Chamar `updateHeadPose(yaw, pitch, elapsedRealtime)`.
4. Renderizar o cursor para `CURSOR_MOVED` e executar seleção acessível para `DWELL_SELECT`.
5. Para interruptor, configurar `setScanItems(labels, intervalMs)`, chamar `startSwitchScan`, `advanceSwitchScan` e `pressSwitch` a partir do adaptador de hardware.
6. A aplicação anfitriã deve expor ações com rótulos acessíveis, permitir pausa imediata e indicar visual/sonoramente quando o controlo adaptativo está ativo.

## Compatibilidade
O módulo é Java puro e evita APIs Android recentes. A aplicação-base continua com `minSdk 26` (Android 8.0+). A compatibilidade final depende das bibliotecas e do dispositivo.
