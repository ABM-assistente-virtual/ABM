# ABM 2.6.0 — Camera Head Tracking Foundation

## O que esta versão acrescenta
- `ABMHeadPoseMapper`: calibração de pose neutra, conversão de yaw/pitch em coordenadas normalizadas e limites configuráveis.
- `ABMFacePoseTracker`: adaptador ML Kit Face Detection que recebe frames `InputImage` fornecidos pelo anfitrião e emite pose relativa da cabeça.
- `ABMAdaptiveCursorView`: vista reutilizável para desenhar o indicador do cursor adaptativo.
- Testes Java puros para calibração, limites, dados inválidos e reinicialização.

## Limites honestos
- O tracker deteta uma face e ângulos da cabeça; não identifica a pessoa, não faz eye-tracking e não autentica o utilizador.
- Esta entrega não liga ainda a captura Camera2/CameraX à Activity, não cria overlay sobre outras aplicações e não injeta toques no sistema.
- O anfitrião deve pedir `CAMERA` em tempo de execução, apresentar um indicador visível, fornecer frames em série e chamar `close()` no ciclo de vida adequado.
- A pose depende da posição da câmara, iluminação, orientação e capacidade do dispositivo. A calibração é obrigatória.
- Não usar este mecanismo como desbloqueio de ecrã nem como fator biométrico de segurança.

## Integração prevista
1. Pedir consentimento e permissão de câmara.
2. Abrir a câmara com API compatível com o dispositivo (Camera2 para a base Android 8.1; CameraX em variantes que suportem a dependência escolhida).
3. Criar `ABMFacePoseTracker` e fornecer `InputImage` sequencialmente.
4. Pedir ao utilizador para olhar em frente e chamar `calibrateFrom`.
5. Em `onHeadPose`, encaminhar valores para `ABMAdaptiveInputEngine.updateHeadPose(yaw, pitch, SystemClock.uptimeMillis())`.
6. Atualizar `ABMAdaptiveCursorView` com as coordenadas do motor.
7. Pausar a câmara quando a funcionalidade for desligada ou a Activity perder o estado apropriado; chamar `close()` ao terminar.

## Compatibilidade
O módulo usa ML Kit Face Detection já declarado no projeto. A compilação Android completa ainda precisa de Gradle/Android SDK e de ser executada num ambiente Android. O código Java puro do mapper pode ser testado separadamente.
