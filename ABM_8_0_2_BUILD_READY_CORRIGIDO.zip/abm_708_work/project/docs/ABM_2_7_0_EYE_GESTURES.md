# ABM 2.7.0 — Gestos oculares (fundação)

## Fluxo
1. O componente que gere a câmara solicita a permissão CAMERA e entrega frames reduzidos a `ABMEyeGestureTracker`.
2. ML Kit fornece probabilidades de olhos abertos.
3. `ABMEyeGestureEngine` exige que ambos os olhos estejam abaixo do limiar durante o tempo configurado.
4. Emite um evento único, com debounce, para o componente de acessibilidade decidir a ação.

## Acessibilidade e segurança
- O gesto deve ser configurável e desligado por padrão até o utilizador o calibrar.
- Não usar como autenticação de identidade ou desbloqueio.
- Disponibilizar sempre método alternativo (voz, interruptor, toque ou leitor de ecrã).
- Mostrar indicador quando a câmara estiver ativa e permitir parar imediatamente.
- O adaptador não guarda frames nem faz reconhecimento de identidade.

## Limitação técnica
ML Kit Face Detection fornece classificação de olhos abertos/fechados, mas não fornece gaze tracking preciso. Para mover um cursor com o olhar será necessário outro modelo de landmarks/pupila, calibração individual e avaliação com utilizadores reais.
