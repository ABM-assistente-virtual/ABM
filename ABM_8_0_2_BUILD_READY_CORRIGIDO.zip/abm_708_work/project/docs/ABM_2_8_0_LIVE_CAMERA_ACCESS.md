# ABM 2.8.0 — Live Camera Access

## O que existe
A atividade `ABMLiveAccessActivity` liga a câmara frontal através de CameraX, executa análise facial com ML Kit, permite calibrar a posição neutra da cabeça e desloca um cursor visual dentro da própria atividade. O fecho ocular prolongado é reconhecido como seleção local e anunciado na interface.

## Como testar
1. Abrir ABM.
2. Escolher **Câmara acessível**.
3. Autorizar a câmara.
4. Manter o rosto visível e pressionar **Calibrar posição central**.
5. Mover a cabeça suavemente e observar o cursor.
6. Fechar ambos os olhos por um período prolongado para testar a seleção ocular. Piscar normalmente não deve selecionar.

## Privacidade e segurança
A câmara só é iniciada depois de o utilizador abrir este ecrã e conceder a permissão. O código não guarda imagens nem usa este mecanismo para identificar pessoas. A seleção ocular não desbloqueia o telefone e não clica noutras aplicações.

## Ainda não implementado
Rastreamento ocular (gaze) calibrado, controlo do sistema inteiro, clique global, integração com desbloqueio, suporte Braille e testes com utilizadores. Estas capacidades exigem APIs e hardware compatíveis e validação adicional.
