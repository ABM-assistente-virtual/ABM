# ABM 2.9.0 — Cursor global e gestos acessíveis

## Objetivo
Ligar a saída do rastreador de cabeça da sessão de câmara a um cursor global e disponibilizar seleção por permanência com autorização explícita.

## Fluxo
1. O utilizador abre Câmara acessível e concede permissão de câmara.
2. Ativa manualmente o serviço ABM em Definições > Acessibilidade.
3. Calibra a posição central.
4. A atividade envia coordenadas normalizadas ao serviço por broadcast protegido por permissão de assinatura.
5. O serviço desenha um cursor TYPE_ACCESSIBILITY_OVERLAY.
6. Se o utilizador ativar seleção por permanência, um evento DWELL_SELECT pode gerar um toque Android via dispatchGesture.
7. Fechar a atividade desliga o cursor.

## Privacidade e segurança
- Janela overlay não tocável e não focável.
- Sem recolha de conteúdo das janelas.
- Sem registo de toques, palavras-passe ou conteúdo de outras apps.
- Seleção por permanência desligada por padrão.
- Não desbloqueia o dispositivo nem contorna o ecrã de bloqueio.

## Limitações
A análise da câmara está vinculada à atividade visível. Portanto, esta versão é uma ponte funcional para cursor/gesto global durante a sessão ABM, não um serviço contínuo de rastreamento em segundo plano. Para controlar outras aplicações sem manter a atividade em primeiro plano, será necessária uma arquitetura separada de captura/serviço em foreground, com notificação persistente, compatibilidade de fabricante e consentimento explícito.
