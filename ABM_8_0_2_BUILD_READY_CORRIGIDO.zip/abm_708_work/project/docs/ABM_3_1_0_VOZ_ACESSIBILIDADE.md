# ABM Android 3.1.0 — Voz e acesso universal

## Objetivo
Unificar comandos de voz simples com o serviço de acessibilidade e o cursor global já introduzidos nas versões anteriores.

## Comandos de voz adicionados
- **Ativa cursor / liga cursor / mostrar cursor** — apresenta o cursor assistivo global.
- **Desativa cursor / esconde cursor / desliga cursor** — remove o cursor.
- **Seleciona / clica / pressionar Enter** — envia um toque na posição atual do cursor, apenas durante uma sessão de cursor ativa.

Foram também acrescentadas variantes de português para abrir notificações, definições e definições rápidas.

## Como utilizar
1. Abrir a aplicação ABM.
2. Nas definições Android > Acessibilidade, ativar **ABM — controlo assistivo**.
3. Na aplicação, tocar em **Falar** para um comando pontual ou em **Modo mãos livres** para ativar a audição contínua voluntária.
4. Dizer, por exemplo, **"ativa cursor"**.
5. Mover o cursor com um teclado/interruptor compatível. Dizer **"seleciona"** para tocar na posição atual.
6. Dizer **"desativa cursor"** quando terminar.

## Privacidade e segurança
- A audição contínua só começa após ação explícita do utilizador e permanece limitada à aplicação aberta.
- O serviço de acessibilidade não recolhe o texto nem o conteúdo das janelas de outras aplicações (`canRetrieveWindowContent=false`).
- O ABM não desbloqueia o telefone nem contorna autenticação do Android.
- A ativação do serviço é feita manualmente pelo utilizador nas definições do sistema.

## Limitações conhecidas
- A precisão do reconhecimento depende do motor de voz instalado e da disponibilidade de português.
- O comando de voz **seleciona** a posição atual, mas não determina por si só onde estão os botões das outras aplicações.
- O cursor não lê nomes de botões nem percorre automaticamente os elementos de cada aplicação.
- A câmara de rastreio permanece dependente da atividade visível; esta versão não acrescenta rastreio permanente em segundo plano.
- A compilação do APK e o teste físico continuam pendentes por ausência do Android SDK/Gradle neste ambiente.
