# ABM Android 3.2.0 — Varrimento inteligente

## O que faz
O utilizador inicia o varrimento. O serviço consulta a árvore de acessibilidade da janela ativa e recolhe somente elementos visíveis que sejam clicáveis ou focáveis. Ordena-os aproximadamente de cima para baixo e da esquerda para a direita. O cursor desloca-se para o centro do elemento escolhido. O utilizador avança e confirma por voz ou por teclado/interruptor.

## Comandos
- **Inicia varrimento** — começa no primeiro elemento elegível.
- **Próximo elemento** — avança para o seguinte.
- **Seleciona** — executa a ação de clique; se não estiver em varrimento, mantém a seleção do cursor manual.
- **Para varrimento** — encerra o modo.

Teclas durante o varrimento: RIGHT/DOWN avança; ENTER/CENTER seleciona; ESC termina.

## Permissão e privacidade
Esta capacidade requer `canRetrieveWindowContent=true`. Por isso, o Android informa que o Serviço de Acessibilidade pode observar a estrutura da janela. A ativação é manual e revogável pelo utilizador nas definições de Acessibilidade. O código deste módulo não lê nem guarda rótulos, texto digitado, palavras-passe ou conteúdo textual; usa apenas flags de visibilidade/clicabilidade/foco e coordenadas. A compatibilidade depende da aplicação: algumas interfaces não expõem os seus elementos à árvore de acessibilidade, e nessas janelas o varrimento pode encontrar zero alvos.

## Limites
- Máximo de 150 alvos e profundidade de 30 níveis.
- Ordenação geométrica simples; não garante a ordem semântica ideal.
- Algumas aplicações podem rejeitar `ACTION_CLICK` ou não disponibilizar nós.
- O cursor é uma indicação visual aproximada, não um destaque nativo do botão.
- Ainda não compilado como APK nem testado num telefone físico neste ambiente.
