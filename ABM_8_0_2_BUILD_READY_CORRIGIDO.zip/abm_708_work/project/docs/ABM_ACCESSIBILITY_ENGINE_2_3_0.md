# ABM Accessibility Engine 2.3.0

## Implementado nesta versão
- Interpretador Java independente para comandos de acessibilidade em português, tolerante a acentos.
- Comandos de voz: voltar, início, notificações, definições rápidas, abrir YouTube/WhatsApp/Definições, ler a última resposta, parar a voz e ajuda.
- Atalho “Modo mãos livres” para audição contínua através do reconhecedor de voz instalado no Android. O utilizador ativa e desativa manualmente.
- Orientações no painel de acessibilidade para ativar o serviço assistivo e para explorar Voice Access/Switch Access.
- Broadcast interno do serviço de acessibilidade protegido por permissão Android de assinatura.

## Limites importantes
- A audição contínua desta versão depende do serviço de reconhecimento de voz instalado e da aplicação permanecer aberta; não é uma palavra de ativação sempre ligada em segundo plano.
- O serviço de acessibilidade executa apenas ações globais explícitas. Não lê o conteúdo do ecrã, não clica arbitrariamente em aplicações e não contorna bloqueios.
- Controlo pelo olhar e pela cabeça ainda não está implementado. O detector facial ML Kit existente não equivale a rastreamento ocular calibrado nem a um método de seleção confiável.
- Pessoas que não conseguem falar precisam de uma interface de comunicação alternativa (CAA) e/ou interruptor externo; ainda não incluída nesta versão.
- Envio de mensagens, chamadas, pagamentos, eliminação de ficheiros e partilha de dados exigem interfaces e confirmações específicas.

## Compatibilidade e validação
- `minSdk 26` (Android 8.0+); Android 8.1 está dentro do mínimo declarado.
- Foram feitas verificações estáticas dos ficheiros e testes unitários do interpretador Java. Não foi possível compilar APK nem testar em hardware neste ambiente.
