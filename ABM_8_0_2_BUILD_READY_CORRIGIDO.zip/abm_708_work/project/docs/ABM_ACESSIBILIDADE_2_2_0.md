# ABM — Acessibilidade 2.2.0

## Objetivo
Dar uma primeira camada de controlo a utilizadores com mobilidade reduzida, sem obrigar a tocar nos botões do ABM para ações básicas.

## Ativar
1. Abrir ABM e tocar em **Acessibilidade**.
2. Abrir Definições de Acessibilidade.
3. Ativar **ABM — controlo assistivo** manualmente.
4. Confirmar a explicação do Android.
5. Voltar ao ABM e usar os comandos de voz ou texto.

## Comandos incluídos
- “Volta” / “Voltar” — ação global Voltar.
- “Vai para início” — ação global Início.
- “Abre notificações” — painel de notificações.
- “Abre definições rápidas” — painel de definições rápidas.

## Privacidade e segurança
O serviço não pede acesso ao conteúdo das janelas, não lê mensagens, não recolhe texto de outras aplicações e não executa cliques/gestos arbitrários. Só recebe pedidos locais explícitos do próprio ABM para as quatro ações acima. O utilizador pode revogar o serviço nas definições.

## Próximas etapas
- Testar compatibilidade com ColorOS/Android 8.1.
- Adicionar comandos de navegação e acessibilidade com confirmação.
- Integrar suporte orientado para Switch Access e Voice Access.
- Projetar controlo por cabeça e olhar com análise local e consentimento explícito; requer avaliação de desempenho, privacidade e compatibilidade do aparelho.
- Criar modo de comunicação assistida por frases, símbolos e leitura TTS.

**Não afirmar que o ABM tem controlo ocular, controlo pela cabeça ou acesso total: ainda não foram implementados.**
