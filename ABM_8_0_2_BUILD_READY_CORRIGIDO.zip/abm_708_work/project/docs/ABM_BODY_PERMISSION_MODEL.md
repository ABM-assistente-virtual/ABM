# ABM BODY — modelo de acesso ao dispositivo

O objetivo é dar ao ABM o maior conjunto de ações útil que o Android permite, não prometer privilégios que a aplicação não pode obter.

- Apps: abrir qualquer app que tenha um launcher activity visível ao utilizador.
- Ficheiros: aceder aos documentos escolhidos pelo utilizador via Storage Access Framework; sem ler dados privados de outras apps.
- Internet: abrir URLs no navegador e usar API Cloud quando a conta estiver autenticada.
- Comunicação: abrir marcador, SMS/email/partilha através dos ecrãs oficiais; o utilizador confirma o envio/chamada.
- Câmara/microfone: pedir permissões runtime, mostrar quando ativos e parar quando o utilizador desliga.
- Sistema: abrir páginas oficiais de Definições; não contornar PIN, biometria, permissões ou políticas de segurança.
- Ações destrutivas/sensíveis: confirmação explícita.

Não existe API legítima que dê a uma aplicação Android acesso ilimitado a todos os dados e ações de todas as outras aplicações. Root, abuso de Accessibility, gravação escondida ou bypass de autenticação não são uma base aceitável para o ABM.
