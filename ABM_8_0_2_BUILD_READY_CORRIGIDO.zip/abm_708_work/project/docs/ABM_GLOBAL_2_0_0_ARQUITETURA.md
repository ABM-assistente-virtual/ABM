# ABM Global 2.0.0 — arquitetura e escala

## Objetivo de produto
Atender pessoas em espera e admitir sessões apenas quando existe capacidade. “30 milhões na fila” significa 30 milhões de tickets/identidades à espera, não 30 milhões de tarefas de IA simultâneas. A capacidade de processamento simultâneo é outra métrica e depende do custo por tarefa.

## Caminho de uma requisição
1. Aplicação Android ou cliente web comunica por HTTPS com o gateway.
2. Load balancer distribui pedidos pelas réplicas stateless da API.
3. Autenticação identifica o utilizador; o `user_id` é encaminhado por rendezvous hashing a um shard.
4. Fila Redis atómica mantém a ordem, capacidade ativa, expiração e proprietário do ticket. O ID identifica o shard de origem para consultas futuras.
5. Quando existe vaga, a fila promove o ticket mais antigo.
6. Tarefas demoradas são enviadas para Redis Streams e executadas por workers separados.
7. PostgreSQL guarda contas e memórias; os estados transitórios da fila ficam no Redis.

## Escala horizontal
- API: múltiplas réplicas atrás de load balancer.
- Fila: vários namespaces por shard; no Redis Cluster, chaves do mesmo shard partilham hash tag e ficam num slot.
- Workers: réplicas independentes que consomem streams de cada shard.
- Dados: PostgreSQL gerido com pool por réplica, backups, PITR e réplicas de leitura quando justificadas.
- Regiões: deploy separado por região, com roteamento global no gateway e política explícita de residência/replicação dos dados.

## O que esta entrega realmente comprova
13 testes de contrato/unitários locais, compilação Python e integração estrutural. Não comprova throughput real do Redis Cluster, disponibilidade multi-região, nem 30 milhões de pessoas em fila. É necessária uma implantação cloud, teste de carga e observabilidade para estabelecer números.
