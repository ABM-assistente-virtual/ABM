# ABM GLOBAL — arquitetura-alvo para 30.000.000 de pessoas em espera

## Objetivo
Permitir que muitas pessoas aguardem para usar o ABM sem depender do telemóvel do fundador. A aplicação Android será cliente; a fila, autenticação, orquestração e processamento ficam na nuvem.

## Fluxo pretendido
1. A pessoa autentica-se e pede acesso.
2. O gateway global encaminha-a para uma região e shard de fila.
3. O serviço de admissão emite um bilhete aleatório.
4. O cliente consulta o estado e a posição com polling controlado ou notificações.
5. Quando há capacidade, o sistema admite a sessão.
6. O serviço de tarefas encaminha o pedido para trabalhadores disponíveis.
7. O resultado é guardado na conta correta e devolvido ao cliente.

## Camadas necessárias para produção
- DNS e proteção DDoS/WAF.
- API Gateway global com TLS, autenticação e quotas.
- Serviço de fila particionado por região e shard.
- Redis Cluster/serviço gerido para estado rápido da fila.
- Base de dados relacional para contas, permissões e histórico.
- Broker de mensagens para tarefas demoradas.
- Workers horizontais e escalonamento automático.
- Object storage para ficheiros de utilizadores.
- Observabilidade, alertas, backups e recuperação de desastre.
- Isolamento de dados por utilizador e políticas de retenção.

## Como chegar a 30 milhões em espera
30 milhões é o requisito de capacidade total da fila, não 30 milhões de sessões ativas. Não se deve colocar toda a carga numa única instância Redis ou API. A fila deve ser dividida em shards e regiões, com roteamento determinístico e capacidade testada. A quantidade de shards e recursos só pode ser definida após medir o tamanho real de cada ticket, memória por entrada, taxa de entrada/saída, frequência de consulta, duração média da espera e disponibilidade exigida.

## Fases obrigatórias antes de produção
1. Executar a demonstração local incluída em `cloud/`.
2. Ligar o cliente Android ao endpoint HTTPS publicado.
3. Adicionar autenticação real, gestão de sessões e rate limiting.
4. Migrar para Redis gerido/clusterizado e base de dados durável.
5. Criar múltiplos shards e reequilíbrio sem perder bilhetes.
6. Fazer testes de carga graduais (1k, 10k, 100k, 1M e só depois 30M de tickets), medindo latência, memória, falhas e recuperação.
7. Fazer auditoria de segurança e ensaio de recuperação de desastre.

## Critério de honestidade
O código incluído é uma implementação inicial executável da API de fila para um shard. Os três testes automatizados são testes de contrato/estrutura; não são testes de integração Redis, testes de rede, nem testes de carga. Não existe prova de que suporte 30 milhões neste momento. Não publicar como serviço global de produção antes de concluir as fases acima.
