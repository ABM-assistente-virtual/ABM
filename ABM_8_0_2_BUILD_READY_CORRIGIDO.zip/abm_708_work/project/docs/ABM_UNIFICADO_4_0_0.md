# ABM 4.0.0 — Sistema Unificado

## O que esta versão unifica

A versão 4.0.0 usa a aplicação Android 3.2.0 como base móvel, preserva o núcleo Python ABM 5.2, os oito módulos especializados, os motores de acessibilidade e o pacote de serviços ABM Global 2.1.0. Acrescenta `UnifiedABM`, uma camada única de catálogo e orquestração que encaminha pedidos ao `GeneralTaskEngine` e apresenta o estado dos 15 departamentos.

## Os 15 departamentos e o estado honesto

| Departamento | Estado nesta versão | Base presente |
|---|---|---|
| BRAIN | Integrado | ABM 5.2 + Brain |
| EARS | Protótipo | análise WAV + SpeechRecognizer Android |
| EYES | Protótipo | análise de imagem + ML Kit |
| VOICE | Protótipo | preparação de texto + TTS Android |
| BODY | Protótipo | Body + UniversalToolConnector + ações Android limitadas |
| ACCESSIBILITY | Protótipo | cursor, gestos, varrimento e interruptores |
| AUTONOMY | Integrado | objetivos + GeneralTaskEngine |
| SOCIAL | Protótipo | análise heurística de texto |
| MEMORY | Protótipo | estado local JSON e memória do companheiro |
| SECURITY | Integrado | regras de permissão e confirmações |
| CONNECT | Protótipo | conector de ferramentas + cliente HTTP cloud |
| SYSTEM | Protótipo | integração com APIs Android disponíveis |
| INTERFACE | Protótipo | MainActivity, serviço e overlays |
| CLOUD | Protótipo | API FastAPI, PostgreSQL/Redis opcionais e workers |
| DEVELOPER | Protótipo | CapabilityRegistry e registo de ferramentas |

**Integrado** significa ligado e exercitado no núcleo de software. **Protótipo** significa que há uma base funcional ou integração parcial, mas faltam testes reais, fornecedores, permissões ou cobertura. Nenhum departamento é declarado como produto completo.

## Como usar

- No Android, iniciar a aplicação e conceder apenas as permissões necessárias.
- O serviço de acessibilidade deve ser ativado manualmente nas definições do Android para usar recursos globais.
- O motor Python disponibiliza `/departamentos` para listar os 15 departamentos e respetivos estados.
- `/capacidades` mostra as ferramentas registadas.
- A API cloud é um serviço separado em `cloud/`; requer configuração de segredos, PostgreSQL/Redis e implantação própria. A presença dos ficheiros no ZIP não significa que o servidor esteja publicado ou ligado automaticamente ao telefone.

## Testes executados nesta entrega

- Núcleo ABM 5.2 e suites históricas: 48 testes PASS.
- Módulos especializados: 20 verificações PASS.
- Unificação/catálogo/orquestrador: 10 verificações PASS.
- API cloud: 25 testes PASS; compilação Python PASS.
- Verificações estáticas Android e ponte Python: PASS.

## Limitações não resolvidas

- APK não compilado neste ambiente: Android SDK/Gradle não estão disponíveis.
- Não testado num OPPO A3S nem noutro telefone físico.
- Câmera/visão não permanece ativa globalmente em segundo plano.
- Acessibilidade depende do serviço ativado, das permissões e do que cada app expõe à API Android.
- STT/TTS e ML Kit dependem das APIs/serviços e compatibilidade do dispositivo.
- Cloud não está publicada nem ligada a uma conta de produção; Redis/PostgreSQL reais não foram usados nestes testes.
- Não foi feito teste de carga de 30 milhões de utilizadores.
- O sistema não contorna bloqueio Android, PIN, biometria ou limites de segurança do sistema.

## Próxima validação necessária

1. Compilar com Android SDK 35 e Gradle compatível.
2. Instalar num dispositivo API 26+ (incluindo teste dedicado no Android 8.1).
3. Testar cada permissão e serviço de acessibilidade com consentimento.
4. Testar API cloud em ambiente isolado com PostgreSQL e Redis reais.
5. Executar testes de carga progressivos antes de qualquer alegação de escala.
