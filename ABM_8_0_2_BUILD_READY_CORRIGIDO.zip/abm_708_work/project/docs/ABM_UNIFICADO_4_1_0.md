# ABM 4.1.0 — Barramento funcional entre departamentos

## Objetivo
A 4.0.0 apresentava um catálogo de 15 departamentos e uma camada de orquestração. A 4.1.0 acrescenta um barramento comum (`UnifiedABM.dispatch`) para encaminhar operações identificadas a adaptadores explícitos.

## Interface comum
- Python: `abm_android.dispatch_department(department, action, payload_json="{}")`
- Comando: `/departamento <id> <ação> [JSON]`
- Estado: `abm_android.status()` inclui versão, número de chamadas e última chamada.
- Cada resposta contém `department`, `action`, `dispatch_id` e `status`.

## Operações locais implementadas
| Departamento | Operação | O que realmente faz |
|---|---|---|
| BRAIN | `think` | Encaminha texto para o núcleo ABM 5.2. |
| EARS | `transcript`, `analyze_wav` | Normaliza texto já transcrito ou mede propriedades de WAV; não grava nem transcreve sozinho. |
| EYES | `analyze_image` | Analisa propriedades básicas da imagem se Pillow estiver instalado; não reconhece semanticamente objetos/pessoas. |
| VOICE | `prepare` | Prepara texto para TTS; a fala real depende do Android TextToSpeech. |
| BODY | `plan` | Converte algumas intenções em ações Android permitidas; execução depende da Activity/ponte Android. |
| ACCESSIBILITY | `start_scan`, `next`, `select`, `stop_scan`, `show_cursor`, `hide_cursor` | Produz pedidos para a ponte Android; requer AccessibilityService ativo e consentimento. |
| AUTONOMY | `add_goal` | Regista objetivo no motor de autonomia. |
| SOCIAL | `analyze_text` | Faz análise heurística de texto fornecido. |
| MEMORY | `remember`, `save` | Guarda contexto na memória do companheiro e persiste estado local. |
| SECURITY | `authorize` | Aplica regras de permissão e confirmação. |
| CONNECT | `list_tools` | Lista ferramentas disponíveis no conector local. |
| SYSTEM | `status` | Indica que o estado Android detalhado precisa da ponte Java. |
| INTERFACE | `prepare_response` | Prepara texto de resposta para voz/interface. |
| CLOUD | `status` | Expõe explicitamente que o serviço não está publicado/configurado. |
| DEVELOPER | `register_capability` | Regista uma nova capacidade no motor de tarefas. |

Todos os 15 departamentos respondem ao contrato comum `status`. Isto significa que são endereçáveis pelo barramento, não que todos sejam produtos completos ou serviços ativos.

## Segurança
- O barramento não desbloqueia o Android.
- Ações sensíveis continuam sujeitas às regras de `ABM SECURITY` e confirmação.
- ACCESSIBILITY devolve `needs_android_bridge`; não simula que um toque global foi executado.
- CLOUD devolve `not_deployed` enquanto não existir servidor configurado e publicado.

## Testes executados nesta entrega
- `tools/test_unified_system.py`: 10 verificações PASS.
- `tools/test_unified_4_1.py`: 31 verificações PASS reportadas; 15 departamentos endereçáveis e operações locais exercitadas.
- `tools/test_modules.py`: 20 verificações PASS.
- `tools/validate_project.py`: PASSOU_TOTALMENTE, incluindo compilação Python, núcleo histórico, ponte, estrutura Android e módulos.
- `PYTHONPATH=cloud python -m pytest -q cloud/tests`: 25 testes PASS.

## Limitações
- APK não compilado: Android SDK/Gradle não estão disponíveis neste ambiente.
- Não testado num telefone físico, incluindo OPPO A3S/Android 8.1.
- A integração por barramento não cria automaticamente serviços Android, reconhecimento de fala, visão ML, backend cloud ou ferramentas externas.
- Os estados `prototype` continuam protótipos, mesmo que já tenham adaptadores ou respostas de estado.
