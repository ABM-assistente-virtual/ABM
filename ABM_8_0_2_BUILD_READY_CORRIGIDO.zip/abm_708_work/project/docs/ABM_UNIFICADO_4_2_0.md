# ABM Unificado 4.2.0 — Coordenação Central

## Objetivo
A versão 4.2 acrescenta um fluxo único que faz vários departamentos cooperarem
na análise de um pedido, em vez de chamar cada módulo isoladamente.

## Fluxo

- **EARS**: quando `source="voice"`, normaliza a transcrição recebida do Android.
- **BRAIN**: interpreta o pedido usando o núcleo ABM 5.2.
- **BODY**: identifica uma ação Android conhecida e prepara os argumentos.
- **SECURITY**: verifica confirmação e permissões para ações sensíveis.
- **VOICE**: prepara a resposta para Android TextToSpeech.

O resultado contém `trace`, `action`, `authorization`, `voice` e
`execution_performed`. A última propriedade permanece `false` neste núcleo.

## API

```python
abm_android.initialize(data_dir)
result_json = abm_android.coordinate_request("Abre o WhatsApp")
voice_json = abm_android.coordinate_request("ABM abre YouTube", source="voice")
```

`source` aceita `text` ou `voice`. `confirmed=True` representa uma confirmação
recebida pela camada chamadora, mas não substitui a confirmação de sistema nem
as permissões Android. O chamador deve autenticar a origem dessa confirmação.

## Limites

- Não há execução Android dentro desta função Python.
- O reconhecimento de voz é fornecido pelo Android; EARS apenas normaliza a
  transcrição recebida.
- O TTS é preparado, não reproduzido por este módulo.
- A análise BRAIN é experimental e não equivale a inteligência geral.
- O desbloqueio Android nunca é feito pelo ABM.
- Os estados dos 15 departamentos não foram artificialmente promovidos.
- Cloud continua sem deploy e APK sem compilação/teste físico.
