# ABM Unificado 4.3.0 — Memória local controlada

## O que esta etapa faz

O departamento ABM MEMORY passa a ter uma base SQLite local, separada do histórico de conversa. O módulo só guarda um registo quando a operação recebe `consent=True`. Não existe recolha automática de mensagens.

## Operações disponíveis

Pela API de departamentos:

- `remember`: `{"text":"...", "consent":true, "category":"preference", "importance":4}`
- `search`: `{"query":"português", "limit":10}`
- `list`: `{"limit":50}`
- `export`: devolve JSON exportável
- `forget`: `{"id":"...", "confirmed":true}`
- `clear`: `{"confirmed":true}`

Exemplo Python:

```python
import abm_android
abm_android.initialize('/caminho/privado/abm-data')
print(abm_android.memory_dispatch('remember', '{"text":"Prefiro português", "consent":true}'))
print(abm_android.memory_dispatch('search', '{"query":"português"}'))
```

Comandos de conversa:

- `/memoria guardar Prefiro respostas em português`
- `/memoria procurar português`

O comando `guardar` é uma ação explícita do utilizador. Para a API, o campo `consent` é obrigatório.

## Segurança e privacidade

- O ficheiro `abm_memory.sqlite3` fica dentro da pasta de dados fornecida na inicialização.
- SQLite não está cifrado por este módulo. A proteção depende também do armazenamento privado da aplicação e do sistema Android.
- Não guardar senhas, PINs, tokens, dados bancários ou informação altamente sensível.
- `forget` e `clear` não apagam sem `confirmed=true`.
- A função `export` permite ao utilizador obter os registos em JSON.
- Não há sincronização Cloud nesta versão.

## Testes

Execute `python tools/test_memory_4_3.py`. Foram verificadas gravação com/sem consentimento, pesquisa, listagem, exportação, eliminação individual e limpeza com confirmação, além da ponte Android/Python.

O validador geral é `python tools/validate_project.py`. A compilação APK não foi executada porque este ambiente não dispõe do Android SDK/Gradle configurado.
