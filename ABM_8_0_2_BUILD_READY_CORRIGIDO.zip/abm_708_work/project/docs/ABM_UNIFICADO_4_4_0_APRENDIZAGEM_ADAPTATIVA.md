# ABM 4.4.0 — Aprendizagem adaptativa local

## O que faz

O motor `AdaptiveLearning` regista três tipos de dados, sempre com consentimento explícito:

1. **Correções:** associa um pedido original a uma correção indicada pelo utilizador.
2. **Preferências:** guarda pares chave/valor, por exemplo `language = português`.
3. **Padrões:** mantém contadores agregados quando a aplicação os envia com `consent=true`.

O orquestrador consulta preferências e correções lexicalmente relevantes e devolve-as em `adaptive_context`. A versão atual não altera automaticamente a resposta do BRAIN; fornece contexto para uma integração futura que deverá continuar sujeita a revisão.

## Comandos

- `/aprender corrigir <tema> | <pedido original> | <correção>`
- `/aprender preferencia <chave> | <valor>`
- `/aprender estado`

Exemplos:

- `/aprender corrigir idioma | responde em inglês | responde em português`
- `/aprender preferencia idioma | português`

Estes comandos representam uma ação explícita do utilizador e, por isso, passam consentimento afirmativo à camada local.

## API Python

`abm_android.learning_dispatch(action, payload_json)` aceita:

- `feedback`: `topic`, `input`, `correction`, `consent`
- `preference`: `key`, `value`, `consent`
- `preferences`: lista preferências
- `suggestions`: `text`, `limit`
- `pattern`: `key`, `consent`
- `status`, `export`
- `forget_feedback`: `id`, `confirmed`
- `clear`: `confirmed`

O departamento `memory` também oferece `learn_feedback`, `set_preference`, `get_preferences`, `learning_suggestions`, `learning_status` e `learning_clear`.

## Privacidade e limites

- Sem consentimento, a operação de gravação é recusada.
- Não existe recolha automática de conversas.
- Não existe treino de pesos neurais; o sistema guarda exemplos e recupera-os por correspondência lexical.
- O SQLite não tem cifragem própria nesta versão. Não guardar PINs, palavras-passe, tokens ou dados sensíveis.
- O armazenamento é local ao dispositivo/ambiente e não sincroniza com a Cloud.
- Não substitui revisão humana nem validação de segurança.
