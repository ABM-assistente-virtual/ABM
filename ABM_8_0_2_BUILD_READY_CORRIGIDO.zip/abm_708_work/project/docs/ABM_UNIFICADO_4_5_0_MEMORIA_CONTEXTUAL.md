# ABM 4.5.0 — Memória contextual

## Objetivo
Adicionar contexto recuperável com limites de consentimento, perfil, departamento, expiração e auditoria.

## Operações pelo barramento
Todas usam `dispatch_department("memory", ação, payload_json)`.

- `context_remember`: `{ "topic":"idioma", "content":"Prefere português", "consent":true, "profile_id":"perfil-local", "source_department":"brain", "sensitivity":"personal", "ttl_days":90 }`
- `context_search`: `{ "query":"idioma português", "profile_id":"perfil-local", "limit":5 }`
- `context_delete`: `{ "id":"...", "profile_id":"perfil-local", "confirmed":true }`
- `context_clear_profile`: `{ "profile_id":"perfil-local", "confirmed":true }`
- `context_audit`: `{ "profile_id":"perfil-local", "limit":50 }`
- `context_purge_expired`: `{}`

## Garantias implementadas
- Sem `consent=true`, não grava.
- Pesquisas e eliminações são limitadas ao `profile_id` indicado.
- `ttl_days=0` significa sem expiração automática; valores positivos definem expiração.
- Eliminação requer `confirmed=true`.
- Eventos principais são registados numa tabela de auditoria.
- Padrões óbvios de palavras-passe e números de cartão são recusados.

## Limites e segurança
A base SQLite é texto simples, não cifrado. O chmod 0600 é uma proteção adicional de ficheiro quando o sistema operativo o suporta, não é cifragem. Em Android, o diretório deve ser armazenamento interno privado da aplicação. O `profile_id` não autentica ninguém por si só: a camada Android deve associá-lo à sessão autenticada. O filtro de segredos é apenas heurístico. A pesquisa é lexical simples.

Não há recolha automática, treino neuronal, sincronização cloud nem prova de isolamento entre utilizadores no dispositivo físico. APK e dispositivo real ainda não foram testados.
