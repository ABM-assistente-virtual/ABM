# ABM Unificado 4.6.0 — BRAIN Advanced

## Objetivo
Dar ao BRAIN um planeador determinístico e auditável que divide pedidos em etapas e explicita dependências, riscos, confirmações e critérios de verificação.

## API Python

```python
plan = unified.advanced_plan("Abre o WhatsApp")
# Após uma ferramenta Android real devolver evidência:
result = unified.verify_plan_step(
    plan["plan_id"], step_id=3, success=True,
    evidence="Android confirmou que a aplicação abriu", confirmed=True
)
```

`advanced_plan` prepara um plano; não executa as etapas. `verify_plan_step` apenas regista um resultado e evidência fornecida pelo executor. Não deve ser chamado com sucesso sem confirmação observável.

## Estrutura de cada etapa
- `department`: departamento responsável.
- `action`: identificador da ação proposta.
- `depends_on`: IDs das etapas anteriores necessárias.
- `risk`: low, medium ou high.
- `confirmation_required`: bloqueio até confirmação explícita.
- `verification`: critério que o executor deverá comprovar.
- `status`: planned, completed ou blocked.

## Segurança e limites
- Chamadas, câmara e operações de acessibilidade são marcadas como sensíveis quando aplicável.
- A pesquisa de memória é opcional, apenas leitura e limitada ao perfil pedido.
- Não há execução arbitrária de código nem controlo Android autónomo nesta versão.
- Um plano só fica `verified` quando todas as etapas tiverem sido registadas como concluídas com evidência.
- Esta versão ainda não foi compilada como APK nem testada num telefone físico.
