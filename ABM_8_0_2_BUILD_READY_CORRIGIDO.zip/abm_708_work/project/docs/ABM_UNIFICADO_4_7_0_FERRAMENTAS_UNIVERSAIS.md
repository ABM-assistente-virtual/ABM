# ABM 4.7.0 — Motor Universal de Ferramentas

## Objetivo
Permitir ao BRAIN e ao ABM CONNECT descobrir ferramentas registadas, pesquisar capacidades, validar argumentos, preparar operações, pedir confirmação quando necessário e encaminhar a execução ao handler apropriado.

## Fluxo
1. `discover(query)` lista apenas handlers já registados.
2. `prepare(name, arguments)` valida ferramenta e argumentos e cria um plano.
3. Ferramentas sensíveis ficam em `awaiting_confirmation`.
4. `execute(execution_id, confirmed=True)` verifica confirmação e, para alto risco, autorização adicional.
5. O resultado e a auditoria distinguem execução local de despacho Android.

## Comandos
- `/ferramentas` — lista ferramentas disponíveis.
- `/ferramenta procurar android` — pesquisa o catálogo.
- `/ferramenta preparar android.open_app {"request":"abre calculadora"}` — prepara operação.
- `/ferramenta executar ID` — executa ferramenta não sensível já preparada.
- `/ferramenta executar ID confirmar` — confirma ferramenta sensível.

## API Python
- `discover_tools(query="")`
- `prepare_tool(name, arguments_json="{}")`
- `execute_tool(execution_id, confirmed=False)`
- `dispatch_department("connect", "search_tools", {"query":"android"})`
- `dispatch_department("connect", "prepare_tool", {"name":"abm.create_note", "arguments":{"request":"texto"}})`

## Segurança
O motor não usa `eval`, não importa módulos fornecidos pelo utilizador e não executa nomes de ferramentas desconhecidos. A lista é construída a partir dos handlers existentes no `UniversalToolConnector`. Campos não declarados são rejeitados. A execução de ações externas é separada da preparação.

## Limites reais
Ferramentas Android devolvem `dispatch=android`; isso significa apenas que a ação foi preparada para a ponte Android. A Activity/serviço precisa receber, validar permissões e executar a Intent ou API Android. Um retorno do motor Python não prova que uma aplicação abriu ou que uma chamada ocorreu.
