# ABM 4.8.0 — Ponte de execução Android

## Fluxo
1. Preparar ferramenta: `/ferramenta preparar android.open_app {"request":"abre calculadora"}`
2. Copiar o `execution_id` devolvido.
3. Executar: `/ferramenta executar ID`
4. Se a ferramenta for sensível, a Activity mostra um diálogo de confirmação.
5. A Activity chama o adaptador Android apropriado e devolve aceitação/rejeição ao motor Python.

## Estados
- `ready`: plano local preparado, ainda sem execução.
- `awaiting_confirmation`: aguarda aprovação explícita.
- `dispatched`: pedido encaminhado ao adaptador Android.
- `android_accepted`: o adaptador conseguiu iniciar/encaminhar o Intent.
- `android_rejected`: o adaptador não conseguiu iniciar a ação.
- `completed`: ferramenta local terminou.

`android_accepted` não significa que a tarefa dentro da app de destino foi concluída.

## Ferramentas Android adaptadas
`open_app`, `open_camera`, `choose_file`, `web_search`, `open_url`, `share_text`, `open_maps`, `open_settings`, `pause_media`, `dial`.

## Limitações
A execução ocorre na Activity visível, não como controlo irrestrito em segundo plano. As aplicações podem não estar instaladas ou podem rejeitar intents. Ações sensíveis continuam sujeitas a confirmação e permissões Android.
