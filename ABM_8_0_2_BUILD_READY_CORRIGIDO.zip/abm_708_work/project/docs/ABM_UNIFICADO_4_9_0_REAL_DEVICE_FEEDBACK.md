# ABM UNIFICADO 4.9.0 — Real Device Feedback

## Fluxo
1. O motor prepara e despacha uma ferramenta Android registada.
2. A Activity chama o adaptador Android oficial.
3. O Python recebe o resultado limitado do adaptador: `android_accepted` ou `android_rejected`.
4. Quando aceite, a interface pergunta ao utilizador se a tarefa-alvo terminou.
5. O utilizador escolhe `success`, `failure` ou `unknown`.
6. O motor regista, respetivamente, `user_reported_success`, `user_reported_failure` ou `unverified`.

## Semântica importante
- `android_accepted`: o adaptador conseguiu iniciar/encaminhar o Intent. Não prova a conclusão da tarefa.
- `user_reported_success`: o utilizador declarou que a tarefa foi concluída. Não é uma verificação automática.
- `user_reported_failure`: o utilizador declarou que não foi concluída.
- `unverified`: o resultado final continua desconhecido.

## API Python
- `record_android_target_outcome(execution_id, outcome, evidence="")`
- `get_tool_execution_status(execution_id)`

A API rejeita resultados fora de sequência, valores inválidos e feedback duplicado. O resumo de estado não devolve os argumentos da ferramenta.

## Testes
Executar na raiz do projeto:

```bash
python tools/test_execution_feedback_4_9.py
python tools/test_execution_bridge_4_8.py
python tools/test_android_bridge_static_4_8.py
python tools/validate_project.py
```

## Limitações atuais
O feedback fica no objeto do motor em memória durante a execução do processo. Não existe ainda persistência durável nem verificação visual/semântica automática universal do que ocorre em aplicações externas. O APK ainda precisa de ser compilado com Android SDK/Gradle e testado num dispositivo real.
