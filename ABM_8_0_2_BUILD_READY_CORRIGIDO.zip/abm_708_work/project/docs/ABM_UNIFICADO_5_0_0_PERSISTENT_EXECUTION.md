# ABM UNIFICADO 5.0.0 — Persistent Execution Memory

## Objetivo
Guardar o histórico de execução para que o ABM reconheça operações anteriores e recupere estados depois de reiniciar o processo.

## Dados persistidos
- ID da execução, ferramenta, plataforma, risco e estado.
- Datas de criação/atualização.
- Resultado reportado pelo adaptador Android e resultado reportado pelo utilizador.
- Eventos de auditoria.
- Hash dos argumentos para diagnóstico de integridade.
- Argumentos completos apenas quando `persist_context=True`.

## Política de recuperação
- Por padrão, argumentos não são escritos na base de dados.
- Uma operação preparada sem consentimento é recuperada como `interrupted_requires_reprepare`; o ABM pede nova preparação e não inventa os argumentos.
- Com consentimento explícito, argumentos são recuperados e operações locais elegíveis podem ser retomadas.
- Operações Android que já foram despachadas nunca são repetidas automaticamente. O seu estado pode ser recuperado e o utilizador pode fornecer feedback depois do reinício.
- Ações já concluídas não são executadas novamente.

## API
- `prepare(name, arguments, persist_context=False)`
- `list_history(limit=50)`
- `execution_events(execution_id, limit=100)`
- `resume_execution(execution_id, confirmed=False)`
- Ponte: `list_execution_history()` e `resume_tool_execution(...)`.
- Unified dispatch: `connect.execution_history`, `connect.execution_events`, `connect.resume_execution`.

## Privacidade
A base SQLite é armazenada na área privada da aplicação, mas **não está cifrada**. A persistência de argumentos é opt-in e não deve ser usada para senhas, PINs, tokens, dados bancários ou outros segredos. A cifragem via Android Keystore é trabalho futuro.

## Testes
`python tools/test_persistent_execution_5_0.py` cobre persistência, recuperação, retoma, não repetição, feedback Android após reinício, auditoria e omissão de argumentos sem consentimento.

## Limitações
Não existe observação universal de apps externas. `android_accepted` continua a significar apenas que o adaptador iniciou/encaminhou o Intent. A conclusão dentro da aplicação-alvo não é automaticamente verificada. APK não compilado nem testado em dispositivo nesta entrega.
