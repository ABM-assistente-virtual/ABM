# ABM 5.1.0 — Self-Recovery Engine

## Objetivo
Diagnosticar estados de falha e propor recuperação segura sem executar ações às cegas.

## Política de segurança
- Nenhuma repetição automática.
- Uma operação Android aceite não é considerada concluída.
- Chamadas, partilhas, criação de notas e outras operações não idempotentes não são repetidas pelo motor.
- Apenas operações locais de leitura (`abm.list_notes`, `abm.read_note`) podem gerar um novo plano, e apenas após confirmação explícita.
- O novo plano permanece por executar; o utilizador deve executar separadamente.
- Se argumentos não foram guardados por consentimento, o utilizador tem de preparar novamente a operação.

## Comandos
- `/recuperacao estado` — estado do motor.
- `/recuperacao diagnosticar ID` — diagnóstico seguro.
- `/recuperacao preparar ID` — mostra que confirmação é necessária.
- `/recuperacao preparar ID confirmar` — cria novo plano permitido, sem o executar.
- `/recuperacao eventos ID` — histórico de recuperação.

## Persistência e privacidade
Eventos guardados em `abm_recovery.sqlite3`. A base SQLite não é cifrada. Não guardar credenciais, PINs, tokens ou dados bancários.

## Limites verificados
Este módulo analisa o estado disponível no motor; não lê automaticamente outras aplicações, não deteta a causa física de cada falha e não repara o Android. APK requer compilação e teste num dispositivo real.
