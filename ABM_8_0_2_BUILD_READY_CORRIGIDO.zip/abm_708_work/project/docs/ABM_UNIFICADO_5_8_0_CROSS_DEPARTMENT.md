# ABM UNIFICADO 5.8.0 — Cross-Department Intelligence Engine

## Objetivo
Criar uma camada local de comunicação entre departamentos ABM, com mensagens persistentes, correlação de tarefas e contexto partilhado sob consentimento.

## Capacidades
- Mensagens departamento-a-departamento guardadas em SQLite.
- Receção e confirmação explícita de mensagens.
- Identificador de correlação para ligar resultados da mesma tarefa.
- Contexto partilhado com consentimento obrigatório.
- Validação de departamentos, payload JSON e limites de tamanho/TTL.
- Sem execução de ações externas: o barramento apenas transporta dados.

## Comandos
- `/departamentos-compartilhamento estado`
- `/departamento enviar brain | eyes | analisar | {"pedido":"..."}`
- `/departamento receber eyes`
- `/departamento confirmar ID | eyes`
- `/contexto partilhar CORRELACAO | brain | objetivo | texto`
- `/contexto consultar CORRELACAO | eyes`

## Limitações
O barramento não torna automaticamente os departamentos inteligentes nem os liga a serviços externos. Cada integração precisa de adaptador próprio. SQLite local não está encriptado nesta versão. APK não compilado nem testado em dispositivo físico.
