# ABM Universal Access Engine 2.4.0

## Objetivo
Criar uma camada adaptativa para que pessoas com diferentes capacidades possam comunicar e utilizar as funções do telefone por métodos compatíveis com cada dispositivo. Os perfis são preferências de interface, não diagnósticos médicos.

## Implementado nesta versão
- Oito perfis selecionáveis e guardados localmente: padrão, mobilidade reduzida, sem fala, baixa visão/cegueira, surdez/baixa audição, surdocegueira, apoio cognitivo e personalizado.
- Quadro básico de Comunicação Aumentativa e Alternativa (CAA), com frases para respostas, necessidades, comunicação e pedido de ajuda.
- Saída de frases pela funcionalidade Android TextToSpeech existente e apresentação no histórico.
- Campo para escrever uma mensagem própria e comunicá-la por voz.
- Botões com alvos maiores e descrições acessíveis para leitores de ecrã.
- Testes unitários independentes para os perfis e frases.

## O que ainda NÃO está implementado
- Rastreamento ocular por câmara, calibração ou seleção por olhar.
- Rastreamento da cabeça como ponteiro.
- Varredura automática com interruptor único dentro do ABM.
- Saída Braille direta; depende de serviço/dispositivo Braille compatível do Android.
- Transcrição automática de fala para legendas em todas as aplicações.
- Perfis que detetem ou diagnostiquem automaticamente uma deficiência.
- Desbloqueio do ecrã por voz/rosto/lábios. Uma aplicação comum não pode substituir o bloqueio seguro do Android.

## Integrações de acessibilidade previstas
- Usar TalkBack e leitor de ecrã suportado pelo Android para navegação falada e braille quando houver dispositivo compatível.
- Usar Voice Access para controlo por voz em nível de sistema, quando instalado e compatível.
- Usar Switch Access para varrimento e interruptores externos compatíveis.
- Usar legendas instantâneas/Live Caption quando disponíveis no sistema.
- Explorar controlo por cabeça/olhar através de hardware e SDKs específicos, após testes de precisão, privacidade e segurança.

## Privacidade e segurança
- Nenhum áudio, imagem, rosto, voz ou dado biométrico é recolhido por este motor de perfis/CAA.
- O quadro CAA apenas apresenta e vocaliza frases escolhidas pelo utilizador.
- Frases como “Emergência” não contactam automaticamente serviços de emergência; o utilizador deve confirmar e iniciar a chamada por um fluxo próprio.
- A escolha de um perfil não concede permissões Android nem desbloqueia o dispositivo.

## Compatibilidade e validação
- Projeto declara `minSdk 26` (Android 8.0+); Android 8.1 cumpre o mínimo, mas o comportamento deve ser validado no aparelho real.
- Testes Python do projeto: 48 testes do núcleo, 20 verificações dos módulos especializados e verificações estruturais passaram.
- Testes Java independentes do interpretador de comandos e do Universal Access Engine passaram.
- APK não compilado neste ambiente: não foi confirmada a presença de Android SDK/Gradle nem foi feito teste num dispositivo físico.
