# ABM 1.1.0 — organização técnica em oito duplas

A estrutura de trabalho foi dividida em 16 responsabilidades técnicas (duas por módulo). Isto representa a distribuição de funções de engenharia usada no projeto; não significa que 16 pessoas humanas tenham participado.

| Módulo | Especialista A | Especialista B | Entrega implementada |
|---|---|---|---|
| ABM BRAIN | Arquitetura do agente | Integração de memória e diálogo | Fachada sobre ABM 5.2, resposta e estado |
| ABM EARS | Entrada/transcrição Android | Análise acústica offline | Normalização de transcrição e métricas WAV |
| ABM EYES | Entrada de imagem | Extração visual básica | Dimensão, formato, orientação e brilho via Pillow |
| ABM VOICE | Preparação de diálogo falado | Integração TTS Android | Preparação de texto e saída Android TTS |
| ABM BODY | Interpretação de intenção | Execução Android | Roteador de intenções e intents Java permitidas |
| ABM SOCIAL | Contexto de interação | Segurança em conflito | Heurísticas de texto e sugestões não agressivas |
| ABM AUTONOMY | Planeamento de objetivos | Aprovação de tarefas | Objetivos, passos e fila de aprovação |
| ABM SECURITY | Permissões/consentimento | Auditoria e bloqueios | Matriz de permissões e autorização explícita |

## Ciclo de execução

1. Android recebe texto digitado ou transcrito pelo reconhecedor do sistema.
2. EARS normaliza a transcrição.
3. BRAIN consulta o agente ABM 5.2 e a memória.
4. SOCIAL pode classificar texto explicitamente fornecido.
5. AUTONOMY pode propor um plano ou ação.
6. SECURITY verifica permissão e confirmação.
7. BODY devolve uma intenção permitida à camada Java.
8. VOICE prepara a resposta e Android TextToSpeech pode pronunciá-la.
9. A memória é guardada na área privada da aplicação.

## Limites funcionais desta versão

- Não existe microfone sempre ligado, palavra de ativação offline, gravação ambiente ou escuta de terceiros.
- Não existe reconhecimento facial, identificação de pessoas, leitura de emoções ou reconhecimento semântico de objetos.
- A análise de WAV é acústica (duração, RMS, pico); não é speech-to-text.
- A análise de imagem é estatística básica; não é um modelo de visão artificial semântico.
- A análise social é heurística e só funciona sobre texto fornecido; não prova intenção nem substitui avaliação humana.
- O Android pode restringir processos em segundo plano, câmara, microfone, chamadas e intents de outras aplicações.
- O ABM não desbloqueia o telefone, não responde automaticamente a chamadas e não finge ser o proprietário numa conversa telefónica.
- Não existe consciência ou equivalência a uma pessoa humana. É software experimental.

## Verificação

Executar `python3 tools/validate_project.py`. A compilação do APK deve ocorrer no GitHub Actions com JDK 17, Gradle 8.7 e Android SDK Platform 35. Até o workflow concluir, não considerar o APK compilado.


## Atualização 1.2.0 — EARS e EYES Android

- EARS: Android SpeechRecognizer em sessões sucessivas, acionado pelo utilizador. A palavra-chave “ABM” é detetada no texto reconhecido e o restante texto é enviado para o despachante de comandos. A audição é encerrada quando a Activity perde visibilidade. Não é um detector acústico de palavra-chave independente nem funciona em segundo plano. A disponibilidade/idioma/offline dependem do serviço de reconhecimento instalado no telefone.
- VOICE: Android TextToSpeech, com tentativa pt-PT e fallback pt-BR.
- EYES: ML Kit Image Labeling, Object Detection e Face Detection. Face Detection reporta contagem, probabilidade de sorriso e olhos abertos quando o modelo disponibiliza esses valores; não faz identificação biométrica nem leitura fiável de emoções.
- Vídeo: MediaMetadataRetriever extrai até cinco fotogramas espaçados e encaminha-os para os mesmos analisadores. Não é processamento contínuo de vídeo em tempo real.
- Câmara: a intent externa de captura pode devolver apenas uma miniatura; o ABM analisa a imagem devolvida.
- Requer compilação Gradle com acesso às dependências Google ML Kit e teste no dispositivo.
