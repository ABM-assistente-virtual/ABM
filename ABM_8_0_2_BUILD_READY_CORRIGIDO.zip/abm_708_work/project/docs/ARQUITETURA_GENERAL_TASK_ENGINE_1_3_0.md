# ABM Execution Engine 1.4.0

## Objetivo
Transformar planos em execuções verificáveis quando existir um handler real ligado à capacidade. O motor separa planeamento, execução, resultados e etapas bloqueadas.

## Componentes
- `CapabilityRegistry`: registo extensível de capacidades e handlers.
- `GeneralTaskEngine.process()`: interpreta o pedido, identifica capacidades e cria um plano.
- `GeneralTaskEngine.execute()`: executa handlers disponíveis, regista resultados e explica capacidades sem adaptador.
- `abm_android.py`: expõe `/tarefa`, `/executar <id>`, `/executar-agora <pedido>`, `/capacidades`, `process_task()` e `execute_task()`.

## Handlers executáveis incluídos
- `abm.create_goal`: grava objetivos no módulo AUTONOMY.
- `abm.task_planning`: devolve etapas estruturadas.
- `abm.calculate`: cálculo aritmético restrito a números e operadores, sem acesso a builtins.
- `abm.conversation`: chama o cérebro quando invocado como capacidade.

## Capacidades ainda sem adaptador Android
Abrir aplicações, câmara, seletor de ficheiros, pesquisa Web, telefonia, entrada de voz e análise de multimédia aparecem no registo, mas o executor Python não finge que as executou. A Activity Android tem ações próprias, mas ainda não existe despacho universal de todos os handlers Python para intents Android.

## Segurança e confirmação
Capacidades que exigem confirmação não são executadas sem aprovação. Ações externas e sensíveis continuam dependentes de permissões do Android e de confirmação explícita. O motor não tenta contornar proteções do sistema.

## Testes
Executar `python3 tools/validate_project.py`. A validação cobre compilação Python, 48 testes do núcleo, 20 verificações especializadas, cálculo, gravação de objetivos, execução parcial e relato honesto de ações sem adaptador.

## Limitação
Este motor executa apenas as capacidades para as quais existe handler. Não é uma inteligência geral ilimitada, não cria ferramentas do nada e não substitui serviços externos/LLM. O APK ainda precisa de ser compilado e testado num dispositivo Android real.
