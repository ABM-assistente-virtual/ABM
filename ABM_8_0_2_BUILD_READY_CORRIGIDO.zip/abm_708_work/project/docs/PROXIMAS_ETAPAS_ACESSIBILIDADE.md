# Próximas etapas de acessibilidade ABM

1. Comunicação aumentativa e alternativa (CAA): grelha de símbolos, frases favoritas, escrita e leitura por voz.
2. Integração opcional de interruptor externo via Switch Access/teclado Bluetooth.
3. Controlo por cabeça: protótipo com detecção facial, calibração e zonas grandes; necessita validação com utilizadores e não deve ser tratado como rastreamento ocular.
4. Controlo ocular verdadeiro: requer câmara frontal adequada, calibração, estimativa de olhar e mecanismo de seleção por permanência; validar latência, precisão e fadiga.
5. Testes com pessoas com diferentes limitações motoras e de comunicação, com consentimento e participação voluntária.

Cada recurso deve ter alternativa de saída, pausa imediata, indicador visível de microfone/câmara ativos e controlos configuráveis. Nunca prometer substituição de apoio humano ou de dispositivos médicos sem validação.
