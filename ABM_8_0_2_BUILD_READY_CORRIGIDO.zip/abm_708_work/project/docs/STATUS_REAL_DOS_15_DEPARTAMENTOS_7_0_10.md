# Estado real dos 15 departamentos — ABM 7.0.10

| Departamento | Estado | Pendência principal |
|---|---|---|
| BRAIN | Motor Python/orquestração presentes | Validar modelos, raciocínio avançado e estado persistente cifrado. |
| EARS | Reconhecimento Android presente | Ativação contínua/wake word depende de serviço e restrições do Android. |
| EYES | ML Kit e amostragem de vídeo presentes | Compreensão visual mais geral e testes em hardware. |
| VOICE | Android TextToSpeech presente | Voz/idioma dependem de pacotes instalados; prosódia e lip-sync fonético. |
| BODY | APIs Android seletivas presentes | Ligar dispatch nativo e verificar resultados reais com consentimento. |
| ACCESSIBILITY | Serviço e motores presentes | Testar modalidades e permissões em aparelho real. |
| AUTONOMY | Planeamento e gates de autorização presentes | Orquestração robusta multi-etapa; sem execução sensível automática. |
| SOCIAL | Motor de contexto presente | Modelos/conectores externos e validação. |
| MEMORY | Memória principal, contextual, adaptativa e conhecimento com campos cifráveis via Keystore | Estado do companion/brain e metadados restantes ainda não cifrados integralmente. |
| SECURITY | Android Keystore AES-GCM e políticas presentes | Teste físico, auditoria completa e cobertura total dos dados. |
| CONNECT | Cliente e conectores presentes | Serviços externos reais e credenciais. |
| SYSTEM | Orquestração dos 15 departamentos presente | Testes de integração em dispositivo e estabilidade. |
| INTERFACE | Avatar OpenGL ES procedural com cinco estilos, pestanejo e boca aproximada | Face semelhante ao utilizador, rig facial e lip-sync fonético. |
| CLOUD | Backend e cliente presentes | Implantação, TLS/domínio, segredos, monitorização e teste ponta-a-ponta. |
| DEVELOPER | Ferramentas e testes presentes | SDK/API estável e documentação para extensões. |

## Limites de validação
APK e hardware requerem SDK/Gradle e dispositivo físico. Cloud requer alojamento e credenciais do operador. AOSP requer código específico do dispositivo, kernel, vendor blobs, toolchain e assinatura. Não declarar estes resultados concluídos sem validação real.
