# Estado real dos 15 departamentos — ABM 7.0.3

Este quadro distingue módulos de software presentes de capacidades completas em operação. Registo de um departamento não prova operação física ou integração completa.

| Departamento | Implementação observável | Estado honesto |
|---|---|---|
| BRAIN | Núcleo ABM 5.2, Brain e motores de compreensão/decisão | Integrado no núcleo Python; inteligência geral não demonstrada |
| EARS | Android SpeechRecognizer e análise de WAV | Parcial; depende de serviço Android e microfone |
| EYES | ML Kit para objetos/rostos, imagens e amostras de vídeo | Parcial; não identifica identidade nem acompanha gaze preciso |
| VOICE | Android TextToSpeech | Parcial; depende do motor e dados de voz instalados |
| BODY | Ferramentas Android autorizadas e ponte de execução | Parcial; várias ações apenas despachadas, não verificadas em apps externas |
| ACCESSIBILITY | AccessibilityService, cursor, gestos, varrimento e interruptores | Parcial; depende de ativação e validação no dispositivo |
| AUTONOMY | Planeamento, tarefas e recuperação | Integrado no núcleo; execução externa permanece limitada |
| SOCIAL | Modelo social heurístico | Protótipo |
| MEMORY | JSON local e múltiplas bases SQLite | Parcial; SQLite não cifrado por completo |
| SECURITY | Política de permissões e armazenamento de token/ticket com Keystore | Parcial; precisa de validação física e auditoria adicional |
| CONNECT | Conectores e cliente de API cloud | Protótipo operacional local; serviços externos dependem de configuração |
| SYSTEM | Integração através de APIs Android | Parcial; não é firmware nem integração privilegiada |
| INTERFACE | Activity Android e overlays assistivos | Protótipo funcional; avatar 3D completo e cinco aparências não demonstrados nesta base |
| CLOUD | API FastAPI, contas, filas e componentes de dados | Código presente e testes locais; produção não implantada/verificada |
| DEVELOPER | Registo de capacidades e ferramentas | Parcial; ferramentas de extensão ainda limitadas |

## Bloqueios externos
- APK ainda precisa de compilação num ambiente com Android SDK e Gradle.
- Câmara, microfone, TTS, Keystore, AccessibilityService e operações externas precisam de teste no OPPO A3S.
- Cloud de produção exige infraestrutura, domínio, segredos e credenciais do proprietário.
- Firmware próprio exige árvore AOSP/fabricante e toolchain correspondentes.

## Não declarar
Não declarar 15 departamentos completos, consciência digital, controlo absoluto do Android, produção cloud, firmware ou compatibilidade física confirmada sem provas correspondentes.
