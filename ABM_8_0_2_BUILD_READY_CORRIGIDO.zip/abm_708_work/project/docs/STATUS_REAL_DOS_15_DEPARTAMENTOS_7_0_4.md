# Estado operacional dos 15 departamentos — ABM 7.0.4

O diagnóstico `/abm departamentos` agora apresenta três informações separadas: adaptador registado (`available`), dependências locais (`dependencies_available`) e prontidão (`readiness`). A presença de um adaptador não significa operação completa.

| Departamento | Prontidão reportada | Limite conhecido |
|---|---|---|
| BRAIN | Núcleo local inicializado | Inteligência geral não demonstrada |
| EARS | Requer runtime/permissão Android | Serviço SpeechRecognizer e microfone no dispositivo |
| EYES | Requer runtime/permissão Android | Câmara e ML Kit em sessão visível; sem identificação pessoal nem gaze preciso |
| VOICE | Requer runtime/dispositivo Android | Depende do motor TTS e dados de idioma instalados |
| BODY | Requer runtime/dispositivo Android | Despacho de ações não garante resultado em apps externas |
| ACCESSIBILITY | Requer runtime/permissão Android | Serviço deve ser ativado e testado no dispositivo |
| AUTONOMY | Núcleo local inicializado | Execução externa condicionada a ferramentas e confirmação |
| SOCIAL | Núcleo local inicializado | Modelo heurístico, não agente social humano |
| MEMORY | Núcleo local inicializado | SQLite local não cifrado integralmente |
| SECURITY | Núcleo local inicializado | Requer validação física e auditoria complementar |
| CONNECT | Núcleo local inicializado | Conectores e serviços externos dependem de configuração |
| SYSTEM | Requer runtime/permissão Android | Integração por APIs públicas, não firmware privilegiado |
| INTERFACE | Núcleo de interação presente; avatar parcial | Avatar 3D completo e cinco aparências não demonstrados |
| CLOUD | Adaptador; implantação externa necessária | Sem deployment de produção verificado |
| DEVELOPER | Núcleo local inicializado | Catálogo/extensão de ferramentas ainda limitado |

## Bloqueios externos
- APK requer compilação com Android SDK/Gradle.
- OPPO A3S requer teste físico.
- Cloud de produção requer infraestrutura, domínio, segredos e configuração do operador.
- AOSP/firmware requer árvore de código e toolchain do fabricante.

A classificação acima é uma matriz técnica de prontidão, não uma certificação de produto acabado.
