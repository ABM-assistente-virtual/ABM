# Estado operacional dos 15 departamentos — ABM 7.0.6

Esta versão melhora a proteção local de dados, mas não transforma automaticamente os departamentos em serviços completos.

| Departamento | Estado real nesta entrega |
|---|---|
| BRAIN | Núcleo Python e motores de raciocínio/regras locais; não é cérebro humano nem AGI. |
| EARS | Integração Android de reconhecimento de fala; depende de serviço/permissão do dispositivo. |
| EYES | Câmara e deteção ML Kit; não identifica pessoas nem oferece rastreio ocular preciso. |
| VOICE | TTS Android; depende de motor e dados de idioma instalados. |
| BODY | Adaptadores de ações Android permitidas; ações externas podem exigir confirmação e não são verificadas automaticamente. |
| ACCESSIBILITY | Serviço Android sujeito a ativação explícita e capacidades do dispositivo. |
| AUTONOMY | Planeamento e preparação de tarefas com limites/autorizações; não é autonomia irrestrita. |
| SOCIAL | Modelos locais de interação; não equivale a relações humanas reais. |
| MEMORY | Memória principal, contextual e aprendizagem adaptativa com campos protegidos via Keystore quando executados na Activity Android; outros dados ainda permanecem fora dessa proteção. |
| SECURITY | Políticas e armazenamento Keystore; ainda requer auditoria de todos os fluxos e teste em dispositivo. |
| CONNECT | Conectores/adaptadores; serviços externos precisam de credenciais e integração real. |
| SYSTEM | Registo/orquestração de departamentos; não é firmware nem controlo total do Android. |
| INTERFACE | Activity Android funcional; avatar 3D final e cinco aparências ainda não demonstrados. |
| CLOUD | Código de backend presente; implantação e conexão de produção não verificadas. |
| DEVELOPER | Ferramentas e estruturas extensíveis; não representa ecossistema completo de plugins. |

## Validação

- Testes automatizados Python: executados nesta revisão.
- Testes Keystore: adaptador simulado; não é teste do Android Keystore real.
- APK: não compilado neste ambiente por ausência de Android SDK/Gradle.
- OPPO A3S: não testado fisicamente.
- AOSP: sem árvore-fonte/firmware para compilar.
