# Estado operacional dos 15 departamentos — ABM 7.0.8

| Departamento | Estado nesta entrega | Limite principal |
|---|---|---|
| BRAIN | Núcleo Python, motores de raciocínio e integração com motores de decisão | Não é cérebro humano nem AGI; precisa de validação funcional extensa. |
| EARS | Reconhecimento Android de fala, modo contínuo limitado à aplicação visível | Depende de permissão, serviço de reconhecimento e teste no dispositivo. |
| EYES | Câmara, ML Kit para rótulos, objetos e deteção facial; amostragem de vídeo | Não identifica identidade; não faz rastreio ocular preciso nem análise contínua em tempo real. |
| VOICE | TTS Android | Depende de motor e dados de idioma instalados; voz natural avançada não concluída. |
| BODY | Adaptadores Android e ponte de execução com permissões | Ação externa exige autorização quando aplicável; confirmação de execução real é limitada. |
| ACCESSIBILITY | Serviço Android, perfis e mecanismos de interação adaptativa | Requer ativação explícita e compatibilidade do dispositivo; não controla tudo. |
| AUTONOMY | Planeamento, tarefas e workflows com etapas e validação humana | Workflow organiza/prepara; não executa automaticamente ações externas. |
| SOCIAL | Modelos locais de interação | Não equivale a relações humanas nem a compreensão social completa. |
| MEMORY | Memória principal, contextual, aprendizagem adaptativa, histórico de execução, workflows, recuperação e eventos de interação com adaptador Keystore | Parte dos metadados e outros bancos ainda não cifrados; teste físico Keystore pendente. |
| SECURITY | Políticas, permissões, Android Keystore e cifragem AES-GCM | Auditoria completa e validação física ainda pendentes. |
| CONNECT | Conectores e handlers locais registados; APIs cloud no projeto | Serviços externos exigem credenciais e implantação. |
| SYSTEM | Registo, diagnóstico e orquestração dos 15 departamentos | Não é firmware nem controlo irrestrito do Android. |
| INTERFACE | Activity Android e seletor persistente de cinco aparências; personalidade fixa “Consciência Digital” | Avatar 3D final, sincronização facial e semelhança com foto não concluídos. |
| CLOUD | Backend, contas, filas e componentes distribuídos no código | Não implantado nem ligado a produção. |
| DEVELOPER | Ferramentas, motor de ferramentas registadas e estrutura extensível | Ecossistema completo de extensões/plugins não concluído. |

## Verificação desta revisão

- Python: 132 testes passaram.
- Release estática: 47/47 verificações passaram.
- Histórico/workflows: 9 testes novos com adaptador simulado passaram.
- APK: não compilado neste ambiente.
- Android Keystore: adaptador real ainda precisa de teste físico.
- OPPO A3S: não testado fisicamente.
- Cloud: não implantada.
- AOSP: sem árvore-fonte/firmware para compilação.
