# Estado real dos 15 departamentos — ABM 7.0.9

A versão 7.0.9 mantém a arquitetura de 15 departamentos. O número de departamentos registados não significa que todas as capacidades de cada departamento estejam completas em hardware real.

| Departamento | Estado nesta versão |
|---|---|
| BRAIN | Motor Python e orquestração presentes; inteligência depende dos módulos locais e serviços/modelos externos configurados. |
| EARS | Reconhecimento Android disponível por serviço de fala; ativação contínua é limitada à aplicação visível. |
| EYES | ML Kit para imagem/objetos/face e amostragem de vídeo; não é compreensão visual geral irrestrita. |
| VOICE | Android TextToSpeech; qualidade/idioma dependem das vozes instaladas no dispositivo. |
| BODY | Integrações Android seletivas por APIs/serviços e permissões; não controla livremente todo o telefone. |
| ACCESSIBILITY | Serviço e motores de acessibilidade presentes; perfis cifrados quando Keystore é injetado; requer configuração/consentimento Android. |
| AUTONOMY | Planeamento e autorização de tarefas; operações sensíveis requerem confirmação e ações Android não são consideradas concluídas sem confirmação. |
| SOCIAL | Motor de conversação/contexto presente; capacidades dependem dos modelos e conectores ligados. |
| MEMORY | Memória local e cofres de campos em várias áreas; cifragem integral de todas as bases ainda não concluída. |
| SECURITY | Android Keystore AES-GCM para segredos/campos integrados; auditoria adicional ainda necessária. |
| CONNECT | Cliente cloud e conectores presentes; integração depende de serviços/credenciais externos. |
| SYSTEM | Orquestração local; não é firmware nem substitui Android. |
| INTERFACE | Avatar OpenGL ES procedural com pestanejo e animação aproximada da boca; likeness pessoal e rig facial ainda não implementados. |
| CLOUD | Backend e cliente presentes; deployment real ainda não configurado/verificado. |
| DEVELOPER | Ferramentas, testes e estrutura de extensão presentes; APIs/SDK público ainda precisam de estabilização. |

## Bloqueios de validação externa

APK e hardware Android exigem Android SDK/Gradle e dispositivo físico. Cloud exige endpoint, credenciais e hospedagem. AOSP exige código específico do dispositivo, kernel, blobs e chaves. Nenhum desses resultados é declarado concluído nesta versão.
