# Estado técnico real dos 15 departamentos — ABM 8.0.0

Legenda: **IMPLEMENTADO E TESTADO** significa que o componente local passou nos testes automatizados disponíveis; não significa validação física. **PARCIAL** indica que faltam integrações, serviços externos, hardware ou capacidades mais abrangentes.

| Departamento | Estado | Evidência e limite principal |
|---|---|---|
| BRAIN | PARCIAL — núcleo local testado | Núcleo Python, decisões e orquestração presentes; não é AGI nem cérebro biológico. |
| EARS | PARCIAL — APIs Android presentes | Reconhecimento e audição contínua dentro das restrições do Android; sem wake-word sempre ativo garantido. |
| EYES | PARCIAL — APIs ML Kit presentes | Deteção de objetos/rostos e análise de frames; não equivale a compreensão visual geral. |
| VOICE | PARCIAL — TTS Android integrado | Voz depende do motor/idioma instalados; visemas aproximados via intervalos TTS. |
| BODY | PARCIAL — operações seletivas | Intents e AccessibilityService; cada ação exige permissões/consentimento e confirmação conforme risco. |
| ACCESSIBILITY | IMPLEMENTADO LOCALMENTE, HARDWARE PENDENTE | Serviço, cursor, gestos e perfil adaptativo; feedback cifrado por campo com Keystore quando injetado. |
| AUTONOMY | PARCIAL — planeamento controlado | Motor de tarefas/workflows e gates; ações sensíveis não são executadas autonomamente sem aprovação. |
| SOCIAL | PARCIAL — motor local presente | Contexto e interação disponíveis; conectores/modelos externos não validados. |
| MEMORY | PARCIAL — campos sensíveis protegidos | Memórias e módulos com vault Keystore; metadados SQLite permanecem visíveis. |
| SECURITY | PARCIAL — políticas e Keystore no código | AES-GCM e migrações por campo; requer teste físico, auditoria adicional e SQLCipher se for exigida cifragem integral da base. |
| CONNECT | PARCIAL — conectores disponíveis | Integrações dependem de apps instaladas, endpoints, credenciais e permissões. |
| SYSTEM | IMPLEMENTADO COMO REGISTO/ORQUESTRADOR LOCAL | 15 departamentos registados e dependências verificadas; não prova execução de todos em hardware. |
| INTERFACE | PARCIAL — avatar OpenGL ES | Cinco aparências, pestanejo, olhar e visemas aproximados; sem face personalizada/rig facial completo. |
| CLOUD | BACKEND IMPLEMENTADO, NÃO IMPLANTADO | FastAPI, Postgres/Redis e testes; falta servidor, domínio/TLS e segredos de produção. |
| DEVELOPER | PARCIAL — ferramentas locais presentes | Catálogo, validação e execução controlada; SDK público estável e extensibilidade/documentação ainda incompletos. |

## Evidência de validação

- 146 testes Python passaram na suíte do projeto.
- 65/65 verificações estáticas de release passaram.
- Validador geral: `PASSOU_TOTALMENTE`.
- 25 testes cloud passaram.
- Compilação dos módulos Python passou.

## Dependências externas que impedem declarar conclusão integral

1. Android SDK + Gradle num runner para compilar o APK; o workflow `.github/workflows/build-apk.yml` está preparado, mas não foi executado aqui.
2. OPPO A3S físico para validar API, memória, microfone, câmara, Keystore, acessibilidade e desempenho.
3. Servidor, domínio, TLS e credenciais para implantação cloud.
4. Árvore AOSP compatível, device tree, kernel, vendor blobs licenciados, toolchain e assinatura para firmware AOSP.
5. Modelo facial de referência fornecido pelo utilizador e trabalho de rig/arte 3D para um avatar semelhante à sua aparência.

## Classificação global

**ABM 8.0.0 é uma versão de integração de software testada em ambiente Python, não uma versão final validada em Android, cloud ou AOSP.** Nenhum desses resultados externos é declarado como concluído.
