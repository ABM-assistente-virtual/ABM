package com.forla.abm;
public final class ABMAccessibilityEngineVoiceTest {
  private static void expect(String s, ABMAccessibilityEngine.Action a) {
    ABMAccessibilityEngine.Result r=ABMAccessibilityEngine.interpret(s);
    if(r.action!=a) throw new AssertionError(s+" -> "+r.action+", esperado "+a);
  }
  public static void main(String[] args) {
    expect("inicia varrimento", ABMAccessibilityEngine.Action.SCAN_START);
    expect("próximo elemento", ABMAccessibilityEngine.Action.SCAN_NEXT);
    expect("seleciona", ABMAccessibilityEngine.Action.SCAN_SELECT);
    expect("para varrimento", ABMAccessibilityEngine.Action.SCAN_STOP);
    expect("volta", ABMAccessibilityEngine.Action.BACK);
    System.out.println("ABMAccessibilityEngine: 5 comandos passaram");
  }
}
