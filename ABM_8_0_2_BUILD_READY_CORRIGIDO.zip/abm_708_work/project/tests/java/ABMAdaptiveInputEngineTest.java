package com.forla.abm;
import java.util.Arrays;
public final class ABMAdaptiveInputEngineTest {
  private static void check(boolean ok, String name) { if (!ok) throw new AssertionError(name); System.out.println("PASS " + name); }
  public static void main(String[] args) {
    ABMAdaptiveInputEngine e = new ABMAdaptiveInputEngine();
    e.configureHead(1.8f, 0.035f, false, 1400);
    ABMAdaptiveInputEngine.Event move = e.updateHeadPose(0.8f, 0f, 1000);
    check(move.type == ABMAdaptiveInputEngine.EventType.CURSOR_MOVED && e.getCursorX() > 0.5f, "head pose moves smoothed cursor");
    float before = e.getCursorX();
    e.updateHeadPose(Float.NaN, 0f, 1100);
    check(Math.abs(before - e.getCursorX()) < 0.0001f, "invalid sensor values ignored");
    e.configureHead(1.8f, 0.035f, true, 900);
    e.updateHeadPose(0f, 0f, 2000);
    ABMAdaptiveInputEngine.Event dwell = e.updateHeadPose(0f, 0f, 3000);
    check(dwell.type == ABMAdaptiveInputEngine.EventType.DWELL_SELECT, "dwell selection after configured interval");
    e.setScanItems(Arrays.asList("Ligar", "Mensagem", "Ajuda"), 700);
    ABMAdaptiveInputEngine.Event first = e.startSwitchScan(4000);
    check(first.type == ABMAdaptiveInputEngine.EventType.SCAN_HIGHLIGHT && first.itemIndex == 0, "switch scan starts at first item");
    ABMAdaptiveInputEngine.Event next = e.advanceSwitchScan(4700);
    check(next.type == ABMAdaptiveInputEngine.EventType.SCAN_HIGHLIGHT && next.itemIndex == 1, "switch scan advances on interval");
    ABMAdaptiveInputEngine.Event selected = e.pressSwitch();
    check(selected.type == ABMAdaptiveInputEngine.EventType.SCAN_SELECT && selected.itemIndex == 1, "switch selects highlighted item");
    e.stopSwitchScan();
    check(e.pressSwitch().type == ABMAdaptiveInputEngine.EventType.NONE, "stopped scan cannot select");
  }
}
