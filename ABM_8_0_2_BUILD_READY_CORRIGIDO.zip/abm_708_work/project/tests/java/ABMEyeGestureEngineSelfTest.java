package com.forla.abm;
public final class ABMEyeGestureEngineSelfTest {
  private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
  public static void main(String[] args) {
    final int[] events = {0};
    ABMEyeGestureEngine e = new ABMEyeGestureEngine(() -> events[0]++);
    e.process(0.1f,0.1f,1000); e.process(0.1f,0.1f,1500); check(events[0]==0,"não disparar antes do hold");
    e.process(0.1f,0.1f,1800); check(events[0]==1,"disparar após hold");
    e.process(0.1f,0.1f,1900); check(events[0]==1,"não repetir durante fecho contínuo");
    e.process(0.9f,0.9f,2000); e.process(0.1f,0.1f,2200); e.process(0.1f,0.1f,2800); check(events[0]==1,"debounce impede repetição rápida");
    e.process(0.9f,0.9f,2900); e.process(0.1f,0.1f,3200); e.process(0.1f,0.1f,4000); check(events[0]==2,"novo gesto após debounce");
    e.process(-1f,0.1f,5000); check(events[0]==2,"probabilidade desconhecida ignorada");
    boolean rejected=false; try { e.configure(0.9f,700,1000); } catch(IllegalArgumentException ex) { rejected=true; } check(rejected,"configuração inválida rejeitada");
    e.configure(0.2f,800,1300); e.reset();
    System.out.println("ABM eye gesture engine: 7 checks PASSED");
  }
}
