package com.forla.abm;
public final class ABMHeadPoseMapperTest {
  private static void check(boolean ok, String name) { if (!ok) throw new AssertionError(name); System.out.println("PASS " + name); }
  public static void main(String[] args) {
    ABMHeadPoseMapper m = new ABMHeadPoseMapper();
    check(m.map(0, 0) == null, "pose ignored before calibration");
    check(!m.calibrate(Float.NaN, 0), "invalid calibration rejected");
    check(m.calibrate(2, -1), "neutral pose calibration accepted");
    float[] center = m.map(2, -1);
    check(center != null && Math.abs(center[0]) < 0.0001f && Math.abs(center[1]) < 0.0001f, "neutral pose maps to center");
    float[] right = m.map(27, -1);
    check(right[0] == 1f, "yaw is clamped at right boundary");
    float[] up = m.map(2, -21);
    check(up[1] == -1f, "pitch is clamped at upper boundary");
    m.setRanges(2, 1000);
    float[] adjusted = m.map(12, -1);
    check(adjusted[0] > 0f && adjusted[0] <= 1f, "movement range is configurable and bounded");
    m.reset();
    check(m.map(2, -1) == null, "reset requires recalibration");
  }
}
