package com.forla.abm;
public final class ABMScanEngineTest {
    private static void check(boolean v, String m) { if (!v) throw new AssertionError(m); }
    public static void main(String[] args) {
        ABMScanEngine e = new ABMScanEngine();
        e.reset(3);
        check(e.next() == 0, "primeiro");
        check(e.next() == 1, "segundo");
        check(e.next() == 2, "terceiro");
        check(e.next() == 0, "ciclo");
        check(e.hasSelection(), "seleção válida");
        e.reset(0);
        check(e.next() == -1, "sem alvos");
        check(!e.hasSelection(), "sem seleção");
        e.reset(1);
        check(e.next() == 0 && e.next() == 0, "um alvo");
        System.out.println("ABMScanEngine: 7 verificações passaram");
    }
}
