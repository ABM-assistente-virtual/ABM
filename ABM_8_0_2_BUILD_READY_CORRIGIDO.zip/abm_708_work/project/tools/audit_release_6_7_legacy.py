from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
checks = {}

def check(name, condition):
    checks[name] = bool(condition)

manifest = (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
gradle = (ROOT / 'app/build.gradle').read_text(encoding='utf-8')
main = (ROOT / 'app/src/main/java/com/forla/abm/MainActivity.java').read_text(encoding='utf-8')
live = (ROOT / 'app/src/main/java/com/forla/abm/ABMLiveAccessActivity.java').read_text(encoding='utf-8')
service = (ROOT / 'app/src/main/java/com/forla/abm/ABMAccessibilityService.java').read_text(encoding='utf-8')
registry = (ROOT / 'app/src/main/python/abm_modules/system_unification.py').read_text(encoding='utf-8')
cloud = ROOT / 'cloud/abm_cloud/main.py'

check('android versionName 6.7.0', "versionName '6.7.0'" in gradle)
check('android versionCode 29', 'versionCode 29' in gradle)
check('android minimum API 26', 'minSdk 26' in gradle)
check('microphone permission declared', 'android.permission.RECORD_AUDIO' in manifest)
check('camera permission declared', 'android.permission.CAMERA' in manifest)
check('foreground service declared', '.ABMForegroundService' in manifest)
check('accessibility service declared', '.ABMAccessibilityService' in manifest)
check('speech recognition wired', 'SpeechRecognizer.createSpeechRecognizer' in main and 'startSpeech()' in main)
check('text to speech wired', 'new TextToSpeech' in main)
check('generic installed-app launch', 'getInstalledApplications' in main and 'getLaunchIntentForPackage' in main)
check('dialer flow uses ACTION_DIAL', 'Intent.ACTION_DIAL' in main)
check('SMS flow uses ACTION_SENDTO', 'Intent.ACTION_SENDTO' in main)
check('global actions through accessibility', 'performGlobalAction' in service)
check('ML Kit object detector', 'objectDetector.process(image)' in live)
check('ML Kit face detector', 'detector.process(image)' in live)
check('camera proxy waits for both tasks', 'Tasks.whenAllComplete(objectTask, faceTask)' in live)
check('15 department registry', all(x in registry for x in ['ABM BRAIN','ABM EARS','ABM EYES','ABM VOICE','ABM BODY','ABM ACCESSIBILITY','ABM AUTONOMY','ABM SOCIAL','ABM MEMORY','ABM SECURITY','ABM CONNECT','ABM SYSTEM','ABM INTERFACE','ABM CLOUD','ABM DEVELOPER']))
check('cloud API source present', cloud.exists())
check('AOSP boundary documented', (ROOT / 'aosp/README_ABM_SYSTEM_AOSP.md').exists())

report = {'version':'6.7.0','checks':checks,'passed':sum(checks.values()),'total':len(checks),'status':'PASSOU' if all(checks.values()) else 'FALHOU'}
(ROOT / 'TEST_REPORT_6_7_0.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
print(json.dumps(report, indent=2, ensure_ascii=False))
if not all(checks.values()):
    raise SystemExit(1)
