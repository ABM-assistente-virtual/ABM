#!/usr/bin/env python3
"""Transparent first-pass memory estimator for ABM waiting tickets.
This is a planning calculator, not a benchmark or a capacity guarantee.
"""
import argparse, json
p=argparse.ArgumentParser()
p.add_argument('--users', type=int, default=30_000_000)
p.add_argument('--bytes-per-ticket', type=int, default=1024,
               help='Planning assumption for ticket+indexes+metadata; replace with measured value')
p.add_argument('--overhead-factor', type=float, default=2.5,
               help='Extra factor for allocator, replication, fragmentation and headroom')
p.add_argument('--shards', type=int, default=256)
a=p.parse_args()
if min(a.users,a.bytes_per_ticket,a.shards) <= 0 or a.overhead_factor < 1:
    raise SystemExit('All values must be positive and overhead-factor >= 1')
raw=a.users*a.bytes_per_ticket
planned=int(raw*a.overhead_factor)
print(json.dumps({
 'users_waiting':a.users,
 'assumed_bytes_per_ticket':a.bytes_per_ticket,
 'overhead_factor':a.overhead_factor,
 'raw_estimated_bytes':raw,
 'planning_bytes_with_overhead':planned,
 'planning_gib':round(planned/(1024**3),2),
 'logical_shards':a.shards,
 'average_users_per_shard':a.users/a.shards,
 'warning':'Estimativa ilustrativa. Medir Redis real, tamanho das chaves, consultas por segundo, replicação e recuperação antes de dimensionar produção.'
},ensure_ascii=False,indent=2))
