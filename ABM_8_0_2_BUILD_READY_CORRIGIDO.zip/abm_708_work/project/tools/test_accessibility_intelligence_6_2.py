import tempfile
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.accessibility_intelligence import AccessibilityIntelligenceEngine

def main():
 with tempfile.TemporaryDirectory() as d:
  e=AccessibilityIntelligenceEngine(Path(d)/'a.sqlite')
  assert e.status()['profile_configured'] is False
  assert e.set_profile(['voice','switch'],['voice','switch'],False)['reason']=='consent_required'
  assert e.set_profile(['voice','switch'],['voice','switch'],True)['ok']
  r=e.recommend('navigation'); assert r['status']=='recommendations_ready' and r['automatic_switch'] is False
  e.feedback('switch',True,True)
  assert e.recommend()['recommendations'][0]['modality']=='switch'
  assert e.feedback('voice',False,False)['reason']=='consent_required'
  try: e.set_profile(['unknown'],['unknown'],True); raise AssertionError('invalid modality accepted')
  except ValueError: pass
  try: e.recommend('x',1.5); raise AssertionError('invalid confidence accepted')
  except ValueError: pass
  e2=AccessibilityIntelligenceEngine(Path(d)/'a.sqlite'); assert e2.status()['feedback_records']==1
  assert e.clear(False)['reason']=='confirmation_required'
  assert e.clear(True)['cleared'] and not e.status()['profile_configured']
 print('PASSOU: 9 verificações do Accessibility Intelligence Engine 6.2.0')
if __name__=='__main__': main()
