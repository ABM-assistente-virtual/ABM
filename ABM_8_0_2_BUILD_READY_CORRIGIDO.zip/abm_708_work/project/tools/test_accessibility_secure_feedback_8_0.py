import sqlite3

from app.src.main.python.abm_modules.accessibility_intelligence import AccessibilityIntelligenceEngine
from app.src.main.python.abm_modules.secure_fields import MARKER


class FakeSecureStore:
    def __init__(self):
        self.values = {}
    def putString(self, key, value):
        self.values[key] = str(value)
    def getString(self, key, default=None):
        return self.values.get(key, default)
    def remove(self, key):
        self.values.pop(key, None)


def test_encrypted_feedback_is_readable_and_profile_check_works(tmp_path):
    secure = FakeSecureStore()
    engine = AccessibilityIntelligenceEngine(tmp_path / 'access.sqlite3', secure_store=secure)
    assert engine.set_profile(['voice', 'touch'], consent=True)['ok']
    saved = engine.feedback('voice', True, consent=True)
    assert saved['encrypted_at_rest'] is True
    with sqlite3.connect(tmp_path / 'access.sqlite3') as db:
        modality = db.execute('SELECT modality FROM feedback').fetchone()[0]
    assert modality == MARKER
    assert 'voice' not in modality
    result = engine.recommend()
    voice = next(x for x in result['recommendations'] if x['modality'] == 'voice')
    touch = next(x for x in result['recommendations'] if x['modality'] == 'touch')
    assert voice['score'] > touch['score']


def test_legacy_feedback_rows_migrate_and_remain_usable(tmp_path):
    path = tmp_path / 'legacy.sqlite3'
    engine = AccessibilityIntelligenceEngine(path)
    engine.set_profile(['voice'], consent=True)
    engine.feedback('voice', True, consent=True)
    secure = FakeSecureStore()
    migrated = AccessibilityIntelligenceEngine(path, secure_store=secure)
    with sqlite3.connect(path) as db:
        profile = db.execute('SELECT data FROM profiles').fetchone()[0]
        modality = db.execute('SELECT modality FROM feedback').fetchone()[0]
    assert profile == MARKER
    assert modality == MARKER
    assert abs(migrated.recommend()['recommendations'][0]['score'] - (2 / 3)) < 0.001


def test_clear_removes_profile_and_feedback_keys(tmp_path):
    secure = FakeSecureStore()
    engine = AccessibilityIntelligenceEngine(tmp_path / 'clear.sqlite3', secure_store=secure)
    engine.set_profile(['voice'], consent=True)
    engine.feedback('voice', False, consent=True)
    assert secure.values
    assert engine.clear(confirmed=True)['cleared']
    assert secure.values == {}
    assert engine.status()['feedback_records'] == 0
