import sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.context_understanding import ContextUnderstandingEngine
from abm_modules.contextual_memory import ContextualMemory
from abm_modules.adaptive_learning import AdaptiveLearning
from abm_modules.adaptive_intelligence import AdaptiveIntelligenceEngine
class AdaptiveIntelligenceTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); root=Path(self.tmp.name)
  self.learning=AdaptiveLearning(root/'learn.db'); self.context=ContextUnderstandingEngine(ContextualMemory(root/'context.db'))
  self.engine=AdaptiveIntelligenceEngine(self.context,self.learning)
 def tearDown(self): self.tmp.cleanup()
 def test_context_connected(self): self.assertEqual(self.engine.analyze('Abre o WhatsApp')['context_analysis']['status'],'understood')
 def test_no_auto_execution(self): self.assertFalse(self.engine.analyze('Abre o WhatsApp')['execution_performed'])
 def test_feedback_requires_consent(self): self.assertFalse(self.learning.learn_feedback('apps','abre app','abre WhatsApp')['learned'])
 def test_feedback_is_surfaced(self):
  self.learning.learn_feedback('apps','abre app','abre WhatsApp',consent=True)
  r=self.engine.analyze('abre app'); self.assertEqual(len(r['relevant_user_corrections']),1)
 def test_correction_not_auto_applied(self):
  self.learning.learn_feedback('apps','abre app','abre WhatsApp',consent=True)
  r=self.engine.analyze('abre app'); self.assertFalse(r['corrections_auto_applied'])
 def test_preferences_visible(self):
  self.learning.set_preference('language','Português',consent=True)
  self.assertEqual(self.engine.analyze('Abre WhatsApp')['preferences'][0]['value'],'Português')
 def test_no_neural_training_claim(self): self.assertFalse(self.engine.status()['automatic_neural_training'])
 def test_empty_request_safe(self): self.assertEqual(self.engine.analyze('')['context_analysis']['status'],'needs_clarification')
 def test_status(self): self.assertEqual(self.engine.status()['version'],'5.5.0')
if __name__=='__main__': unittest.main(verbosity=2)
