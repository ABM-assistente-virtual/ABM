#!/usr/bin/env python3
"""Testes do ABM Adaptive Learning 4.4.0."""
import json, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
PYDIR = ROOT / 'app' / 'src' / 'main' / 'python'
sys.path.insert(0, str(PYDIR))
from abm_modules.adaptive_learning import AdaptiveLearning
import abm_android

checks = 0
with tempfile.TemporaryDirectory() as tmp:
    engine = AdaptiveLearning(Path(tmp) / 'learning.sqlite3')
    denied = engine.learn_feedback('idioma', 'responde em inglês', 'responde em português', consent=False)
    assert denied['learned'] is False and denied['reason'] == 'consent_required'; checks += 1
    saved = engine.learn_feedback('idioma', 'responde em inglês', 'responde em português', consent=True)
    assert saved['learned'] and saved['id']; checks += 1
    pref_denied = engine.set_preference('language', 'português', consent=False)
    assert pref_denied['saved'] is False; checks += 1
    pref = engine.set_preference('language', 'português', consent=True)
    assert pref['saved'] and engine.get_preferences()[0]['value'] == 'português'; checks += 1
    pattern_denied = engine.record_pattern('voice', consent=False)
    assert pattern_denied['recorded'] is False; checks += 1
    assert engine.record_pattern('voice', consent=True)['count'] == 1; checks += 1
    assert engine.record_pattern('voice', consent=True)['count'] == 2; checks += 1
    matches = engine.suggestions('responde em inglês', limit=3)
    assert matches and matches[0]['correction'] == 'responde em português'; checks += 1
    assert engine.forget_feedback(saved['id'], confirmed=False)['deleted'] is False; checks += 1
    assert engine.forget_feedback(saved['id'], confirmed=True)['deleted'] is True; checks += 1
    assert engine.clear(confirmed=False)['cleared'] is False; checks += 1
    engine.learn_feedback('tom', 'fala formal', 'usa tom simples', consent=True)
    assert engine.clear(confirmed=True)['cleared'] is True; checks += 1
    st = engine.status()
    assert st['feedback_examples'] == st['preferences'] == st['pattern_counters'] == 0
    assert st['automatic_training'] is False and st['neural_weights_changed'] is False; checks += 1

with tempfile.TemporaryDirectory() as tmp:
    abm_android.initialize(tmp)
    no = json.loads(abm_android.learning_dispatch('feedback', json.dumps({'topic':'x','input':'a','correction':'b'})))
    assert no['learned'] is False; checks += 1
    ok = json.loads(abm_android.learning_dispatch('feedback', json.dumps({'topic':'idioma','input':'responde em inglês','correction':'responde em português','consent':True})))
    assert ok['learned'] is True; checks += 1
    abm_android.learning_dispatch('preference', json.dumps({'key':'language','value':'português','consent':True}))
    coord = json.loads(abm_android.coordinate_request('responde em inglês'))
    assert coord['adaptive_context']['preferences'][0]['value'] == 'português'; checks += 1
    assert coord['adaptive_context']['relevant_corrections']; checks += 1
    routed = json.loads(abm_android.dispatch_department('memory','learning_status','{}'))
    assert routed['result']['feedback_examples'] == 1; checks += 1
    assert 'adaptive_learning' in json.loads(abm_android.status()); checks += 1

print(json.dumps({'status':'PASSOU','checks':checks,
 'features':['explicit_feedback','explicit_preferences','consented_pattern_counters','relevant_correction_retrieval','department_dispatch','android_python_bridge','export_and_confirmed_deletion'],
 'automatic_training':False,'neural_weights_changed':False,'storage':'local_sqlite_unencrypted'}, ensure_ascii=False))
