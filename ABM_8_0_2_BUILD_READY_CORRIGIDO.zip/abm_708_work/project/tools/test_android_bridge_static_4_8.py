import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'app/src/main/java/com/forla/abm/MainActivity.java').read_text(encoding='utf-8')
py=(ROOT/'app/src/main/python/abm_android.py').read_text(encoding='utf-8')
engine=(ROOT/'app/src/main/python/abm_modules/tool_engine.py').read_text(encoding='utf-8')
checks=[]
def check(name, ok):
    if not ok: raise AssertionError(name)
    checks.append(name)
check('activity_routes_execute_command', 'runUniversalToolExecution(message)' in main)
check('sensitive_action_shows_confirmation_dialog', 'Confirmar ação do ABM' in main and 'executeUniversalToolConfirmed(executionId)' in main)
check('activity_calls_python_tool_executor', 'execute_registered_tool' in main and 'record_android_tool_result' in main)
check('android_app_adapter_present', 'case "open_app"' in main and 'launchAppByName(app)' in main)
check('camera_and_file_adapters_present', 'case "open_camera"' in main and 'case "choose_file"' in main)
check('web_and_url_adapters_present', 'case "web_search"' in main and 'case "open_url"' in main)
check('share_maps_settings_adapters_present', 'case "share_text"' in main and 'case "open_maps"' in main and 'case "open_settings"' in main)
check('dial_uses_system_dialer', 'Intent.ACTION_DIAL' in main)
check('python_returns_structured_tool_result', 'def execute_registered_tool' in py and 'def record_android_tool_result' in py)
check('android_dispatch_waits_for_adapter_result', 'record["status"] = "dispatched"' in engine and 'def record_android_result' in engine)
check('does_not_claim_target_app_completion', 'não foi verificada' in engine)
check('duplicate_external_dispatch_is_blocked', '"dispatched", "android_accepted", "android_rejected"' in engine)
print(json.dumps({'status':'PASSOU','checks':len(checks),'names':checks},ensure_ascii=False,indent=2))
