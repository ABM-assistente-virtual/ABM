import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app/src/main/python"))
from abm_modules.android_execution_bridge import AndroidExecutionBridge
class BridgeTests(unittest.TestCase):
 def setUp(self): self.b=AndroidExecutionBridge()
 def test_disabled_blocks(self): self.assertFalse(self.b.validate("back", True).accepted)
 def test_unknown_blocks(self): self.b.update_service_state(True); self.assertFalse(self.b.validate("launch_anything", True).accepted)
 def test_sensitive_requires_confirmation(self): self.b.update_service_state(True); self.assertFalse(self.b.validate("home").accepted)
 def test_confirmed_allowed(self): self.b.update_service_state(True); self.assertTrue(self.b.validate("home", True).accepted)
 def test_safe_cursor(self): self.b.update_service_state(True); self.assertTrue(self.b.validate("cursor_on").accepted)
 def test_status_no_autonomy(self): self.assertFalse(self.b.status()["automatic_execution"])
if __name__ == "__main__": unittest.main()
