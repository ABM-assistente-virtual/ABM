import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.advanced_brain import AdvancedBrainPlanner
from abm_modules.unified_system import UnifiedABM

class Registry:
    def names(self): return ['abm.conversation']
class TaskEngine:
    registry=Registry()
    def process(self, request, brain=None): return {'status':'planned','request':request}

checks=[]
def check(name, condition):
    if not condition: raise AssertionError(name)
    checks.append(name)

planner=AdvancedBrainPlanner()
p=planner.create_plan('Abre o WhatsApp')
check('plan_created',p['status']=='planned' and p['execution_performed'] is False)
check('security_step_present',any(x['department']=='security' for x in p['steps']))
check('body_step_present',any(x['department']=='body' for x in p['steps']))
check('verification_step_present',p['steps'][-1]['action']=='verify_and_report')
check('dependency_chain',all(x['depends_on']==([] if x['id']==1 else [x['id']-1]) for x in p['steps']))
body=next(x for x in p['steps'] if x['department']=='body')
r=planner.record_step_result(p['plan_id'],body['id'],success=True,evidence='Android confirmou abertura')
check('confirmation_gate',r['status']=='confirmation_required')
r=planner.record_step_result(p['plan_id'],body['id'],success=True,evidence='Android confirmou abertura',confirmed=True)
check('confirmed_step_recorded',r['status']=='recorded' and r['step']['status']=='completed')
r=planner.record_step_result(p['plan_id'],p['steps'][-1]['id'],success=True,evidence='Verificação final concluída')
check('evidence_required_for_verified',r['status']=='recorded')
empty=planner.create_plan('')
check('empty_request_rejected',empty['status']=='needs_input')
unknown=planner.record_step_result('missing',1,success=True,evidence='x')
check('unknown_plan_safe',unknown['status']=='not_found')

class Memory:
    def search(self, query, profile_id='default', limit=3):
        return [{'id':'m1','topic':'Preferência de idioma','department':'brain','match_score':2}]
mp=AdvancedBrainPlanner(Memory()).create_plan('Lembra a minha preferência de idioma',include_memory=True)
check('memory_context_is_read_only',mp['memory_context'][0]['id']=='m1')
check('memory_not_auto_written',mp['execution_performed'] is False)

u=UnifiedABM(TaskEngine(),{})
up=u.advanced_plan('Abre a câmara')
check('unified_entry_point',up['orchestrator']=='ABM_UNIFIED_4.7.0')
check('unified_step_chain',len(up['steps'])>=4)
check('health_version',u.health()['version']=='4.7.0')
print({'status':'PASSOU','checks':len(checks),'names':checks,'execution_performed':False})
