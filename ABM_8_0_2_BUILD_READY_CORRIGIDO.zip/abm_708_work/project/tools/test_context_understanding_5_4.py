import sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.context_understanding import ContextUnderstandingEngine
from abm_modules.contextual_memory import ContextualMemory
class ContextUnderstandingTests(unittest.TestCase):
 def setUp(self): self.e=ContextUnderstandingEngine()
 def test_open_app_entity(self):
  r=self.e.understand("Abre o WhatsApp"); self.assertEqual(r["status"],"understood"); self.assertEqual(r["slots"]["application"],"whatsapp")
 def test_missing_app(self): self.assertEqual(self.e.understand("Abre a aplicação")["status"],"needs_information")
 def test_ambiguous(self): self.assertEqual(self.e.understand("Abre o WhatsApp e pesquisa notícias")["status"],"needs_clarification")
 def test_message_text_missing(self): self.assertIn("texto da mensagem",self.e.understand("Envia mensagem")["missing_information"])
 def test_reference_without_context(self): self.assertEqual(self.e.understand("Abre isso")["status"],"needs_context")
 def test_reference_with_context(self):
  r=self.e.understand("Abre isso",prior_context={"last_app":"whatsapp"}); self.assertEqual(r["status"],"understood")
 def test_no_execution(self): self.assertFalse(self.e.understand("Abre WhatsApp")["execution_performed"])
 def test_empty(self): self.assertEqual(self.e.understand("")["status"],"needs_clarification")
 def test_memory_optional(self):
  with tempfile.TemporaryDirectory() as d:
   m=ContextualMemory(Path(d)/"m.db"); e=ContextUnderstandingEngine(m); self.assertTrue(e.status()["memory_optional"])
if __name__=="__main__": unittest.main(verbosity=2)
