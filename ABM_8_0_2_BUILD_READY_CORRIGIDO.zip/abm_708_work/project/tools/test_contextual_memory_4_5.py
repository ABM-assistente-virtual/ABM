#!/usr/bin/env python3
"""Testes do ABM Contextual Memory 4.5.0."""
import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'/'src'/'main'/'python'))
from abm_modules.contextual_memory import ContextualMemory
import abm_android
checks=0
with tempfile.TemporaryDirectory() as tmp:
    mem=ContextualMemory(Path(tmp)/'context.sqlite3')
    assert mem.remember('idioma','Prefere português',consent=False)['reason']=='consent_required'; checks+=1
    a=mem.remember('idioma','Prefere português',consent=True,profile_id='user-A',department='brain'); assert a['stored']; checks+=1
    b=mem.remember('projeto','Projeto ABM Android',consent=True,profile_id='user-B',department='developer'); assert b['stored']; checks+=1
    assert len(mem.search('português',profile_id='user-A'))==1; checks+=1
    assert mem.search('português',profile_id='user-B')==[]; checks+=1
    assert mem.search('Android',profile_id='user-A')==[]; checks+=1
    assert mem.remember('credencial','password: segredo123',consent=True)['reason']=='possible_secret_rejected'; checks+=1
    assert mem.remember('cartão','4111 1111 1111 1111',consent=True)['reason']=='possible_secret_rejected'; checks+=1
    assert mem.remember('tema','temporário',consent=True,ttl_days=1)['stored']; checks+=1
    assert mem.status()['profile_isolation'] and mem.status()['encryption'] is False; checks+=1
    assert mem.delete(a['id'],profile_id='user-A',confirmed=False)['reason']=='confirmation_required'; checks+=1
    assert mem.delete(a['id'],profile_id='user-B',confirmed=True)['deleted'] is False; checks+=1
    assert mem.delete(a['id'],profile_id='user-A',confirmed=True)['deleted'] is True; checks+=1
    assert mem.clear_profile(profile_id='user-B',confirmed=False)['cleared'] is False; checks+=1
    assert mem.clear_profile(profile_id='user-B',confirmed=True)['deleted_count']==1; checks+=1
    assert any(x['event']=='delete' for x in mem.audit(profile_id='user-A')); checks+=1
    assert mem.purge_expired()['purged']==0; checks+=1
with tempfile.TemporaryDirectory() as tmp:
    abm_android.initialize(tmp)
    denied=json.loads(abm_android.dispatch_department('memory','context_remember',json.dumps({'topic':'x','content':'y'})))
    assert denied['result']['reason']=='consent_required'; checks+=1
    saved=json.loads(abm_android.dispatch_department('memory','context_remember',json.dumps({'topic':'project','content':'ABM accessibility','consent':True,'profile_id':'p1','source_department':'brain'})))
    assert saved['result']['stored']; checks+=1
    found=json.loads(abm_android.dispatch_department('memory','context_search',json.dumps({'query':'ABM accessibility','profile_id':'p1'})))
    assert found['result'] and found['result'][0]['topic']=='project'; checks+=1
    coord=json.loads(abm_android.coordinate_request('ABM accessibility'))
    assert 'relevant_memories' in coord['adaptive_context']; checks+=1
    status=json.loads(abm_android.status())
    assert status['contextual_memory']['profile_isolation']; checks+=1
print(json.dumps({'status':'PASSOU','checks':checks,'features':['explicit_consent','profile_isolation','department_scope','optional_expiration','secret_pattern_rejection','audit_log','confirmed_deletion','orchestrator_context_retrieval'],'encryption':False,'automatic_collection':False},ensure_ascii=False))
