import tempfile, unittest
from pathlib import Path
from abm_modules.continuous_operation import ContinuousOperationEngine
class TestContinuous(unittest.TestCase):
 def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/"w.sqlite"; self.e=ContinuousOperationEngine(self.db)
 def tearDown(self): self.tmp.cleanup()
 def make(self): return self.e.create("Teste",[{"title":"Etapa A"},{"title":"Etapa B","dependencies":[0]}])
 def test_create_persistent(self):
  w=self.make(); self.assertEqual(ContinuousOperationEngine(self.db).get(w['id'])['state'],'planned')
 def test_waits_for_human(self):
  w=self.make(); r=self.e.next_step(w['id']); self.assertEqual(r['status'],'waiting_user'); self.assertFalse(r['execution_performed'])
 def test_no_advance_without_confirmation(self):
  w=self.make(); self.e.next_step(w['id']); self.assertEqual(self.e.next_step(w['id'])['status'],'step_already_open')
 def test_dependency_and_completion(self):
  w=self.make(); a=self.e.next_step(w['id']); self.e.confirm_step(w['id'],a['step_id'],True,'feito'); b=self.e.next_step(w['id']); self.assertEqual(b['step'],'Etapa B'); self.e.confirm_step(w['id'],b['step_id'],True); self.assertEqual(self.e.next_step(w['id'])['status'],'completed')
 def test_pause_resume_cancel(self):
  w=self.make(); self.e.pause(w['id']); self.assertEqual(self.e.next_step(w['id'])['status'],'workflow_not_active'); self.e.resume(w['id']); self.assertEqual(self.e.get(w['id'])['state'],'planned'); self.e.cancel(w['id']); self.assertEqual(self.e.get(w['id'])['state'],'cancelled')
 def test_failed_step_fails_workflow(self):
  w=self.make(); a=self.e.next_step(w['id']); self.e.confirm_step(w['id'],a['step_id'],False,'erro'); self.assertEqual(self.e.get(w['id'])['state'],'failed')
if __name__=='__main__': unittest.main()
