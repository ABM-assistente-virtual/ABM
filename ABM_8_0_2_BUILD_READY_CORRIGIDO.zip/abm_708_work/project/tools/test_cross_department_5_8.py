import tempfile,unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.cross_department import CrossDepartmentEngine
class CrossDepartmentTests(unittest.TestCase):
 def setUp(self): self.t=tempfile.TemporaryDirectory(); self.e=CrossDepartmentEngine(Path(self.t.name)/'x.db')
 def tearDown(self): self.t.cleanup()
 def test_publish_and_receive(self):
  r=self.e.publish('brain','ears','transcript_request',{'text':'olá'}); self.assertEqual(r['status'],'queued'); self.assertEqual(len(self.e.receive('ears')['messages']),1)
 def test_ack(self):
  r=self.e.publish('brain','eyes','analyze',{}); self.e.receive('eyes'); self.assertTrue(self.e.acknowledge(r['message_id'],'eyes')['changed'])
 def test_wrong_recipient_cannot_ack(self):
  r=self.e.publish('brain','eyes','analyze',{}); self.e.receive('eyes'); self.assertFalse(self.e.acknowledge(r['message_id'],'ears')['changed'])
 def test_unknown_department(self):
  with self.assertRaises(ValueError): self.e.receive('alien')
 def test_payload_type(self):
  with self.assertRaises(ValueError): self.e.publish('brain','eyes','x',[])
 def test_context_consent(self): self.assertEqual(self.e.share_context('c','brain','goal','x')['status'],'consent_required')
 def test_context_roundtrip(self):
  self.e.share_context('c','brain','goal',{'v':1},consent=True); self.assertEqual(self.e.get_context('c','eyes')['items'][0]['value'],{'v':1})
 def test_persistence(self):
  self.e.publish('brain','voice','say',{'text':'hi'}); self.assertEqual(len(CrossDepartmentEngine(self.e.db_path).receive('voice')['messages']),1)
 def test_status(self): self.assertEqual(self.e.status()['version'],'5.8.0')
 def test_no_execution(self): self.assertFalse(self.e.status()['automatic_execution'])
 def test_bridge_integration(self):
  import abm_android, json
  with tempfile.TemporaryDirectory() as td:
   abm_android.initialize(td)
   status=json.loads(abm_android.command('/departamentos-compartilhamento estado'))
   self.assertEqual(status['version'],'5.8.0')
   sent=json.loads(abm_android.command('/departamento enviar brain | eyes | scan | {"target":"screen"}'))
   self.assertEqual(sent['status'],'queued')
   received=json.loads(abm_android.command('/departamento receber eyes'))
   self.assertEqual(received['messages'][0]['payload']['target'],'screen')
if __name__=='__main__': unittest.main(verbosity=2)
