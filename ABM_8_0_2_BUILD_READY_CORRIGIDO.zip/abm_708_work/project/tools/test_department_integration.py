"""Testes de integração do registo e das dependências dos 15 departamentos."""
import json
import tempfile
from pathlib import Path

import sys
ROOT = Path(__file__).resolve().parents[1]
PYTHON_APP = ROOT / 'app' / 'src' / 'main' / 'python'
if str(PYTHON_APP) not in sys.path:
    sys.path.insert(0, str(PYTHON_APP))

import abm_android


def test_all_department_adapters_initialize_and_dependencies_resolve():
    with tempfile.TemporaryDirectory(prefix='abm-dept-test-') as tmp:
        abm_android.initialize(tmp)
        status = json.loads(abm_android.command('/abm departamentos'))
        validation = json.loads(abm_android.command('/unificacao validar'))
        assert status['departments_total'] == 15
        assert status['departments_available'] == 15
        assert status['departments_with_missing_dependencies'] == []
        assert validation['passed'] is True
        assert validation['checks']['all_department_dependencies_present'] is True


def test_cloud_and_android_departments_are_not_reported_as_fully_ready():
    with tempfile.TemporaryDirectory(prefix='abm-readiness-test-') as tmp:
        abm_android.initialize(tmp)
        status = json.loads(abm_android.command('/abm departamentos'))
        departments = {item['id']: item for item in status['departments']}
        assert departments['cloud']['readiness'] == 'adapter_only_external_deployment_required'
        assert departments['ears']['readiness'] == 'android_runtime_permission_or_device_required'
        assert departments['interface']['readiness'] == 'interaction_core_present_avatar_experience_partial'
