import tempfile, os
from abm_modules.android_execution_bridge import AndroidExecutionBridge
from abm_modules.device_control import UniversalDeviceControl

def run():
    with tempfile.TemporaryDirectory() as d:
        bridge=AndroidExecutionBridge(); engine=UniversalDeviceControl(os.path.join(d,'x.db'),bridge)
        p=engine.prepare('home'); assert p['accepted'] and p['status']=='pending'
        assert not engine.approve(p['ticket'])['accepted']
        bridge.update_service_state(True)
        assert not engine.approve(p['ticket'])['accepted']
        a=engine.approve(p['ticket'],True); assert a['accepted'] and not a['dispatched'] and not a['completed']
        assert not engine.approve(p['ticket'],True)['accepted']
        q=engine.prepare('scan_next'); assert q['accepted']
        assert engine.cancel(q['ticket'])['cancelled']
        assert not engine.prepare('delete_all')['accepted']
        assert engine.status()['tickets']['authorized_for_android_dispatch']==1
    return {'tests':8,'passed':8,'status':'PASS'}
if __name__=='__main__': print(run())
