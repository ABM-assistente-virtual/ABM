import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'app/src/main/python'))
from abm_modules.tool_connector import UniversalToolConnector
from abm_modules.tool_engine import UniversalToolEngine
from abm_modules.security import Security

checks=[]
def check(name, condition):
    if not condition: raise AssertionError(name)
    checks.append(name)

with tempfile.TemporaryDirectory() as td:
    connector=UniversalToolConnector(td)
    engine=UniversalToolEngine(connector, Security())
    plan=engine.prepare('android.open_app', {'request':'abre calculadora'})
    check('prepare_does_not_execute', plan['status']=='ready' and plan['plan']['execution_id'] in engine.pending)
    result=engine.execute(plan['plan']['execution_id'])
    check('android_tool_is_dispatched_not_claimed_completed', result['status']=='dispatched' and result['external_execution'] is True)
    check('dispatched_waits_for_android_adapter', engine.pending[plan['plan']['execution_id']]['status']=='dispatched')
    accepted=engine.record_android_result(plan['plan']['execution_id'], True, 'Intent iniciado')
    check('android_adapter_acceptance_recorded', accepted['status']=='android_accepted')
    check('acceptance_does_not_claim_target_task_complete', 'não foi verificada' in accepted['message'])
    duplicate=engine.execute(plan['plan']['execution_id'])
    check('duplicate_external_dispatch_blocked', duplicate['status']=='already_executed')
    bad=engine.prepare('android.open_app', {'request':'abre app inexistente'})
    dispatched=engine.execute(bad['plan']['execution_id'])
    rejected=engine.record_android_result(bad['plan']['execution_id'], False, 'Pacote não encontrado')
    check('android_adapter_failure_recorded', dispatched['status']=='dispatched' and rejected['status']=='android_rejected')
    note=engine.prepare('abm.create_note', {'request':'teste local'})
    local=engine.execute(note['plan']['execution_id'])
    check('local_tools_still_complete_locally', local['status']=='completed' and local['external_execution'] is False)
    no=engine.record_android_result(note['plan']['execution_id'], True)
    check('external_result_rejected_for_local_tool', no['status']=='invalid_state')
    pending=engine.prepare('android.open_camera', {})
    gate=engine.execute(pending['plan']['execution_id'])
    check('sensitive_action_requires_confirmation', gate['status']=='confirmation_required')
    confirmed=engine.execute(pending['plan']['execution_id'], confirmed=True)
    check('confirmed_sensitive_action_dispatched', confirmed['status']=='dispatched')

print(json.dumps({'status':'PASSOU','version':'4.8.0','checks':len(checks),'names':checks}, ensure_ascii=False, indent=2))
