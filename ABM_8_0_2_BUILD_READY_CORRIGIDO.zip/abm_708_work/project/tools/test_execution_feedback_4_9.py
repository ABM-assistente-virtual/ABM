import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'app/src/main/python'))
from abm_modules.tool_connector import UniversalToolConnector
from abm_modules.tool_engine import UniversalToolEngine
from abm_modules.security import Security
checks=[]
def check(name, condition):
    if not condition: raise AssertionError(name)
    checks.append(name)
with tempfile.TemporaryDirectory() as td:
    engine=UniversalToolEngine(UniversalToolConnector(td), Security())
    prepared=engine.prepare('android.open_app', {'request':'abre calculadora'})
    eid=prepared['plan']['execution_id']
    dispatched=engine.execute(eid)
    check('external_action_dispatched', dispatched['status']=='dispatched')
    accepted=engine.record_android_result(eid, True, 'Intent iniciado')
    check('adapter_acceptance_recorded', accepted['status']=='android_accepted')
    invalid=engine.record_target_outcome(eid, 'maybe')
    check('invalid_outcome_rejected', invalid['status']=='invalid_outcome')
    success=engine.record_target_outcome(eid, 'success', 'Utilizador confirmou')
    check('user_reported_success_saved', success['status']=='user_reported_success')
    check('success_not_mislabeled_as_automatic_verification', 'não verificação automática' in success['message'])
    status=engine.get_execution_status(eid)
    check('status_exposes_feedback_without_arguments', status['target_outcome']=='user_reported_success' and 'arguments' not in status)
    duplicate=engine.record_target_outcome(eid, 'failure')
    check('second_feedback_blocked_by_state', duplicate['status']=='invalid_state')
    eid2=engine.prepare('android.open_app', {'request':'abre relógio'})['plan']['execution_id']
    engine.execute(eid2)
    rejected=engine.record_android_result(eid2, False, 'Activity não encontrada')
    check('adapter_rejection_recorded', rejected['status']=='android_rejected')
    cannot_feedback=engine.record_target_outcome(eid2, 'success')
    check('cannot_report_target_success_after_adapter_rejection', cannot_feedback['status']=='invalid_state')
    eid3=engine.prepare('android.open_app', {'request':'abre calendário'})['plan']['execution_id']
    engine.execute(eid3); engine.record_android_result(eid3, True)
    unknown=engine.record_target_outcome(eid3, 'unknown')
    check('unknown_result_remains_unverified', unknown['status']=='unverified' and 'permanece por verificar' in unknown['message'])
print(json.dumps({'status':'PASSOU','version':'4.9.0','checks':len(checks),'names':checks},ensure_ascii=False,indent=2))
