from pathlib import Path
import re, json
ROOT = Path(__file__).resolve().parents[1]
main = (ROOT/'app/src/main/java/com/forla/abm/MainActivity.java').read_text()
manifest = (ROOT/'app/src/main/AndroidManifest.xml').read_text()
service = (ROOT/'app/src/main/java/com/forla/abm/ABMForegroundService.java').read_text()
access = (ROOT/'app/src/main/java/com/forla/abm/ABMAccessibilityService.java').read_text()
checks = {
 'sms_opens_official_composer': 'Intent.ACTION_SENDTO' in main and 'sms_body' in main,
 'sms_requires_human_send': 'o ABM não envia sem a tua confirmação' in main,
 'calls_use_dialer': 'Intent.ACTION_DIAL' in main,
 'app_launcher_lookup': 'getInstalledApplications' in main and 'getLaunchIntentForPackage' in main,
 'microphone_permission_declared': 'android.permission.RECORD_AUDIO' in manifest,
 'camera_permission_declared': 'android.permission.CAMERA' in manifest,
 'foreground_service_declared': 'ABMForegroundService' in manifest and 'startForeground' in service,
 'accessibility_service_declared': 'ABMAccessibilityService' in manifest,
 'accessibility_global_actions': 'GLOBAL_ACTION_HOME' in access and 'GLOBAL_ACTION_BACK' in access,
 'no_claim_of_production_cloud': 'Não há URL de produção' in (ROOT/'README_ABM_6_5_0_INTEGRACAO_REAL.txt').read_text(),
 'no_claim_of_android_os': 'Não é Android OS/AOSP' in (ROOT/'README_ABM_6_5_0_INTEGRACAO_REAL.txt').read_text(),
}
failed = [k for k,v in checks.items() if not v]
result = {'version':'6.5.0','status':'PASSOU' if not failed else 'FALHOU','checks':checks,'passed':len(checks)-len(failed),'total':len(checks),'failed':failed}
(ROOT/'TEST_REPORT_6_5_0.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print(json.dumps(result,indent=2,ensure_ascii=False))
if failed: raise SystemExit(1)
