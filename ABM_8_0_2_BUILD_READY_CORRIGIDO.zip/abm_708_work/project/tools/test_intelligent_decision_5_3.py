import sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.tool_connector import UniversalToolConnector
from abm_modules.tool_engine import UniversalToolEngine
from abm_modules.security import Security
from abm_modules.intelligent_decision import IntelligentDecisionEngine
with tempfile.TemporaryDirectory() as td:
    connector=UniversalToolConnector(td)
    engine=UniversalToolEngine(connector,Security(),Path(td)/'history.sqlite3')
    decision=IntelligentDecisionEngine(engine)
    before=len(engine.pending)
    a=decision.decide('Abre o YouTube')
    assert a['status']=='needs_information' and a['recommendation']=='android.open_app'
    assert a['execution_performed'] is False and a['tool_prepared'] is False
    assert len(engine.pending)==before
    b=decision.decide('Liga para a minha mãe')
    assert b['recommendation'] is None or b['status'] in ('needs_information','blocked_by_risk','needs_clarification')
    c=decision.decide('pedido sem correspondência')
    assert c['status']=='needs_clarification'
    d=decision.decide('faz uma chamada',max_risk='low')
    assert d['status'] in ('blocked_by_risk','needs_clarification')
    e=decision.decide('')
    assert e['status']=='needs_clarification'
    assert decision.status()['executes_tools'] is False
    print({'status':'PASSOU','tests':6,'checks':['tool_candidate','no_auto_prepare','no_auto_execute','unknown_request','risk_limit','empty_request']})
