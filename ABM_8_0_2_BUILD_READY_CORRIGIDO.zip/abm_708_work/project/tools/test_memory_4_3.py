#!/usr/bin/env python3
"""Testes do ABM MEMORY 4.3.0: consentimento, pesquisa, exportação e eliminação."""
import json, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'app' / 'src' / 'main' / 'python'))
from abm_modules.memory_store import LocalMemoryStore
import abm_android

with tempfile.TemporaryDirectory() as tmp:
    store = LocalMemoryStore(Path(tmp) / 'memory.sqlite3')
    denied = store.remember('gosto de música', consent=False)
    assert denied['stored'] is False and denied['reason'] == 'consent_required'
    saved = store.remember('Prefiro respostas em português', consent=True, category='preference', importance=5)
    assert saved['stored'] and saved['id']
    assert store.search('português')[0]['id'] == saved['id']
    assert store.list_memories()[0]['category'] == 'preference'
    assert store.forget(saved['id'], confirmed=False)['deleted'] is False
    assert store.forget(saved['id'], confirmed=True)['deleted'] is True
    assert store.status()['count'] == 0
    store.remember('projeto ABM', consent=True)
    exported = json.loads(store.export_json())
    assert exported['format'] == 'abm-memory-v1' and len(exported['memories']) == 1
    assert store.clear(confirmed=False)['cleared'] is False
    assert store.clear(confirmed=True)['deleted_count'] == 1

    abm_android.initialize(Path(tmp) / 'bridge')
    no_consent = json.loads(abm_android.memory_dispatch('remember', json.dumps({'text':'não guardar'})))
    assert no_consent['status'] == 'consent_required'
    ok = json.loads(abm_android.memory_dispatch('remember', json.dumps({'text':'preferência de idioma: português','consent':True})))
    assert ok['result']['stored'] is True
    found = json.loads(abm_android.memory_dispatch('search', json.dumps({'query':'português'})))
    assert len(found['result']) == 1
    blocked = json.loads(abm_android.memory_dispatch('clear', '{}'))
    assert blocked['result']['cleared'] is False

print(json.dumps({'status':'PASSOU','checks':14,
 'features':['explicit_consent','local_sqlite','search','list','export_json','confirmed_delete','confirmed_clear','android_bridge'],
 'automatic_collection':False,'encryption':'not_implemented'}, ensure_ascii=False))
