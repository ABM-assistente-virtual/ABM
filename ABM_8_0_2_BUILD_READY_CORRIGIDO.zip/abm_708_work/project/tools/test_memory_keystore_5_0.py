"""Testes comportamentais do armazenamento de memória com adaptador Keystore."""
import sqlite3
import tempfile
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app" / "src" / "main" / "python"))
from abm_modules.memory_store import LocalMemoryStore


class FakeKeystore:
    """Adaptador determinístico para testar o contrato Java sem alegar teste Android."""
    def __init__(self):
        self.values = {}

    def putString(self, key, value):
        self.values[str(key)] = str(value)

    def getString(self, key, default):
        return self.values.get(str(key), default)

    def remove(self, key):
        self.values.pop(str(key), None)


def test_encrypted_payload_not_written_to_sqlite_and_roundtrip():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "memory.sqlite3"
        keystore = FakeKeystore()
        store = LocalMemoryStore(path, secure_store=keystore)
        saved = store.remember("conteúdo privado ABM", consent=True)
        assert saved["encrypted_at_rest"] is True
        assert store.search("privado")[0]["content"] == "conteúdo privado ABM"
        with sqlite3.connect(path) as db:
            raw = db.execute("SELECT content FROM memories WHERE id = ?", (saved["id"],)).fetchone()[0]
        assert raw == LocalMemoryStore._ENCRYPTED_MARKER
        assert "conteúdo privado ABM" not in raw
        assert store.status()["encrypted_at_rest"] is True


def test_legacy_plaintext_rows_are_migrated():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "memory.sqlite3"
        legacy = LocalMemoryStore(path)
        saved = legacy.remember("memória antiga", consent=True)
        keystore = FakeKeystore()
        migrated = LocalMemoryStore(path, secure_store=keystore)
        assert migrated.list_memories()[0]["content"] == "memória antiga"
        with sqlite3.connect(path) as db:
            raw = db.execute("SELECT content FROM memories WHERE id = ?", (saved["id"],)).fetchone()[0]
        assert raw == LocalMemoryStore._ENCRYPTED_MARKER
        assert keystore.getString(LocalMemoryStore._KEY_PREFIX + saved["id"], None) == "memória antiga"


def test_delete_and_clear_remove_keystore_secrets():
    with tempfile.TemporaryDirectory() as tmp:
        keystore = FakeKeystore()
        store = LocalMemoryStore(Path(tmp) / "memory.sqlite3", secure_store=keystore)
        one = store.remember("primeira", consent=True)
        two = store.remember("segunda", consent=True)
        assert store.forget(one["id"], confirmed=True)["deleted"] is True
        assert LocalMemoryStore._KEY_PREFIX + one["id"] not in keystore.values
        assert store.clear(confirmed=True)["deleted_count"] == 1
        assert LocalMemoryStore._KEY_PREFIX + two["id"] not in keystore.values


def test_keystore_missing_secret_fails_closed():
    with tempfile.TemporaryDirectory() as tmp:
        keystore = FakeKeystore()
        store = LocalMemoryStore(Path(tmp) / "memory.sqlite3", secure_store=keystore)
        saved = store.remember("não deve aparecer", consent=True)
        keystore.remove(LocalMemoryStore._KEY_PREFIX + saved["id"])
        item = store.list_memories()[0]
        assert "chave protegida ausente" in item["content"]
        assert "não deve aparecer" not in item["content"]


if __name__ == "__main__":
    test_encrypted_payload_not_written_to_sqlite_and_roundtrip()
    test_legacy_plaintext_rows_are_migrated()
    test_delete_and_clear_remove_keystore_secrets()
    test_keystore_missing_secret_fails_closed()
    print("ABM MEMORY Keystore: 4 testes comportamentais passaram (adaptador simulado; não é teste físico Android).")
