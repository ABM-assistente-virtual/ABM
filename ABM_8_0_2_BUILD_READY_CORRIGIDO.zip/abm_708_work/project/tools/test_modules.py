#!/usr/bin/env python3
"""Testes unitários dos oito módulos ABM especializados."""
import sys, tempfile, wave, struct
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
PYDIR = ROOT / "app" / "src" / "main" / "python"
sys.path.insert(0, str(PYDIR))
from abm_modules import Brain, Ears, Eyes, Voice, Body, Social, Autonomy, Security, GeneralTaskEngine

# EARS: transcrição e WAV real, gerado localmente.
e = Ears()
assert e.normalize_transcript(" ABM, abre ficheiros ")["wake_word"] is True
with tempfile.TemporaryDirectory() as d:
    wav = Path(d) / "tone.wav"
    samples = [int(9000 * __import__('math').sin(2*__import__('math').pi*440*i/8000)) for i in range(800)]
    with wave.open(str(wav), 'wb') as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(8000)
        f.writeframes(struct.pack('<' + 'h'*len(samples), *samples))
    audio = e.analyze_wav(str(wav))
    assert audio["ok"] and audio["duration_seconds"] == 0.1 and audio["rms"] > 0

# EYES: valida comportamento quando Pillow existe; ausência é explicitamente tratada.
eyes = Eyes()
try:
    from PIL import Image
    with tempfile.TemporaryDirectory() as d:
        img = Path(d) / "test.png"
        Image.new('RGB', (12, 8), (20, 40, 60)).save(img)
        result = eyes.analyze_image(str(img))
        assert result["width"] == 12 and result["height"] == 8
except ImportError:
    pass

# VOICE, BODY, SOCIAL, AUTONOMY, SECURITY
assert Voice().prepare("Olá ABM")["text"] == "Olá ABM"
body = Body()
assert body.plan("abre o YouTube")["action"] == "open_youtube"
assert body.plan("abre os meus ficheiros")["action"] == "open_file_picker"
social = Social()
assert social.analyze_text("és burro")["level"] == "moderado"
assert social.analyze_text("vou-te bater")["level"] == "alto"
auto = Autonomy()
goal = auto.add_goal("Estudar Python", ["Ler", "Praticar"])
assert len(goal["steps"]) == 2
pending = auto.propose_action("make_call", {"number": "123"})
assert auto.approve(pending["id"])["ok"]
security = Security()
assert not security.authorize("unlock_device")["allowed"]
assert not security.authorize("make_call")["allowed"]
assert security.authorize("make_call", confirmed=True)["allowed"]
assert not security.authorize("record_audio", confirmed=True)["allowed"]
# GENERAL TASK ENGINE: pedidos novos são planeados sem depender de uma lista fixa de frases.
engine = GeneralTaskEngine(body, auto)
plan = engine.process("Quero organizar os meus estudos e criar um plano semanal")
assert plan["status"] == "planned" and len(plan["plan"]["steps"]) >= 3
assert "abm.create_goal" in plan["plan"]["capabilities"]
engine.register_capability("user.custom_tool", "Ferramenta personalizada de teste")
assert "user.custom_tool" in engine.registry.names()
chat = engine.process("Olá, como estás?", lambda _: "Estou pronto para ajudar.")
assert chat["status"] == "conversation" and "pronto" in chat["response"]
call = engine.process("Liga para 841234567")
assert "android.dial" in call["confirmation_required"]
print({"status": "PASSOU", "modules": 9, "checks": 20})
