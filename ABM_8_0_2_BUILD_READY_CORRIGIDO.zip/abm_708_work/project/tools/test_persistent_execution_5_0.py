import json, sys, tempfile, sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'app/src/main/python'))
from abm_modules.tool_connector import UniversalToolConnector
from abm_modules.tool_engine import UniversalToolEngine
from abm_modules.security import Security

checks=[]
def check(name, condition):
    if not condition: raise AssertionError(name)
    checks.append(name)

with tempfile.TemporaryDirectory() as td:
    db=Path(td)/'history.sqlite3'
    connector=UniversalToolConnector(td)
    engine=UniversalToolEngine(connector, Security(), db)

    # Sem consentimento, apenas metadados; reinício exige preparação nova.
    p1=engine.prepare('android.open_app', {'request':'abre calculadora'})
    id1=p1['plan']['execution_id']
    engine2=UniversalToolEngine(UniversalToolConnector(td), Security(), db)
    st1=engine2.get_execution_status(id1)
    check('metadata_survives_restart', st1['status']=='interrupted_requires_reprepare')
    check('arguments_not_recovered_without_consent', engine2.pending[id1]['arguments']=={})
    check('unsafe_resume_requires_reprepare', engine2.resume_execution(id1)['status']=='reprepare_required')

    # Com consentimento explícito, argumento local fica guardado e pode continuar.
    p2=engine2.prepare('abm.create_note', {'request':'nota retomada'}, persist_context=True)
    id2=p2['plan']['execution_id']
    engine3=UniversalToolEngine(UniversalToolConnector(td), Security(), db)
    check('consented_context_restored', engine3.pending[id2]['arguments'].get('request')=='nota retomada')
    resumed=engine3.resume_execution(id2)
    check('consented_local_task_resumes', resumed['status']=='completed')
    check('resumed_task_not_duplicated', engine3.execute(id2)['status']=='already_executed')

    # Estado de execução Android e feedback continuam disponíveis depois de reiniciar.
    p3=engine3.prepare('android.open_app', {'request':'abre relógio'}, persist_context=True)
    id3=p3['plan']['execution_id']
    check('android_dispatch', engine3.execute(id3)['status']=='dispatched')
    check('android_acceptance', engine3.record_android_result(id3, True, 'Intent iniciado')['status']=='android_accepted')
    engine4=UniversalToolEngine(UniversalToolConnector(td), Security(), db)
    check('android_status_survives_restart', engine4.get_execution_status(id3)['status']=='android_accepted')
    feedback=engine4.record_target_outcome(id3, 'success', 'Utilizador confirmou')
    check('user_feedback_after_restart', feedback['status']=='user_reported_success')
    engine5=UniversalToolEngine(UniversalToolConnector(td), Security(), db)
    check('feedback_survives_second_restart', engine5.get_execution_status(id3)['target_outcome']=='user_reported_success')
    check('history_lists_all', len(engine5.list_history()['records'])==3)
    check('audit_events_persist', len(engine5.execution_events(id3)['events'])>=3)
    check('history_hides_raw_arguments', 'arguments' not in engine5.list_history()['records'][0])

    # Confirma que argumento do plano sem consentimento não foi guardado na BD.
    with sqlite3.connect(db) as cx:
        row=cx.execute('SELECT args_json,persist_consent FROM executions WHERE execution_id=?',(id1,)).fetchone()
    check('database_omits_unconsented_arguments', row==(None,0))
    check('store_reports_unencrypted_status', engine5.status()['persistent_history']['arguments_encrypted'] is False)

print(json.dumps({'status':'PASSOU','version':'5.0.0','checks':len(checks),'names':checks},ensure_ascii=False,indent=2))
