import sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.context_understanding import ContextUnderstandingEngine
from abm_modules.contextual_memory import ContextualMemory
from abm_modules.adaptive_learning import AdaptiveLearning
from abm_modules.predictive_intelligence import PredictiveIntelligenceEngine

class PredictiveTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); p=Path(self.tmp.name)
  self.learning=AdaptiveLearning(p/'learn.db')
  self.context=ContextUnderstandingEngine(ContextualMemory(p/'context.db'))
  self.engine=PredictiveIntelligenceEngine(self.context,self.learning)
 def tearDown(self): self.tmp.cleanup()
 def test_empty_request(self): self.assertEqual(self.engine.predict('')['status'],'needs_input')
 def test_no_evidence_no_prediction(self): self.assertEqual(self.engine.predict('Quero organizar ficheiros')['status'],'insufficient_evidence')
 def test_feedback_can_support_suggestion(self):
  self.learning.learn_feedback('whatsapp','abre app','abre WhatsApp',consent=True)
  r=self.engine.predict('abre app')
  self.assertTrue(r['predictions'])
  self.assertEqual(r['predictions'][0]['suggestion'],'abre WhatsApp')
 def test_no_execution(self): self.assertFalse(self.engine.predict('abre app')['execution_performed'])
 def test_user_choice_required(self):
  self.learning.learn_feedback('whatsapp','abre app','abre WhatsApp',consent=True)
  self.assertTrue(self.engine.predict('abre app')['predictions'][0]['requires_user_choice'])
 def test_pattern_requires_consent(self): self.assertFalse(self.engine.record_explicit_pattern('rotina',consent=False)['recorded'])
 def test_pattern_persists(self):
  self.engine.record_explicit_pattern('rotina',consent=True)
  self.assertEqual(self.engine.status()['pattern_counters'],1)
 def test_no_background_monitoring(self): self.assertFalse(self.engine.status()['background_monitoring'])
 def test_status_version(self): self.assertEqual(self.engine.status()['version'],'5.6.0')
if __name__=='__main__': unittest.main(verbosity=2)
