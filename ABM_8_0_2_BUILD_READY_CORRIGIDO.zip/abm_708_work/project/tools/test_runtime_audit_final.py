import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.runtime_audit import RuntimeAudit

def test_runtime_audit_is_truthful(tmp_path):
    modules={k:object() for k in ('agent','tool_engine','task_engine','memory_store','security','android_bridge','system_unification')}
    modules['cloud_status']={'configured':False,'runtime_connected':False}
    (tmp_path/'abm_memory.sqlite3').touch()
    report=RuntimeAudit(modules,tmp_path).report()
    assert report['runtime']['python_core_initialized'] is True
    assert report['cloud']['deployment_verified'] is False
    assert report['cloud']['runtime_connected'] is False
    assert report['storage']['local_sqlite_encryption'].startswith('field-level protection')
    assert 'SQLCipher is not configured' in report['storage']['local_sqlite_encryption']
    assert report['storage']['other_sqlite_encryption'].startswith('sensitive_companion_state_brain_snapshot_and_module_state_use_keystore_when_injected')
    assert report['storage']['memory_store']['ready'] is True
    assert 'accessibility_profile_and_feedback' in report['storage']['store_status']
    assert report['departments']['count']==15
    assert report['readiness']=='PARTIAL_REQUIRES_DEVICE_AND_CLOUD_VALIDATION'

def test_runtime_audit_missing_modules(tmp_path):
    report=RuntimeAudit({},tmp_path).report()
    assert report['runtime']['python_core_initialized'] is False
    assert report['departments']['count']==0
    assert report['cloud']['configured'] is False
