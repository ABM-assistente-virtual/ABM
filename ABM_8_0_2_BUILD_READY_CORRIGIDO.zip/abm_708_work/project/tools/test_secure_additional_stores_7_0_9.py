import json
import tempfile
from pathlib import Path
from abm_modules.accessibility_intelligence import AccessibilityIntelligenceEngine
from abm_modules.cross_department import CrossDepartmentEngine

class FakeKeystore:
    def __init__(self): self.data = {}
    def putString(self, key, value): self.data[str(key)] = str(value)
    def getString(self, key, default=None): return self.data.get(str(key), default)
    def remove(self, key): self.data.pop(str(key), None)

def test_accessibility_profile_encrypted_and_restored():
    with tempfile.TemporaryDirectory() as d:
        store = FakeKeystore(); path = Path(d) / 'a.sqlite3'
        engine = AccessibilityIntelligenceEngine(path, store)
        engine.set_profile(['voice','touch'], consent=True)
        raw = __import__('sqlite3').connect(path).execute('select data from profiles').fetchone()[0]
        assert raw == '@abm-keystore-v1'
        assert engine.status()['profile']['preferred'] == ['voice','touch']
        assert engine.recommend()['status'] == 'recommendations_ready'
        engine.clear(confirmed=True)
        assert 'abm.accessibility.profile.v1.profile' not in store.data

def test_cross_department_payload_encrypted_and_delivered():
    with tempfile.TemporaryDirectory() as d:
        store = FakeKeystore(); path = Path(d) / 'x.sqlite3'
        engine = CrossDepartmentEngine(path, store)
        result = engine.publish('brain','memory','context',{'private_note':'segredo'})
        raw = __import__('sqlite3').connect(path).execute('select payload from messages').fetchone()[0]
        assert raw == '@abm-keystore-v1'
        received = engine.receive('memory')['messages'][0]
        assert received['payload'] == {'private_note':'segredo'}
        assert engine.status()['encrypted_payloads'] is True

def test_cross_department_shared_context_encrypted():
    with tempfile.TemporaryDirectory() as d:
        store = FakeKeystore(); path = Path(d) / 'x.sqlite3'
        engine = CrossDepartmentEngine(path, store)
        engine.share_context('corr-1','brain','goal',{'value':'privado'},consent=True)
        raw = __import__('sqlite3').connect(path).execute('select value from shared_context').fetchone()[0]
        assert raw == '@abm-keystore-v1'
        result = engine.get_context('corr-1','memory')
        assert result['items'][0]['value'] == {'value':'privado'}
