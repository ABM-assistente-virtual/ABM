import json, tempfile, unittest, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_android import _secure_json_read, _secure_json_write, _install_secure_companion_persistence, _STATE_MARKER
from ABM_UNIFICADO_5_2 import ABMCompanion

class FakeSecureStore:
    def __init__(self): self.data={}
    def putString(self,k,v): self.data[k]=v
    def getString(self,k,d=None): return self.data.get(k,d)
    def remove(self,k): self.data.pop(k,None)

class SecureCoreStateTests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.path=Path(self.tmp.name)/'state.json'; self.store=FakeSecureStore()
    def tearDown(self): self.tmp.cleanup()
    def test_write_keeps_only_marker_in_file(self):
        payload={'profile':{'private_note':'segredo cerebral'},'pending_action':{'target':'privado'}}
        _secure_json_write(self.path,'abm.core.test.v1',payload,self.store)
        self.assertEqual(self.path.read_text(),_STATE_MARKER)
        self.assertNotIn('segredo cerebral',self.path.read_text())
        self.assertEqual(_secure_json_read(self.path,'abm.core.test.v1',self.store),payload)
    def test_legacy_plain_json_migrates(self):
        payload={'goals':{'g1':'objetivo confidencial'}}
        self.path.write_text(json.dumps(payload),encoding='utf-8')
        self.assertEqual(_secure_json_read(self.path,'abm.core.test.v1',self.store),payload)
        self.assertEqual(self.path.read_text(),_STATE_MARKER)
        self.assertIn('objetivo confidencial',self.store.data['abm.core.test.v1'])
    def test_missing_keystore_value_fails_closed(self):
        self.path.write_text(_STATE_MARKER,encoding='utf-8')
        self.assertIsNone(_secure_json_read(self.path,'missing.key',self.store))
    def test_companion_and_brain_snapshots_are_protected_and_reload(self):
        root=Path(self.tmp.name)/'appdata'; root.mkdir()
        first=ABMCompanion(total_virtual_neurons=64,state_path=str(root/'abm_companion.json'))
        first.companion_profile['display_name']='ABM protegido'
        _install_secure_companion_persistence(first,root,self.store)
        first.save_companion()
        state=root/'abm_companion.json'; brain=root/'abm_companion.brain.json'
        self.assertEqual(state.read_text(),_STATE_MARKER)
        self.assertEqual(brain.read_text(),_STATE_MARKER)
        self.assertNotIn('ABM protegido',state.read_text())
        second=ABMCompanion(total_virtual_neurons=64,state_path=str(state))
        _install_secure_companion_persistence(second,root,self.store)
        self.assertEqual(second.companion_profile.get('display_name'),'ABM protegido')
        self.assertEqual(state.read_text(),_STATE_MARKER)
        self.assertEqual(brain.read_text(),_STATE_MARKER)
    def test_unavailable_store_mode_is_explicit_plain_json(self):
        payload={'state':'desktop'}
        _secure_json_write(self.path,'unused',payload,None)
        self.assertEqual(json.loads(self.path.read_text()),payload)
        self.assertEqual(_secure_json_read(self.path,'unused',None),payload)

if __name__=='__main__': unittest.main()
