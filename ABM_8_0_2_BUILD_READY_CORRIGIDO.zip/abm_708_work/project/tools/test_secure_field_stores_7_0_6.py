"""Testes com adaptador simulado; não substituem validação no Android Keystore real."""
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from abm_modules.contextual_memory import ContextualMemory
from abm_modules.adaptive_learning import AdaptiveLearning

class FakeSecureStore:
    def __init__(self): self.data = {}
    def putString(self, key, value): self.data[str(key)] = str(value)
    def getString(self, key, default=None): return self.data.get(str(key), default)
    def remove(self, key): self.data.pop(str(key), None)

class SecureFieldStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.secure = FakeSecureStore()
    def tearDown(self): self.tmp.cleanup()

    def test_contextual_memory_encrypted_and_searchable(self):
        path = self.root / 'context.sqlite3'
        store = ContextualMemory(path, self.secure)
        saved = store.remember('Projeto privado', 'Conteúdo confidencial', consent=True)
        self.assertTrue(saved['encrypted_at_rest'])
        raw = sqlite3.connect(path).execute('SELECT topic,content FROM contextual_memories').fetchone()
        self.assertEqual(raw, ('@abm-keystore-v1', '@abm-keystore-v1'))
        found = store.search('confidencial')
        self.assertEqual(found[0]['topic'], 'Projeto privado')
        store.delete(saved['id'], confirmed=True)
        self.assertFalse(any(k.endswith(saved['id']) for k in self.secure.data))

    def test_contextual_migrates_legacy_rows(self):
        path = self.root / 'legacy_context.sqlite3'
        legacy = ContextualMemory(path)
        legacy.remember('Antigo', 'Texto antigo', consent=True)
        upgraded = ContextualMemory(path, self.secure)
        raw = sqlite3.connect(path).execute('SELECT topic,content FROM contextual_memories').fetchone()
        self.assertEqual(raw, ('@abm-keystore-v1', '@abm-keystore-v1'))
        self.assertEqual(upgraded.search('antigo')[0]['content'], 'Texto antigo')

    def test_adaptive_learning_encrypts_feedback_and_preferences(self):
        path = self.root / 'learning.sqlite3'
        store = AdaptiveLearning(path, self.secure)
        item = store.learn_feedback('privado', 'pergunta confidencial', 'correção secreta', consent=True)
        store.set_preference('estilo', 'resposta reservada', consent=True)
        raw = sqlite3.connect(path).execute('SELECT topic,input_text,correction FROM feedback').fetchone()
        self.assertEqual(raw, ('@abm-keystore-v1',) * 3)
        self.assertEqual(store.suggestions('confidencial')[0]['correction'], 'correção secreta')
        self.assertEqual(store.get_preferences()[0]['value'], 'resposta reservada')
        store.forget_feedback(item['id'], confirmed=True)
        self.assertNotIn('abm.learning.v1.feedback.' + item['id'], self.secure.data)

    def test_adaptive_migrates_legacy_data(self):
        path = self.root / 'legacy_learning.sqlite3'
        old = AdaptiveLearning(path)
        old.learn_feedback('old', 'input old', 'correction old', consent=True)
        old.set_preference('theme', 'dark', consent=True)
        upgraded = AdaptiveLearning(path, self.secure)
        self.assertEqual(upgraded.suggestions('input old')[0]['correction'], 'correction old')
        self.assertEqual(upgraded.get_preferences()[0]['value'], 'dark')
        raw = sqlite3.connect(path).execute('SELECT correction FROM feedback').fetchone()[0]
        self.assertEqual(raw, '@abm-keystore-v1')

if __name__ == '__main__': unittest.main()
