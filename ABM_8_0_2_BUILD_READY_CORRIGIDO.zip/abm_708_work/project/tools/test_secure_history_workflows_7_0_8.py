import json, sqlite3, tempfile, unittest, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"app/src/main/python"))
from abm_modules.execution_history import ExecutionHistoryStore
from abm_modules.continuous_operation import ContinuousOperationEngine
from abm_modules.secure_fields import MARKER

class FakeSecureStore:
    def __init__(self): self.data={}
    def putString(self,k,v): self.data[k]=v
    def getString(self,k,d=None): return self.data.get(k,d)
    def remove(self,k): self.data.pop(k,None)

class SecureHistoryWorkflowTests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name); self.secure=FakeSecureStore()
    def tearDown(self): self.tmp.cleanup()

    def test_execution_history_encrypts_arguments_and_details(self):
        path=self.root/'history.sqlite3'; store=ExecutionHistoryStore(path,self.secure)
        record={'execution_id':'e1','tool':'abm.read_note','status':'ready','arguments':{'note_name':'segredo privado'},'persist_context':True,'android_adapter_detail':'detalhe confidencial','target_outcome':'resultado reservado'}
        store.save(record)
        with sqlite3.connect(path) as db:
            row=db.execute('SELECT detail,args_json,target_outcome FROM executions').fetchone()
        self.assertEqual(row,(MARKER,MARKER,MARKER))
        self.assertNotIn('segredo privado',path.read_bytes().decode('latin1'))
        recovered=store.recover()[0]
        self.assertEqual(recovered['arguments']['note_name'],'segredo privado')
        self.assertEqual(recovered['android_adapter_detail'],'detalhe confidencial')
        self.assertEqual(recovered['target_outcome'],'resultado reservado')
        self.assertTrue(store.status()['sensitive_fields_encrypted'])

    def test_execution_update_preserves_consented_arguments(self):
        store=ExecutionHistoryStore(self.root/'history.sqlite3',self.secure)
        store.save({'execution_id':'e2','tool':'x','status':'ready','arguments':{'x':'private'},'persist_context':True})
        store.save({'execution_id':'e2','tool':'x','status':'done','arguments':{},'persist_context':False})
        self.assertEqual(store.recover()[0]['arguments'],{'x':'private'})

    def test_legacy_execution_row_migrates(self):
        path=self.root/'legacy.sqlite3'
        plain=ExecutionHistoryStore(path)
        plain.save({'execution_id':'old','tool':'x','status':'ready','arguments':{'token':'legacy-secret'},'persist_context':True,'android_adapter_detail':'legacy detail'})
        secure=ExecutionHistoryStore(path,self.secure)
        with sqlite3.connect(path) as db: row=db.execute('SELECT detail,args_json FROM executions').fetchone()
        self.assertEqual(row,(MARKER,MARKER))
        self.assertEqual(secure.recover()[0]['arguments']['token'],'legacy-secret')

    def test_workflow_result_is_encrypted_and_retrievable(self):
        path=self.root/'workflow.sqlite3'; engine=ContinuousOperationEngine(path,secure_store=self.secure)
        workflow=engine.create('Teste',[{'title':'Etapa 1'}]); step=workflow['steps'][0]
        engine.next_step(workflow['id'])
        engine.confirm_step(workflow['id'],step['id'],True,'resultado confidencial')
        with sqlite3.connect(path) as db: raw=db.execute('SELECT result_summary FROM workflow_steps').fetchone()[0]
        self.assertEqual(raw,MARKER)
        self.assertNotIn('resultado confidencial',path.read_bytes().decode('latin1'))
        self.assertEqual(engine.get(workflow['id'])['steps'][0]['result_summary'],'resultado confidencial')
        self.assertTrue(engine.status()['sensitive_fields_encrypted'])

    def test_legacy_workflow_result_migrates(self):
        path=self.root/'legacy_workflow.sqlite3'
        old=ContinuousOperationEngine(path)
        workflow=old.create('Migração',[{'title':'Etapa'}]); step=workflow['steps'][0]
        old.next_step(workflow['id']); old.confirm_step(workflow['id'],step['id'],True,'old private result')
        secure=ContinuousOperationEngine(path,secure_store=self.secure)
        with sqlite3.connect(path) as db: raw=db.execute('SELECT result_summary FROM workflow_steps').fetchone()[0]
        self.assertEqual(raw,MARKER)
        self.assertEqual(secure.get(workflow['id'])['steps'][0]['result_summary'],'old private result')

if __name__=='__main__': unittest.main()
