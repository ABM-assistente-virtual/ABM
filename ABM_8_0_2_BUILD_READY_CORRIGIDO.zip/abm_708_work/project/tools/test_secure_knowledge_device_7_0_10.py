import sqlite3
import tempfile
from pathlib import Path
from abm_modules.universal_knowledge import UniversalKnowledgeEngine
from abm_modules.device_control import UniversalDeviceControl

class FakeKeystore:
    def __init__(self): self.data={}
    def putString(self,k,v): self.data[str(k)]=str(v)
    def getString(self,k,default=None): return self.data.get(str(k),default)
    def remove(self,k): self.data.pop(str(k),None)

class BridgeResult:
    accepted=True
    reason='ok'
class Bridge:
    def status(self): return {'ready':True}
    def validate(self, action, user_confirmed=False): return BridgeResult()

def test_knowledge_fields_encrypted_and_searchable():
    with tempfile.TemporaryDirectory() as d:
        path=Path(d)/'k.sqlite3'; store=FakeKeystore(); engine=UniversalKnowledgeEngine(path,store)
        result=engine.add_fact('ABM','objetivo','assistente digital','user',consent=True)
        row=sqlite3.connect(path).execute('select subject,relation,object,source from facts').fetchone()
        assert row == ('@abm-keystore-v1',)*4
        assert engine.search('assistente')['facts'][0]['object']=='assistente digital'
        assert engine.related('ABM')['facts'][0]['relation']=='objetivo'
        assert engine.status()['encrypted_at_rest'] is True
        assert engine.forget_source('user',consent=True)['deleted']==1
        assert 'abm.knowledge.v1.fact.'+str(result['fact_id']) not in store.data

def test_knowledge_migrates_legacy_plaintext():
    with tempfile.TemporaryDirectory() as d:
        path=Path(d)/'k.sqlite3'
        db=sqlite3.connect(path); db.execute('CREATE TABLE facts(id INTEGER PRIMARY KEY AUTOINCREMENT,subject TEXT NOT NULL,relation TEXT NOT NULL,object TEXT NOT NULL,source TEXT NOT NULL,confidence REAL NOT NULL,consent INTEGER NOT NULL,created_at REAL NOT NULL,UNIQUE(subject,relation,object,source))'); db.execute("INSERT INTO facts(subject,relation,object,source,confidence,consent,created_at) VALUES('nome','é','valor','user',1,1,1)"); db.commit(); db.close()
        store=FakeKeystore(); engine=UniversalKnowledgeEngine(path,store)
        raw=sqlite3.connect(path).execute('select subject from facts').fetchone()[0]
        assert raw=='@abm-keystore-v1'
        assert engine.search('valor')['facts'][0]['subject']=='nome'

def test_device_control_detail_encrypted():
    with tempfile.TemporaryDirectory() as d:
        path=Path(d)/'d.sqlite3'; store=FakeKeystore(); engine=UniversalDeviceControl(path,Bridge(),store)
        result=engine.prepare('back')
        raw=sqlite3.connect(path).execute('select detail from device_tickets').fetchone()[0]
        assert raw=='@abm-keystore-v1'
        assert 'abm.device_control.v1.ticket.'+result['ticket'] in store.data
        assert engine.status()['encrypted_at_rest'] is True
        assert engine.cancel(result['ticket'])['cancelled'] is True
        assert 'abm.device_control.v1.ticket.'+result['ticket'] not in store.data
