import sqlite3, tempfile, unittest, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.self_recovery import SelfRecoveryEngine
from abm_modules.universal_interaction import UniversalInteractionEngine
from abm_modules.secure_fields import MARKER

class FakeSecureStore:
    def __init__(self): self.data={}
    def putString(self,k,v): self.data[k]=v
    def getString(self,k,d=None): return self.data.get(k,d)
    def remove(self,k): self.data.pop(k,None)

class FakeTools:
    def __init__(self):
        self.pending={'exec-1':{'execution_id':'exec-1','status':'failed','tool':'abm.read_note','platform':'local','target_outcome':'user_reported_failure','android_adapter_detail':'erro confidencial','arguments':{}}}

class SecureRecoveryInteractionTests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name); self.secure=FakeSecureStore()
    def tearDown(self): self.tmp.cleanup()

    def test_recovery_event_detail_encrypted_and_readable(self):
        path=self.root/'recovery.sqlite3'
        engine=SelfRecoveryEngine(FakeTools(),path,secure_store=self.secure)
        engine.diagnose('exec-1')
        with sqlite3.connect(path) as db: row=db.execute('SELECT detail FROM recovery_events').fetchone()[0]
        self.assertEqual(row,MARKER)
        events=engine.events('exec-1')['events']
        self.assertEqual(events[0]['detail'],'execution_failure')
        self.assertTrue(engine.status()['sensitive_fields_encrypted'])

    def test_legacy_recovery_detail_migrates(self):
        path=self.root/'legacy_recovery.sqlite3'
        old=SelfRecoveryEngine(FakeTools(),path)
        old._record('exec-1','old_event','private old detail')
        secure=SelfRecoveryEngine(FakeTools(),path,secure_store=self.secure)
        with sqlite3.connect(path) as db: row=db.execute('SELECT detail FROM recovery_events').fetchone()[0]
        self.assertEqual(row,MARKER)
        self.assertEqual(secure.events('exec-1')['events'][0]['detail'],'private old detail')

    def test_interaction_content_encrypted_and_readable(self):
        path=self.root/'interaction.sqlite3'; engine=UniversalInteractionEngine(path,self.secure)
        accepted=engine.submit('text','conteudo pessoal confidencial','user',consent=True)
        self.assertEqual(accepted['status'],'accepted')
        with sqlite3.connect(path) as db: row=db.execute('SELECT content,source,dedupe_key FROM interaction_events').fetchone()
        self.assertEqual(row[0],MARKER); self.assertEqual(row[1],MARKER)
        self.assertNotIn('conteudo pessoal confidencial',path.read_bytes().decode('latin1'))
        event=engine.next_event()['event']
        self.assertEqual(event['content'],'conteudo pessoal confidencial')
        self.assertEqual(event['source'],'user')
        self.assertTrue(engine.status()['sensitive_fields_encrypted'])

    def test_legacy_interaction_content_migrates(self):
        path=self.root/'legacy_interaction.sqlite3'
        old=UniversalInteractionEngine(path)
        old.submit('text','legacy private text','user',consent=True)
        secure=UniversalInteractionEngine(path,self.secure)
        with sqlite3.connect(path) as db: row=db.execute('SELECT content,source FROM interaction_events').fetchone()
        self.assertEqual(row,(MARKER,MARKER))
        self.assertEqual(secure.next_event()['event']['content'],'legacy private text')

if __name__=='__main__': unittest.main()
