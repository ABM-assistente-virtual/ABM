import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PYDIR=ROOT/"app/src/main/python"
sys.path.insert(0,str(PYDIR))
from abm_modules.tool_connector import UniversalToolConnector
from abm_modules.tool_engine import UniversalToolEngine
from abm_modules.self_recovery import SelfRecoveryEngine

checks=[]
def ck(n,v):
    if not v: raise AssertionError(n)
    checks.append(n)
with tempfile.TemporaryDirectory() as td:
    connector=UniversalToolConnector(td); engine=UniversalToolEngine(connector,history_path=Path(td)/"exec.sqlite")
    recovery=SelfRecoveryEngine(engine,Path(td)/"recovery.sqlite")
    # Falha simulada controlada, sem reexecutar.
    p=engine.prepare("abm.read_note",{"note_name":"nao_existe.txt"},persist_context=True)
    eid=p["plan"]["execution_id"]
    result=engine.execute(eid)
    ck("failed_local_operation",result["status"]=="rejected")
    diag=recovery.diagnose(eid)
    ck("failure_diagnosed",diag["category"]=="execution_failure")
    ck("read_only_policy_detected",diag["retry_policy"]=="read_only_reprepare_allowed")
    ck("no_automatic_retry",diag["automatic_retry"] is False)
    pending=recovery.prepare_recovery(eid)
    ck("confirmation_required",pending["status"]=="confirmation_required")
    prepared=recovery.prepare_recovery(eid,user_confirmed=True)
    ck("new_plan_prepared_only",prepared["status"]=="recovery_plan_prepared" and prepared["execution_performed"] is False)
    ck("original_not_reexecuted",engine.get_execution_status(eid)["status"]=="rejected")
    # Operação Android aceite mas sem confirmação de resultado: não repetir.
    p2=engine.prepare("android.open_app",{"request":"abre calculadora"},persist_context=True); eid2=p2["plan"]["execution_id"]
    engine.execute(eid2); engine.record_android_result(eid2,True,"Intent iniciado")
    d2=recovery.diagnose(eid2)
    ck("android_unverified_detected",d2["category"]=="external_result_unverified")
    blocked=recovery.prepare_recovery(eid2,user_confirmed=True)
    ck("android_not_repeated",blocked["status"]=="manual_review_required")
    # Criação de nota não idempotente exige revisão, não repetição.
    p3=engine.prepare("abm.create_note",{"request":"nota"},persist_context=True); eid3=p3["plan"]["execution_id"]
    engine.execute(eid3)
    d3=recovery.diagnose(eid3)
    ck("success_needs_no_recovery",d3["category"]=="no_recovery_needed")
    ck("recovery_events_persist",len(recovery.events(eid)["events"])>=2)
    ck("status_disables_automatic_retry",recovery.status()["automatic_retry"] is False)
print(json.dumps({"status":"PASSOU","version":"5.1.0","checks":len(checks),"names":checks},ensure_ascii=False,indent=2))
