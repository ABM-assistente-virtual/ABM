import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PYDIR=ROOT/'app'/'src'/'main'/'python'
sys.path.insert(0,str(PYDIR))
import abm_android
with tempfile.TemporaryDirectory() as tmp:
    message=abm_android.initialize(tmp)
    state=json.loads(abm_android.command('/abm sistema'))
    assert state['version']=='8.0.0'
    assert state['departments_total']==15
    assert state['departments_available']==15, state['departments_missing']
    assert len(state['departments'])==15
    assert state['safety']['external_actions_auto_executed'] is False
    report=json.loads(abm_android.command('/unificacao validar'))
    assert report['passed'], report
    assert json.loads(abm_android.command('/abm departamentos'))['departments_total']==15
    assert 'não' not in message.lower() or 'não' in message.lower() # smoke: initialization returned text
print(json.dumps({'status':'PASSOU','checks':7},ensure_ascii=False))
