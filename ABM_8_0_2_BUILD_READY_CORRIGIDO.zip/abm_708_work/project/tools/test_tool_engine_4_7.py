import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'app/src/main/python'))
from abm_modules.tool_connector import UniversalToolConnector
from abm_modules.tool_engine import UniversalToolEngine
from abm_modules.security import Security

checks=[]
def check(name, condition):
    if not condition: raise AssertionError(name)
    checks.append(name)

with tempfile.TemporaryDirectory() as td:
    connector=UniversalToolConnector(td)
    security=Security()
    engine=UniversalToolEngine(connector, security)
    found=engine.discover()
    check('discover_only_registered_tools', found['count']==len(connector.capabilities()))
    check('discovery_never_executes', found['executes_nothing'] is True)
    check('unknown_tool_not_discovered', engine.discover('not-a-tool')['count']==0)
    check('search_android_tools', engine.discover('android')['count']>=8)
    check('unknown_tool_rejected', engine.prepare('system.run_shell', {})['status']=='not_found')
    check('arguments_must_be_object', engine.prepare('android.open_app', [])['status']=='invalid_arguments')
    check('required_arguments_validated', engine.prepare('android.open_url', {})['status']=='invalid_arguments')
    check('unknown_arguments_rejected', engine.prepare('android.open_app', {'request':'abre X','shell':'rm'})['status']=='invalid_arguments')
    note=engine.prepare('abm.create_note', {'request':'teste seguro'})
    check('local_tool_ready_without_confirmation', note['status']=='ready')
    nr=engine.execute(note['plan']['execution_id'])
    check('local_tool_executes', nr['status']=='completed' and nr['external_execution'] is False)
    listed=engine.prepare('abm.list_notes', {})
    lr=engine.execute(listed['plan']['execution_id'])
    check('local_note_list_executes', lr['status']=='completed' and lr['result']['count']==1)
    app=engine.prepare('android.open_app', {'request':'abre calculadora'})
    check('safe_android_tool_ready', app['status']=='ready')
    ar=engine.execute(app['plan']['execution_id'])
    check('android_is_only_dispatched', ar['status']=='dispatched' and ar['external_execution'] is True and ar['result']['dispatch']=='android')
    camera=engine.prepare('android.open_camera', {})
    check('sensitive_tool_waits_confirmation', camera['status']=='awaiting_confirmation')
    blocked=engine.execute(camera['plan']['execution_id'])
    check('sensitive_tool_confirmation_gate', blocked['status']=='confirmation_required')
    cr=engine.execute(camera['plan']['execution_id'], confirmed=True)
    check('confirmed_camera_dispatched', cr['status']=='dispatched' and cr['external_execution'] is True)
    dial=engine.prepare('android.dial', {'request':'liga para 123'})
    check('high_risk_waits_confirmation', dial['status']=='awaiting_confirmation')
    no_perm=engine.execute(dial['plan']['execution_id'], confirmed=True)
    check('high_risk_permission_gate', no_perm['status']=='blocked')
    security.set_permission('phone', True)
    yes=engine.execute(dial['plan']['execution_id'], confirmed=True)
    check('high_risk_authorized_dispatch', yes['status']=='dispatched')
    duplicate=engine.execute(dial['plan']['execution_id'], confirmed=True)
    check('duplicate_execution_blocked', duplicate['status']=='already_executed')
    missing=engine.execute('missing-id')
    check('unknown_execution_id_safe', missing['status']=='not_found')
    status=engine.status()
    check('status_reports_no_auto_execution', status['auto_execution'] is False and status['unknown_code_imports'] is False)
    check('audit_records_operations', status['audit_events']>=8)

print(json.dumps({'status':'PASSOU','checks':len(checks),'names':checks,'android_actions':'dispatch_only'} ,ensure_ascii=False,indent=2))
