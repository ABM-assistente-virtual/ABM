#!/usr/bin/env python3
"""Testes do barramento de departamentos ABM 4.1.0."""
import json, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'app' / 'src' / 'main' / 'python'))
import abm_android
from abm_modules.unified_system import DEPARTMENTS

with tempfile.TemporaryDirectory() as tmp:
    abm_android.initialize(tmp)
    # Todos os 15 departamentos respondem ao contrato comum de estado.
    for dep in DEPARTMENTS:
        result = json.loads(abm_android.dispatch_department(dep['id'], 'status'))
        assert result['department'] == dep['id']
        assert result['status'] in {'catalogued', 'not_deployed', 'bridge_required'}
    # Testa chamadas reais aos módulos locais.
    brain = json.loads(abm_android.dispatch_department('brain', 'think', json.dumps({'text':'Olá ABM'})))
    assert brain['status'] == 'ok' and 'response' in brain['result']
    ears = json.loads(abm_android.dispatch_department('ears', 'transcript', json.dumps({'text':'  ABM   abre   definições '})))
    assert ears['result']['wake_word'] is True and ears['result']['word_count'] == 3
    voice = json.loads(abm_android.dispatch_department('voice', 'prepare', json.dumps({'text':'Teste de voz'})))
    assert voice['result']['requires_android_tts'] is True
    body = json.loads(abm_android.dispatch_department('body', 'plan', json.dumps({'text':'Abre o WhatsApp'})))
    assert body['result']['action'] == 'open_whatsapp'
    social = json.loads(abm_android.dispatch_department('social', 'analyze_text', json.dumps({'text':'Olá'})))
    assert social['status'] == 'ok'
    security = json.loads(abm_android.dispatch_department('security', 'authorize', json.dumps({'action':'send_message'})))
    assert security['result']['allowed'] is False
    accessibility = json.loads(abm_android.dispatch_department('accessibility', 'start_scan'))
    assert accessibility['status'] == 'needs_android_bridge'
    cloud = json.loads(abm_android.dispatch_department('cloud', 'status'))
    assert cloud['result']['configured'] is False
    memory = json.loads(abm_android.dispatch_department('memory', 'remember', json.dumps({'text':'preferência de teste','consent':True})))
    assert memory['result']['stored'] is True
    dev = json.loads(abm_android.dispatch_department('developer', 'register_capability', json.dumps({'name':'test.echo','description':'Teste'})))
    assert dev['result']['registered'] == 'test.echo'
    status = json.loads(abm_android.status())
    assert status['unified_system']['version'] == '4.7.0'
    assert status['unified_system']['dispatch_count'] == 25
print(json.dumps({'status':'PASSOU','checks':31,'departments_routable':15,
                  'local_module_calls':10,'android_cloud_boundaries':'explicit'}, ensure_ascii=False))
