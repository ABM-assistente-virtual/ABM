#!/usr/bin/env python3
"""Testes da coordenação central ABM 4.2.0."""
import json, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'app' / 'src' / 'main' / 'python'))
import abm_android

with tempfile.TemporaryDirectory() as tmp:
    abm_android.initialize(tmp)
    # Fluxo por texto: BRAIN, BODY, SECURITY e VOICE trabalham no mesmo pedido.
    result = json.loads(abm_android.coordinate_request('Abre o WhatsApp'))
    assert result['status'] == 'planned'
    assert result['action']['action'] == 'open_whatsapp'
    assert result['execution_performed'] is False
    assert [x['department'] for x in result['trace']] == ['brain','body','security','voice']
    assert result['voice']['requires_android_tts'] is True

    # Fluxo de voz acrescenta EARS antes do BRAIN.
    voice = json.loads(abm_android.coordinate_request('  ABM   abre   YouTube ', source='voice'))
    assert voice['request'] == 'ABM abre YouTube'
    assert voice['action']['action'] == 'open_youtube'
    assert [x['department'] for x in voice['trace']][:2] == ['ears','brain']

    # Ações sensíveis ficam bloqueadas sem confirmação e permissão.
    call = json.loads(abm_android.coordinate_request('Liga para 841234567'))
    assert call['authorization']['allowed'] is False
    assert call['execution_performed'] is False
    # Mesmo com confirmação, continua a exigir permissão explícita.
    call2 = json.loads(abm_android.coordinate_request('Liga para 841234567', confirmed=True))
    assert call2['authorization']['allowed'] is False

    # Desbloqueio nunca é feito pelo ABM.
    unlock = json.loads(abm_android.coordinate_request('Desbloqueia o telefone', confirmed=True))
    assert unlock['authorization']['allowed'] is False

    # Comando sem ação Android permanece conversa.
    chat = json.loads(abm_android.coordinate_request('Olá, como estás?'))
    assert chat['status'] == 'conversation'
    assert chat['action']['action'] is None

    # Entrada vazia e origem inválida são rejeitadas.
    for args in [('', 'text'), ('Olá', 'camera')]:
        try:
            abm_android.coordinate_request(args[0], source=args[1])
        except ValueError:
            pass
        else:
            raise AssertionError('Entrada inválida aceite: ' + repr(args))

print(json.dumps({'status':'PASSOU','checks':14,
                  'pipeline':['EARS','BRAIN','BODY','SECURITY','VOICE'],
                  'android_execution':'not_performed_by_python_core'}, ensure_ascii=False))
