#!/usr/bin/env python3
"""Testes da camada de unificação ABM 4.0."""
import json, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
PYDIR = ROOT / 'app' / 'src' / 'main' / 'python'
sys.path.insert(0, str(PYDIR))
import abm_android
from abm_modules.unified_system import DEPARTMENTS, UnifiedABM

assert len(DEPARTMENTS) == 15
assert len({d['id'] for d in DEPARTMENTS}) == 15
assert {d['status'] for d in DEPARTMENTS} <= {'integrated', 'prototype', 'planned'}
with tempfile.TemporaryDirectory() as tmp:
    ready = abm_android.initialize(tmp)
    assert 'inicializados' in ready.lower()
    listing = json.loads(abm_android.command('/departamentos'))
    assert listing['total'] == 15
    assert listing['counts']['integrated'] == 3
    assert listing['counts']['prototype'] == 12
    plan = json.loads(abm_android.process_task('Prepara um plano para aprender Python'))
    assert plan['orchestrator'] == 'ABM_UNIFIED_4.7.0'
    assert plan['department_catalog'] == '15_departments'
    state = json.loads(abm_android.status())
    assert state['unified_system']['orchestrator'] == 'ready'
    assert state['departments']['total'] == 15
    assert 'unified' in state['modules']
print(json.dumps({'status':'PASSOU','checks':10,'departments':15,'orchestrator':'ABM_UNIFIED_4.7.0'}, ensure_ascii=False))
