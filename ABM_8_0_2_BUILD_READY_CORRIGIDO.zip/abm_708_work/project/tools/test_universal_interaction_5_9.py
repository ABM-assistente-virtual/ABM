import tempfile, unittest
from pathlib import Path
from app.src.main.python.abm_modules.universal_interaction import UniversalInteractionEngine

class InteractionTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/'i.sqlite'; self.e=UniversalInteractionEngine(self.db)
 def tearDown(self): self.tmp.cleanup()
 def test_consent(self): self.assertEqual(self.e.submit('voice','abrir app')['status'],'consent_required')
 def test_modalities(self):
  for m in self.e.MODALITIES: self.assertEqual(self.e.submit(m,'pedido',consent=True)['status'],'accepted')
 def test_invalid(self):
  with self.assertRaises(ValueError): self.e.submit('telepathy','x',consent=True)
 def test_empty_content(self):
  with self.assertRaises(ValueError): self.e.submit('text',' ',consent=True)
 def test_duplicate(self):
  a=self.e.submit('text','ola',consent=True); b=self.e.submit('text','ola',consent=True)
  self.assertEqual(b['status'],'duplicate_ignored')
 def test_priority(self):
  self.e.submit('text','texto',consent=True); self.e.submit('switch','switch',consent=True)
  self.assertEqual(self.e.next_event()['event']['modality'],'switch')
 def test_ack(self):
  a=self.e.submit('aac','sim',consent=True); self.e.next_event(); self.assertTrue(self.e.acknowledge(a['event_id'])['changed'])
 def test_persistence(self):
  self.e.submit('braille','oi',consent=True); e2=UniversalInteractionEngine(self.db)
  self.assertEqual(e2.status()['events']['pending'],1)
 def test_no_raw_media(self): self.assertFalse(self.e.status()['raw_audio_video_images_saved'])
 def test_no_capture(self): self.assertFalse(self.e.status()['sensor_capture'])
 def test_no_external_execution(self): self.assertFalse(self.e.status()['automatic_external_actions'])
 def test_confidence_clamped(self):
  a=self.e.submit('gaze','selecionar',confidence=3,consent=True); self.assertEqual(a['confidence'],1)
if __name__=='__main__': unittest.main()
