import tempfile, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/src/main/python'))
from abm_modules.universal_knowledge import UniversalKnowledgeEngine
class KnowledgeTests(unittest.TestCase):
 def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/'k.db'; self.e=UniversalKnowledgeEngine(self.db)
 def tearDown(self): self.tmp.cleanup()
 def test_consent_required(self): self.assertEqual(self.e.add_fact('ABM','é','IA')['status'],'consent_required')
 def test_store(self): self.assertTrue(self.e.add_fact('ABM','é','assistente','user',consent=True)['stored'])
 def test_search(self):
  self.e.add_fact('ABM','é','assistente digital',consent=True); self.assertEqual(len(self.e.search('assistente')['facts']),1)
 def test_no_match(self): self.assertEqual(self.e.search('oceano')['status'],'no_match')
 def test_related_subject(self):
  self.e.add_fact('ABM','é','assistente',consent=True); self.assertEqual(len(self.e.related('ABM')['facts']),1)
 def test_related_object(self):
  self.e.add_fact('ABM','usa','SQLite',consent=True); self.assertEqual(len(self.e.related('SQLite')['facts']),1)
 def test_persistence(self):
  self.e.add_fact('ABM','é','sistema',consent=True); self.assertEqual(UniversalKnowledgeEngine(self.db).status()['facts'],1)
 def test_delete_needs_consent(self):
  self.e.add_fact('ABM','é','sistema','fonte',consent=True); self.assertEqual(self.e.forget_source('fonte')['deleted'],0)
 def test_delete_source(self):
  self.e.add_fact('ABM','é','sistema','fonte',consent=True); self.assertEqual(self.e.forget_source('fonte',consent=True)['deleted'],1)
 def test_confidence_bounds(self):
  self.e.add_fact('ABM','é','sistema',confidence=9,consent=True); self.assertEqual(self.e.search('sistema')['facts'][0]['confidence'],1.0)
 def test_no_execution(self):
  self.e.add_fact('ABM','é','sistema',consent=True); self.assertFalse(self.e.search('sistema')['execution_performed'])
 def test_status(self): self.assertEqual(self.e.status()['version'],'7.0.10')
if __name__=='__main__': unittest.main(verbosity=2)
