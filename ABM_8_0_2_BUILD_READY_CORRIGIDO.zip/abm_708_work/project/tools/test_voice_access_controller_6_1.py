import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app/src/main/python'))
from abm_modules.voice_access_controller import VoiceAccessibilityController
class VoiceAccessTests(unittest.TestCase):
 def setUp(self): self.c=VoiceAccessibilityController()
 def test_back(self): self.assertEqual(self.c.interpret('Volta').action, 'back')
 def test_home_alias(self): self.assertEqual(self.c.interpret('vai para casa').action, 'home')
 def test_notifications(self): self.assertEqual(self.c.interpret('abre notificações').action, 'notifications')
 def test_quick_settings(self): self.assertEqual(self.c.interpret('abre definições rápidas').action, 'quick_settings')
 def test_cursor(self): self.assertEqual(self.c.interpret('ativa cursor').action, 'cursor_on')
 def test_scan(self): self.assertEqual(self.c.interpret('inicia varrimento').action, 'scan_start')
 def test_next(self): self.assertEqual(self.c.interpret('próximo elemento').action, 'scan_next')
 def test_select_requires_confirmation(self): self.assertTrue(self.c.interpret('seleciona elemento').requires_confirmation)
 def test_low_confidence_rejected(self): self.assertIsNone(self.c.interpret('volta', .2))
 def test_unknown_rejected(self): self.assertIsNone(self.c.interpret('apaga tudo'))
 def test_empty_rejected(self): self.assertIsNone(self.c.interpret(''))
 def test_no_audio_capture_or_execution(self):
  s=self.c.status(); self.assertFalse(s['captures_audio']); self.assertFalse(s['executes_android_actions'])
if __name__ == '__main__': unittest.main()
