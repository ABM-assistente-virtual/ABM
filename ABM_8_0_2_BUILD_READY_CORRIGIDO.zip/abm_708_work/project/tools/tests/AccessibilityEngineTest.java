import com.forla.abm.ABMAccessibilityEngine;
public class AccessibilityEngineTest {
  static void check(String phrase, ABMAccessibilityEngine.Action expected) {
    ABMAccessibilityEngine.Action actual = ABMAccessibilityEngine.interpret(phrase).action;
    if (actual != expected) throw new AssertionError(phrase + " -> " + actual + ", expected " + expected);
  }
  public static void main(String[] args) {
    check("Volta", ABMAccessibilityEngine.Action.BACK);
    check("VAI PARA INICIO", ABMAccessibilityEngine.Action.HOME);
    check("abre notificacoes", ABMAccessibilityEngine.Action.NOTIFICATIONS);
    check("Abre definicoes rapidas", ABMAccessibilityEngine.Action.QUICK_SETTINGS);
    check("abre o WhatsApp", ABMAccessibilityEngine.Action.OPEN_WHATSAPP);
    check("le a ultima resposta", ABMAccessibilityEngine.Action.READ_LAST_REPLY);
    check("para de falar", ABMAccessibilityEngine.Action.STOP_SPEAKING);
    check("comando que nao existe", ABMAccessibilityEngine.Action.NONE);
    System.out.println("PASSOU: 8 testes do interpretador de acessibilidade.");
  }
}
