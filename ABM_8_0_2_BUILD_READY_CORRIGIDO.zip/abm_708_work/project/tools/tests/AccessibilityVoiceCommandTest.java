package com.forla.abm;

public final class AccessibilityVoiceCommandTest {
    private static int passed = 0;
    private static void check(String phrase, ABMAccessibilityEngine.Action expected) {
        ABMAccessibilityEngine.Action actual = ABMAccessibilityEngine.interpret(phrase).action;
        if (actual != expected) throw new AssertionError(phrase + " expected=" + expected + " actual=" + actual);
        passed++;
    }
    public static void main(String[] args) {
        check("ativa cursor", ABMAccessibilityEngine.Action.CURSOR_ON);
        check("liga cursor", ABMAccessibilityEngine.Action.CURSOR_ON);
        check("desativa o cursor", ABMAccessibilityEngine.Action.CURSOR_OFF);
        check("esconde cursor", ABMAccessibilityEngine.Action.CURSOR_OFF);
        check("seleciona", ABMAccessibilityEngine.Action.SELECT);
        check("pressiona enter", ABMAccessibilityEngine.Action.SELECT);
        check("volta", ABMAccessibilityEngine.Action.BACK);
        check("vai para início", ABMAccessibilityEngine.Action.HOME);
        check("mostra notificações", ABMAccessibilityEngine.Action.NOTIFICATIONS);
        check("abre as definições", ABMAccessibilityEngine.Action.OPEN_SETTINGS);
        check("abre o YouTube", ABMAccessibilityEngine.Action.OPEN_YOUTUBE);
        check("uma frase desconhecida", ABMAccessibilityEngine.Action.NONE);
        System.out.println("PASSOU_TOTALMENTE: " + passed + " testes de interpretação de voz.");
    }
}
