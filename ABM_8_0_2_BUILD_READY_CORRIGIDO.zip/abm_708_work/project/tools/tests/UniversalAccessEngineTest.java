package com.forla.abm;

public final class UniversalAccessEngineTest {
    public static void main(String[] args) {
        check(ABMUniversalAccessEngine.profiles().length >= 8, "perfis adaptativos disponíveis");
        check(ABMUniversalAccessEngine.isValidProfile("NON_SPEAKING"), "perfil sem fala válido");
        check(!ABMUniversalAccessEngine.isValidProfile("UNKNOWN"), "perfil desconhecido rejeitado");
        check(ABMUniversalAccessEngine.phrases().size() >= 10, "frases CAA disponíveis");
        boolean emergency = false;
        for (ABMUniversalAccessEngine.Phrase p : ABMUniversalAccessEngine.phrases())
            if (p.label.equals("Emergência") && p.spoken.toLowerCase().contains("emergência")) emergency = true;
        check(emergency, "frase de emergência presente");
        System.out.println("UNIVERSAL_ACCESS_ENGINE: 5/5 PASSOU");
    }
    private static void check(boolean ok, String name) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASSOU: " + name);
    }
}
