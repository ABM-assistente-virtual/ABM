#!/usr/bin/env python3
"""Run ABM Global cloud source checks and unit/contract tests."""
import json, os, subprocess, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]
cloud = root / 'cloud'
env = os.environ.copy(); env['PYTHONPATH'] = str(cloud)
compile_run = subprocess.run([sys.executable, '-m', 'compileall', '-q', 'abm_cloud', 'tests', 'loadtest'], cwd=cloud, env=env, capture_output=True, text=True)
test_run = subprocess.run([sys.executable, '-m', 'pytest', '-q'], cwd=cloud, env=env, capture_output=True, text=True)
report = {
    'version': '2.1.0',
    'python_compilation': 'PASSOU' if compile_run.returncode == 0 else 'FALHOU',
    'cloud_tests': 'PASSOU' if test_run.returncode == 0 else 'FALHOU',
    'test_output': (test_run.stdout + test_run.stderr).strip(),
    'limitations': [
        'Redis/Redis Cluster integration tests require a live Redis deployment and were not run here.',
        'PostgreSQL integration and migrations were not run against a live database.',
        'Kubernetes manifests were not applied to a cluster.',
        'No load test of 30 million users was performed.',
        'LLM and Tavily integration require server-side credentials and were unit-tested with mocked providers only.',
        'Generated web app code is returned as source; compilation, security review and publication are not automated.',
        'APK was not compiled because Android SDK/Gradle are unavailable.'
    ]
}
path = cloud / 'TEST_REPORT_2_1_0.json'
path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
sys.exit(0 if compile_run.returncode == 0 and test_run.returncode == 0 else 1)
