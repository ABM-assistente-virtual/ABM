#!/usr/bin/env python3
"""Validação local do núcleo Python e da estrutura do projeto Android."""
from pathlib import Path
import json
import py_compile
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
PYDIR = ROOT / "app" / "src" / "main" / "python"
CORE = PYDIR / "ABM_UNIFICADO_5_2.py"
BRIDGE = PYDIR / "abm_android.py"

for file in list(PYDIR.rglob("*.py")):
    py_compile.compile(str(file), doraise=True)

run = subprocess.run(
    [sys.executable, str(CORE), "--all-tests"],
    cwd=str(PYDIR), text=True, capture_output=True, check=True,
)
results = json.loads(run.stdout)
expected = {"base_34", "base_41", "abm_50", "abm_51", "abm_52"}
assert set(results) == expected, results.keys()
for name, result in results.items():
    assert result.get("status") == "PASSOU_TOTALMENTE", (name, result)

# Testa os oito módulos especializados.
module_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_modules.py")],
                             cwd=str(ROOT), text=True, capture_output=True, check=True)
unified_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_unified_system.py")],
                              cwd=str(ROOT), text=True, capture_output=True, check=True)
learning_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_adaptive_learning_4_4.py")],
                               cwd=str(ROOT), text=True, capture_output=True, check=True)
brain_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_brain_advanced_4_6.py")],
                             cwd=str(ROOT), text=True, capture_output=True, check=True)
tool_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_tool_engine_4_7.py")],
                            cwd=str(ROOT), text=True, capture_output=True, check=True)
persistent_execution_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_persistent_execution_5_0.py")],
                                         cwd=str(ROOT), text=True, capture_output=True, check=True)
recovery_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_self_recovery_5_1.py")],
                              cwd=str(ROOT), text=True, capture_output=True, check=True)
decision_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_intelligent_decision_5_3.py")],
                              cwd=str(ROOT), text=True, capture_output=True, check=True)
module_results = json.loads(module_test.stdout.replace("'", '"'))
assert module_results["status"] == "PASSOU"

# Exercita a ponte tal como a aplicação Android a invoca.
sys.path.insert(0, str(PYDIR))
import abm_android
with tempfile.TemporaryDirectory() as tmp:
    ready = abm_android.initialize(tmp)
    assert "inicializado" in ready.lower()
    assert "5.2" in abm_android.command("/estado")
    assert "Elísio" in abm_android.command("/nome Elísio")
    abm_android.command("/conhecer Ana | amiga")
    assert "moderado" in abm_android.command("/social és burro")
    assert "Objetivo registado" in abm_android.command("/objetivo estudar Android")
    assert "open_youtube" in abm_android.plan_action("abre o YouTube")
    chat_answer = abm_android.command("Olá ABM, vamos testar a conversa.")
    assert isinstance(chat_answer, str) and chat_answer
    image_note = abm_android.command("/plano abre os meus ficheiros")
    assert "open_file_picker" in image_note
    task_answer = abm_android.command("Quero organizar os meus estudos e criar um plano semanal")
    assert "Objetivo:" in task_answer and "Etapas:" in task_answer
    assert "ABM Execution Engine" in abm_android.command("/capacidades")
    decision_status = json.loads(abm_android.command("/decisao estado"))
    assert decision_status["version"] == "5.3.0" and decision_status["executes_tools"] is False
    decision_result = json.loads(abm_android.command("/decidir Abre o YouTube"))
    assert decision_result["execution_performed"] is False and decision_result["tool_prepared"] is False
    advanced_plan = json.loads(abm_android.advanced_plan("Abre o WhatsApp"))
    assert advanced_plan["orchestrator"] == "ABM_UNIFIED_4.7.0"
    assert advanced_plan["execution_performed"] is False
    advanced_command = abm_android.command("/plano-avancado Abre a câmara")
    assert "ABM_UNIFIED_4.7.0" in advanced_command
    tool_list = json.loads(abm_android.command("/ferramentas"))
    assert tool_list["count"] >= 10 and tool_list["executes_nothing"] is True
    cmd_prepared = json.loads(abm_android.command('/ferramenta preparar abm.create_note {"request":"nota por comando"}'))
    assert cmd_prepared["status"] == "ready"
    cmd_executed = json.loads(abm_android.command('/ferramenta executar ' + cmd_prepared["plan"]["execution_id"]))
    assert cmd_executed["status"] == "completed"
    assert json.loads(abm_android.discover_tools("android"))["count"] >= 8
    prepared_tool = json.loads(abm_android.prepare_tool("abm.create_note", json.dumps({"request":"nota do validador"})))
    assert prepared_tool["status"] == "ready"
    persisted_tool = json.loads(abm_android.prepare_tool("abm.create_note", json.dumps({"request":"nota persistente"}), True))
    assert persisted_tool["status"] == "ready" and "consentimento explícito" in persisted_tool["persistence"]
    assert json.loads(abm_android.list_execution_history())["persistent"] is True
    tool_result = json.loads(abm_android.execute_tool(prepared_tool["plan"]["execution_id"]))
    assert tool_result["status"] == "completed" and tool_result["external_execution"] is False
    task_json = json.loads(abm_android.process_task("Prepara uma pesquisa sobre energia solar"))
    assert task_json["status"] == "planned"
    # Motor de execução: cálculo local seguro e criação de objetivo.
    calc = json.loads(abm_android.process_task("Calcula 12 * (8 + 2)"))
    assert "abm.calculate" in calc["plan"]["capabilities"]
    calc_result = json.loads(abm_android.execute_task(calc["plan"]["id"]))
    assert any(x["capability"] == "abm.calculate" and x["result"].get("result") == 120 for x in calc_result["results"])
    goal_plan = json.loads(abm_android.process_task("Quero organizar os meus estudos e criar um plano semanal"))
    goal_result = json.loads(abm_android.execute_task(goal_plan["plan"]["id"]))
    assert goal_result["status"] in ("completed", "partially_completed")
    assert any(x["capability"] == "abm.create_goal" for x in goal_result["results"])
    # Universal Tool Connector: notas locais e pedidos encaminhados à Activity Android.
    note_plan = json.loads(abm_android.process_task("Cria uma nota com a ideia do projeto ABM"))
    note_result = json.loads(abm_android.execute_task(note_plan["plan"]["id"]))
    note_items = [x for x in note_result["results"] if x["capability"] == "abm.create_note"]
    assert note_items and note_items[0]["result"]["ok"]
    list_plan = json.loads(abm_android.process_task("Mostra as notas guardadas"))
    list_result = json.loads(abm_android.execute_task(list_plan["plan"]["id"]))
    assert any(x["capability"] == "abm.list_notes" for x in list_result["results"])
    android_request = json.loads(abm_android.process_and_execute("Abre a câmara"))
    assert any(x["result"].get("dispatch") == "android" and x["result"].get("action") == "open_camera" for x in android_request["execution"]["results"])
    search_request = json.loads(abm_android.process_and_execute("Pesquisa na internet sobre energia solar"))
    assert any(x["result"].get("action") == "web_search" for x in search_request["execution"]["results"])
    url_request = json.loads(abm_android.process_and_execute("Abre https://example.org no navegador"))
    assert any(x["result"].get("action") == "open_url" for x in url_request["execution"]["results"])
    map_request = json.loads(abm_android.process_and_execute("Mostra no mapa onde fica o mercado central"))
    assert any(x["result"].get("action") == "open_maps" for x in map_request["execution"]["results"])
    saved = abm_android.save()
    assert Path(saved).exists()
    # Verifica que a restauração do cérebro herdado não rebaixa o orquestrador.
    from ABM_UNIFICADO_5_2 import ABMCompanion
    restored = ABMCompanion(total_virtual_neurons=1000, state_path=saved)
    assert restored.load_companion()
    assert restored.version == "5.2", restored.version

manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
main_java = (ROOT / "app/src/main/java/com/forla/abm/MainActivity.java").read_text(encoding="utf-8")
service_java = (ROOT / "app/src/main/java/com/forla/abm/ABMForegroundService.java").read_text(encoding="utf-8")
assert "RECORD_AUDIO" in manifest and "READ_PHONE_STATE" in manifest
assert "startForegroundService" in main_java
assert "ACTION_OPEN_DOCUMENT" in main_java
assert "CALL_STATE_RINGING" in service_java
assert "analyze_image" in main_java and "analyze_wav" in main_java
assert "SpeechRecognizer" in main_java and "toggleContinuousListening" in main_java
assert "handleContinuousTranscript" in main_java and 'lower.indexOf("abm")' in main_java
assert "ImageLabeling" in main_java and "ObjectDetection" in main_java and "FaceDetection" in main_java
assert "MediaMetadataRetriever" in main_java and "REQ_VIDEO_ANALYSIS" in main_java
assert "com.google.mlkit:object-detection" in (ROOT / "app/build.gradle").read_text()
assert "com.google.mlkit:image-labeling" in (ROOT / "app/build.gradle").read_text()
assert "com.google.mlkit:face-detection" in (ROOT / "app/build.gradle").read_text()
assert "ABMForegroundService" in manifest
assert "process_and_execute" in main_java and "dispatchAndroidTool" in main_java
assert "UniversalToolConnector" in (PYDIR / "abm_modules" / "tool_connector.py").read_text(encoding="utf-8")
assert "Perguntar à IA Cloud" in main_java and "Pesquisar com IA" in main_java
assert "/v1/agent/ask" in main_java and "/v1/agent/research" in main_java
assert "open_maps" in main_java and "share_text" in main_java

accessibility_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_accessibility_intelligence_6_2.py")], cwd=str(ROOT), text=True, capture_output=True, check=True)
with tempfile.TemporaryDirectory() as tmp_access:
    import abm_android as _abm_access_bridge
    _abm_access_bridge.initialize(tmp_access)
    assert 'profile_configured' in _abm_access_bridge.command('/acessibilidade inteligente estado')
    profile_result = json.loads(_abm_access_bridge.command('/acessibilidade perfil preferidas=voice,switch | disponiveis=voice,switch | confirmar'))
    assert profile_result['ok'] is True
    recommendation = json.loads(_abm_access_bridge.command('/acessibilidade recomendar navegação'))
    assert recommendation['automatic_switch'] is False

cross_test = subprocess.run([sys.executable, str(ROOT / "tools" / "test_cross_department_5_8.py")], cwd=str(ROOT), text=True, capture_output=True, check=True)

summary = {
    "status": "PASSOU_TOTALMENTE",
    "python_compilation": "PASSOU",
    "core_suites": {k: v["tests_executed"] for k, v in results.items()},
    "bridge_smoke_test": "PASSOU",
    "specialized_modules": module_results,
    "unified_system": json.loads(unified_test.stdout),
    "adaptive_learning": json.loads(learning_test.stdout),
    "brain_advanced": "PASSOU",
    "universal_tool_engine": json.loads(tool_test.stdout),
    "persistent_execution_memory": json.loads(persistent_execution_test.stdout),
    "self_recovery_engine": json.loads(recovery_test.stdout),
    "memory_restore_version_check": "PASSOU",
    "android_structure_checks": "PASSOU",
    "speech_recognizer_and_wake_word_static_checks": "PASSOU",
    "mlkit_vision_and_video_static_checks": "PASSOU",
    "general_task_engine": "PASSOU",
    "execution_engine": "PASSOU",
    "universal_tool_connector": "PASSOU",
    "cross_department_engine": "PASSOU",
    "accessibility_intelligence_6_2": "PASSOU",
    "apk_compilation": "NAO_EXECUTADA_NESTE_AMBIENTE_SEM_ANDROID_SDK",
}
print(json.dumps(summary, ensure_ascii=False, indent=2))
