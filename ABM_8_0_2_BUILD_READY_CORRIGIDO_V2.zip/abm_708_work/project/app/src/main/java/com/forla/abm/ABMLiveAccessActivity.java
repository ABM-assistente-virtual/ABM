package com.forla.abm;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.objects.DetectedObject;
import com.google.mlkit.vision.objects.ObjectDetection;
import com.google.mlkit.vision.objects.ObjectDetector;
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions;
import com.google.android.gms.tasks.Tasks;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Demonstração integrada da câmara frontal para acessibilidade.
 * Usa pose da cabeça para mover um cursor DENTRO desta interface e um fecho
 * ocular prolongado como seleção local. Não controla o ecrã de bloqueio,
 * não autentica identidade e não clica noutras aplicações.
 */
public final class ABMLiveAccessActivity extends ComponentActivity {
    private static final int REQUEST_CAMERA = 280;
    private PreviewView previewView;
    private ABMAdaptiveCursorView cursorView;
    private TextView status;
    private Button calibrateButton;
    private Button dwellButton;
    private boolean dwellEnabled = false;
    private ExecutorService cameraExecutor;
    private FaceDetector detector;
    private ObjectDetector objectDetector;
    private ProcessCameraProvider cameraProvider;
    private final AtomicBoolean frameBusy = new AtomicBoolean(false);
    private final ABMHeadPoseMapper headMapper = new ABMHeadPoseMapper();
    private final ABMAdaptiveInputEngine inputEngine = new ABMAdaptiveInputEngine();
    private ABMEyeGestureEngine eyeEngine;
    private volatile boolean calibrateNextFrame = false;
    private volatile boolean hasFace = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        cameraExecutor = Executors.newSingleThreadExecutor();
        eyeEngine = new ABMEyeGestureEngine(() -> runOnUiThread(() -> {
            status.setText("Seleção ocular reconhecida nesta interface.");
            Toast.makeText(this, "Seleção ocular", Toast.LENGTH_SHORT).show();
        }));
        eyeEngine.configure(0.20f, 900L, 1400L);
        buildScreen();
        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .enableTracking().build();
        detector = FaceDetection.getClient(options);
        ObjectDetectorOptions objectOptions = new ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableMultipleObjects()
            .enableClassification()
            .build();
        objectDetector = ObjectDetection.getClient(objectOptions);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
        }
    }

    private void buildScreen() {
        FrameLayout frame = new FrameLayout(this);
        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        frame.addView(previewView, new FrameLayout.LayoutParams(-1, -1));
        cursorView = new ABMAdaptiveCursorView(this);
        frame.addView(cursorView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(18, 16, 18, 18);
        panel.setBackgroundColor(0xCC101522);
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(16);
        status.setText("Câmara acessível: autoriza a câmara e calibra olhando para o centro.");
        status.setContentDescription("Estado do controlo adaptativo por cabeça e gesto ocular");
        panel.addView(status);
        calibrateButton = new Button(this);
        calibrateButton.setText("Calibrar posição central");
        calibrateButton.setOnClickListener(v -> {
            calibrateNextFrame = true;
            status.setText("Calibração solicitada. Mantém a cabeça na posição central.");
        });
        panel.addView(calibrateButton);
        dwellButton = new Button(this);
        dwellButton.setText("Ativar seleção por permanência: desligada");
        dwellButton.setOnClickListener(v -> {
            dwellEnabled = !dwellEnabled;
            inputEngine.configureHead(1.8f, 0.035f, dwellEnabled, 1400L);
            dwellButton.setText("Seleção por permanência: " + (dwellEnabled ? "ligada" : "desligada"));
            Toast.makeText(this, dwellEnabled ? "Mantém o cursor parado para selecionar" : "Seleção por permanência desligada", Toast.LENGTH_SHORT).show();
        });
        panel.addView(dwellButton);
        Button close = new Button(this);
        close.setText("Fechar câmara acessível");
        close.setOnClickListener(v -> finish());
        panel.addView(close);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        frame.addView(panel, pp);
        setContentView(frame);
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis analysis = new ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetResolution(new android.util.Size(480, 360)).build();
                analysis.setAnalyzer(cameraExecutor, this::analyzeFrame);
                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis);
                status.setText("Câmara ativa. Pressiona Calibrar para definir o centro.");
                sendGlobalCursor(0.5f, 0.5f, false);
            } catch (Exception e) {
                status.setText("Não foi possível iniciar a câmara: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void analyzeFrame(@NonNull ImageProxy proxy) {
        if (!frameBusy.compareAndSet(false, true)) { proxy.close(); return; }
        android.media.Image media = proxy.getImage();
        if (media == null) { frameBusy.set(false); proxy.close(); return; }
        InputImage image = InputImage.fromMediaImage(media, proxy.getImageInfo().getRotationDegrees());
        com.google.android.gms.tasks.Task<List<DetectedObject>> objectTask = objectDetector.process(image);
        objectTask.addOnSuccessListener(cameraExecutor, objects -> {
            if (!objects.isEmpty()) {
                StringBuilder found = new StringBuilder("Objetos detetados: ");
                int count = 0;
                for (DetectedObject object : objects) {
                    if (count++ == 3) break;
                    if (!object.getLabels().isEmpty()) found.append(object.getLabels().get(0).getText());
                    else found.append("objeto");
                    found.append("; ");
                }
                runOnUiThread(() -> status.setText(found.toString()));
            }
        }).addOnFailureListener(cameraExecutor, error ->
            runOnUiThread(() -> status.setText("Falha na deteção de objetos: " + error.getMessage())));
        com.google.android.gms.tasks.Task<List<Face>> faceTask = detector.process(image);
        faceTask.addOnSuccessListener(cameraExecutor, faces -> {
            Face face = largestFace(faces);
            if (face == null) {
                hasFace = false;
                runOnUiThread(() -> status.setText("Nenhum rosto detetado. Ajusta a posição perante a câmara."));
                return;
            }
            hasFace = true;
            if (calibrateNextFrame) {
                headMapper.calibrate(face.getHeadEulerAngleY(), face.getHeadEulerAngleX());
                calibrateNextFrame = false;
                runOnUiThread(() -> status.setText("Calibrado. Move suavemente a cabeça para deslocar o cursor."));
            } else if (headMapper.isCalibrated()) {
                float[] pose = headMapper.map(face.getHeadEulerAngleY(), face.getHeadEulerAngleX());
                if (pose != null) {
                    ABMAdaptiveInputEngine.Event event = inputEngine.updateHeadPose(pose[0], pose[1], System.currentTimeMillis());
                    cursorView.setNormalizedPosition(inputEngine.getCursorX(), inputEngine.getCursorY());
                    sendGlobalCursor(inputEngine.getCursorX(), inputEngine.getCursorY(), false);
                    if (event.type == ABMAdaptiveInputEngine.EventType.DWELL_SELECT && dwellEnabled) {
                        sendGlobalCursor(inputEngine.getCursorX(), inputEngine.getCursorY(), true);
                    }
                }
            }
            Float left = face.getLeftEyeOpenProbability();
            Float right = face.getRightEyeOpenProbability();
            if (left != null && right != null) eyeEngine.process(left, right, System.currentTimeMillis());
        }).addOnFailureListener(cameraExecutor, error -> runOnUiThread(() -> status.setText("Erro na análise facial: " + error.getMessage())));
        // ImageProxy só pode ser libertado quando AMBOS os modelos terminarem de ler o frame.
        Tasks.whenAllComplete(objectTask, faceTask).addOnCompleteListener(cameraExecutor, task -> {
            proxy.close();
            frameBusy.set(false);
        });
    }

    private static Face largestFace(List<Face> faces) {
        Face best = null; int area = -1;
        for (Face f : faces) {
            int a = f.getBoundingBox().width() * f.getBoundingBox().height();
            if (a > area) { area = a; best = f; }
        }
        return best;
    }

    private void sendGlobalCursor(float x, float y, boolean tap) {
        Intent intent = new Intent(ABMAccessibilityService.ACTION_CURSOR);
        intent.putExtra(ABMAccessibilityService.EXTRA_ENABLED, true);
        intent.putExtra(ABMAccessibilityService.EXTRA_X, x);
        intent.putExtra(ABMAccessibilityService.EXTRA_Y, y);
        intent.putExtra("tap", tap);
        sendBroadcast(intent, "com.forla.abm.permission.CONTROL_ACCESSIBILITY");
    }

    private void stopGlobalCursor() {
        Intent intent = new Intent(ABMAccessibilityService.ACTION_CURSOR);
        intent.putExtra(ABMAccessibilityService.EXTRA_ENABLED, false);
        sendBroadcast(intent, "com.forla.abm.permission.CONTROL_ACCESSIBILITY");
    }

    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_CAMERA && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startCamera();
        else status.setText("Permissão da câmara recusada. O telefone continua utilizável sem este modo.");
    }

    @Override protected void onDestroy() {
        stopGlobalCursor();
        if (cameraProvider != null) cameraProvider.unbindAll();
        if (detector != null) detector.close();
        if (objectDetector != null) objectDetector.close();
        if (cameraExecutor != null) cameraExecutor.shutdown();
        super.onDestroy();
    }
}
